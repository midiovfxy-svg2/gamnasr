const sharp = require('sharp'); const fs = require('fs'); const pngToIco = require('png-to-ico');
const SRC = '/home/user/sandbox/release/assets/icon-source.png';
const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
async function mipmaps(RES) {
  for (const [d, k] of Object.entries(dens)) {
    const dir = RES + 'mipmap-' + d + '/'; fs.mkdirSync(dir, { recursive: true });
    const L = Math.round(48 * k), AD = Math.round(108 * k);
    const sq = await sharp(SRC).resize(L, L).png().toBuffer();
    const rrect = Buffer.from(`<svg width="${L}" height="${L}"><rect width="${L}" height="${L}" rx="${Math.round(L * 0.18)}"/></svg>`);
    const circ = Buffer.from(`<svg width="${L}" height="${L}"><circle cx="${L / 2}" cy="${L / 2}" r="${L / 2}"/></svg>`);
    await sharp(sq).composite([{ input: rrect, blend: 'dest-in' }]).png().toFile(dir + 'ic_launcher.png');
    await sharp(sq).composite([{ input: circ, blend: 'dest-in' }]).png().toFile(dir + 'ic_launcher_round.png');
    await sharp(SRC).resize(AD, AD).blur(Math.max(6, AD / 10)).png().toFile(dir + 'ic_launcher_background.png');
    const fgSize = Math.round(AD * 0.72);
    const fg = await sharp(SRC).resize(fgSize, fgSize).png().toBuffer();
    const mask = Buffer.from(`<svg width="${fgSize}" height="${fgSize}"><defs><radialGradient id="g"><stop offset="0.72" stop-color="#fff"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs><rect width="${fgSize}" height="${fgSize}" fill="url(#g)"/></svg>`);
    const fgm = await sharp(fg).ensureAlpha().composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer();
    await sharp({ create: { width: AD, height: AD, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } }).composite([{ input: fgm, gravity: 'center' }]).png().toFile(dir + 'ic_launcher_foreground.png');
  }
  const xml = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@mipmap/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>';
  fs.mkdirSync(RES + 'mipmap-anydpi-v26', { recursive: true });
  fs.writeFileSync(RES + 'mipmap-anydpi-v26/ic_launcher.xml', xml);
  fs.writeFileSync(RES + 'mipmap-anydpi-v26/ic_launcher_round.xml', xml);
}
(async () => {
  const P = '/home/user/sandbox/';
  await sharp(SRC).resize(192, 192).png().toFile(P + 'public/icon-192.png');
  await sharp(SRC).resize(512, 512).png().toFile(P + 'public/icon-512.png');
  await sharp(SRC).resize(1024, 1024).png().toFile('/tmp/work/icon-1024.png');
  const bufs = []; for (const s of [16, 24, 32, 48, 64, 128, 256]) bufs.push(await sharp(SRC).resize(s, s).png().toBuffer());
  fs.writeFileSync('/tmp/work/icon.ico', await pngToIco(bufs));
  await mipmaps('/tmp/work/mobile/android/app/src/main/res/');
  fs.mkdirSync('/tmp/work/box/app/src/main/res', { recursive: true });
  await mipmaps('/tmp/work/box/app/src/main/res/');
  // solid dark splash (Capacitor)
  const solid = await sharp({ create: { width: 8, height: 8, channels: 3, background: '#06091a' } }).png().toBuffer();
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach(e => { const p = d + e.name; if (e.isDirectory()) walk(p + '/'); else if (e.name === 'splash.png') fs.writeFileSync(p, solid); });
  walk('/tmp/work/mobile/android/app/src/main/res/');
  console.log('icons ok');
})();
