import path from 'path';
import { fileURLToPath } from 'url';
import react from '@vitejs/plugin-react';
import legacy from '@vitejs/plugin-legacy';
import { defineConfig } from 'vite';
const d = path.dirname(fileURLToPath(import.meta.url));
export default defineConfig({
  base: './',
  plugins: [
    react(),
    legacy({ targets: ['chrome >= 49', 'android >= 5'], renderModernChunks: false, polyfills: true, modernPolyfills: false }),
  ],
  resolve: {
    alias: {
      '@capacitor/core': path.resolve(d, 'stubs/capacitor-core.ts'),
      '@capacitor/app': path.resolve(d, 'stubs/capacitor-app.ts'),
    },
  },
  build: { outDir: 'dist-box', cssTarget: 'chrome49', target: 'es2015', minify: 'terser', chunkSizeWarningLimit: 4000 },
});
