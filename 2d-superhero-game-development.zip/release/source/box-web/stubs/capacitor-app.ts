type W = { __parsaBack?: (() => void) | null; ParsaNative?: { exit?: () => void } };
export const App = {
  addListener(_ev: string, cb: () => void) {
    (window as unknown as W).__parsaBack = cb;
    return Promise.resolve({ remove: () => { (window as unknown as W).__parsaBack = null; } });
  },
  exitApp() {
    const n = (window as unknown as W).ParsaNative;
    if (n && n.exit) n.exit();
  },
};
