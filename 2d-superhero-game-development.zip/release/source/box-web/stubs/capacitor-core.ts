// Minimal replacement used by the Android-box build (no Capacitor runtime inside the APK).
export const Capacitor = {
  isNativePlatform: (): boolean => typeof window !== 'undefined' && !!(window as unknown as { ParsaNative?: unknown }).ParsaNative,
};
