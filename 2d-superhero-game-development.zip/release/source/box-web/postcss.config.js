import tailwindcss from 'tailwindcss';
import autoprefixer from 'autoprefixer';
import colorFn from 'postcss-color-functional-notation';
export default { plugins: [tailwindcss(), colorFn({ preserve: false }), autoprefixer({ overrideBrowserslist: ['chrome >= 49', 'android >= 5'] })] };
