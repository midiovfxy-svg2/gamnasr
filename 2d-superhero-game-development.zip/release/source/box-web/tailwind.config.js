export default { content: ['./index.html', './src/**/*.{ts,tsx}'], theme: { extend: {} }, plugins: [], corePlugins: { backdropBlur: true } };
