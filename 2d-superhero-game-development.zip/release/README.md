# خروجی‌های نصب — محمد پارسا و ساعت سبز (نسخه ۱.۰.۱)

## سه فایل اصلی
| فایل | برای چه دستگاهی |
|---|---|
| `mobile/ParsaGreenWatch-1.0.1-Mobile.apk` | گوشی/تبلت اندروید ۶+، دکمه‌های لمسی |
| `android-box/ParsaGreenWatch-1.0.1-AndroidBox.apk` | اندروید باکس / تی‌وی‌باکس / دستگاه قدیمی (اندروید ۵+)، ریموت و دسته |
| `windows/ParsaGreenWatch-Setup-1.0.1-Windows.exe` | ویندوز ۱۰/۱۱ (۶۴ بیتی) |
| `playstore/ParsaGreenWatch-1.0.1-playstore.aab` | فقط برای آپلود در Google Play |

چک‌سام‌ها: `SHA256SUMS.txt`. هر سه نسخه کاملاً آفلاین‌اند.

## نسخه‌ی اندروید باکس چه فرقی دارد؟
- کد بازی به **ES5** تبدیل شده و polyfill دارد؛ روی WebView قدیمی (Chrome 49+) هم اجرا می‌شود.
- CSS بدون ویژگی‌های جدید (`@layer`، `oklch`، `aspect-ratio`، `dvh`…) ساخته شده.
- پوسته‌ی بومی سبک (فقط WebView) از اندروید ۵؛ بدون AndroidX.
- منوها با **ریموت/دی‌پد/دسته** قابل پیمایش‌اند (حلقه‌ی سبز روی دکمه‌ی انتخاب‌شده)؛ دکمه‌های دسته از طرف جاوا مستقیم به بازی می‌رسند.
- افکت‌های سنگین (glow) از ابتدا خاموش‌اند؛ دکمه‌ی Back ریموت = برگشت به منو.
- اگر WebView خیلی قدیمی باشد (کمتر از Chrome 49) پیام راهنما نشان می‌دهد؛ اگر خطای جاوااسکریپت رخ دهد، متن خطا و نسخه‌ی مرورگر روی صفحه چاپ می‌شود.

## کلید امضا — مهم
- فایل: `keys/parsa-release.keystore`، alias: `parsa`، رمز: داخل `keys/keystore.properties`
- SHA-256 گواهی: `B3:6F:56:84:BB:43:E5:75:46:F3:92:67:96:4E:38:AF:33:F6:CE:67:2B:3D:47:6A:31:9B:96:18:15:E4:F2:04`
- **کلید نسخه‌ی ۱.۰.۰ (اثرانگشت 86:24:DB:6E…) گم شد** (فقط فایل‌های متنی محیط بازسازی‌شده بودند). نسخه‌ی ۱.۰.۱ با این کلید جدید امضا شده؛ پس **روی ۱.۰.۰ آپدیت نمی‌شود: اول ۱.۰.۰ را پاک کن** (پیشرفت بازی ذخیره‌شده در آن هم پاک می‌شود).
- از این کلید و رمزش چند نسخه‌ی پشتیبان بگیر و جایی عمومی نگذار. اگر بخواهی در Play منتشر کنی، **Play App Signing** را روشن بگذار تا این کلید فقط «کلید آپلود» باشد.
- شناسه‌ها: موبایل `com.parsa.greenwatch`، باکس `com.parsa.greenwatch.box` (می‌توان هر دو را کنار هم نصب کرد).

## ویندوز
Setup را اجرا کن؛ ادمین لازم نیست. چون با گواهی پولی امضا نشده SmartScreen هشدار می‌دهد: **More info ← Run anyway**. F11 = تمام‌صفحه.

## انتشار در Google Play
فقط `.aab`؛ آیکون ۵۱۲ (`public/icon-512.png`)، تصویر ۱۰۲۴×۵۰۰، اسکرین‌شات، سیاست حریم خصوصی، فرم Data safety. **هشدار حقوقی:** نام‌ها و کاراکترهای Ben 10 متعلق به صاحب حقوق‌اند و Play اپ بدون مجوز را رد می‌کند؛ برای انتشار عمومی نام و ظاهر را عوض کن.

## ساخت دوباره
- وب: `npm run build` (پوشه‌ی `dist`)
- موبایل: `source/android-capacitor` + `dist` در `www` + `npx cap sync android` + Gradle 8.11 / JDK 21 / SDK 35 (`gradle assembleRelease bundleRelease`)
- اندروید باکس: در `source/box-web` با `VITE_BOX=1 npx vite build -c vite.config.ts` (پروژه‌ی وب را در کنارش کپی کن، Tailwind 3 لازم است و `src/index.css` باید با دستورهای `@tailwind` جایگزین شود)، خروجی `dist-box` را در `source/android-box/app/src/main/assets/www` بگذار و `gradle assembleRelease`
- ویندوز: `electron-builder --win dir --x64` سپس `makensis installer.nsi`
- آیکون‌ها: `assets/make-icons.js` از `assets/icon-source.png`
