import { DialogChoice, DialogLine, EnemyKind, FORMS, FORM_ORDER, FormId, LEVELS, LevelDef } from './data';
import {
  Anim,
  CityScene,
  buildCity,
  drawBrute,
  drawBuildings,
  drawCosmic,
  drawEx,
  drawExBackground,
  drawForm,
  drawGoliath,
  drawGroundAndProps,
  drawGrunt,
  drawKevin,
  drawMeteor,
  drawNpc,
  drawSky,
  drawTank,
  drawWatch,
  drawGwen,
  drawMax,
  drawRV,
  drawScout,
  drawShark,
  rr,
  seededRandom,
} from './draw';
import { Input } from './input';

export const W = 1280;
export const H = 720;
const GROUND = 560;
const GRAVITY = 1900;
const FONT = "'Vazirmatn', 'Segoe UI', Tahoma, sans-serif";

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: number;
  form: FormId;
  formTime: number;
  recharge: number;
  hp: number;
  maxHp: number;
  inv: number;
  attackT: number;
  attackCd: number;
  splitCd: number;
  crouch: boolean;
  onGround: boolean;
  hasWatch: boolean;
  dashT: number;
}

interface Enemy {
  kind: EnemyKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  w: number;
  h: number;
  hp: number;
  maxHp: number;
  facing: number;
  timer: number;
  state: string;
  stateT: number;
  flash: number;
  dead: boolean;
  baseY: number;
  onGround: boolean;
  patrolL: number;
  patrolR: number;
}

interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  dmg: number;
  owner: 'player' | 'enemy';
  kind: 'fire' | 'shard' | 'laser' | 'wave' | 'rock' | 'cosmic' | 'shell' | 'crystal' | 'disc' | 'neuro';
  life: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
  grav: number;
}

interface FloatText {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
}

interface Crack {
  x: number;
  dir: number;
  len: number;
  life: number;
  hit: Set<Enemy>;
}

interface Beam {
  x1: number;
  x2: number;
  y: number;
  life: number;
  hitPlayer: boolean;
}

interface Ally {
  kind: 'kevin' | 'gwen';
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: number;
  onGround: boolean;
  attackT: number;
  attackCd: number;
  absorb: string | null;
  absorbT: number;
}

export type Mode = 'intro' | 'play' | 'outro' | 'complete' | 'dead' | 'paused' | 'cutscene';

export interface LevelResult {
  levelId: number;
  kills: number;
  friend?: string;
  unlock?: FormId;
  timeSec: number;
  hpLeft: number;
}

export type GameEvent =
  | { type: 'complete'; result: LevelResult }
  | { type: 'dead' }
  | { type: 'confirm' }
  | { type: 'dialog'; open: boolean; choices: string[] | null }
  | { type: 'friend'; name: string }
  | { type: 'unlock'; form: FormId };

export interface GameOptions {
  lowFx?: boolean;
  levelId: number;
  unlocked: FormId[];
  onEvent: (e: GameEvent) => void;
}

const sfx = {
  ctx: null as AudioContext | null,
  play(freq: number, dur = 0.08, type: OscillatorType = 'square', vol = 0.05, slide = 0) {
    try {
      if (!this.ctx) this.ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const c = this.ctx;
      if (c.state === 'suspended') c.resume();
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = type;
      o.frequency.setValueAtTime(freq, c.currentTime);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq + slide), c.currentTime + dur);
      g.gain.setValueAtTime(vol, c.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
      o.connect(g).connect(c.destination);
      o.start();
      o.stop(c.currentTime + dur);
    } catch {
      /* ignore */
    }
  },
};

/** Make the 2D context tolerant: bad numbers can never throw and freeze the game loop. */
function hardenCtx(ctx: CanvasRenderingContext2D) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const c = ctx as any;
  if (c.__hardened) return;
  c.__hardened = true;
  const f = (v: number) => (typeof v === 'number' && isFinite(v) ? v : 0);
  const p = (v: number) => Math.max(0, f(v));
  const arc = ctx.arc.bind(ctx);
  c.arc = (x: number, y: number, r: number, a0: number, a1: number, ccw?: boolean) => arc(f(x), f(y), p(r), f(a0), f(a1), ccw);
  const ellipse = ctx.ellipse.bind(ctx);
  c.ellipse = (x: number, y: number, rx: number, ry: number, rot: number, a0: number, a1: number, ccw?: boolean) => ellipse(f(x), f(y), p(rx), p(ry), f(rot), f(a0), f(a1), ccw);
  const arcTo = ctx.arcTo.bind(ctx);
  c.arcTo = (x1: number, y1: number, x2: number, y2: number, r: number) => arcTo(f(x1), f(y1), f(x2), f(y2), p(r));
  const lg = ctx.createLinearGradient.bind(ctx);
  c.createLinearGradient = (x0: number, y0: number, x1: number, y1: number) => lg(f(x0), f(y0), f(x1), f(y1));
  const rg = ctx.createRadialGradient.bind(ctx);
  c.createRadialGradient = (x0: number, y0: number, r0: number, x1: number, y1: number, r1: number) => rg(f(x0), f(y0), p(r0), f(x1), f(y1), p(r1));
}

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  input: Input;
  level: LevelDef;
  scene: CityScene;
  platforms: Rect[] = [];
  player: Player;
  enemies: Enemy[] = [];
  projectiles: Projectile[] = [];
  particles: Particle[] = [];
  texts: FloatText[] = [];
  cracks: Crack[] = [];
  beams: Beam[] = [];
  kevin: Ally | null = null;
  gwen: Ally | null = null;
  water: { from: number; to: number; surface: number }[] = [];
  rvX = 260;
  rvUsed = false;
  freezeT = 0;
  playerWet = false;
  hintShownSwim = false;
  npcTalked = false;
  npcX = 0;
  boss: Enemy | null = null;
  bossIntroDone = false;
  dialog: { lines: DialogLine[]; idx: number; then: () => void; choice: number } | null = null;
  mode: Mode = 'intro';
  prevMode: Mode = 'play';
  wheelOpen = false;
  wheelIdx = 0;
  unlocked: FormId[];
  camX = 0;
  time = 0;
  levelTime = 0;
  shake = 0;
  flash = 0;
  flashColor = '#7CFC00';
  kills = 0;
  friendMade?: string;
  raf = 0;
  last = 0;
  acc = 0;
  running = false;
  onEvent: GameOptions['onEvent'];
  formDuration: number;
  hint = '';
  hintT = 0;
  craterX = 0;
  craterDone = false;
  malfunctionT = 6;
  meteorT = 2;
  defendT = 0;
  defendStarted = false;
  defendWaveT = 0;
  towerX = 0;
  questionIdx = 0;
  questionXs: number[] = [];
  rescueEnemies: Enemy[] = [];
  timeScale = 1;

  constructor(canvas: HTMLCanvasElement, input: Input, opts: GameOptions) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('no ctx');
    hardenCtx(ctx);
    this.ctx = ctx;
    this.input = input;
    let saved = false;
    try {
      saved = localStorage.getItem('parsa-lowfx') === '1';
    } catch {
      /* ignore */
    }
    if (opts.lowFx || saved) this.enableLowFx();
    this.onEvent = opts.onEvent;
    this.level = LEVELS.find((l) => l.id === opts.levelId) ?? LEVELS[0];
    const allowed = new Set(this.level.available);
    this.unlocked = FORM_ORDER.filter((f) => (opts.unlocked.includes(f) || this.level.available.includes(f)) && allowed.has(f) && !(this.level.noAlienX && f === 'alienx'));
    if (this.level.noWatch) this.unlocked = [];
    if (this.level.questions) this.unlocked = this.unlocked.filter((f) => f !== 'alienx');
    this.formDuration = this.level.id >= 18 ? 38 : 26;
    this.scene = buildCity(this.level.seed, this.level.length, this.level.theme);
    this.player = {
      x: 300,
      y: GROUND,
      vx: 0,
      vy: 0,
      facing: 1,
      form: 'human',
      formTime: 0,
      recharge: 0,
      hp: 100,
      maxHp: 100,
      inv: 0,
      attackT: 0,
      attackCd: 0,
      splitCd: 0,
      crouch: false,
      onGround: true,
      hasWatch: !this.level.noWatch,
      dashT: 0,
    };
    this.buildLevel();
    this.showDialog(this.level.intro, () => {
      this.mode = 'play';
    });
  }

  /* ---------------- setup ---------------- */
  buildLevel() {
    const L = this.level;
    const rnd = seededRandom(L.seed * 31 + 7);
    const endSafe = L.boss ? L.length - 1000 : L.defend ? L.length - 900 : L.length - 420;
    if (L.craterAt) this.craterX = Math.floor(L.craterAt * L.length);
    if (L.npc) this.npcX = 400 + L.npc.atFrac * (L.length - 800);
    if (L.defend) this.towerX = L.length - 500;
    if (L.questions) this.questionXs = L.questions.map((_, i) => 700 + i * ((L.length - 1200) / Math.max(1, L.questions!.length - 1)));
    // platforms
    let x = 650;
    while (x < endSafe) {
      const w = 130 + rnd() * 160;
      const h = 90 + rnd() * 150;
      this.platforms.push({ x, y: GROUND - h, w, h: 18 });
      if (rnd() > 0.55) {
        this.platforms.push({ x: x + w * 0.4 + rnd() * 80, y: GROUND - h - 100 - rnd() * 60, w: 110 + rnd() * 100, h: 18 });
      }
      x += w + 240 + rnd() * 320;
    }
    if (L.defend) {
      this.platforms.push({ x: this.towerX - 420, y: GROUND - 140, w: 160, h: 18 });
      this.platforms.push({ x: this.towerX + 120, y: GROUND - 140, w: 160, h: 18 });
    }
    // enemies
    const startX = L.craterAt ? this.craterX + 350 : 520;
    const spawnRange: [number, number] = [startX, endSafe];
    const spawn = (kind: EnemyKind, n: number) => {
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5 + (rnd() - 0.5) * 0.6) / n;
        const ex = spawnRange[0] + t * (spawnRange[1] - spawnRange[0]);
        this.enemies.push(this.makeEnemy(kind, ex, rnd));
      }
    };
    (Object.keys(L.enemies) as EnemyKind[]).forEach((k) => spawn(k, L.enemies[k] ?? 0));
    // rescue: enemies around the friend
    if (L.npc) {
      for (let i = 0; i < 3; i++) {
        const e = this.makeEnemy(i === 1 ? 'scout' : 'grunt', this.npcX + (i - 1) * 150, rnd);
        e.patrolL = this.npcX - 220;
        e.patrolR = this.npcX + 220;
        this.enemies.push(e);
        this.rescueEnemies.push(e);
      }
    }
    // boss
    if (L.boss === 'ex') {
      const bx = L.length - 420;
      this.platforms.push({ x: bx - 900, y: GROUND - 130, w: 170, h: 18 });
      this.platforms.push({ x: bx - 640, y: GROUND - 230, w: 160, h: 18 });
      this.platforms.push({ x: bx - 420, y: GROUND - 150, w: 150, h: 18 });
      this.boss = { kind: 'ex', x: bx, y: GROUND, vx: 0, vy: 0, w: 230, h: 470, hp: L.bossHp ?? 600, maxHp: L.bossHp ?? 600, facing: -1, timer: 2.5, state: 'idle', stateT: 0, flash: 0, dead: false, baseY: GROUND, onGround: true, patrolL: bx, patrolR: bx };
    } else if (L.boss === 'goliath') {
      const bx = L.length - 600;
      this.boss = { kind: 'goliath', x: bx, y: GROUND, vx: 0, vy: 0, w: 140, h: 240, hp: L.bossHp ?? 450, maxHp: L.bossHp ?? 450, facing: -1, timer: 1.5, state: 'wait', stateT: 0, flash: 0, dead: false, baseY: GROUND, onGround: true, patrolL: bx - 600, patrolR: bx + 200 };
    }
    if (L.kevinAlly) {
      this.kevin = { kind: 'kevin', x: 230, y: GROUND, vx: 0, vy: 0, facing: 1, onGround: true, attackT: 0, attackCd: 0, absorb: null, absorbT: 0 };
    }
    if (L.gwenAlly) {
      this.gwen = { kind: 'gwen', x: 160, y: GROUND, vx: 0, vy: 0, facing: 1, onGround: true, attackT: 0, attackCd: 0, absorb: null, absorbT: 0 };
    }
    // water
    if (L.water) this.water = L.water.map((z) => ({ ...z, to: Math.min(z.to, L.length + 200), from: Math.max(-200, z.from) }));
    if (L.seaZones) {
      const n = L.seaZones;
      for (let i = 0; i < n; i++) {
        const c = 900 + ((i + 0.5) / n) * (endSafe - 1100);
        const w = 520 + rnd() * 200;
        this.water.push({ from: c - w / 2, to: c + w / 2, surface: GROUND - 230 });
      }
      // remove submerged platforms; add a dock over each zone
      this.platforms = this.platforms.filter((pl) => !this.water.some((z) => pl.x + pl.w > z.from && pl.x < z.to && pl.y > z.surface - 30));
      for (const z of this.water) this.platforms.push({ x: z.from + (z.to - z.from) * 0.35, y: z.surface - 70, w: 130, h: 18 });
    }
    // sharks: place inside water
    for (const e of this.enemies) {
      if (e.kind !== 'shark') continue;
      if (!this.water.length) { e.dead = true; continue; }
      let z = this.water.find((w) => e.x > w.from && e.x < w.to);
      if (!z) {
        z = this.water[Math.floor(rnd() * this.water.length)];
        e.x = z.from + 60 + rnd() * Math.max(10, z.to - z.from - 120);
      }
      e.baseY = z.surface + 50 + rnd() * Math.max(20, GROUND - z.surface - 100);
      e.y = e.baseY;
      e.patrolL = Math.max(z.from + 40, e.x - 250);
      e.patrolR = Math.min(z.to - 40, e.x + 250);
    }
    if (L.theme === 'ocean' && this.platforms.length) {
      // underwater platforms are coral ledges, keep them
    }
  }

  surfaceAt(x: number) {
    for (const z of this.water) if (x >= z.from && x <= z.to) return z.surface;
    return Infinity;
  }

  inWater(x: number, y: number) {
    return y > this.surfaceAt(x);
  }

  makeEnemy(kind: EnemyKind, x: number, rnd: () => number): Enemy {
    const base = { x, vx: 0, vy: 0, facing: -1, timer: rnd() * 2, state: 'patrol', stateT: 0, flash: 0, dead: false, onGround: true, patrolL: x - 140 - rnd() * 100, patrolR: x + 140 + rnd() * 100 };
    switch (kind) {
      case 'scout':
        return { ...base, kind, y: GROUND, baseY: GROUND, w: 44, h: 56, hp: 35, maxHp: 35, timer: 1 + rnd() * 1.5 };
      case 'brute':
        return { ...base, kind, y: GROUND, baseY: GROUND, w: 80, h: 130, hp: 150, maxHp: 150 };
      case 'tank':
        return { ...base, kind, y: GROUND, baseY: GROUND, w: 110, h: 80, hp: 120, maxHp: 120, timer: 1 + rnd() };
      case 'shark':
        return { ...base, kind, y: GROUND - 100, baseY: GROUND - 100, w: 76, h: 30, hp: 45, maxHp: 45 };
      case 'meteor':
        return { ...base, kind, y: -60, baseY: -60, w: 44, h: 44, hp: 20, maxHp: 20, vy: 160 + rnd() * 100, vx: -60 + rnd() * 120, patrolL: 0, patrolR: 0 };
      default:
        return { ...base, kind: 'grunt', y: GROUND, baseY: GROUND, w: 40, h: 86, hp: 55, maxHp: 55 };
    }
  }

  /* ---------------- lifecycle ---------------- */
  private onVis = () => {
    if (document.hidden && (this.mode === 'play' || this.mode === 'cutscene')) {
      this.prevMode = this.mode;
      this.mode = 'paused';
    }
  };

  lowFx = false;
  private errCount = 0;
  private errStreak = 0;
  errMsg = '';
  private perfAcc = 0;
  private perfN = 0;
  private warm = 0;

  /** Drop expensive glow effects (shadowBlur) for slow devices such as TV boxes. */
  enableLowFx() {
    if (this.lowFx) return;
    this.lowFx = true;
    try {
      Object.defineProperty(this.ctx, 'shadowBlur', { get: () => 0, set: () => undefined, configurable: true });
    } catch {
      /* ignore */
    }
  }

  private resetCtx() {
    const ctx = this.ctx;
    try {
      for (let i = 0; i < 60; i++) ctx.restore();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
      ctx.filter = 'none';
    } catch {
      /* ignore */
    }
  }

  private fail(err: unknown) {
    this.errStreak++;
    if (this.errCount++ < 6) console.error('[game]', err);
    this.errMsg = String((err as Error)?.message ?? err).slice(0, 140);
    this.resetCtx();
  }

  start() {
    if (this.running) return;
    this.running = true;
    document.addEventListener('visibilitychange', this.onVis);
    this.input.attach();
    this.last = performance.now();
    const loop = (ts: number) => {
      if (!this.running) return;
      const raw = (ts - this.last) / 1000;
      const dtReal = Math.min(0.1, raw);
      this.last = ts;
      this.acc += dtReal;
      const step = 1 / 60;
      let n = 0;
      let ok = true;
      try {
        while (this.acc >= step && n < 5) {
          this.frame(step);
          this.acc -= step;
          n++;
        }
      } catch (err) {
        ok = false;
        this.acc = 0;
        this.fail(err);
      }
      try {
        this.render();
      } catch (err) {
        ok = false;
        this.fail(err);
      }
      if (ok) this.errStreak = 0;
      // auto quality: if the device cannot keep ~40fps, switch to low-fx permanently
      if (!this.lowFx && this.mode === 'play') {
        if (this.warm < 120) this.warm++;
        else {
          this.perfAcc += raw;
          if (++this.perfN >= 90) {
            if (this.perfAcc / this.perfN > 0.026) {
              this.enableLowFx();
              try {
                localStorage.setItem('parsa-lowfx', '1');
              } catch {
                /* ignore */
              }
            }
            this.perfAcc = 0;
            this.perfN = 0;
          }
        }
      }
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  stop() {
    this.running = false;
    document.removeEventListener('visibilitychange', this.onVis);
    cancelAnimationFrame(this.raf);
    this.input.detach();
  }

  /* ---------------- helpers ---------------- */
  private lastDialogSig = '';
  emitDialog() {
    const d = this.dialog;
    const ch = d ? d.lines[d.idx]?.choices?.map((c) => c.text) ?? null : null;
    const sig = (d ? 'o' : 'c') + JSON.stringify(ch);
    if (sig === this.lastDialogSig) return;
    this.lastDialogSig = sig;
    this.onEvent({ type: 'dialog', open: !!d, choices: ch });
  }

  /** Used by on-screen buttons for multiple-choice dialog lines. */
  pickChoice(i: number) {
    const d = this.dialog;
    const cur = d?.lines[d.idx];
    if (!d || !cur?.choices || !cur.choices[i]) return;
    d.choice = i;
    d.lines.splice(d.idx + 1, 0, ...cur.choices[i].reply);
    d.idx++;
    d.choice = 0;
    sfx.play(880, 0.1, 'triangle', 0.04, 200);
    this.emitDialog();
  }

  showDialog(lines: DialogLine[], then: () => void) {
    if (!lines.length) {
      then();
      return;
    }
    this.dialog = { lines: [...lines], idx: 0, then, choice: 0 };
    this.emitDialog();
    if (this.mode === 'play') this.mode = 'cutscene';
  }

  spawnParticles(x: number, y: number, n: number, color: string, speed = 200, size = 4, grav = 600, life = 0.6) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = Math.random() * speed;
      this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - speed * 0.3, life, max: life, color, size: size * (0.5 + Math.random()), grav });
    }
  }

  addText(x: number, y: number, text: string, color = '#fff') {
    this.texts.push({ x, y, text, color, life: 1 });
  }

  setHint(h: string, t = 3.5) {
    this.hint = h;
    this.hintT = t;
  }

  get form() {
    return FORMS[this.player.form];
  }

  get playerRect(): Rect {
    const p = this.player;
    const f = this.form;
    const h = p.crouch ? f.h * 0.6 : f.h;
    return { x: p.x - f.w / 2, y: p.y - h, w: f.w, h };
  }

  enemyRect(e: Enemy): Rect {
    if (e.kind === 'ex') return { x: e.x - 120, y: e.y - 470, w: 230, h: 470 };
    if (e.kind === 'meteor') return { x: e.x - 22, y: e.y - 22, w: 44, h: 44 };
    if (e.kind === 'shark') return { x: e.x - 38, y: e.y - 15, w: 76, h: 30 };
    if (e.kind === 'goliath') return { x: e.x - 70, y: e.y - 240, w: 140, h: 240 };
    return { x: e.x - e.w / 2, y: e.y - e.h, w: e.w, h: e.h };
  }

  overlap(a: Rect, b: Rect) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  /* ---------------- update ---------------- */
  frame(dt: number) {
    this.input.poll();
    const inp = this.input;
    this.time += dt;

    // global: pause
    if (inp.justPressed('pause')) {
      if (this.mode === 'paused') this.mode = this.prevMode;
      else if (this.mode === 'play' || this.mode === 'cutscene') {
        this.prevMode = this.mode;
        this.mode = 'paused';
      }
    }

    if (this.mode === 'paused') {
      if (inp.justPressed('confirm')) this.mode = this.prevMode;
      return;
    }

    if (this.dialog) {
      const d = this.dialog;
      const cur = d.lines[d.idx];
      if (cur?.choices) {
        if (inp.justPressed('left') || inp.justPressed('right') || inp.justPressed('up') || inp.justPressed('down')) {
          d.choice = (d.choice + 1) % cur.choices.length;
          sfx.play(520, 0.04, 'sine', 0.03);
        }
        if (inp.justPressed('transform') || inp.justPressed('attack')) {
          const pick: DialogChoice = cur.choices[d.choice];
          d.lines.splice(d.idx + 1, 0, ...pick.reply);
          d.idx++;
          d.choice = 0;
          sfx.play(880, 0.1, 'triangle', 0.04, 200);
        }
      } else if (inp.justPressed('confirm') || inp.justPressed('attack') || inp.justPressed('jump')) {
        d.idx++;
        sfx.play(660, 0.05, 'sine', 0.03);
        if (d.idx >= d.lines.length) {
          const then = d.then;
          this.dialog = null;
          then();
        }
      }
      this.emitDialog();
      this.updateParticles(dt);
      return;
    }
    if (this.lastDialogSig.startsWith('o')) this.emitDialog();

    if (this.mode === 'complete' || this.mode === 'dead') {
      if (inp.justPressed('confirm')) this.onEvent({ type: 'confirm' });
      this.updateParticles(dt);
      return;
    }

    if (this.mode !== 'play') return;

    this.levelTime += dt;
    if (this.hintT > 0) this.hintT -= dt;
    if (this.flash > 0) this.flash -= dt * 2.5;
    this.updateSpecials(dt);
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 30);

    // watch wheel
    const p = this.player;
    if (this.wheelOpen) {
      if (inp.justPressed('left') || inp.justPressed('down')) this.wheelIdx = (this.wheelIdx - 1 + this.unlocked.length) % this.unlocked.length;
      if (inp.justPressed('right') || inp.justPressed('up')) this.wheelIdx = (this.wheelIdx + 1) % this.unlocked.length;
      if (inp.justPressed('transform') || inp.justPressed('jump') || inp.justPressed('attack')) {
        this.wheelOpen = false;
        this.transform(this.unlocked[this.wheelIdx]);
      } else if (inp.justPressed('watch')) {
        this.wheelOpen = false;
      }
      dt *= 0.08; // slow motion while choosing
    } else if (inp.justPressed('watch')) {
      if (!p.hasWatch) this.setHint('هنوز ساعتی نداری! برو سمت شهاب‌سنگ.');
      else if (p.form !== 'human') this.revert();
      else if (p.recharge > 0) this.setHint('ساعت در حال شارژ است...');
      else if (!this.unlocked.length) this.setHint('هنوز موجودی داخل ساعت نیست.');
      else {
        this.wheelOpen = true;
        sfx.play(880, 0.12, 'triangle', 0.04, 300);
      }
    } else if (inp.justPressed('transform') && p.form === 'human' && p.hasWatch && p.recharge <= 0 && this.unlocked.length) {
      this.transform(this.unlocked[this.wheelIdx % this.unlocked.length]);
    }

    this.timeScale = p.form === 'alienx' ? 0.45 : 1;
    const edt = dt * this.timeScale;
    this.updatePlayer(dt);
    this.updateEnemies(edt);
    if (this.boss && !this.boss.dead) this.updateBoss(this.boss, edt);
    if (this.kevin) this.updateAlly(this.kevin, dt);
    if (this.gwen) this.updateAlly(this.gwen, dt);
    if (this.freezeT > 0) this.freezeT -= dt;
    this.updateProjectiles(dt);
    this.updateCracks(dt);
    this.updateBeams(dt);
    this.updateParticles(dt);
    this.checkTriggers();

    // camera
    const maxCam = this.level.length - W;
    const target = Math.max(0, Math.min(maxCam, p.x - W * 0.4));
    this.camX += (target - this.camX) * Math.min(1, dt * 6);
  }

  transform(f: FormId) {
    const p = this.player;
    p.form = f;
    p.formTime = f === 'alienx' ? FORMS.alienx.duration : this.formDuration;
    p.crouch = false;
    this.flash = 1;
    this.flashColor = '#7CFC00';
    this.spawnParticles(p.x, p.y - 40, 40, '#7CFC00', 300, 5, 0, 0.8);
    this.addText(p.x, p.y - 110, FORMS[f].name + '!', FORMS[f].glow);
    this.input.vibrate(200, 0.8);
    sfx.play(300, 0.4, 'sawtooth', 0.05, 900);
  }

  revert() {
    const p = this.player;
    if (p.form === 'human') return;
    p.form = 'human';
    p.formTime = 0;
    p.recharge = 8;
    this.flash = 0.6;
    this.flashColor = '#ff3b3b';
    this.spawnParticles(p.x, p.y - 40, 25, '#ff5a5a', 220, 4, 0, 0.6);
    sfx.play(700, 0.35, 'sawtooth', 0.04, -500);
  }

  moveWithCollisions(o: { x: number; y: number; vx: number; vy: number; onGround: boolean }, w: number, dt: number, grav = 1) {
    const prevY = o.y;
    o.vy += GRAVITY * dt * grav;
    o.x += o.vx * dt;
    o.y += o.vy * dt;
    o.onGround = false;
    if (o.y >= GROUND) {
      o.y = GROUND;
      o.vy = 0;
      o.onGround = true;
    }
    if (o.vy >= 0) {
      for (const pl of this.platforms) {
        if (o.x + w / 2 > pl.x && o.x - w / 2 < pl.x + pl.w && prevY <= pl.y + 2 && o.y >= pl.y) {
          o.y = pl.y;
          o.vy = 0;
          o.onGround = true;
        }
      }
    }
    o.x = Math.max(20, Math.min(this.level.length - 20, o.x));
  }

  updatePlayer(dt: number) {
    const p = this.player;
    const inp = this.input;
    const f = this.form;
    if (p.inv > 0) p.inv -= dt;
    if (p.attackCd > 0) p.attackCd -= dt;
    if (p.attackT > 0) p.attackT -= dt * 4;
    if (p.splitCd > 0) p.splitCd -= dt;
    if (p.dashT > 0) p.dashT -= dt;
    if (p.recharge > 0) p.recharge -= dt;
    if (p.form !== 'human') {
      p.formTime -= dt;
      if (p.formTime <= 0) this.revert();
    }

    // movement
    let dir = 0;
    if (!this.wheelOpen) {
      if (inp.isDown('left')) dir -= 1;
      if (inp.isDown('right')) dir += 1;
      if (Math.abs(inp.axisX) > 0.3) dir = Math.sign(inp.axisX);
    }
    const wet = this.inWater(p.x, p.y - f.h * 0.5);
    if (wet && !this.playerWet) {
      this.spawnParticles(p.x, this.surfaceAt(p.x), 18, '#bae6fd', 220, 4, 600, 0.6);
      sfx.play(200, 0.2, 'sine', 0.05, -120);
      if (!this.hintShownSwim) {
        this.hintShownSwim = true;
        this.setHint('شنا: Space را نگه دار برای بالا رفتن، S برای شیرجه. جت‌ری در آب خیلی سریع است!', 5);
      }
    }
    this.playerWet = wet;
    p.crouch = !wet && p.onGround && inp.isDown('down') && !this.wheelOpen;
    const waterMul = wet ? (p.form === 'jetray' ? 1.35 : p.form === 'xlr8' ? 0.5 : 0.65) : 1;
    const speed = f.speed * (p.crouch ? 0.45 : 1) * waterMul;
    const targetVx = dir * speed + (p.dashT > 0 ? p.facing * 900 : 0);
    p.vx += (targetVx - p.vx) * Math.min(1, dt * (p.onGround || wet ? 14 : 8));
    if (dir !== 0) p.facing = dir;

    if (wet) {
      // swimming
      const up = (inp.isDown('jump') || inp.isDown('up')) && !this.wheelOpen;
      const down = inp.isDown('down') && !this.wheelOpen;
      const stroke = p.form === 'jetray' ? 2200 : 1300;
      if (up) p.vy -= stroke * dt;
      if (down) p.vy += stroke * dt;
      const maxV = p.form === 'jetray' ? 420 : 280;
      p.vy = Math.max(-maxV, Math.min(maxV, p.vy));
      p.vy *= 1 - Math.min(1, dt * 2.5);
      const surf = this.surfaceAt(p.x);
      if (inp.justPressed('jump') && p.y - f.h * 0.5 < surf + 40) {
        p.vy = -f.jump * 0.85;
        this.spawnParticles(p.x, surf, 14, '#e0f2fe', 200, 3, 600, 0.5);
      }
      if (Math.random() < 0.12) this.particles.push({ x: p.x + p.facing * 10, y: p.y - f.h * 0.8, vx: (Math.random() - 0.5) * 20, vy: -60, life: 1, max: 1, color: 'rgba(255,255,255,0.7)', size: 3, grav: -40 });
      this.moveWithCollisions(p, f.w, dt, 0.12);
      if (p.y - f.h < 40) p.y = 40 + f.h;
    } else {
      if (inp.justPressed('jump') && p.onGround && !this.wheelOpen && !p.crouch) {
        p.vy = -f.jump;
        p.onGround = false;
        sfx.play(420, 0.12, 'square', 0.03, 300);
        this.spawnParticles(p.x, p.y, 6, '#ddd', 80, 3, 400, 0.4);
      }
      // jetray flight
      if (p.form === 'jetray' && !p.onGround && inp.isDown('jump') && !this.wheelOpen) {
        p.vy = Math.max(-340, p.vy - 2700 * dt);
        if (Math.random() < 0.3) this.particles.push({ x: p.x - p.facing * 20, y: p.y - 40, vx: -p.facing * 60, vy: 20, life: 0.4, max: 0.4, color: '#fca5a5', size: 3, grav: 0 });
      }
      // variable jump height
      if (!inp.isDown('jump') && p.vy < -200) p.vy += GRAVITY * dt * 1.2;
      this.moveWithCollisions(p, f.w, dt);
      if (p.y - f.h < 30) {
        p.y = 30 + f.h;
        if (p.vy < 0) p.vy = 0;
      }
    }

    // boss gate
    if (this.boss && !this.boss.dead && this.boss.kind === 'ex') {
      const gate = this.boss.x - 170;
      if (p.x > gate) p.x = gate;
    }

    // attack
    if (inp.justPressed('attack') && p.attackCd <= 0 && !this.wheelOpen) {
      this.doAttack();
    }
    // earth split
    if (inp.justPressed('split') && !this.wheelOpen) {
      if (!p.hasWatch) this.setHint('برای قاچ‌کردن زمین به ساعت نیاز داری!');
      else if (p.splitCd > 0) this.setHint('قدرت قاچ زمین هنوز آماده نیست!', 1.2);
      else if (!p.onGround) this.setHint('برای قاچ زمین باید روی زمین باشی!', 1.2);
      else this.earthSplit();
    }

    // talk to NPC
    if (this.level.maxRV && !this.rvUsed && Math.abs(p.x - this.rvX) < 160 && !wet && inp.justPressed('up')) {
      this.rvUsed = true;
      p.hp = p.maxHp;
      p.recharge = 0;
      this.addText(p.x, p.y - 100, '❤ سلامتی کامل!', '#ff6b9d');
      this.spawnParticles(p.x, p.y - 50, 30, '#fdba74', 200, 4, 200, 1);
      const tips = [
        'یه ساندویچ خوشمزه برات درست کردم! یادت باشه: جت‌ری توی آب از همه سریع‌تره.',
        'بیا این آب‌میوه رو بخور! چهاردست اگه بشینه و حمله کنه، کف می‌زنه و موج انفجار می‌سازه.',
        'قهرمان‌ها هم باید غذا بخورن! ایلان ایکس اگه بشینه و حمله کنه، زمان رو متوقف می‌کنه.',
        'گوئن و کوین همیشه کنارتن. هیچ‌وقت تنها نیستی پسرم.',
        'وقتی قاچ زمین رو می‌زنی، همه‌ی دشمنای روی زمین پرت می‌شن. تانک‌ها خیلی ازش می‌ترسن!',
      ];
      this.showDialog([{ speaker: 'بابابزرگ مکس', text: tips[this.level.id % tips.length], color: '#fdba74' }], () => {
        this.mode = 'play';
      });
    }
    if (this.level.npc && !this.npcTalked && Math.abs(p.x - this.npcX) < 70 && inp.justPressed('up')) {
      if (this.rescueEnemies.some((e) => !e.dead)) {
        this.setHint(`اول دشمنان دور ${this.level.npc.name} را شکست بده!`, 2);
        return;
      }
      this.npcTalked = true;
      this.friendMade = this.level.npc.name;
      p.hp = Math.min(p.maxHp, p.hp + 40);
      this.addText(p.x, p.y - 100, '+40 ❤', '#ff6b9d');
      this.spawnParticles(this.npcX, GROUND - 60, 30, '#fde68a', 200, 4, 200, 1);
      const npc = this.level.npc;
      this.onEvent({ type: 'friend', name: npc.name });
      this.showDialog(npc.dialog, () => {
        this.mode = 'play';
      });
    }

    // fell too hard? (no pits) — contact damage with enemies
    const pr = this.playerRect;
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (this.overlap(pr, this.enemyRect(e))) {
        const dmg = e.kind === 'brute' ? (e.state === 'charge' ? 20 : 12) : e.kind === 'grunt' ? 10 : e.kind === 'meteor' ? 15 : 8;
        this.hurtPlayer(dmg, Math.sign(p.x - e.x) || 1);
        if (e.kind === 'meteor') this.explodeMeteor(e);
      }
    }
    if (this.boss && !this.boss.dead && this.boss.kind === 'goliath' && this.overlap(pr, this.enemyRect(this.boss))) {
      this.hurtPlayer(14, Math.sign(p.x - this.boss.x) || 1);
    }
  }

  doAttack() {
    const p = this.player;
    const f = this.form;
    p.attackCd = f.attackCd;
    p.attackT = 1;
    const ox = p.x + p.facing * (f.w / 2);
    const oy = p.y - f.h * 0.55;
    if (p.form === 'fourarms' && p.crouch) {
      p.attackCd = 1.4;
      this.shake = 16;
      this.flash = 0.3;
      this.flashColor = '#fca5a5';
      this.input.vibrate(300, 1);
      sfx.play(70, 0.5, 'sawtooth', 0.09, -30);
      this.addText(p.x, p.y - 130, 'کف‌زدن رعدآسا!', '#ff8c86');
      for (let i = 0; i < 40; i++) {
        const ang = (i / 40) * Math.PI * 2;
        this.particles.push({ x: p.x, y: p.y - 50, vx: Math.cos(ang) * 420, vy: Math.sin(ang) * 420, life: 0.5, max: 0.5, color: '#fecaca', size: 5, grav: 0 });
      }
      for (const e of [...this.enemies, ...(this.boss ? [this.boss] : [])]) {
        if (e.dead) continue;
        if (Math.abs(e.x - p.x) < 300 && Math.abs((this.enemyRect(e).y + this.enemyRect(e).h / 2) - (p.y - 50)) < 220) this.damageEnemy(e, 30, Math.sign(e.x - p.x) || 1);
      }
      return;
    }
    if (p.form === 'alienx' && p.crouch) {
      p.attackCd = 4;
      this.freezeT = 3.5;
      this.flash = 0.8;
      this.flashColor = '#a78bfa';
      sfx.play(600, 1, 'sine', 0.06, -500);
      this.addText(p.x, p.y - 130, 'توقف زمان!', '#c4b5fd');
      return;
    }
    switch (p.form) {
      case 'heat':
        this.projectiles.push({ x: ox, y: oy, vx: p.facing * 640, vy: 0, r: 10, dmg: f.attackDmg, owner: 'player', kind: 'fire', life: 1.4 });
        sfx.play(200, 0.15, 'sawtooth', 0.04, 100);
        break;
      case 'diamond':
        for (let i = -1; i <= 1; i++) {
          this.projectiles.push({ x: ox, y: oy, vx: p.facing * 560, vy: i * 120, r: 7, dmg: f.attackDmg, owner: 'player', kind: 'shard', life: 1.2 });
        }
        sfx.play(1200, 0.1, 'triangle', 0.04, -400);
        break;
      case 'xlr8':
        p.dashT = 0.14;
        this.melee(70, f.attackDmg);
        sfx.play(900, 0.1, 'square', 0.03, 600);
        break;
      case 'jetray':
        this.projectiles.push({ x: ox, y: oy - 14, vx: p.facing * 820, vy: 0, r: 6, dmg: f.attackDmg, owner: 'player', kind: 'neuro', life: 1.1 });
        sfx.play(1600, 0.08, 'square', 0.03, -900);
        break;
      case 'alienx':
        this.projectiles.push({ x: ox, y: oy, vx: p.facing * 520, vy: 0, r: 16, dmg: f.attackDmg, owner: 'player', kind: 'cosmic', life: 1.6 });
        this.shake = 3;
        sfx.play(150, 0.3, 'sine', 0.06, 700);
        break;
      case 'fourarms':
        this.melee(95, f.attackDmg);
        this.shake = 6;
        this.spawnParticles(p.x + p.facing * 50, p.y - 10, 10, '#d1d5db', 150, 3, 500, 0.4);
        sfx.play(90, 0.2, 'square', 0.06, -40);
        break;
      default:
        this.melee(46, f.attackDmg);
        sfx.play(500, 0.06, 'square', 0.03);
    }
  }

  melee(range: number, dmg: number) {
    const p = this.player;
    const f = this.form;
    const hit: Rect = { x: p.facing > 0 ? p.x : p.x - range, y: p.y - f.h, w: range + f.w / 2, h: f.h };
    const targets = [...this.enemies, ...(this.boss ? [this.boss] : [])];
    for (const e of targets) {
      if (e.dead) continue;
      if (this.overlap(hit, this.enemyRect(e))) {
        this.damageEnemy(e, dmg, p.facing);
      }
    }
  }

  earthSplit() {
    const p = this.player;
    p.splitCd = 6;
    this.cracks.push({ x: p.x, dir: p.facing, len: 0, life: 1.3, hit: new Set() });
    this.shake = 10;
    this.flash = 0.3;
    this.flashColor = '#7CFC00';
    this.input.vibrate(300, 1);
    sfx.play(80, 0.5, 'sawtooth', 0.08, -50);
    this.addText(p.x, p.y - 120, 'قاچ زمین!', '#7CFC00');
  }

  hurtPlayer(dmg: number, dir: number) {
    const p = this.player;
    if (p.inv > 0 || this.mode !== 'play') return;
    const mult = p.form === 'diamond' ? 0.5 : p.form === 'fourarms' ? 0.75 : 1;
    const d = Math.round(dmg * mult);
    p.hp -= d;
    p.inv = 1.1;
    p.vx = dir * 320;
    p.vy = -260;
    p.onGround = false;
    this.shake = 8;
    this.addText(p.x, p.y - 90, `-${d}`, '#ff5a5a');
    this.spawnParticles(p.x, p.y - 40, 10, '#ff5a5a', 180, 3, 500, 0.5);
    this.input.vibrate(150, 0.5);
    sfx.play(160, 0.2, 'sawtooth', 0.05, -80);
    if (p.hp <= 0) {
      p.hp = 0;
      this.mode = 'dead';
      this.onEvent({ type: 'dead' });
    }
  }

  damageEnemy(e: Enemy, dmg: number, dir: number, core = false) {
    if (e.dead) return;
    const d = core ? dmg * 2 : dmg;
    e.hp -= d;
    e.flash = 0.12;
    if (e.kind !== 'ex') {
      e.vx += dir * 120;
      e.vy = -150;
    }
    const r = this.enemyRect(e);
    this.addText(e.x, r.y - 10, `-${d}${core ? ' ✦' : ''}`, core ? '#ffd166' : '#fff');
    this.spawnParticles(e.x, r.y + r.h / 2, 8, '#c084fc', 150, 3, 400, 0.5);
    sfx.play(260, 0.06, 'square', 0.03, -100);
    if (e.hp <= 0) {
      e.hp = 0;
      e.dead = true;
      if (e.kind === 'meteor') {
        this.spawnParticles(e.x, e.y, 20, '#ff9f1c', 250, 4, 300, 0.7);
        this.addText(e.x, e.y - 30, 'نابود شد!', '#ffd166');
        return;
      }
      this.kills++;
      this.spawnParticles(e.x, r.y + r.h / 2, e.kind === 'ex' ? 120 : 25, e.kind === 'ex' ? '#ff5a5a' : '#a855f7', e.kind === 'ex' ? 500 : 250, 5, 300, 1);
      sfx.play(120, 0.3, 'sawtooth', 0.05, -100);
      if (e === this.boss) this.bossDefeated(e);
    }
  }

  bossDefeated(e: Enemy) {
    e.state = 'dead';
    e.stateT = 0;
    this.shake = 20;
    this.flash = 1;
    this.flashColor = '#fff';
    // remove remaining minions
    for (const m of this.enemies) if (!m.dead) {
      m.dead = true;
      this.spawnParticles(m.x, m.y - 30, 15, '#a855f7', 200, 3, 300, 0.7);
    }
    setTimeout(() => this.finishLevel(), 1500);
  }

  finishLevel() {
    if (this.mode === 'complete' || this.mode === 'dead') return;
    this.mode = 'outro';
    if (this.level.friendOnComplete) {
      this.friendMade = this.level.friendOnComplete;
      this.onEvent({ type: 'friend', name: this.level.friendOnComplete });
    }
    this.showDialog(this.level.outro, () => {
      this.mode = 'complete';
      if (this.level.unlock && !this.level.craterAt) this.onEvent({ type: 'unlock', form: this.level.unlock });
      this.onEvent({
        type: 'complete',
        result: { levelId: this.level.id, kills: this.kills, friend: this.friendMade, unlock: this.level.unlock, timeSec: Math.round(this.levelTime), hpLeft: Math.round(this.player.hp) },
      });
    });
  }

  checkTriggers() {
    const p = this.player;
    const L = this.level;
    // mid-level crater: get the watch
    if (L.craterAt && !this.craterDone && p.x > this.craterX - 60) {
      this.craterDone = true;
      p.hasWatch = true;
      this.unlocked = FORM_ORDER.filter((f) => L.available.includes(f));
      this.flash = 1;
      this.flashColor = '#00FF7F';
      this.shake = 8;
      this.spawnParticles(this.craterX, GROUND - 20, 60, '#00FF7F', 350, 5, 100, 1.2);
      sfx.play(300, 0.6, 'sine', 0.06, 900);
      this.input.vibrate(400, 1);
      if (L.unlock) this.onEvent({ type: 'unlock', form: L.unlock });
      this.showDialog(L.craterDialog ?? [], () => {
        this.mode = 'play';
        this.setHint('Q: باز کردن ساعت  •  E: تبدیل  •  K: قاچ زمین  •  J: حمله', 6);
      });
      return;
    }
    // moral questions (level 10)
    if (L.questions && this.questionIdx < L.questions.length && p.x > this.questionXs[this.questionIdx] - 30) {
      const q = L.questions[this.questionIdx];
      this.questionIdx++;
      this.flash = 0.6;
      this.flashColor = '#a78bfa';
      this.spawnParticles(p.x, p.y - 60, 40, '#a78bfa', 250, 4, -50, 1);
      sfx.play(440, 0.4, 'sine', 0.05, 440);
      this.showDialog([q], () => {
        this.mode = 'play';
        if (this.questionIdx >= (L.questions?.length ?? 0)) {
          if (!this.unlocked.includes('alienx')) this.unlocked.push('alienx');
          this.wheelIdx = this.unlocked.length - 1;
          this.flash = 1;
          this.flashColor = '#a78bfa';
          this.spawnParticles(p.x, p.y - 50, 80, '#a78bfa', 400, 5, 0, 1.4);
          this.setHint('ژن کیهانی ایلان ایکس آزاد شد! Q را بزن و امتحانش کن، بعد به سمت نور برو.', 6);
        }
      });
      return;
    }
    // defend mode (level 18)
    if (L.defend && !this.defendStarted && p.x > this.towerX - 500) {
      this.defendStarted = true;
      this.defendT = L.defend;
      this.defendWaveT = 1;
      this.setHint('از برج دفاع کن! دوستانت سلامتی‌ات را پر می‌کنند.', 4);
      sfx.play(600, 0.3, 'square', 0.04, 300);
    }
    // level end
    const questionsDone = !L.questions || this.questionIdx >= L.questions.length;
    if (!L.boss && !L.defend && questionsDone && p.x > L.length - 140) {
      this.finishLevel();
      return;
    }
    if (L.questions && !questionsDone && p.x > L.length - 140) p.x = L.length - 140;
    // boss intro
    if (this.boss && this.boss.kind === 'ex' && !this.bossIntroDone && p.x > this.boss.x - 1000) {
      this.bossIntroDone = true;
      this.shake = 14;
      sfx.play(60, 1, 'sawtooth', 0.1, -20);
      this.setHint('هسته‌ی سرخ روی سینه‌ی اِکس را هدف بگیر! موج زمینی: بپر — چشم‌های سفید: بنشین!', 6);
    }
    if (this.boss && this.boss.kind === 'goliath' && !this.bossIntroDone && p.x > this.boss.x - 800) {
      this.bossIntroDone = true;
      this.boss.state = 'walk';
      this.shake = 10;
      sfx.play(80, 0.8, 'sawtooth', 0.08, -30);
      this.setHint('گولیات! وقتی دستش بالا رفت بپر، وقتی توپش درخشید بنشین.', 5);
    }
  }

  updateSpecials(dt: number) {
    const L = this.level;
    const p = this.player;
    // watch malfunction: random switching
    if (L.malfunction && p.hasWatch) {
      this.malfunctionT -= dt;
      if (this.malfunctionT <= 0) {
        this.malfunctionT = 5 + Math.random() * 4;
        const pool = this.unlocked.filter((f) => f !== p.form);
        if (pool.length) {
          const f = pool[Math.floor(Math.random() * pool.length)];
          const keep = p.form !== 'human' ? p.formTime : this.formDuration * 0.6;
          this.transform(f);
          p.formTime = Math.max(6, keep);
          this.flashColor = '#c084fc';
          this.addText(p.x, p.y - 140, 'اتصال کوتاه ساعت!', '#c084fc');
          sfx.play(1200, 0.3, 'sawtooth', 0.05, -900);
        }
      }
    }
    // meteor rain
    if (L.meteorRain || (this.boss?.kind === 'ex' && this.boss.state === 'meteor')) {
      this.meteorT -= dt;
      if (this.meteorT <= 0) {
        this.meteorT = L.meteorRain ? 1.6 + Math.random() * 1.2 : 0.5;
        const rnd = seededRandom(Math.floor(this.time * 997));
        const m = this.makeEnemy('meteor', p.x + (Math.random() - 0.3) * 900, rnd);
        m.x = Math.max(60, Math.min(L.length - 60, m.x));
        this.enemies.push(m);
      }
    }
    // defend tower
    if (this.defendStarted && this.defendT > 0) {
      this.defendT -= dt;
      this.defendWaveT -= dt;
      if (this.defendWaveT <= 0) {
        this.defendWaveT = 7;
        const rnd = seededRandom(Math.floor(this.time * 331));
        const kinds: EnemyKind[] = ['grunt', 'grunt', 'scout', 'brute', 'scout'];
        for (let i = 0; i < 3; i++) {
          const k = kinds[Math.floor(rnd() * kinds.length)];
          const side = i % 2 === 0 ? -1 : 1;
          const e = this.makeEnemy(k, this.towerX + side * (700 + rnd() * 200), rnd);
          e.patrolL = this.towerX - 600;
          e.patrolR = this.towerX + 600;
          this.enemies.push(e);
          this.spawnParticles(e.x, GROUND - 40, 12, '#a855f7', 180, 3, 200, 0.6);
        }
        // friends heal
        if (p.hp < p.maxHp) {
          p.hp = Math.min(p.maxHp, p.hp + 12);
          this.addText(this.towerX, GROUND - 260, '+12 ❤ دوستان', '#ff6b9d');
        }
      }
      // keep player near tower
      if (Math.abs(p.x - this.towerX) > 720) p.x = this.towerX + Math.sign(p.x - this.towerX) * 720;
      if (this.defendT <= 0) {
        for (const m of this.enemies) if (!m.dead) { m.dead = true; this.spawnParticles(m.x, m.y - 30, 12, '#a855f7', 200, 3, 300, 0.7); }
        this.flash = 1;
        this.flashColor = '#00FF7F';
        this.finishLevel();
      }
    }
  }

  explodeMeteor(e: Enemy) {
    if (e.dead) return;
    e.dead = true;
    this.shake = 8;
    this.spawnParticles(e.x, GROUND - 10, 30, '#ff6a00', 300, 5, 500, 0.8);
    sfx.play(90, 0.4, 'sawtooth', 0.07, -60);
  }

  /* ---------------- enemies ---------------- */
  updateEnemies(dt: number) {
    const p = this.player;
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (e.flash > 0) e.flash -= dt;
      if (this.freezeT > 0 && e.kind !== 'meteor') continue;
      e.timer -= dt;
      const dx = p.x - e.x;
      const dist = Math.abs(dx);
      if (e.kind === 'scout') {
        if (dist < 580) {
          e.facing = Math.sign(dx) || 1;
          const want = dist > 340 ? 110 : dist < 220 ? -90 : 0;
          e.vx += (e.facing * want - e.vx) * dt * 4;
          if (e.timer <= 0 && dist < 540) {
            e.timer = 2.2 + Math.random() * 0.9;
            const high = Math.random() < 0.4;
            this.projectiles.push({ x: e.x + e.facing * 32, y: e.y - (high ? 52 : 22), vx: e.facing * 400, vy: 0, r: 5, dmg: 8, owner: 'enemy', kind: 'laser', life: 2 });
            sfx.play(1400, 0.08, 'square', 0.02, -600);
          }
        } else {
          e.vx += (e.facing * 60 - e.vx) * dt * 3;
          if (e.x < e.patrolL) e.facing = 1;
          if (e.x > e.patrolR) e.facing = -1;
        }
        this.moveWithCollisions(e, e.w, dt);
      } else if (e.kind === 'grunt') {
        if (dist < 460) {
          e.facing = Math.sign(dx) || 1;
          e.vx += (e.facing * 130 - e.vx) * dt * 6;
          if (e.onGround && p.y < e.y - 70 && e.timer <= 0 && dist < 150) {
            e.vy = -620;
            e.timer = 1.5;
          }
        } else {
          e.vx += (e.facing * 60 - e.vx) * dt * 4;
          if (e.x < e.patrolL) e.facing = 1;
          if (e.x > e.patrolR) e.facing = -1;
        }
        this.moveWithCollisions(e, e.w, dt);
      } else if (e.kind === 'brute') {
        e.stateT += dt;
        if (e.state === 'charge') {
          e.vx += (e.facing * 480 - e.vx) * dt * 8;
          if (e.stateT > 1.1) {
            e.state = 'rest';
            e.stateT = 0;
            this.shake = 5;
          }
        } else if (e.state === 'rest') {
          e.vx *= 0.85;
          if (e.stateT > 1.4) {
            e.state = 'patrol';
            e.stateT = 0;
          }
        } else {
          if (dist < 520 && e.timer <= 0) {
            e.facing = Math.sign(dx) || 1;
            e.state = 'charge';
            e.stateT = 0;
            e.timer = 3;
            sfx.play(100, 0.3, 'sawtooth', 0.05, 60);
          } else {
            e.vx += (e.facing * 50 - e.vx) * dt * 4;
            if (e.x < e.patrolL) e.facing = 1;
            if (e.x > e.patrolR) e.facing = -1;
          }
        }
        this.moveWithCollisions(e, e.w, dt);
      } else if (e.kind === 'shark') {
        const pWet = this.inWater(p.x, p.y - 30);
        const surf = this.surfaceAt(e.x);
        if (pWet && dist < 420) {
          e.facing = Math.sign(dx) || 1;
          e.vx += (e.facing * 190 - e.vx) * dt * 3;
          const ty = p.y - 35;
          e.y += (ty - e.y) * dt * 1.8;
        } else {
          e.vx += (e.facing * 80 - e.vx) * dt * 2;
          if (e.x < e.patrolL) e.facing = 1;
          if (e.x > e.patrolR) e.facing = -1;
          e.y += (e.baseY + Math.sin(this.time * 2 + e.x) * 20 - e.y) * dt * 2;
        }
        e.x += e.vx * dt;
        e.y = Math.max(surf + 25, Math.min(GROUND - 20, e.y));
        if (!this.inWater(e.x, e.y)) e.x -= e.vx * dt * 2;
      } else if (e.kind === 'tank') {
        if (dist < 700) {
          e.facing = Math.sign(dx) || 1;
          e.vx += (e.facing * (dist > 320 ? 60 : 0) - e.vx) * dt * 3;
          if (e.timer <= 0) {
            e.timer = 2.8;
            const vx = e.facing * 300;
            this.projectiles.push({ x: e.x + e.facing * 70, y: e.y - 70, vx, vy: -380, r: 8, dmg: 14, owner: 'enemy', kind: 'shell', life: 3 });
            this.spawnParticles(e.x + e.facing * 80, e.y - 70, 8, '#ddd', 100, 3, 0, 0.4);
            sfx.play(120, 0.2, 'square', 0.05, -60);
          }
        } else e.vx *= 0.9;
        this.moveWithCollisions(e, e.w, dt);
      } else if (e.kind === 'meteor') {
        e.vy += 120 * dt;
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        if (Math.random() < 0.5) this.particles.push({ x: e.x, y: e.y, vx: 30, vy: -80, life: 0.4, max: 0.4, color: '#ff9f1c', size: 4, grav: -100 });
        if (e.y >= GROUND - 10) {
          this.explodeMeteor(e);
          if (Math.abs(p.x - e.x) < 90 && p.y > GROUND - 60) this.hurtPlayer(14, Math.sign(p.x - e.x) || 1);
          this.addText(e.x, GROUND - 40, 'بوم!', '#ff6a00');
        }
      }
    }
  }

  updateBoss(b: Enemy, dt: number) {
    if (this.freezeT > 0) return;
    const p = this.player;
    if (b.flash > 0) b.flash -= dt;
    b.stateT += dt;
    if (b.kind === 'goliath') {
      const dx = p.x - b.x;
      b.timer -= dt;
      if (b.state === 'wait') {
        b.vx *= 0.9;
      } else if (b.state === 'walk') {
        b.facing = Math.sign(dx) || 1;
        b.vx += (b.facing * 90 - b.vx) * dt * 4;
        if (b.timer <= 0) {
          if (Math.abs(dx) < 260) { b.state = 'slam'; b.stateT = 0; b.timer = 2.2; }
          else { b.state = 'shoot'; b.stateT = 0; b.timer = 2.6; }
        }
      } else if (b.state === 'slam') {
        b.vx *= 0.8;
        if (b.stateT >= 0.7 && b.stateT - dt < 0.7) {
          this.shake = 14;
          this.input.vibrate(300, 0.9);
          sfx.play(60, 0.5, 'sawtooth', 0.1, -20);
          this.spawnParticles(b.x - b.facing * 85, GROUND, 30, '#9ca3af', 260, 5, 500, 0.8);
          this.projectiles.push({ x: b.x, y: GROUND - 20, vx: b.facing * 460, vy: 0, r: 20, dmg: 14, owner: 'enemy', kind: 'wave', life: 2 });
        }
        if (b.stateT > 1.3) { b.state = 'walk'; b.stateT = 0; }
      } else if (b.state === 'shoot') {
        b.vx *= 0.8;
        if (b.stateT >= 0.8 && b.stateT - dt < 0.8) {
          for (let i = -1; i <= 1; i++) this.projectiles.push({ x: b.x + b.facing * 120, y: b.y - 130, vx: b.facing * 420, vy: i * 90 - 40, r: 7, dmg: 10, owner: 'enemy', kind: 'crystal', life: 2.5 });
          sfx.play(1300, 0.15, 'triangle', 0.05, -500);
        }
        if (b.stateT > 1.4) { b.state = 'walk'; b.stateT = 0; }
      }
      this.moveWithCollisions(b, b.w, dt);
      if (b.state === 'slam' && b.stateT < 0.1 && b.stateT + dt >= 0.1) this.setHint('کوبش! بپر!', 1);
      if (b.state === 'shoot' && b.stateT < 0.1 && b.stateT + dt >= 0.1) this.setHint('شلیک کریستال! بنشین!', 1);
      return;
    }
    // EX
    const alive = this.enemies.filter((e) => !e.dead && e.kind === 'scout').length;
    switch (b.state) {
      case 'idle':
        if (b.stateT > b.timer) {
          const r = Math.random();
          if (alive < 2 && r < 0.2) {
            b.state = 'summon';
          } else if (r < 0.4 && b.hp < b.maxHp * 0.7) {
            b.state = 'meteor';
            this.meteorT = 0.3;
            this.setHint('باران شهاب‌سنگ! سنگ‌ها را در هوا بزن!', 2);
          } else if (r < 0.7) {
            b.state = 'stomp';
          } else {
            b.state = 'beam';
          }
          b.stateT = 0;
        }
        break;
      case 'hurt':
        if (b.stateT > 0.25) {
          b.state = 'idle';
          b.stateT = 0;
          b.timer = 0.8 + Math.random();
        }
        break;
      case 'stomp':
        if (b.stateT >= 0.8 && b.stateT - dt < 0.8) {
          this.shake = 18;
          this.input.vibrate(400, 1);
          sfx.play(50, 0.6, 'sawtooth', 0.12, -20);
          this.spawnParticles(b.x + 60, GROUND, 40, '#9ca3af', 300, 5, 500, 0.8);
          this.projectiles.push({ x: b.x - 40, y: GROUND - 20, vx: -520, vy: 0, r: 22, dmg: 16, owner: 'enemy', kind: 'wave', life: 3 });
        }
        if (b.stateT > 1.6) {
          b.state = 'idle';
          b.stateT = 0;
          b.timer = 1.2 + Math.random() * 1.2;
        }
        break;
      case 'beam':
        if (b.stateT >= 1.2 && b.stateT - dt < 1.2) {
          this.beams.push({ x1: b.x - 1100, x2: b.x + 60, y: GROUND - 95, life: 0.7, hitPlayer: false });
          sfx.play(900, 0.7, 'sawtooth', 0.07, -600);
          this.shake = 6;
        }
        if (b.stateT > 2.2) {
          b.state = 'idle';
          b.stateT = 0;
          b.timer = 1.5 + Math.random();
        }
        break;
      case 'meteor':
        if (b.stateT > 3.5) {
          b.state = 'idle';
          b.stateT = 0;
          b.timer = 1.5;
        }
        break;
      case 'summon':
        if (b.stateT > 0.6) {
          const rnd = seededRandom(Math.floor(this.time * 1000));
          for (let i = 0; i < 2; i++) {
            const d = this.makeEnemy('scout', b.x - 300 - i * 120, rnd);
            this.enemies.push(d);
            this.spawnParticles(d.x, d.y - 30, 15, '#a855f7', 200, 4, 0, 0.6);
          }
          b.state = 'idle';
          b.stateT = 0;
          b.timer = 2;
        }
        break;
    }
    // stomp telegraph hint
    if (b.state === 'stomp' && b.stateT < 0.1 && b.stateT + dt >= 0.1) this.setHint('موج زمینی! بپر!', 1.2);
    if (b.state === 'beam' && b.stateT < 0.1 && b.stateT + dt >= 0.1) this.setHint('لیزر چشم! بنشین (S / پایین)!', 1.4);
  }

  updateAlly(k: Ally, dt: number) {
    const p = this.player;
    if (k.attackCd > 0) k.attackCd -= dt;
    if (k.attackT > 0) k.attackT -= dt * 4;
    if (k.absorbT > 0) {
      k.absorbT -= dt;
      if (k.absorbT <= 0) k.absorb = null;
    }
    const off = k.kind === 'kevin' ? 80 : 140;
    const targetX = p.x - p.facing * off;
    const dx = targetX - k.x;
    const want = Math.abs(dx) > 30 ? Math.sign(dx) * Math.min(440, Math.abs(dx) * 3) : 0;
    k.vx += (want - k.vx) * Math.min(1, dt * 8);
    if (Math.abs(k.vx) > 20) k.facing = Math.sign(k.vx);
    if (this.inWater(k.x, k.y - 35)) {
      const surf = this.surfaceAt(k.x);
      const ty = Math.max(surf + 60, Math.min(GROUND, p.y));
      k.vy += ((ty - k.y) * 3 - k.vy) * Math.min(1, dt * 3);
      k.x += k.vx * dt * 0.7;
      k.y += k.vy * dt;
      if (k.y > GROUND) k.y = GROUND;
      k.onGround = k.y >= GROUND;
      if (Math.random() < 0.05) this.particles.push({ x: k.x, y: k.y - 60, vx: 0, vy: -50, life: 1, max: 1, color: 'rgba(255,255,255,0.6)', size: 2.5, grav: -30 });
    } else {
      if (k.onGround && p.y < k.y - 70 && Math.abs(p.x - k.x) < 220) k.vy = -700;
      this.moveWithCollisions(k, 34, dt);
    }
    if (Math.abs(p.x - k.x) > 900 || Math.abs(p.y - k.y) > 500) {
      k.x = p.x - p.facing * off;
      k.y = Math.min(GROUND, p.y);
      k.vy = 0;
      this.spawnParticles(k.x, k.y - 40, 12, k.kind === 'gwen' ? '#f472b6' : '#cbd5e1', 150, 3, 0, 0.5);
    }
    const targets = [...this.enemies.filter((e) => e.kind !== 'meteor' || k.kind === 'gwen'), ...(this.boss ? [this.boss] : [])];
    if (k.kind === 'kevin') {
      if (p.form !== 'human' && Math.abs(p.x - k.x) < 40 && Math.abs(p.y - k.y) < 40) {
        const col = p.form === 'alienx' ? '#a78bfa' : FORMS[p.form].color;
        if (k.absorb !== col) {
          k.absorb = col;
          k.absorbT = 20;
          this.addText(k.x, k.y - 90, 'جذب شد!', col);
          this.spawnParticles(k.x, k.y - 40, 15, col, 150, 3, 0, 0.6);
        }
      }
      if (k.attackCd <= 0) {
        for (const e of targets) {
          if (e.dead) continue;
          const r = this.enemyRect(e);
          const near = Math.abs(e.x - k.x) < (e.kind === 'ex' ? 160 : e.kind === 'goliath' ? 110 : 75) && r.y < k.y && r.y + r.h > k.y - 90;
          if (near) {
            k.facing = Math.sign(e.x - k.x) || 1;
            k.attackT = 1;
            k.attackCd = 0.9;
            this.damageEnemy(e, k.absorb ? 18 : 9, k.facing);
            break;
          }
        }
      }
    } else if (k.attackCd <= 0) {
      // Gwen: pink energy discs
      let best: Enemy | null = null;
      let bd = 520;
      for (const e of targets) {
        if (e.dead) continue;
        const d = Math.hypot(e.x - k.x, (e.kind === 'ex' ? e.y - 285 : this.enemyRect(e).y + this.enemyRect(e).h / 2) - (k.y - 50));
        if (d < bd) {
          bd = d;
          best = e;
        }
      }
      if (best) {
        const r = this.enemyRect(best);
        const ty = best.kind === 'ex' ? best.y - 285 : r.y + r.h / 2;
        const ang = Math.atan2(ty - (k.y - 50), best.x - k.x);
        k.facing = Math.sign(best.x - k.x) || 1;
        k.attackT = 1;
        k.attackCd = 1.15;
        this.projectiles.push({ x: k.x + k.facing * 18, y: k.y - 50, vx: Math.cos(ang) * 560, vy: Math.sin(ang) * 560, r: 11, dmg: 12, owner: 'player', kind: 'disc', life: 1.4 });
        sfx.play(1000, 0.08, 'sine', 0.025, 400);
      }
    }
  }

  updateProjectiles(dt: number) {
    const p = this.player;
    const pr = this.playerRect;
    for (const pj of this.projectiles) {
      const pdt = pj.owner === 'enemy' ? dt * this.timeScale : dt;
      pj.life -= pdt;
      if (pj.kind === 'rock' || pj.kind === 'shell') pj.vy += GRAVITY * 0.7 * pdt;
      pj.x += pj.vx * pdt;
      pj.y += pj.vy * pdt;
      if ((pj.kind === 'rock' || pj.kind === 'shell') && pj.y > GROUND) {
        pj.life = 0;
        this.spawnParticles(pj.x, GROUND, 10, '#ddd', 150, 3, 400, 0.4);
      }
      if (pj.kind === 'cosmic' && Math.random() < 0.7) this.particles.push({ x: pj.x, y: pj.y + (Math.random() - 0.5) * 20, vx: 0, vy: 0, life: 0.4, max: 0.4, color: '#fff', size: 2, grav: 0 });
      if (pj.kind === 'fire' && Math.random() < 0.6) this.particles.push({ x: pj.x, y: pj.y, vx: -pj.vx * 0.1, vy: -40, life: 0.3, max: 0.3, color: '#ffb347', size: 5, grav: -200 });
      if (pj.owner === 'player') {
        const targets = [...this.enemies, ...(this.boss ? [this.boss] : [])];
        for (const e of targets) {
          if (e.dead) continue;
          const r = this.enemyRect(e);
          if (pj.x > r.x && pj.x < r.x + r.w && pj.y > r.y && pj.y < r.y + r.h) {
            let core = false;
            if (e.kind === 'ex') {
              const sway = Math.sin(this.time * 1.3) * 6;
              core = Math.abs(pj.x - e.x) < 32 && Math.abs(pj.y - (e.y - 285 + sway)) < 48;
            }
            this.damageEnemy(e, pj.dmg, Math.sign(pj.vx) || 1, core);
            if (pj.kind !== 'cosmic') {
              pj.life = 0;
              break;
            }
          }
        }
      } else {
        if (pj.kind === 'wave') {
          // only hits grounded player
          const hit = Math.abs(pj.x - p.x) < 30 && p.y > GROUND - 30;
          if (hit) {
            this.hurtPlayer(pj.dmg, Math.sign(pj.vx) || 1);
          }
          if (Math.random() < 0.8) this.particles.push({ x: pj.x, y: GROUND, vx: (Math.random() - 0.5) * 100, vy: -200 - Math.random() * 200, life: 0.5, max: 0.5, color: '#a3a3a3', size: 4, grav: 600 });
          // breaks platforms? no. kills kevin? no.
        } else if (pj.x > pr.x && pj.x < pr.x + pr.w && pj.y > pr.y && pj.y < pr.y + pr.h) {
          this.hurtPlayer(pj.dmg, Math.sign(pj.vx) || 1);
          pj.life = 0;
        }
      }
      if (pj.x < -100 || pj.x > this.level.length + 100 || pj.y < -200 || pj.y > H + 100) pj.life = 0;
    }
    this.projectiles = this.projectiles.filter((q) => q.life > 0);
  }

  updateCracks(dt: number) {
    for (const c of this.cracks) {
      c.life -= dt;
      c.len = Math.min(440, c.len + dt * 1500);
      if (Math.random() < 0.9) {
        const px = c.x + c.dir * Math.random() * c.len;
        this.particles.push({ x: px, y: GROUND, vx: (Math.random() - 0.5) * 60, vy: -150 - Math.random() * 250, life: 0.6, max: 0.6, color: Math.random() < 0.5 ? '#7CFC00' : '#8b8b8b', size: 4, grav: 700 });
      }
      const targets = [...this.enemies, ...(this.boss ? [this.boss] : [])];
      for (const e of targets) {
        if (e.dead || c.hit.has(e) || e.kind === 'meteor') continue;
        const r = this.enemyRect(e);
        const onGround = r.y + r.h > GROUND - 40;
        const inRange = c.dir > 0 ? e.x > c.x - 20 && e.x < c.x + c.len + r.w / 2 : e.x < c.x + 20 && e.x > c.x - c.len - r.w / 2;
        if (onGround && inRange) {
          c.hit.add(e);
          this.damageEnemy(e, e.kind === 'ex' ? 40 : e.kind === 'tank' ? 60 : 28, c.dir);
          if (e.kind !== 'ex' && e.kind !== 'goliath') e.vy = -400;
        }
      }
    }
    this.cracks = this.cracks.filter((c) => c.life > 0);
  }

  updateBeams(dt: number) {
    const p = this.player;
    for (const b of this.beams) {
      b.life -= dt;
      if (!b.hitPlayer && p.x > b.x1 && p.x < b.x2) {
        const top = p.y - (p.crouch ? this.form.h * 0.6 : this.form.h);
        if (top < b.y + 18 && p.y > b.y - 18) {
          b.hitPlayer = true;
          this.hurtPlayer(20, -1);
        }
      }
    }
    this.beams = this.beams.filter((b) => b.life > 0);
  }

  updateParticles(dt: number) {
    for (const pt of this.particles) {
      pt.life -= dt;
      pt.vy += pt.grav * dt;
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
    }
    this.particles = this.particles.filter((q) => q.life > 0);
    for (const t of this.texts) {
      t.life -= dt;
      t.y -= 40 * dt;
    }
    this.texts = this.texts.filter((q) => q.life > 0);
    if (this.boss && this.boss.dead) this.boss.stateT += dt;
    for (const e of this.enemies) if (e.flash > 0) e.flash -= dt;
  }

  /* ---------------- render ---------------- */
  render() {
    const ctx = this.ctx;
    const L = this.level;
    const t = this.time;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const sx = this.shake > 0 ? (Math.random() - 0.5) * this.shake : 0;
    const sy = this.shake > 0 ? (Math.random() - 0.5) * this.shake : 0;
    ctx.translate(sx, sy);

    drawSky(ctx, W, H, L.theme, t, this.scene, this.camX);
    if (L.theme === 'cosmic') drawCosmic(ctx, W, GROUND, this.camX, t);
    else if (L.theme === 'subway' || L.theme === 'ship') this.drawInterior(ctx);
    else {
      if (L.exBackground) drawExBackground(ctx, W, GROUND, this.camX, t);
      drawBuildings(ctx, this.scene, this.camX, GROUND, L.theme, t);
    }
    if (L.meteorRain) {
      ctx.fillStyle = 'rgba(120,40,160,0.25)';
      ctx.fillRect(0, 0, W, H);
    }
    if (L.id === 20 || L.storm) this.drawRain(ctx);

    // world space
    ctx.save();
    ctx.translate(-this.camX, 0);

    // boss behind foreground props
    if (this.boss && this.boss.kind === 'ex' && (!this.boss.dead || this.boss.stateT < 3)) {
      drawEx(ctx, this.boss.x, this.boss.y, -1, t, this.boss.dead ? 'dead' : this.boss.flash > 0 ? 'hurt' : (this.boss.state as 'idle' | 'stomp' | 'beam'), this.boss.stateT, this.boss.hp / this.boss.maxHp);
    }

    ctx.restore();
    drawGroundAndProps(ctx, this.scene, this.camX, GROUND, W, H, L.theme, t);
    ctx.save();
    ctx.translate(-this.camX, 0);

    // platforms
    for (const pl of this.platforms) {
      if (pl.x + pl.w < this.camX - 50 || pl.x > this.camX + W + 50) continue;
      ctx.fillStyle = L.theme === 'ship' ? '#5b21b6' : L.theme === 'park' ? '#7c5a3a' : '#475569';
      rr(ctx, pl.x, pl.y, pl.w, pl.h, 5);
      ctx.fill();
      ctx.fillStyle = L.theme === 'ship' ? '#a78bfa' : L.theme === 'park' ? '#3f9a46' : '#94a3b8';
      rr(ctx, pl.x, pl.y, pl.w, 6, 3);
      ctx.fill();
      // supports
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      ctx.fillRect(pl.x + 10, pl.y + pl.h, 6, GROUND - pl.y - pl.h);
      ctx.fillRect(pl.x + pl.w - 16, pl.y + pl.h, 6, GROUND - pl.y - pl.h);
    }

    // crater (level 1)
    if (L.craterAt && !this.craterDone) {
      ctx.fillStyle = '#3a2a2a';
      ctx.beginPath();
      ctx.ellipse(this.craterX, GROUND + 6, 110, 26, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#5a4040';
      ctx.beginPath();
      ctx.ellipse(this.craterX, GROUND + 4, 80, 16, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#374151';
      ctx.beginPath();
      ctx.arc(this.craterX, GROUND - 14, 26, 0, Math.PI * 2);
      ctx.fill();
      const g = 0.6 + 0.4 * Math.sin(t * 5);
      ctx.shadowColor = '#00FF7F';
      ctx.shadowBlur = 40 * g;
      drawWatch(ctx, this.craterX, GROUND - 14, 12, 'ready', t);
      ctx.shadowBlur = 0;
      if (Math.random() < 0.3) this.particles.push({ x: this.craterX + (Math.random() - 0.5) * 80, y: GROUND, vx: 0, vy: -40, life: 1.5, max: 1.5, color: 'rgba(200,200,200,0.4)', size: 10, grav: -20 });
    }
    // question orbs (level 10)
    if (L.questions) {
      this.questionXs.forEach((qx, i) => {
        if (i < this.questionIdx) return;
        ctx.fillStyle = i % 2 ? '#f9a8d4' : '#f87171';
        ctx.shadowColor = ctx.fillStyle;
        ctx.shadowBlur = 30;
        ctx.beginPath();
        ctx.arc(qx, GROUND - 90 + Math.sin(t * 2 + i) * 10, 22, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#fff';
        ctx.font = `bold 22px ${FONT}`;
        ctx.textAlign = 'center';
        ctx.fillText('?', qx, GROUND - 82 + Math.sin(t * 2 + i) * 10);
      });
    }
    // defend tower (level 18)
    if (L.defend) {
      const tx = this.towerX;
      if (L.theme === 'forest') {
        ctx.fillStyle = '#5b3a1e';
        ctx.fillRect(tx - 30, GROUND - 260, 60, 260);
        ctx.fillStyle = '#22c55e';
        ctx.shadowColor = '#86efac';
        ctx.shadowBlur = 30;
        ctx.beginPath();
        ctx.arc(tx, GROUND - 300, 110, 0, Math.PI * 2);
        ctx.arc(tx - 90, GROUND - 240, 70, 0, Math.PI * 2);
        ctx.arc(tx + 90, GROUND - 240, 70, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      } else if (L.theme === 'beach') {
        ctx.fillStyle = '#f8fafc';
        ctx.beginPath();
        ctx.moveTo(tx - 34, GROUND);
        ctx.lineTo(tx - 20, GROUND - 300);
        ctx.lineTo(tx + 20, GROUND - 300);
        ctx.lineTo(tx + 34, GROUND);
        ctx.fill();
        ctx.fillStyle = '#ef4444';
        for (let i = 0; i < 4; i++) ctx.fillRect(tx - 30 + i * 3, GROUND - 60 - i * 70, 60 - i * 6, 26);
        ctx.fillStyle = `rgba(255,240,150,${0.6 + 0.4 * Math.sin(t * 3)})`;
        ctx.beginPath();
        ctx.moveTo(tx, GROUND - 316);
        ctx.lineTo(tx + 400 * Math.cos(t), GROUND - 340);
        ctx.lineTo(tx + 400 * Math.cos(t), GROUND - 290);
        ctx.fill();
      }
      ctx.fillStyle = '#334155';
      if (L.theme !== 'forest' && L.theme !== 'beach') ctx.fillRect(tx - 14, GROUND - 300, 28, 300);
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 3;
      for (let i = 0; i < 6; i++) {
        ctx.beginPath();
        ctx.moveTo(tx - 40 + i * 4, GROUND - i * 50);
        ctx.lineTo(tx + 40 - i * 4, GROUND - i * 50);
        ctx.stroke();
      }
      ctx.fillStyle = '#ef4444';
      ctx.globalAlpha = 0.5 + 0.5 * Math.sin(t * 4);
      ctx.beginPath();
      ctx.arc(tx, GROUND - 306, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
      if (this.defendStarted) {
        ctx.strokeStyle = `rgba(0,255,127,${0.4 + 0.3 * Math.sin(t * 6)})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(tx, GROUND - 306, 30 + (t * 60) % 60, 0, Math.PI * 2);
        ctx.stroke();
      }
      // friends cheering at tower base
      drawNpc(ctx, tx - 70, GROUND, t, '#facc15', true, 'girl');
      drawNpc(ctx, tx + 70, GROUND, t, '#3b82f6', true, 'boy');
      drawNpc(ctx, tx + 110, GROUND, t, '#fff', true, 'cat');
    }
    // finish flag
    if (!L.boss && !L.defend) {
      const fx = L.length - 110;
      ctx.fillStyle = '#e5e7eb';
      ctx.fillRect(fx - 3, GROUND - 160, 6, 160);
      ctx.fillStyle = L.theme === 'cosmic' ? '#a78bfa' : '#22c55e';
      ctx.beginPath();
      ctx.moveTo(fx + 3, GROUND - 160);
      ctx.lineTo(fx + 70 + Math.sin(t * 4) * 5, GROUND - 140);
      ctx.lineTo(fx + 3, GROUND - 120);
      ctx.fill();
    }

    // Grandpa Max's RV
    if (L.maxRV && this.rvX > this.camX - 300 && this.rvX < this.camX + W + 300) drawRV(ctx, this.rvX, GROUND, t, this.rvUsed);
    // npc
    if (L.npc) drawNpc(ctx, this.npcX, GROUND, t, L.npc.color, this.npcTalked, L.npc.kind);

    // enemies
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (e.x < this.camX - 150 || e.x > this.camX + W + 150) continue;
      if (e.kind === 'scout') drawScout(ctx, e.x, e.y, e.facing, t + e.x, Math.abs(e.vx) > 10, e.flash > 0);
      else if (e.kind === 'grunt') drawGrunt(ctx, e.x, e.y, e.facing, t + e.x, Math.abs(e.vx) > 10, e.flash > 0);
      else if (e.kind === 'brute') drawBrute(ctx, e.x, e.y, e.facing, t + e.x, Math.abs(e.vx) > 10, e.flash > 0, e.state === 'charge');
      else if (e.kind === 'tank') drawTank(ctx, e.x, e.y, e.facing, t, e.flash > 0);
      else if (e.kind === 'meteor') drawMeteor(ctx, e.x, e.y, 20, t);
      else if (e.kind === 'shark') drawShark(ctx, e.x, e.y, e.facing, t + e.x, e.flash > 0);
      // hp bar
      if (e.hp < e.maxHp) {
        const r = this.enemyRect(e);
        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.fillRect(e.x - 22, r.y - 12, 44, 5);
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(e.x - 22, r.y - 12, 44 * (e.hp / e.maxHp), 5);
      }
    }
    // goliath boss
    if (this.boss && this.boss.kind === 'goliath' && !this.boss.dead) {
      const b = this.boss;
      drawGoliath(ctx, b.x, b.y, b.facing, t, b.flash > 0, b.state, b.stateT);
    }

    // gwen ally
    if (this.gwen) {
      const k = this.gwen;
      drawGwen(ctx, k.x, k.y, k.facing, { t, moving: Math.abs(k.vx) > 20, onGround: k.onGround, crouch: false, attack: Math.max(0, k.attackT), hurt: false, vy: k.vy });
    }
    // kevin ally
    if (this.kevin) {
      const k = this.kevin;
      drawKevin(ctx, k.x, k.y, k.facing, { t, moving: Math.abs(k.vx) > 20, onGround: k.onGround, crouch: false, attack: k.attackT, hurt: false, vy: k.vy }, k.absorb);
    }

    // player
    const p = this.player;
    const anim: Anim = { t, moving: Math.abs(p.vx) > 20, onGround: p.onGround, crouch: p.crouch, attack: Math.max(0, p.attackT), hurt: p.inv > 0, vy: p.vy };
    const watchState = !p.hasWatch ? 'none' : p.form !== 'human' ? 'active' : p.recharge > 0 ? 'recharge' : 'ready';
    // shadow
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath();
    ctx.ellipse(p.x, GROUND + 2, this.form.w * 0.7, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    if (p.form !== 'human' && p.formTime < 5) {
      ctx.globalAlpha = 0.5 + 0.5 * Math.sin(t * 12);
    }
    drawForm(ctx, p.form, p.x, p.y, p.facing, anim, watchState);
    ctx.globalAlpha = 1;

    // projectiles
    for (const pj of this.projectiles) {
      ctx.save();
      if (pj.kind === 'fire') {
        ctx.shadowColor = '#ff7a00';
        ctx.shadowBlur = 16;
        const g = ctx.createRadialGradient(pj.x, pj.y, 0, pj.x, pj.y, pj.r);
        g.addColorStop(0, '#fff3b0');
        g.addColorStop(0.5, '#ff9f1c');
        g.addColorStop(1, 'rgba(255,60,0,0.3)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(pj.x, pj.y, pj.r, 0, Math.PI * 2);
        ctx.fill();
      } else if (pj.kind === 'shard') {
        ctx.fillStyle = '#a7ffd1';
        ctx.shadowColor = '#2fd27a';
        ctx.shadowBlur = 10;
        ctx.translate(pj.x, pj.y);
        ctx.rotate(Math.atan2(pj.vy, pj.vx));
        ctx.beginPath();
        ctx.moveTo(12, 0);
        ctx.lineTo(-8, -5);
        ctx.lineTo(-8, 5);
        ctx.closePath();
        ctx.fill();
      } else if (pj.kind === 'laser') {
        ctx.strokeStyle = '#ff2d2d';
        ctx.shadowColor = '#ff2d2d';
        ctx.shadowBlur = 10;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(pj.x, pj.y);
        ctx.lineTo(pj.x - pj.vx * 0.04, pj.y - pj.vy * 0.04);
        ctx.stroke();
      } else if (pj.kind === 'wave') {
        ctx.fillStyle = 'rgba(160,160,170,0.9)';
        ctx.beginPath();
        ctx.moveTo(pj.x - 30, GROUND);
        ctx.lineTo(pj.x, GROUND - 46);
        ctx.lineTo(pj.x + 30, GROUND);
        ctx.fill();
        ctx.fillStyle = '#7CFC00';
        ctx.fillRect(pj.x - 2, GROUND - 40, 4, 40);
      } else if (pj.kind === 'rock' || pj.kind === 'shell') {
        ctx.fillStyle = pj.kind === 'shell' ? '#a855f7' : '#6b7280';
        ctx.shadowColor = '#a855f7';
        ctx.shadowBlur = pj.kind === 'shell' ? 10 : 0;
        ctx.beginPath();
        ctx.arc(pj.x, pj.y, pj.r, 0, Math.PI * 2);
        ctx.fill();
      } else if (pj.kind === 'crystal') {
        ctx.fillStyle = '#22d3ee';
        ctx.shadowColor = '#22d3ee';
        ctx.shadowBlur = 10;
        ctx.translate(pj.x, pj.y);
        ctx.rotate(Math.atan2(pj.vy, pj.vx));
        ctx.beginPath();
        ctx.moveTo(12, 0);
        ctx.lineTo(-8, -6);
        ctx.lineTo(-8, 6);
        ctx.closePath();
        ctx.fill();
      } else if (pj.kind === 'disc') {
        ctx.translate(pj.x, pj.y);
        ctx.rotate(this.time * 20);
        ctx.shadowColor = '#f472b6';
        ctx.shadowBlur = 20;
        ctx.fillStyle = 'rgba(244,114,182,0.85)';
        ctx.beginPath();
        ctx.ellipse(0, 0, pj.r, pj.r * 0.45, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.ellipse(0, 0, pj.r * 0.4, pj.r * 0.18, 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (pj.kind === 'neuro') {
        ctx.strokeStyle = '#bef264';
        ctx.shadowColor = '#84cc16';
        ctx.shadowBlur = 14;
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(pj.x, pj.y);
        ctx.lineTo(pj.x - Math.sign(pj.vx) * 36, pj.y);
        ctx.stroke();
      } else if (pj.kind === 'cosmic') {
        ctx.shadowColor = '#a78bfa';
        ctx.shadowBlur = 30;
        const g = ctx.createRadialGradient(pj.x, pj.y, 0, pj.x, pj.y, pj.r);
        g.addColorStop(0, '#fff');
        g.addColorStop(0.4, '#a78bfa');
        g.addColorStop(1, 'rgba(20,0,60,0.2)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(pj.x, pj.y, pj.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // beams
    for (const b of this.beams) {
      const a = Math.min(1, b.life / 0.3);
      ctx.fillStyle = `rgba(255,60,60,${0.75 * a})`;
      ctx.shadowColor = '#ff2d2d';
      ctx.shadowBlur = 30;
      ctx.fillRect(b.x1, b.y - 10, b.x2 - b.x1, 20);
      ctx.fillStyle = `rgba(255,255,255,${0.9 * a})`;
      ctx.fillRect(b.x1, b.y - 3, b.x2 - b.x1, 6);
      ctx.shadowBlur = 0;
    }

    // cracks
    for (const c of this.cracks) {
      const a = Math.min(1, c.life);
      ctx.strokeStyle = `rgba(124,252,0,${a})`;
      ctx.shadowColor = '#7CFC00';
      ctx.shadowBlur = 20;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(c.x, GROUND);
      let yy = GROUND;
      for (let i = 1; i <= 10; i++) {
        yy = GROUND + ((i % 2) * 2 - 1) * 10 * (i / 10);
        ctx.lineTo(c.x + c.dir * c.len * (i / 10), yy);
      }
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.fillStyle = `rgba(20,20,20,${a * 0.8})`;
      ctx.fillRect(Math.min(c.x, c.x + c.dir * c.len), GROUND - 2, c.len, 12);
    }

    // water bodies
    for (const z of this.water) {
      const x1 = Math.max(z.from, this.camX - 20);
      const x2 = Math.min(z.to, this.camX + W + 20);
      if (x2 <= x1) continue;
      const g = ctx.createLinearGradient(0, z.surface, 0, H);
      g.addColorStop(0, 'rgba(56,189,248,0.38)');
      g.addColorStop(1, 'rgba(3,60,120,0.6)');
      ctx.fillStyle = g;
      ctx.fillRect(x1, z.surface, x2 - x1, H - z.surface);
      ctx.strokeStyle = 'rgba(255,255,255,0.8)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      for (let x = x1; x <= x2; x += 12) {
        const y = z.surface + Math.sin(x * 0.04 + t * 3) * 4;
        if (x === x1) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      if (L.theme !== 'ocean') {
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.fillRect(z.from - 3, z.surface, 6, GROUND - z.surface);
        ctx.fillRect(z.to - 3, z.surface, 6, GROUND - z.surface);
      }
    }
    // frozen time overlay
    if (this.freezeT > 0) {
      ctx.fillStyle = `rgba(167,139,250,${0.12 + 0.05 * Math.sin(t * 6)})`;
      ctx.fillRect(this.camX, 0, W, H);
    }

    // particles
    for (const pt of this.particles) {
      ctx.globalAlpha = Math.max(0, pt.life / pt.max);
      ctx.fillStyle = pt.color;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size * (pt.life / pt.max), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // floating texts
    ctx.font = `bold 18px ${FONT}`;
    ctx.textAlign = 'center';
    for (const ft of this.texts) {
      ctx.globalAlpha = Math.max(0, ft.life);
      ctx.fillStyle = ft.color;
      ctx.strokeStyle = 'rgba(0,0,0,0.6)';
      ctx.lineWidth = 3;
      ctx.strokeText(ft.text, ft.x, ft.y);
      ctx.fillText(ft.text, ft.x, ft.y);
    }
    ctx.globalAlpha = 1;

    ctx.restore(); // world

    // darkness (night forest / deep sea) with light around the player
    if (L.dark) {
      const px = this.player.x - this.camX;
      const py = this.player.y - 50;
      const g = ctx.createRadialGradient(px, py, 80, px, py, 520);
      g.addColorStop(0, 'rgba(0,0,15,0)');
      g.addColorStop(1, 'rgba(0,0,15,0.82)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#fef08a';
      for (let i = 0; i < 24; i++) {
        const fx = ((i * 137 + Math.sin(t + i) * 40) % W + W) % W;
        const fy = 200 + ((i * 53) % 320) + Math.sin(t * 2 + i) * 20;
        ctx.globalAlpha = 0.4 + 0.6 * Math.abs(Math.sin(t * 2 + i));
        ctx.shadowColor = '#fef08a';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(fx, fy, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.shadowBlur = 0;
    }
    // alien x time-slow vignette
    if (this.timeScale < 1 && this.mode === 'play') {
      const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.8);
      g.addColorStop(0, 'rgba(80,40,160,0)');
      g.addColorStop(1, 'rgba(80,40,160,0.45)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
    // flash
    if (this.flash > 0) {
      ctx.fillStyle = this.flashColor;
      ctx.globalAlpha = Math.min(0.7, this.flash * 0.7);
      ctx.fillRect(-10, -10, W + 20, H + 20);
      ctx.globalAlpha = 1;
    }

    this.drawHud(ctx);
    if (this.wheelOpen) this.drawWheel(ctx);
    if (this.dialog) this.drawDialog(ctx);
    if (this.mode === 'paused') this.drawPaused(ctx);
    if (this.errStreak >= 3 && this.errMsg) {
      ctx.fillStyle = 'rgba(127,29,29,0.85)';
      ctx.fillRect(0, H - 22, W, 22);
      ctx.fillStyle = '#fff';
      ctx.font = '12px monospace';
      ctx.textAlign = 'left';
      ctx.direction = 'ltr';
      ctx.fillText('error: ' + this.errMsg, 8, H - 7);
    }
    ctx.restore();
  }

  drawInterior(ctx: CanvasRenderingContext2D) {
    const L = this.level;
    const ship = L.theme === 'ship';
    const off = ((-this.camX * 0.5) % 120 + 120) % 120;
    ctx.fillStyle = ship ? '#160d2b' : '#2b2b36';
    ctx.fillRect(0, 0, W, GROUND);
    for (let x = off - 120; x < W; x += 120) {
      ctx.fillStyle = ship ? '#241546' : '#3a3a48';
      ctx.fillRect(x, 60, 90, GROUND - 60);
      if (ship) {
        ctx.fillStyle = `rgba(168,85,247,${0.4 + 0.3 * Math.sin(this.time * 3 + x)})`;
        ctx.fillRect(x + 20, 120, 50, 8);
        ctx.fillRect(x + 20, 300, 50, 8);
        ctx.shadowColor = '#a855f7';
      } else {
        ctx.fillStyle = '#d4d4d8';
        for (let y = 120; y < GROUND - 40; y += 40) {
          ctx.fillRect(x + 8, y, 74, 30);
        }
        ctx.fillStyle = '#2563eb';
        ctx.fillRect(x + 8, 200, 74, 30);
      }
    }
    // ceiling lights
    for (let x = off - 120; x < W; x += 240) {
      ctx.fillStyle = ship ? 'rgba(236,72,153,0.25)' : 'rgba(255,255,220,0.3)';
      ctx.beginPath();
      ctx.moveTo(x + 40, 0);
      ctx.lineTo(x - 80, GROUND);
      ctx.lineTo(x + 160, GROUND);
      ctx.fill();
    }
  }

  drawRain(ctx: CanvasRenderingContext2D) {
    ctx.strokeStyle = 'rgba(180,200,255,0.35)';
    ctx.lineWidth = 1.5;
    const t = this.time;
    ctx.beginPath();
    for (let i = 0; i < 160; i++) {
      const x = ((i * 97 + t * 900) % (W + 200)) - 100;
      const y = ((i * 53 + t * 1400) % (H + 100)) - 50;
      ctx.moveTo(x, y);
      ctx.lineTo(x - 6, y + 22);
    }
    ctx.stroke();
    if (Math.floor(t * 2) % 11 === 0 && Math.random() < 0.08) {
      ctx.fillStyle = 'rgba(255,255,255,0.25)';
      ctx.fillRect(0, 0, W, H);
    }
  }

  drawHud(ctx: CanvasRenderingContext2D) {
    const p = this.player;
    const L = this.level;
    ctx.save();
    ctx.direction = 'rtl';
    // top-left panel: HP
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    rr(ctx, 16, 16, 300, 74, 14);
    ctx.fill();
    ctx.fillStyle = '#ff6b9d';
    ctx.font = `bold 20px ${FONT}`;
    ctx.textAlign = 'left';
    ctx.direction = 'ltr';
    ctx.fillText('❤', 28, 46);
    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    rr(ctx, 56, 30, 246, 20, 10);
    ctx.fill();
    const hpw = 246 * Math.max(0, p.hp / p.maxHp);
    const g = ctx.createLinearGradient(56, 0, 302, 0);
    g.addColorStop(0, '#ff4d6d');
    g.addColorStop(1, '#ff9f1c');
    ctx.fillStyle = g;
    rr(ctx, 56, 30, hpw, 20, 10);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = `bold 13px ${FONT}`;
    ctx.textAlign = 'center';
    ctx.fillText(`${Math.ceil(p.hp)} / ${p.maxHp}`, 179, 45);
    // name + friends
    ctx.direction = 'rtl';
    ctx.textAlign = 'left';
    ctx.font = `bold 15px ${FONT}`;
    ctx.fillStyle = '#f5c6e0';
    ctx.fillText(`${FORMS[p.form].name}`, 56, 76);
    ctx.textAlign = 'right';
    ctx.fillStyle = '#cbd5e1';
    ctx.font = `13px ${FONT}`;
    const foes = this.enemies.filter((e) => !e.dead).length;
    ctx.fillText(`دشمن: ${foes}`, 302, 76);

    // top-center: level name
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    rr(ctx, W / 2 - 170, 16, 340, 44, 12);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = `bold 18px ${FONT}`;
    ctx.fillText(`مرحله ${L.id} — ${L.name}`, W / 2, 45);

    // top-right: watch
    const wx = W - 70;
    const wy = 60;
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    rr(ctx, W - 316, 16, 300, 90, 14);
    ctx.fill();
    const watchState = !p.hasWatch ? 'none' : this.level.malfunction && Math.sin(this.time * 9) > 0.6 ? 'broken' : p.form !== 'human' ? 'active' : p.recharge > 0 ? 'recharge' : 'ready';
    if (watchState === 'none') {
      ctx.fillStyle = '#9ca3af';
      ctx.font = `14px ${FONT}`;
      ctx.textAlign = 'right';
      ctx.fillText('ساعت: هنوز پیدا نشده', W - 30, 50);
    } else {
      // ring
      ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.arc(wx, wy, 30, 0, Math.PI * 2);
      ctx.stroke();
      let frac = 1;
      let col = '#7CFC00';
      if (watchState === 'active') {
        frac = p.formTime / (p.form === 'alienx' ? FORMS.alienx.duration : this.formDuration);
        col = frac < 0.2 ? '#ff3b3b' : '#7CFC00';
      } else if (watchState === 'recharge') {
        frac = 1 - p.recharge / 8;
        col = '#ff3b3b';
      } else if (watchState === 'broken') {
        frac = 0;
        col = '#6b7280';
      }
      ctx.strokeStyle = col;
      ctx.beginPath();
      ctx.arc(wx, wy, 30, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * frac);
      ctx.stroke();
      drawWatch(ctx, wx, wy, 16, watchState, this.time);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#fff';
      ctx.font = `bold 14px ${FONT}`;
      const label = p.form !== 'human' ? `${FORMS[p.form].name} — ${Math.ceil(p.formTime)} ثانیه` : p.recharge > 0 ? `شارژ: ${Math.ceil(p.recharge)} ثانیه` : this.level.malfunction ? 'ساعت ناپایدار! (Q)' : 'ساعت آماده (Q)';
      ctx.fillText(label, wx - 44, 46);
      // split cooldown
      ctx.font = `13px ${FONT}`;
      ctx.fillStyle = p.splitCd > 0 ? '#9ca3af' : '#7CFC00';
      ctx.fillText(p.splitCd > 0 ? `قاچ زمین: ${Math.ceil(p.splitCd)} ثانیه` : 'قاچ زمین آماده (K)', wx - 44, 70);
      // unlocked aliens icons
      FORM_ORDER.forEach((f, i) => {
        const has = this.unlocked.includes(f);
        ctx.fillStyle = has ? (f === 'alienx' ? '#a78bfa' : FORMS[f].color) : 'rgba(255,255,255,0.12)';
        ctx.beginPath();
        ctx.arc(W - 300 + 16 + i * 26, 92, 8, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // boss bar
    if (this.boss && !this.boss.dead && this.bossIntroDone) {
      const b = this.boss;
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      rr(ctx, W / 2 - 300, 70, 600, 34, 10);
      ctx.fill();
      ctx.fillStyle = '#4c1d95';
      rr(ctx, W / 2 - 290, 78, 580, 18, 8);
      ctx.fill();
      const bg = ctx.createLinearGradient(W / 2 - 290, 0, W / 2 + 290, 0);
      bg.addColorStop(0, '#ef4444');
      bg.addColorStop(1, '#f97316');
      ctx.fillStyle = bg;
      rr(ctx, W / 2 - 290, 78, 580 * (b.hp / b.maxHp), 18, 8);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = `bold 13px ${FONT}`;
      ctx.textAlign = 'center';
      ctx.fillText(b.kind === 'ex' ? 'اِکس غول‌پیکر کیهانی — Titan Godzilla X' : 'نگهبان کریستالی اِکس — Goliath Drone', W / 2, 92);
    }

    // defend timer
    if (this.defendStarted && this.defendT > 0) {
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      rr(ctx, W / 2 - 160, 70, 320, 40, 12);
      ctx.fill();
      ctx.fillStyle = '#00FF7F';
      ctx.font = `bold 20px ${FONT}`;
      ctx.textAlign = 'center';
      ctx.fillText(`دفاع از برج: ${Math.ceil(this.defendT)} ثانیه`, W / 2, 98);
    }
    // kevin / friend indicator
    if (this.kevin) {
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      rr(ctx, 16, 100, 150, 30, 10);
      ctx.fill();
      ctx.fillStyle = this.kevin.absorb ?? '#cbd5e1';
      ctx.font = `bold 14px ${FONT}`;
      ctx.textAlign = 'right';
      ctx.fillText(this.kevin.absorb ? 'کوین: قدرت جذب‌شده' : 'کوین: همراه تو', 156, 121);
    }
    if (this.gwen) {
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      rr(ctx, 16, 136, 150, 30, 10);
      ctx.fill();
      ctx.fillStyle = '#f9a8d4';
      ctx.font = `bold 14px ${FONT}`;
      ctx.textAlign = 'right';
      ctx.fillText('گوئن: بشقاب صورتی', 156, 157);
    }
    if (this.playerWet) {
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      rr(ctx, 16, 172, 150, 30, 10);
      ctx.fill();
      ctx.fillStyle = '#7dd3fc';
      ctx.font = `bold 14px ${FONT}`;
      ctx.textAlign = 'right';
      ctx.fillText('🌊 در حال شنا', 156, 193);
    }
    // gamepad
    if (this.input.gamepadConnected) {
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      rr(ctx, W - 160, 112, 144, 26, 8);
      ctx.fill();
      ctx.fillStyle = '#7CFC00';
      ctx.font = `12px ${FONT}`;
      ctx.textAlign = 'center';
      ctx.fillText('🎮 دسته متصل است', W - 88, 130);
    }
    // hint
    if (this.hintT > 0 && this.hint) {
      ctx.globalAlpha = Math.min(1, this.hintT);
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.font = `bold 18px ${FONT}`;
      const tw = ctx.measureText(this.hint).width + 40;
      rr(ctx, W / 2 - tw / 2, H - 70, tw, 40, 12);
      ctx.fill();
      ctx.fillStyle = '#fde68a';
      ctx.textAlign = 'center';
      ctx.fillText(this.hint, W / 2, H - 43);
      ctx.globalAlpha = 1;
    }
    // progress bar bottom
    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    ctx.fillRect(0, H - 6, W, 6);
    ctx.fillStyle = '#7CFC00';
    ctx.fillRect(0, H - 6, W * Math.min(1, p.x / this.level.length), 6);
    ctx.restore();
  }

  drawWheel(ctx: CanvasRenderingContext2D) {
    const cx = W / 2;
    const cy = H / 2;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    ctx.fillRect(0, 0, W, H);
    // dial
    ctx.fillStyle = '#111827';
    ctx.beginPath();
    ctx.arc(cx, cy, 200, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#7CFC00';
    ctx.lineWidth = 6;
    ctx.shadowColor = '#7CFC00';
    ctx.shadowBlur = 25;
    ctx.stroke();
    ctx.shadowBlur = 0;
    const n = this.unlocked.length;
    this.unlocked.forEach((f, i) => {
      const ang = -Math.PI / 2 + (i / n) * Math.PI * 2;
      const x = cx + Math.cos(ang) * 130;
      const y = cy + Math.sin(ang) * 130;
      const sel = i === this.wheelIdx;
      ctx.fillStyle = sel ? (f === 'alienx' ? '#2e1065' : FORMS[f].color) : '#1f2937';
      ctx.shadowColor = FORMS[f].glow;
      ctx.shadowBlur = sel ? 30 : 0;
      ctx.beginPath();
      ctx.arc(x, y, sel ? 52 : 40, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.save();
      ctx.beginPath();
      ctx.arc(x, y, sel ? 50 : 38, 0, Math.PI * 2);
      ctx.clip();
      ctx.translate(0, 0);
      const sc = sel ? 0.75 : 0.55;
      ctx.translate(x, y + (sel ? 36 : 28));
      ctx.scale(sc, sc);
      drawForm(ctx, f, 0, 0, 1, { t: this.time, moving: false, onGround: true, crouch: false, attack: 0, hurt: false, vy: 0 }, 'active');
      ctx.restore();
    });
    // center hologram
    ctx.fillStyle = '#7CFC00';
    ctx.font = `bold 26px ${FONT}`;
    ctx.textAlign = 'center';
    ctx.direction = 'rtl';
    const cur = FORMS[this.unlocked[this.wheelIdx]];
    ctx.fillText(cur.name, cx, cy - 4);
    ctx.fillStyle = '#d1fae5';
    ctx.font = `14px ${FONT}`;
    ctx.fillText(cur.desc, cx, cy + 22);
    ctx.fillStyle = '#9ca3af';
    ctx.font = `15px ${FONT}`;
    ctx.fillText('← → انتخاب   |   E / RB تبدیل   |   Q بستن', cx, cy + 240);
    ctx.restore();
  }

  wrapText(ctx: CanvasRenderingContext2D, text: string, maxW: number) {
    const words = text.split(' ');
    const lines: string[] = [];
    let cur = '';
    for (const w of words) {
      const test = cur ? cur + ' ' + w : w;
      if (ctx.measureText(test).width > maxW && cur) {
        lines.push(cur);
        cur = w;
      } else cur = test;
    }
    if (cur) lines.push(cur);
    return lines;
  }

  drawDialog(ctx: CanvasRenderingContext2D) {
    if (!this.dialog) return;
    const line = this.dialog.lines[this.dialog.idx];
    ctx.save();
    ctx.direction = 'rtl';
    const bx = 80;
    const bw = W - 160;
    const bh = 170;
    const by = H - bh - 40;
    ctx.fillStyle = 'rgba(8,10,20,0.88)';
    rr(ctx, bx, by, bw, bh, 18);
    ctx.fill();
    ctx.strokeStyle = line.color ?? '#fff';
    ctx.lineWidth = 3;
    ctx.stroke();
    // speaker tag
    ctx.font = `bold 20px ${FONT}`;
    const nw = ctx.measureText(line.speaker).width + 36;
    ctx.fillStyle = line.color ?? '#fff';
    rr(ctx, bx + bw - nw - 20, by - 20, nw, 40, 12);
    ctx.fill();
    ctx.fillStyle = '#0b0f14';
    ctx.textAlign = 'center';
    ctx.fillText(line.speaker, bx + bw - 20 - nw / 2, by + 7);
    // text
    ctx.fillStyle = '#fff';
    ctx.font = `24px ${FONT}`;
    ctx.textAlign = 'right';
    const lines = this.wrapText(ctx, line.text, bw - 60);
    lines.forEach((l, i) => ctx.fillText(l, bx + bw - 30, by + 50 + i * 30));
    if (line.choices) {
      line.choices.forEach((c, i) => {
        const sel = i === this.dialog!.choice;
        ctx.font = `bold 18px ${FONT}`;
        const cw = ctx.measureText(c.text).width + 50;
        const cx = bx + bw - 30 - cw;
        const cy = by + 100 + i * 36;
        ctx.fillStyle = sel ? '#a78bfa' : 'rgba(255,255,255,0.08)';
        rr(ctx, cx, cy - 22, cw, 30, 10);
        ctx.fill();
        ctx.fillStyle = sel ? '#0b0f14' : '#e5e7eb';
        ctx.textAlign = 'right';
        ctx.fillText((sel ? '◀ ' : '') + c.text, cx + cw - 14, cy);
      });
      ctx.fillStyle = '#c4b5fd';
      ctx.font = `14px ${FONT}`;
      ctx.textAlign = 'left';
      ctx.fillText('← → انتخاب  •  E / J تأیید', bx + 24, by + bh - 16);
    } else {
      ctx.fillStyle = '#9ca3af';
      ctx.font = `14px ${FONT}`;
      ctx.textAlign = 'left';
      ctx.fillText(`${this.dialog.idx + 1}/${this.dialog.lines.length}  —  ادامه: Space / A`, bx + 24, by + bh - 16);
    }
    // portrait avatar
    ctx.save();
    ctx.translate(bx + 70, by + bh - 30);
    const sp = line.speaker;
    if (sp === 'محمد پارسا') {
      drawForm(ctx, 'human', 0, 0, 1, { t: this.time, moving: false, onGround: true, crouch: false, attack: 0, hurt: false, vy: 0 }, this.player.hasWatch ? 'ready' : 'none');
    } else if (sp === 'کوین') {
      drawKevin(ctx, 0, 0, 1, { t: this.time, moving: false, onGround: true, crouch: false, attack: 0, hurt: false, vy: 0 }, null);
    } else if (sp === 'بلیکوس' || sp === 'سرینا') {
      const col = sp === 'بلیکوس' ? '#f87171' : '#f9a8d4';
      ctx.shadowColor = col;
      ctx.shadowBlur = 30;
      ctx.fillStyle = col;
      ctx.globalAlpha = 0.85;
      ctx.beginPath();
      ctx.ellipse(0, -50, 22, 30 + Math.sin(this.time * 4) * 3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-20, -30);
      ctx.quadraticCurveTo(0, 10, 20, -30);
      ctx.fill();
      ctx.fillStyle = '#0b0f14';
      ctx.beginPath();
      ctx.ellipse(-7, -56, 4, 6, 0, 0, Math.PI * 2);
      ctx.ellipse(7, -56, 4, 6, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (sp === 'اِکس') {
      ctx.scale(0.22, 0.22);
      drawEx(ctx, 60, 0, -1, this.time, 'idle', 0, 1);
    } else if (sp === 'گوئن') {
      drawGwen(ctx, 0, 0, 1, { t: this.time, moving: false, onGround: true, crouch: false, attack: 0, hurt: false, vy: 0 });
    } else if (sp === 'بابابزرگ مکس') {
      drawMax(ctx, 0, 0, 1, this.time, true);
    } else if (sp === 'سارا') {
      drawNpc(ctx, 0, 0, this.time, '#facc15', true, 'girl');
    } else if (sp === 'علی') {
      drawNpc(ctx, 0, 0, this.time, '#3b82f6', true, 'boy');
    } else if (sp === 'برفی') {
      drawNpc(ctx, 0, 0, this.time, '#fff', true, 'cat');
    } else if (sp !== 'راوی') {
      drawNpc(ctx, 0, 0, this.time, this.level.npc?.color ?? '#fde68a', true, this.level.npc?.kind ?? 'adult');
    }
    ctx.restore();
    ctx.restore();
  }

  drawPaused(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#fff';
    ctx.font = `bold 44px ${FONT}`;
    ctx.textAlign = 'center';
    ctx.direction = 'rtl';
    ctx.fillText('توقف', W / 2, H / 2 - 20);
    ctx.font = `18px ${FONT}`;
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText('برای ادامه Esc یا Start را بزن — یا روی صفحه بزن', W / 2, H / 2 + 24);
    ctx.restore();
  }
}
