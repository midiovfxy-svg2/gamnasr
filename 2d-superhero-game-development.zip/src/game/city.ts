import type { Theme } from './data';

type Ctx = CanvasRenderingContext2D;

export interface BSprite {
  img: HTMLCanvasElement | null;
  pad: number;
  lights: { x: number; y: number }[];
}

export interface BSpec {
  w: number;
  h: number;
  layer: 'far' | 'mid';
  body: string;
  style: number;
  roof: number;
  seed: number;
}

export interface Look {
  mode: 'day' | 'dusk' | 'night' | 'ruin';
  far: string[];
  mid: string[];
  haze: string;
  glass: [string, string];
  lit: string[];
  litChance: number;
  shops: string[];
}

export const PAD = 96;

/* ---------- small helpers ---------- */
function lcg(seed: number) {
  let s = (seed >>> 0) || 1;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function toRgb(c: string): [number, number, number] {
  const n = parseInt(c.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function toHex(r: number, g: number, b: number) {
  const f = (v: number) => ('0' + Math.max(0, Math.min(255, Math.round(v))).toString(16)).slice(-2);
  return '#' + f(r) + f(g) + f(b);
}

export function mixHex(a: string, b: string, t: number) {
  const A = toRgb(a);
  const B = toRgb(b);
  return toHex(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t);
}
const darker = (c: string, t: number) => mixHex(c, '#000000', t);
const lighter = (c: string, t: number) => mixHex(c, '#ffffff', t);

export function hexA(c: string, a: number) {
  const [r, g, b] = toRgb(c);
  return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
}

function mkCanvas(w: number, h: number): HTMLCanvasElement | null {
  try {
    if (typeof document === 'undefined' || typeof document.createElement !== 'function') return null;
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.ceil(w));
    c.height = Math.max(1, Math.ceil(h));
    if (typeof c.getContext !== 'function') return null;
    return c;
  } catch {
    return null;
  }
}

/* ---------- palettes per theme ---------- */
export function cityLook(theme: Theme): Look {
  const shops = ['#ef4444', '#3b82f6', '#22c55e', '#f59e0b', '#a855f7', '#14b8a6'];
  switch (theme) {
    case 'day':
      return {
        mode: 'day',
        far: ['#9db7d2', '#8aa7c6', '#a9bfd6', '#b7c8da'],
        mid: ['#e8d3ba', '#d8bba4', '#cfd9e4', '#ecdcc4', '#c3d2e2', '#e3c5b0'],
        haze: '#dcefff',
        glass: ['#a5dcff', '#3f84c8'],
        lit: ['#fff3c4'],
        litChance: 0,
        shops,
      };
    case 'sunset':
      return {
        mode: 'dusk',
        far: ['#7c4c88', '#6a3f7a', '#8c5c92'],
        mid: ['#6a4570', '#86506f', '#553a62', '#9a6070'],
        haze: '#ffb067',
        glass: ['#ffc98a', '#8f4a78'],
        lit: ['#ffd98a', '#ffb866'],
        litChance: 0.28,
        shops,
      };
    case 'ruins':
      return {
        mode: 'ruin',
        far: ['#6a6670', '#5a5660', '#756f78'],
        mid: ['#62606a', '#6f6a72', '#524f58', '#7a7574'],
        haze: '#a89a98',
        glass: ['#7b8a98', '#2f3a45'],
        lit: ['#ffcf8a'],
        litChance: 0.05,
        shops,
      };
    default:
      // night, park, rooftop, ship ...
      return {
        mode: 'night',
        far: ['#1b2444', '#161d38', '#222c54'],
        mid: ['#2a3552', '#323f62', '#232d46', '#37436e'],
        haze: theme === 'park' ? '#4d4478' : '#2a3a70',
        glass: ['#27406e', '#101a3a'],
        lit: ['#ffd98a', '#ffc266', '#fff1b8', '#a8e6ff', '#ffb36b'],
        litChance: 0.5,
        shops,
      };
  }
}

/* ---------- windows ---------- */
interface GridOpt {
  cw: number;
  ch: number;
  gx: number;
  gy: number;
  frame: boolean;
  far: boolean;
  rnd: () => number;
  L: Look;
  deco?: (x: number, y: number, i: number, j: number) => void;
}

function drawCell(g: Ctx, x: number, y: number, w: number, h: number, lit: boolean, o: GridOpt) {
  const L = o.L;
  if (lit) {
    const col = L.lit[Math.floor(o.rnd() * L.lit.length) % L.lit.length];
    const gr = g.createLinearGradient(0, y, 0, y + h);
    gr.addColorStop(0, lighter(col, 0.45));
    gr.addColorStop(1, col);
    g.shadowColor = col;
    g.shadowBlur = o.far ? 2 : 7;
    g.fillStyle = gr;
    g.fillRect(x, y, w, h);
    g.shadowBlur = 0;
  } else {
    const gr = g.createLinearGradient(x, y, x + w, y + h);
    gr.addColorStop(0, L.glass[0]);
    gr.addColorStop(1, L.glass[1]);
    g.fillStyle = gr;
    g.fillRect(x, y, w, h);
    if (L.mode === 'day' || L.mode === 'dusk') {
      g.fillStyle = 'rgba(255,255,255,0.30)';
      g.beginPath();
      g.moveTo(x, y + h);
      g.lineTo(x + w * 0.55, y);
      g.lineTo(x + w * 0.82, y);
      g.lineTo(x + w * 0.27, y + h);
      g.closePath();
      g.fill();
    }
  }
}

function windowGrid(g: Ctx, x0: number, y0: number, w: number, h: number, o: GridOpt) {
  const cols = Math.max(1, Math.floor((w - 8 + o.gx) / (o.cw + o.gx)));
  const rows = Math.max(1, Math.floor((h + o.gy) / (o.ch + o.gy)));
  const totalW = cols * o.cw + (cols - 1) * o.gx;
  const sx = x0 + (w - totalW) / 2;
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      const x = sx + i * (o.cw + o.gx);
      const y = y0 + j * (o.ch + o.gy);
      const lit = o.rnd() < o.L.litChance;
      if (o.frame) {
        g.fillStyle = 'rgba(0,0,0,0.30)';
        g.fillRect(x - 1.5, y - 1.5, o.cw + 3, o.ch + 3);
      }
      drawCell(g, x, y, o.cw, o.ch, lit, o);
      if (o.frame && !o.far) {
        g.fillStyle = 'rgba(255,255,255,0.25)';
        g.fillRect(x - 2.5, y + o.ch + 1.5, o.cw + 5, 2);
        g.fillStyle = 'rgba(0,0,0,0.25)';
        g.fillRect(x + o.cw / 2 - 0.5, y, 1, o.ch);
      }
      if (!o.far && !lit && o.L.mode !== 'night' && o.rnd() < 0.2) {
        g.fillStyle = 'rgba(255,238,220,0.55)';
        g.fillRect(x, y, o.cw / 2.3, o.ch);
      }
      if (o.L.mode === 'ruin' && o.rnd() < 0.22) {
        g.strokeStyle = 'rgba(0,0,0,0.65)';
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(x, y);
        g.lineTo(x + o.cw, y + o.ch);
        g.moveTo(x + o.cw, y);
        g.lineTo(x, y + o.ch);
        g.stroke();
      }
      if (o.deco) o.deco(x, y, i, j);
    }
  }
}

/* ---------- shop front band ---------- */
function shopBand(g: Ctx, w: number, H: number, L: Look, rnd: () => number) {
  const bandH = 46;
  const y0 = H - bandH;
  g.fillStyle = '#16181f';
  g.fillRect(0, y0, w, bandH);
  const n = Math.max(1, Math.floor(w / 78));
  const sw = (w - 8) / n;
  for (let k = 0; k < n; k++) {
    const x = 4 + k * sw;
    const col = L.shops[Math.floor(rnd() * L.shops.length)];
    // sign board
    g.fillStyle = col;
    g.fillRect(x + 4, y0 + 2, sw - 8, 9);
    g.fillStyle = 'rgba(255,255,255,0.35)';
    g.fillRect(x + 4, y0 + 2, sw - 8, 2);
    // striped awning
    const stripes = 6;
    const aw = (sw - 6) / stripes;
    for (let s = 0; s < stripes; s++) {
      g.fillStyle = s % 2 ? '#f5f5f4' : col;
      g.fillRect(x + 3 + s * aw, y0 + 12, aw, 9);
      g.beginPath();
      g.arc(x + 3 + s * aw + aw / 2, y0 + 21, aw / 2, 0, Math.PI);
      g.fill();
    }
    // shop window
    const lit = L.mode === 'night' || L.mode === 'dusk' || rnd() < 0.5;
    const wx = x + 6;
    const wy = y0 + 28;
    const ww = sw - (k === n - 1 ? 24 : 12);
    const gr = g.createLinearGradient(0, wy, 0, y0 + bandH);
    if (lit) {
      gr.addColorStop(0, '#fff4c8');
      gr.addColorStop(1, '#ffb866');
      g.shadowColor = '#ffcf8a';
      g.shadowBlur = 8;
    } else {
      gr.addColorStop(0, L.glass[0]);
      gr.addColorStop(1, L.glass[1]);
    }
    g.fillStyle = gr;
    g.fillRect(wx, wy, ww, bandH - 28);
    g.shadowBlur = 0;
    // shelves
    g.fillStyle = 'rgba(0,0,0,0.22)';
    g.fillRect(wx, wy + 8, ww, 1.5);
    g.fillStyle = 'rgba(0,0,0,0.35)';
    for (let q = 0; q < Math.floor(ww / 12); q++) g.fillRect(wx + 3 + q * 12, wy + 2 + (q % 3), 5, 6);
    if (k === n - 1) {
      g.fillStyle = '#2a2a33';
      g.fillRect(x + sw - 16, y0 + 24, 12, bandH - 24);
      g.fillStyle = '#e5e7eb';
      g.fillRect(x + sw - 8, y0 + 34, 2, 6);
    }
  }
  g.fillStyle = 'rgba(0,0,0,0.35)';
  g.fillRect(0, H - 3, w, 3);
}

/* ---------- roof gadgets ---------- */
function roofDeco(g: Ctx, x: number, y: number, w: number, kind: number, L: Look, rnd: () => number, lights: BSprite['lights'], far: boolean) {
  g.fillStyle = 'rgba(255,255,255,0.22)';
  g.fillRect(x - 2, y - 4, w + 4, 4);
  g.fillStyle = 'rgba(0,0,0,0.28)';
  g.fillRect(x - 2, y - 1, w + 4, 2);
  const cx = x + w * (0.25 + rnd() * 0.4);
  switch (kind % 5) {
    case 1: {
      // water tank
      g.strokeStyle = '#3b2a1c';
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(cx - 8, y - 4);
      g.lineTo(cx - 8, y - 14);
      g.moveTo(cx + 8, y - 4);
      g.lineTo(cx + 8, y - 14);
      g.stroke();
      g.fillStyle = '#7a5a43';
      g.fillRect(cx - 12, y - 34, 24, 20);
      g.fillStyle = '#4d3727';
      g.fillRect(cx - 12, y - 28, 24, 2);
      g.fillRect(cx - 12, y - 20, 24, 2);
      g.beginPath();
      g.moveTo(cx - 13, y - 34);
      g.lineTo(cx, y - 44);
      g.lineTo(cx + 13, y - 34);
      g.fill();
      break;
    }
    case 2: {
      // antenna + blinking light
      g.strokeStyle = '#64748b';
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(cx, y - 4);
      g.lineTo(cx, y - 56);
      g.stroke();
      g.lineWidth = 1.5;
      for (let i = 0; i < 3; i++) {
        g.beginPath();
        g.moveTo(cx - 8 + i * 2, y - 22 - i * 12);
        g.lineTo(cx + 8 - i * 2, y - 22 - i * 12);
        g.stroke();
      }
      lights.push({ x: cx, y: y - 58 });
      break;
    }
    case 3: {
      if (far) break;
      // billboard
      const bw = Math.min(w * 0.7, 70);
      const bx = x + (w - bw) / 2;
      g.fillStyle = '#334155';
      g.fillRect(bx + 6, y - 14, 3, 10);
      g.fillRect(bx + bw - 9, y - 14, 3, 10);
      const col = L.shops[Math.floor(rnd() * L.shops.length)];
      const gr = g.createLinearGradient(bx, 0, bx + bw, 0);
      gr.addColorStop(0, col);
      gr.addColorStop(1, lighter(col, 0.4));
      if (L.mode === 'night') {
        g.shadowColor = col;
        g.shadowBlur = 12;
      }
      g.fillStyle = gr;
      g.fillRect(bx, y - 36, bw, 22);
      g.shadowBlur = 0;
      g.fillStyle = 'rgba(255,255,255,0.7)';
      g.fillRect(bx + 6, y - 30, bw * 0.5, 3);
      g.fillRect(bx + 6, y - 24, bw * 0.3, 3);
      break;
    }
    default: {
      // HVAC units + chimney
      g.fillStyle = '#8a94a3';
      g.fillRect(cx - 16, y - 14, 18, 10);
      g.fillRect(cx + 6, y - 11, 14, 7);
      g.fillStyle = '#5c6572';
      g.beginPath();
      g.arc(cx - 7, y - 9, 3.5, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#6b5b52';
      g.fillRect(x + w * 0.78, y - 24, 8, 20);
      g.fillStyle = '#3f342f';
      g.fillRect(x + w * 0.78 - 1, y - 26, 10, 3);
    }
  }
}

/* ---------- the main sprite ---------- */
export function makeBuilding(spec: BSpec, L: Look): BSprite {
  const { w, h, layer, body, roof } = spec;
  const far = layer === 'far';
  const c = mkCanvas(w, h + PAD);
  const g = c ? c.getContext('2d') : null;
  if (!c || !g) return { img: null, pad: PAD, lights: [] };
  const rnd = lcg(spec.seed);
  const H = h + PAD;
  const lights: BSprite['lights'] = [];
  const style = spec.style % 4;
  const bandH = far ? 0 : 46;
  const bodyTop = PAD;

  // tiers (stepped skyscraper / glass tower with crown)
  const tiers: { x: number; w: number; y: number }[] = [];
  if (style === 2) {
    tiers.push({ x: 0, w, y: bodyTop + h * 0.4 });
    tiers.push({ x: w * 0.11, w: w * 0.78, y: bodyTop + h * 0.12 });
    tiers.push({ x: w * 0.23, w: w * 0.54, y: bodyTop - 26 });
  } else if (style === 0) {
    tiers.push({ x: 0, w, y: bodyTop });
    tiers.push({ x: w * 0.2, w: w * 0.6, y: bodyTop - 22 });
  } else {
    tiers.push({ x: 0, w, y: bodyTop });
  }

  tiers.forEach((t, ti) => {
    const col = ti === 0 ? body : lighter(body, 0.05 * ti);
    const tw = t.w;
    const th = H - t.y;
    // base paint with side-to-side shading
    const gx = g.createLinearGradient(t.x, 0, t.x + tw, 0);
    gx.addColorStop(0, lighter(col, 0.1));
    gx.addColorStop(0.55, col);
    gx.addColorStop(1, darker(col, 0.2));
    g.fillStyle = gx;
    g.fillRect(t.x, t.y, tw, th);
    // top-down light
    const gy = g.createLinearGradient(0, t.y, 0, H);
    gy.addColorStop(0, 'rgba(255,255,255,0.10)');
    gy.addColorStop(1, 'rgba(0,0,0,0.20)');
    g.fillStyle = gy;
    g.fillRect(t.x, t.y, tw, th);

    if (style === 1) {
      // brick courses
      g.strokeStyle = 'rgba(0,0,0,0.07)';
      g.lineWidth = 1;
      for (let y = t.y + 4; y < H; y += far ? 8 : 6) {
        g.beginPath();
        g.moveTo(t.x, y);
        g.lineTo(t.x + tw, y);
        g.stroke();
      }
    }

    const wy0 = t.y + 10;
    const wh = H - bandH - wy0 - 6;
    if (wh > 12) {
      const base: GridOpt = { cw: 12, ch: 16, gx: 2.5, gy: 3.5, frame: false, far, rnd, L };
      if (far) {
        windowGrid(g, t.x + 2, wy0, tw - 4, wh, { ...base, cw: 6, ch: 8, gx: 4, gy: 6 });
      } else if (style === 0 || style === 2) {
        windowGrid(g, t.x + 4, wy0, tw - 8, wh, { ...base, cw: 11 + Math.floor(rnd() * 4), ch: 15, gx: 2.5, gy: 3.5 });
        // glass reflections
        g.save();
        g.beginPath();
        g.rect(t.x, t.y, tw, th);
        g.clip();
        g.fillStyle = L.mode === 'night' ? 'rgba(160,190,255,0.07)' : 'rgba(255,255,255,0.13)';
        for (let k = 0; k < 2; k++) {
          const sx = t.x + tw * (0.1 + k * 0.45);
          g.beginPath();
          g.moveTo(sx, t.y);
          g.lineTo(sx + 26, t.y);
          g.lineTo(sx - 70, H);
          g.lineTo(sx - 96, H);
          g.closePath();
          g.fill();
        }
        g.restore();
      } else if (style === 1) {
        windowGrid(g, t.x + 6, wy0, tw - 12, wh, {
          ...base,
          cw: 15,
          ch: 20,
          gx: 11,
          gy: 14,
          frame: true,
          deco: (x, y, i, j) => {
            if (j % 2 === 1 && (i + j) % 3 !== 0) {
              // balcony
              g.fillStyle = 'rgba(255,255,255,0.28)';
              g.fillRect(x - 4, y + 22, 23, 3);
              g.strokeStyle = 'rgba(0,0,0,0.38)';
              g.lineWidth = 1;
              for (let q = 0; q < 5; q++) {
                g.beginPath();
                g.moveTo(x - 3 + q * 5, y + 25);
                g.lineTo(x - 3 + q * 5, y + 30);
                g.stroke();
              }
            } else if ((i * 7 + j * 3) % 5 === 0) {
              // AC unit
              g.fillStyle = '#c3cad4';
              g.fillRect(x + 17, y + 12, 8, 6);
              g.fillStyle = '#7b8594';
              g.fillRect(x + 18, y + 14, 6, 1);
            }
          },
        });
      } else {
        // vertical fins
        windowGrid(g, t.x + 4, wy0, tw - 8, wh, { ...base, cw: 8, ch: 26, gx: 6, gy: 5 });
        g.fillStyle = lighter(col, 0.18);
        const cols = Math.max(1, Math.floor((tw - 8 + 6) / 14));
        const total = cols * 8 + (cols - 1) * 6;
        const sx = t.x + 4 + (tw - 8 - total) / 2;
        for (let i = 0; i <= cols; i++) g.fillRect(sx + i * 14 - 4, wy0 - 4, 2, wh + 8);
      }
    }
  });

  // street-level shops
  if (!far) shopBand(g, w, H, L, rnd);

  // roof details on the highest tier
  const top = tiers[tiers.length - 1];
  roofDeco(g, top.x, top.y, top.w, roof, L, rnd, lights, far);
  if (style === 2) {
    g.strokeStyle = '#94a3b8';
    g.lineWidth = 2;
    g.beginPath();
    g.moveTo(top.x + top.w / 2, top.y - 4);
    g.lineTo(top.x + top.w / 2, top.y - 40);
    g.stroke();
    lights.push({ x: top.x + top.w / 2, y: top.y - 42 });
  }

  // edge light / shadow
  g.globalCompositeOperation = 'source-atop';
  const eg = g.createLinearGradient(w - 8, 0, w, 0);
  eg.addColorStop(0, 'rgba(0,0,0,0)');
  eg.addColorStop(1, 'rgba(0,0,0,0.30)');
  g.fillStyle = eg;
  g.fillRect(w - 8, 0, 8, H);
  g.fillStyle = 'rgba(255,255,255,0.10)';
  g.fillRect(0, 0, 2, H);

  // ambient occlusion near the ground
  const ao = g.createLinearGradient(0, H - 90, 0, H);
  ao.addColorStop(0, 'rgba(0,0,0,0)');
  ao.addColorStop(1, far ? 'rgba(0,0,0,0.12)' : 'rgba(0,0,0,0.30)');
  g.fillStyle = ao;
  g.fillRect(0, H - 90, w, 90);

  // texture noise
  if (!far) {
    const n = Math.floor(w * h * 0.0025);
    for (let i = 0; i < n; i++) {
      g.fillStyle = rnd() < 0.5 ? 'rgba(255,255,255,0.045)' : 'rgba(0,0,0,0.06)';
      g.fillRect(rnd() * w, PAD - 30 + rnd() * (h + 30), 1.5, 1.5);
    }
  }

  // ruined buildings: broken corners, cracks, soot
  if (L.mode === 'ruin') {
    g.globalCompositeOperation = 'destination-out';
    for (const side of [0, 1]) {
      if (rnd() < 0.7) {
        const nw = 20 + rnd() * 40;
        const nh = 18 + rnd() * 50;
        const ox = side ? w : 0;
        const dir = side ? -1 : 1;
        g.beginPath();
        g.moveTo(ox, PAD - 60);
        g.lineTo(ox + dir * nw, PAD - 60);
        const steps = 5;
        for (let s = 1; s <= steps; s++) {
          const f = s / steps;
          g.lineTo(ox + dir * nw * (1 - f) + (s % 2 ? dir * 6 : 0), PAD - 60 + f * (nh + 60) + rnd() * 8);
        }
        g.closePath();
        g.fill();
      }
    }
    g.globalCompositeOperation = 'source-atop';
    g.strokeStyle = 'rgba(0,0,0,0.4)';
    g.lineWidth = 1.5;
    for (let i = 0; i < 3; i++) {
      let cx = rnd() * w;
      let cy = PAD + rnd() * h * 0.5;
      g.beginPath();
      g.moveTo(cx, cy);
      for (let s = 0; s < 6; s++) {
        cx += (rnd() - 0.5) * 18;
        cy += 10 + rnd() * 14;
        g.lineTo(cx, cy);
      }
      g.stroke();
    }
    const soot = g.createLinearGradient(0, PAD, 0, PAD + 120);
    soot.addColorStop(0, 'rgba(20,16,16,0.35)');
    soot.addColorStop(1, 'rgba(20,16,16,0)');
    g.fillStyle = soot;
    g.fillRect(0, PAD - 30, w, 150);
  }

  // atmospheric haze (strong on the far layer)
  g.globalCompositeOperation = 'source-atop';
  const hz = g.createLinearGradient(0, PAD - 40, 0, H);
  hz.addColorStop(0, hexA(L.haze, far ? 0.5 : 0.04));
  hz.addColorStop(1, hexA(L.haze, far ? 0.72 : 0.22));
  g.fillStyle = hz;
  g.fillRect(0, 0, w, H);
  g.globalCompositeOperation = 'source-over';

  return { img: c, pad: PAD, lights };
}
