/** Remote-control / gamepad / arrow-key navigation for the HTML menus (TV boxes have no touch or mouse). */
type Dir = 'left' | 'right' | 'up' | 'down';

function focusables(): HTMLElement[] {
  const all = document.querySelectorAll<HTMLElement>('button, a[href], [tabindex]');
  const out: HTMLElement[] = [];
  for (let i = 0; i < all.length; i++) {
    const el = all[i];
    if ((el as HTMLButtonElement).disabled || el.getAttribute('tabindex') === '-1') continue;
    const r = el.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) out.push(el);
  }
  return out;
}

function mark() {
  document.body.setAttribute('data-nav', '1');
}

function move(dir: Dir) {
  const list = focusables();
  if (!list.length) return;
  mark();
  const cur = document.activeElement as HTMLElement | null;
  if (!cur || cur === document.body || list.indexOf(cur) < 0) {
    list[0].focus();
    return;
  }
  const cr = cur.getBoundingClientRect();
  const cx = cr.left + cr.width / 2;
  const cy = cr.top + cr.height / 2;
  let best: HTMLElement | null = null;
  let bs = 1e12;
  for (let i = 0; i < list.length; i++) {
    const el = list[i];
    if (el === cur) continue;
    const r = el.getBoundingClientRect();
    const dx = r.left + r.width / 2 - cx;
    const dy = r.top + r.height / 2 - cy;
    let prim = 0;
    let sec = 0;
    if (dir === 'right' && dx > 4) {
      prim = dx;
      sec = Math.abs(dy);
    } else if (dir === 'left' && dx < -4) {
      prim = -dx;
      sec = Math.abs(dy);
    } else if (dir === 'down' && dy > 4) {
      prim = dy;
      sec = Math.abs(dx);
    } else if (dir === 'up' && dy < -4) {
      prim = -dy;
      sec = Math.abs(dx);
    } else continue;
    const score = prim + sec * 2.2;
    if (score < bs) {
      bs = score;
      best = el;
    }
  }
  if (best) {
    best.focus();
    try {
      best.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    } catch {
      /* ignore */
    }
  }
}

function goBack() {
  const btns = document.querySelectorAll<HTMLElement>('button');
  for (let i = 0; i < btns.length; i++) {
    if ((btns[i].textContent || '').indexOf('بازگشت') >= 0) {
      btns[i].click();
      return;
    }
  }
}

export function startMenuNav(): () => void {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const w = window as any;
  const onKey = (e: KeyboardEvent) => {
    const map: Record<string, Dir> = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' };
    const d = map[e.key];
    if (d) {
      e.preventDefault();
      move(d);
    } else if (e.key === 'Escape' || e.key === 'Backspace') {
      goBack();
    }
  };
  window.addEventListener('keydown', onKey);

  // gamepad API (desktop, Chrome) — edge triggered
  const prev: Record<string, boolean> = {};
  let raf = 0;
  const edge = (k: string, now: boolean, fn: () => void) => {
    if (now && !prev[k]) fn();
    prev[k] = now;
  };
  const poll = () => {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (let i = 0; i < pads.length; i++) {
      const p = pads[i];
      if (!p) continue;
      const b = (n: number) => !!p.buttons[n] && p.buttons[n].pressed;
      const ax = p.axes[0] || 0;
      const ay = p.axes[1] || 0;
      edge('l', b(14) || ax < -0.6, () => move('left'));
      edge('r', b(15) || ax > 0.6, () => move('right'));
      edge('u', b(12) || ay < -0.6, () => move('up'));
      edge('d', b(13) || ay > 0.6, () => move('down'));
      edge('a', b(0), () => {
        const a = document.activeElement as HTMLElement | null;
        if (a && a !== document.body) a.click();
        else move('down');
      });
      edge('b', b(1), goBack);
      break;
    }
    raf = requestAnimationFrame(poll);
  };
  raf = requestAnimationFrame(poll);

  // native bridge used by the Android-box APK (A / B / stick forwarded from Java)
  const prevBtn = w.__padBtn;
  const prevAxis = w.__padAxis;
  let axisState = '';
  w.__padBtn = (i: number, down: boolean) => {
    if (!down) return;
    if (i === 0) {
      const a = document.activeElement as HTMLElement | null;
      if (a && a !== document.body) a.click();
      else move('down');
    } else if (i === 1) goBack();
  };
  w.__padAxis = (x: number, y: number) => {
    const s = x < -0.6 ? 'l' : x > 0.6 ? 'r' : y < -0.6 ? 'u' : y > 0.6 ? 'd' : '';
    if (s && s !== axisState) move(s === 'l' ? 'left' : s === 'r' ? 'right' : s === 'u' ? 'up' : 'down');
    axisState = s;
  };

  return () => {
    window.removeEventListener('keydown', onKey);
    cancelAnimationFrame(raf);
    w.__padBtn = prevBtn;
    w.__padAxis = prevAxis;
  };
}
