export type FormId = 'human' | 'heat' | 'fourarms' | 'xlr8' | 'diamond' | 'jetray' | 'alienx';

export const FORM_ORDER: FormId[] = ['heat', 'fourarms', 'xlr8', 'diamond', 'jetray', 'alienx'];

export interface FormDef {
  id: FormId;
  name: string;
  nameEn: string;
  color: string;
  glow: string;
  speed: number;
  jump: number;
  w: number;
  h: number;
  attackCd: number;
  attackDmg: number;
  duration: number;
  desc: string;
}

export const FORMS: Record<FormId, FormDef> = {
  human: { id: 'human', name: 'محمد پارسا', nameEn: 'Parsa', color: '#873C68', glow: '#00FF7F', speed: 270, jump: 640, w: 34, h: 68, attackCd: 0.45, attackDmg: 6, duration: 0, desc: 'پسرک شجاع — مشت کوچولو و قدرت قاچ‌کردن زمین' },
  heat: { id: 'heat', name: 'کله‌آتشی', nameEn: 'Heatblast', color: '#ff6a00', glow: '#ffb347', speed: 290, jump: 660, w: 40, h: 82, attackCd: 0.35, attackDmg: 16, duration: 26, desc: 'گلوله‌های آتشین پرتاب می‌کند' },
  fourarms: { id: 'fourarms', name: 'چهاردست', nameEn: 'Four Arms', color: '#d6342c', glow: '#ff8c86', speed: 210, jump: 580, w: 62, h: 104, attackCd: 0.55, attackDmg: 34, duration: 26, desc: 'مشت سنگین — نشسته + حمله: کف‌زدن موج‌انفجاری' },
  xlr8: { id: 'xlr8', name: 'موجود سریع و سر (XLR8)', nameEn: 'XLR8', color: '#2b6cff', glow: '#8ec5ff', speed: 540, jump: 620, w: 36, h: 72, attackCd: 0.25, attackDmg: 13, duration: 26, desc: 'سریع‌تر از صوت — ضربه‌ی برق‌آسا' },
  diamond: { id: 'diamond', name: 'کله‌الماسی', nameEn: 'Diamondhead', color: '#2fd27a', glow: '#a7ffd1', speed: 240, jump: 600, w: 44, h: 92, attackCd: 0.6, attackDmg: 11, duration: 26, desc: 'خارهای کریستالی می‌اندازد و نصف آسیب می‌بیند' },
  jetray: { id: 'jetray', name: 'جت‌ری', nameEn: 'Jetray', color: '#c81e1e', glow: '#facc15', speed: 310, jump: 640, w: 44, h: 80, attackCd: 0.3, attackDmg: 15, duration: 26, desc: 'پرواز (پرش را نگه دار) و لیزر عصبی — در آب فوق‌سریع' },
  alienx: { id: 'alienx', name: 'ایلان ایکس', nameEn: 'Alien X', color: '#0b0b1f', glow: '#a78bfa', speed: 300, jump: 720, w: 40, h: 92, attackCd: 0.5, attackDmg: 32, duration: 16, desc: 'انفجار ستاره‌ای و کند کردن زمان — نشسته + حمله: توقف زمان' },
};

export interface DialogChoice {
  text: string;
  reply: DialogLine[];
}
export interface DialogLine {
  speaker: string;
  text: string;
  color?: string;
  choices?: DialogChoice[];
}

export type Theme = 'day' | 'sunset' | 'night' | 'park' | 'ruins' | 'rooftop' | 'ship' | 'subway' | 'cosmic' | 'beach' | 'forest' | 'ocean';
export type EnemyKind = 'scout' | 'grunt' | 'brute' | 'tank' | 'meteor' | 'shark' | 'goliath' | 'ex';
export type NpcKind = 'girl' | 'boy' | 'cat' | 'adult';

export interface NpcDef {
  name: string;
  role: string;
  kind: NpcKind;
  atFrac: number;
  dialog: DialogLine[];
  color: string;
}

export interface LevelDef {
  id: number;
  name: string;
  subtitle: string;
  theme: Theme;
  length: number;
  seed: number;
  enemies: Partial<Record<EnemyKind, number>>;
  boss?: 'ex' | 'goliath';
  bossHp?: number;
  npc?: NpcDef;
  intro: DialogLine[];
  outro: DialogLine[];
  unlock?: FormId;
  noWatch?: boolean;
  craterAt?: number;
  craterDialog?: DialogLine[];
  malfunction?: boolean;
  noAlienX?: boolean;
  meteorRain?: boolean;
  defend?: number;
  questions?: DialogLine[];
  exBackground?: boolean;
  kevinAlly?: boolean;
  friendOnComplete?: string;
  available: FormId[];
  water?: { from: number; to: number; surface: number }[];
  seaZones?: number;
  maxRV?: boolean;
  gwenAlly?: boolean;
  storm?: boolean;
  dark?: boolean;
  chapter?: number;
}

const P = 'محمد پارسا';
const BEL = 'بلیکوس';
const SER = 'سرینا';
const KEVIN = 'کوین';
const EX = 'اِکس';
const NAR = 'راوی';
export const C = { p: '#f5c6e0', bel: '#f87171', ser: '#f9a8d4', kevin: '#cbd5e1', ex: '#ff5a5a', npc: '#fde68a', nar: '#ddd' };

const A1: FormId[] = ['heat'];
const A2: FormId[] = ['heat', 'fourarms'];
const A4: FormId[] = ['heat', 'fourarms', 'xlr8'];
const A6: FormId[] = ['heat', 'fourarms', 'xlr8', 'diamond'];
const A10: FormId[] = ['heat', 'fourarms', 'xlr8', 'diamond', 'alienx'];

export const LEVELS: LevelDef[] = [
  {
    id: 1, name: 'سقوط شهاب‌سنگ و کشف ساعت', subtitle: 'پارک شهر — شب', theme: 'park', length: 3600, seed: 11,
    enemies: { scout: 4 }, noWatch: true, craterAt: 0.32, unlock: 'heat', available: A1,
    intro: [
      { speaker: NAR, text: 'شهر نورآباد، یک شب آرام. ناگهان شهاب‌سنگی مرموز وسط پارک شهر سقوط می‌کند...', color: C.nar },
      { speaker: P, text: 'وااای! یه ستاره افتاد تو پارک! باید برم ببینم چیه!', color: C.p },
      { speaker: NAR, text: 'با A/D یا ← → حرکت کن و با Space بپر. (دسته: استیک چپ و دکمه A)', color: C.nar },
    ],
    craterDialog: [
      { speaker: P, text: 'این چیه؟ یه ساعت سبز خوشگل! بذار دستش کنم...', color: C.p },
      { speaker: NAR, text: 'کلیک! ساعت روی مچ چپ پارسا قفل شد. هرچه کشید، در نیامد!', color: C.nar },
      { speaker: P, text: 'در نمیاد! ولی... چه نور قشنگی داره!', color: C.p },
      { speaker: BEL, text: 'کودک! تو ساعت اُمنی‌تریکس را لمس کردی. من بلیکوس هستم، صدای عدالت درون این ساعت.', color: C.bel },
      { speaker: SER, text: 'و من سرینا هستم، صدای محبت. نترس عزیزم؛ ما حالا درون وجود تو زندگی می‌کنیم.', color: C.ser },
      { speaker: BEL, text: 'ساعت را به زمین بکوب (K) تا زمین را قاچ کنی. با Q ساعت را باز کن و با E به «کله‌آتشی» تبدیل شو. با J حمله کن.', color: C.bel },
      { speaker: SER, text: 'ربات‌های شناسایی نزدیک می‌شوند... قدرتت را امتحان کن پارسا!', color: C.ser },
    ],
    outro: [
      { speaker: P, text: 'آخ جووون! من آتیش پرت کردم! زمین رو قاچ کردم!', color: C.p },
      { speaker: SER, text: 'آفرین قهرمان کوچولو! اما سیگنال ساعت در فضا پخش شده... مراقب باش.', color: C.ser },
    ],
  },
  {
    id: 2, name: 'ربات‌های تهاجمی بیگانه', subtitle: 'خیابان‌های شهر', theme: 'day', length: 3800, seed: 22,
    enemies: { scout: 8 }, unlock: 'fourarms', available: A2,
    intro: [
      { speaker: BEL, text: 'سیگنال ساعت در فضا پخش شده. نخستین ناوگان ربات‌های شناسایی دشمن به خیابان‌ها سرازیر شده‌اند.', color: C.bel },
      { speaker: SER, text: 'با آتش کله‌آتشی ربات‌ها را بزن. گلوله‌ی آتش از دور هم کار می‌کند!', color: C.ser },
    ],
    outro: [
      { speaker: BEL, text: 'ساعت DNA جدیدی پیدا کرد: جنگجوی «چهاردست»!', color: C.bel },
      { speaker: P, text: 'چهار تا دست؟! یعنی چهار تا بستنی می‌تونم بگیرم!', color: C.p },
    ],
  },
  {
    id: 3, name: 'نجات سارا در مرکز شهر', subtitle: 'اولین دوست', theme: 'day', length: 4000, seed: 33,
    enemies: { scout: 4, grunt: 5 }, available: A2,
    npc: { name: 'سارا', role: 'همکلاسی مهدکودک', kind: 'girl', atFrac: 0.55, color: '#facc15',
      dialog: [
        { speaker: 'سارا', text: 'پارسا! تو نجاتم دادی! ربات‌ها دورم جمع شده بودن، خیلی ترسیده بودم.', color: C.npc },
        { speaker: P, text: 'دیگه نترس سارا. دوست‌ها همیشه همدیگه رو نجات می‌دن!', color: C.p },
        { speaker: 'سارا', text: 'من هم کمکت می‌کنم! بیا این ساندویچ رو بخور تا جون بگیری.', color: C.npc },
      ] },
    intro: [
      { speaker: SER, text: 'آوار سنگین در پیاده‌رو باعث گیر افتادن سارا، همبازی مهدکودک پارسا شده. ربات‌ها دورش جمع شده‌اند!', color: C.ser },
      { speaker: BEL, text: 'اول دشمنان اطراف او را شکست بده، بعد با دکمه‌ی ↑ نجاتش بده.', color: C.bel },
    ],
    outro: [{ speaker: P, text: 'من یه دوست نجات دادم! این بهترین حس دنیاست!', color: C.p }],
  },
  {
    id: 4, name: 'ظهور موج صوتی و قدرت XLR8', subtitle: 'پل بزرگ', theme: 'sunset', length: 4400, seed: 44,
    enemies: { scout: 6, grunt: 5 }, unlock: 'xlr8', available: A4,
    intro: [
      { speaker: BEL, text: 'دشمنان با موشک‌های هدایت‌شونده خیابان‌ها را محاصره کرده‌اند. ربات‌ها از دور شلیک می‌کنند.', color: C.bel },
      { speaker: SER, text: 'پارسا نیازمند سرعتی بالاتر از صوت است... ساعت دارد چیزی را حس می‌کند!', color: C.ser },
    ],
    outro: [
      { speaker: BEL, text: 'موجود سریع و سر — XLR8 — آزاد شد! با او از همه‌ی موشک‌ها جلو می‌زنی.', color: C.bel },
      { speaker: P, text: 'زووووم! حالا از همه سریع‌ترم!', color: C.p },
    ],
  },
  {
    id: 5, name: 'دیدار با کوین لوین', subtitle: 'جذب ماده', theme: 'night', length: 4400, seed: 55,
    enemies: { grunt: 8, scout: 4 }, kevinAlly: true, friendOnComplete: 'کوین', available: A4,
    intro: [
      { speaker: NAR, text: 'پسری به نام کوین با دست زدن به ستون‌های آهنی، بدنش فلزی می‌شود و با ربات‌ها می‌جنگد!', color: C.nar },
      { speaker: KEVIN, text: 'هی کوچولو! اون ساعت باحاله. من کوینم؛ به هرچی دست بزنم همون می‌شم. بیا با هم اینا رو بزنیم!', color: C.kevin },
      { speaker: P, text: 'باشه کوین! با هم قوی‌تریم!', color: C.p },
      { speaker: SER, text: 'اگر در حالت تبدیل‌شده به کوین دست بزنی، قدرتت را جذب می‌کند و دو برابر می‌زند!', color: C.ser },
    ],
    outro: [
      { speaker: KEVIN, text: 'رفیق، تو عالی بودی! از این به بعد من همیشه کنارتم.', color: C.kevin },
      { speaker: P, text: 'هورا! کوین بهترین دوست من شد!', color: C.p },
    ],
  },
  {
    id: 6, name: 'شکوفایی بلورهای کله‌الماسی', subtitle: 'توپ‌های لیزری', theme: 'sunset', length: 4600, seed: 66,
    enemies: { scout: 7, grunt: 6, brute: 2 }, unlock: 'diamond', kevinAlly: true, available: A6,
    intro: [{ speaker: BEL, text: 'توپ‌های لیزری غول‌پیکر دشمن دیوارها را سوراخ می‌کنند. ساعت به رنگ فیروزه‌ای می‌درخشد...', color: C.bel }],
    outro: [
      { speaker: SER, text: 'کله‌الماسی بیدار شد! بدنش پرتوهای لیزر را منعکس می‌کند و خارهای کریستالی می‌اندازد.', color: C.ser },
      { speaker: P, text: 'من می‌درخشم! مثل یه الماس بزرگ!', color: C.p },
    ],
  },
  {
    id: 7, name: 'خرابکاری در ساعت!', subtitle: 'نفوذ نفوذی', theme: 'ruins', length: 4400, seed: 77,
    enemies: { scout: 6, grunt: 6, brute: 1 }, malfunction: true, kevinAlly: true, available: A6,
    intro: [
      { speaker: NAR, text: 'یک ربات هکر مخفی با شلیک پارازیت کوانتومی ساعت پارسا را خراب می‌کند! زززت!', color: C.nar },
      { speaker: P, text: 'آخ! ساعتم داره خودش عوض می‌شه! کله‌آتشی... نه الماسی... نه!', color: C.p },
      { speaker: BEL, text: 'اتصال کوتاه! ساعت به صورت تصادفی موجود را عوض می‌کند. با هر شکلی که هستی بجنگ!', color: C.bel },
      { speaker: SER, text: 'قدرت قاچ‌کردن زمین هنوز کار می‌کند. هکرها را پاکسازی کن!', color: C.ser },
    ],
    outro: [{ speaker: KEVIN, text: 'تونستی با ساعت خراب هم ببری! ولی باید یکی تعمیرش کنه... علی رو می‌شناسم!', color: C.kevin }],
  },
  {
    id: 8, name: 'تعمیرگاه علی و تنظیم ساعت', subtitle: 'کالیبره کردن ساعت', theme: 'day', length: 4600, seed: 88,
    enemies: { grunt: 8, scout: 6, brute: 2 }, kevinAlly: true, available: A6,
    npc: { name: 'علی', role: 'پسر همسایه — مکانیک کوچک', kind: 'boy', atFrac: 0.5, color: '#3b82f6',
      dialog: [
        { speaker: 'علی', text: 'پارسا! ممنون که ازم محافظت کردی. حالا بذار ساعتت رو با آچارم کالیبره کنم... تق‌تق... تمام!', color: C.npc },
        { speaker: BEL, text: 'سیستم پایدار شد. این پسر استعداد مهندسی دارد.', color: C.bel },
        { speaker: P, text: 'مرسی علی! تو دوست من شدی!', color: C.p },
      ] },
    intro: [{ speaker: SER, text: 'علی، دوست مکانیک پارسا، با ابزارهایش وسط معرکه ایستاده. از او محافظت کن و نجاتش بده!', color: C.ser }],
    outro: [{ speaker: 'علی', text: 'ساعتت حالا تنظیمه! اگه باز خراب شد، خبرم کن!', color: C.npc }],
  },
  {
    id: 9, name: 'بزرگراه شکافته‌شده', subtitle: 'تانک‌های اِکس', theme: 'sunset', length: 5000, seed: 99,
    enemies: { tank: 4, grunt: 6, scout: 4 }, kevinAlly: true, available: A6,
    intro: [
      { speaker: BEL, text: 'تانک‌های زمینی اِکس پل اتوبان را مسدود کرده‌اند. وقت استفاده از قاچ‌کردن زمین در مقیاس وسیع است!', color: C.bel },
      { speaker: SER, text: 'ساعت را به آسفالت بکوب (K) — شکاف نوری تانک‌ها را از جا می‌کَند!', color: C.ser },
    ],
    outro: [{ speaker: KEVIN, text: 'تانک‌ها رو ترکوندی! ولی... پارسا؟ چشمات داره می‌درخشه... چی شده؟', color: C.kevin }],
  },
  {
    id: 10, name: 'ورود به ذهن ایلان ایکس', subtitle: 'بُعد کیهانی — بلیکوس و سرینا', theme: 'cosmic', length: 2800, seed: 110,
    enemies: {}, unlock: 'alienx', available: A10,
    intro: [
      { speaker: NAR, text: 'در اوج نبرد، هوشیاری پارسا وارد بُعد کیهانی ایلان ایکس می‌شود. همه‌جا ستاره است...', color: C.nar },
      { speaker: BEL, text: 'کودک، تو به مکانی آمده‌ای که هیچ انسانی نیامده. ما سه نفر باید با هم تصمیم بگیریم.', color: C.bel },
      { speaker: SER, text: 'به سه پرسش ما پاسخ بده پارسا. با ← → انتخاب کن و با E تأیید کن. از قلبت جواب بده.', color: C.ser },
    ],
    questions: [
      { speaker: BEL, text: 'پرسش اول: دشمنی که شهر را خراب کرده شکست خورده و افتاده. با او چه می‌کنی؟', color: C.bel,
        choices: [
          { text: 'نابودش می‌کنم تا دیگر برنگردد', reply: [
            { speaker: BEL, text: 'عدالت سخت‌گیرانه... قابل درک است.', color: C.bel },
            { speaker: SER, text: 'اما پارسا، یک قهرمان واقعی وقتی دشمن افتاده، دستش را می‌گیرد. قدرت بدون رحم، ویرانی است.', color: C.ser },
            { speaker: P, text: 'راست می‌گی سرینا... من نمی‌خوام مثل اِکس باشم.', color: C.p } ] },
          { text: 'نگهش می‌دارم و فرصت دوباره می‌دهم', reply: [
            { speaker: SER, text: 'قلب مهربان! این همان چیزی است که دنیا را نجات می‌دهد.', color: C.ser },
            { speaker: BEL, text: 'هوم... شجاعت هم همین است: بخشیدن وقتی می‌توانی مجازات کنی. قبول.', color: C.bel } ] },
        ] },
      { speaker: SER, text: 'پرسش دوم: می‌توانی زمان را متوقف کنی و همه‌ی اسباب‌بازی‌های دنیا را برداری. چه می‌کنی؟', color: C.ser,
        choices: [
          { text: 'همه را برمی‌دارم! اسباب‌بازی!', reply: [
            { speaker: BEL, text: 'قدرت برای سود شخصی؟ این راه اِکس است، نه راه تو.', color: C.bel },
            { speaker: P, text: 'اوه... خب فقط یه کمی! باشه، نه. اسباب‌بازی مال همه‌ی بچه‌هاست.', color: C.p },
            { speaker: SER, text: 'آفرین که فهمیدی عزیزم.', color: C.ser } ] },
          { text: 'زمان را فقط برای نجات مردم متوقف می‌کنم', reply: [
            { speaker: BEL, text: 'درست است. قدرت، امانت است نه هدیه.', color: C.bel },
            { speaker: SER, text: 'تو واقعاً انتخاب درست ساعت بودی.', color: C.ser } ] },
        ] },
      { speaker: BEL, text: 'پرسش آخر: ابعاد جهان ترک برداشته‌اند. ترمیم آن یعنی تو برای همیشه کوچک و بی‌قدرت بمانی. حاضری؟', color: C.bel,
        choices: [
          { text: 'بله! دنیا مهم‌تر از قدرت منه', reply: [
            { speaker: SER, text: 'اشک شوق... بلیکوس، او آماده است.', color: C.ser },
            { speaker: BEL, text: 'موافقم. سه رأی از سه رأی. ژن کیهانی ایلان ایکس آزاد می‌شود!', color: C.bel } ] },
          { text: 'می‌ترسم... ولی دوستام رو تنها نمی‌ذارم', reply: [
            { speaker: SER, text: 'ترسیدن اشکالی ندارد پارسا. شجاعت یعنی با وجود ترس، درست را انتخاب کنی.', color: C.ser },
            { speaker: BEL, text: 'پذیرفته شد. سه رأی از سه رأی. ژن کیهانی ایلان ایکس آزاد می‌شود!', color: C.bel } ] },
        ] },
    ],
    outro: [
      { speaker: NAR, text: 'بدن پارسا سیاه مثل شب و پر از ستاره شد. ایلان ایکس، قدرتمندترین موجود ساعت، بیدار شد.', color: C.nar },
      { speaker: SER, text: 'این قدرت فقط ۱۶ ثانیه دوام دارد و زمان را برای دشمنان کند می‌کند. عاقلانه استفاده کن.', color: C.ser },
      { speaker: P, text: 'من پر از ستاره‌ام! بیایین بریم شهر رو نجات بدیم!', color: C.p },
    ],
  },
  {
    id: 11, name: 'تعقیب و گریز روی بام‌های شهر', subtitle: 'ربات‌های نینجا', theme: 'rooftop', length: 5200, seed: 121,
    enemies: { scout: 12, grunt: 6 }, kevinAlly: true, available: A10,
    intro: [
      { speaker: SER, text: 'ربات‌های نینجا دنبال دزدیدن سارا و علی هستند! قبل از فرارشان شکارشان کن.', color: C.ser },
      { speaker: BEL, text: 'با سرعت XLR8 از ساختمانی به ساختمان دیگر بپر!', color: C.bel },
    ],
    outro: [{ speaker: 'سارا', text: 'پارسا تو از همه سریع‌تری! ممنون!', color: C.npc }],
  },
  {
    id: 12, name: 'نجات برفی، گربه‌ی بازیگوش محله', subtitle: 'کانتینرهای در آتش', theme: 'night', length: 4800, seed: 132,
    enemies: { grunt: 8, brute: 2, scout: 6 }, kevinAlly: true, available: A10,
    npc: { name: 'برفی', role: 'گربه‌ی بازیگوش خیابان', kind: 'cat', atFrac: 0.6, color: '#f8fafc',
      dialog: [
        { speaker: 'برفی', text: 'میـــو! میو میو! (پارسا رو لیس می‌زنه)', color: C.npc },
        { speaker: P, text: 'برفی کوچولو! دیگه نترس، من اینجام. بیا بغلم!', color: C.p },
        { speaker: SER, text: 'نجات یک موجود کوچک هم به اندازه‌ی نجات یک شهر ارزش دارد.', color: C.ser },
      ] },
    intro: [{ speaker: NAR, text: 'صدای میو میو از میان کانتینرهای در آتش می‌آید! برفی، گربه‌ی محله در خطر است!', color: C.nar },
      { speaker: BEL, text: 'با کله‌الماسی از خودت در برابر آتش محافظت کن و دشمنان دور برفی را دور کن.', color: C.bel }],
    outro: [{ speaker: P, text: 'برفی حالا دوست ماست! میو!', color: C.p }],
  },
  {
    id: 13, name: 'ارتش ربات‌های زره‌پوش اِکس', subtitle: 'غول‌های آهنی', theme: 'day', length: 5200, seed: 143,
    enemies: { brute: 6, grunt: 8, scout: 4 }, kevinAlly: true, available: A10,
    intro: [
      { speaker: BEL, text: 'غول‌های آهنی سنگین به میدان آمده‌اند؛ تیرهای عادی روی آن‌ها بی‌اثر است.', color: C.bel },
      { speaker: KEVIN, text: 'من فلز سخت رو لمس می‌کنم و آهنی می‌شم! تو هم چهاردست شو و زره‌هاشون رو خرد کن!', color: C.kevin },
    ],
    outro: [{ speaker: KEVIN, text: 'چه تیمی! هیچ زرهی جلوی ما دووم نمیاره.', color: C.kevin }],
  },
  {
    id: 14, name: 'موج دوم هک ساعت و غافلگیری', subtitle: 'سه فرمانده سایبری', theme: 'night', length: 5000, seed: 154,
    enemies: { brute: 3, grunt: 8, scout: 8 }, malfunction: true, noAlienX: true, kevinAlly: true, available: A6,
    intro: [
      { speaker: SER, text: 'ماهواره‌ی مدارگرد اِکس فرکانس معکوس می‌فرستد. ساعت در حال داغ شدن است!', color: C.ser },
      { speaker: BEL, text: 'میدان مغناطیسی دشمن عملکرد ساعت را دچار نوسان کرده. ایلان ایکس در دسترس نیست! سه فرمانده‌ی سایبری (غول‌های زره‌پوش) را شکست بده.', color: C.bel },
    ],
    outro: [{ speaker: BEL, text: 'فرکانس هک خنثی شد. ساعت دوباره پایدار است.', color: C.bel }],
  },
  {
    id: 15, name: 'باران خرده‌شهاب‌سنگ‌ها', subtitle: 'آسمان بنفش', theme: 'ruins', length: 5000, seed: 165,
    enemies: { scout: 6, grunt: 6 }, meteorRain: true, kevinAlly: true, available: A10,
    intro: [
      { speaker: NAR, text: 'آسمان به رنگ بنفش تیره درآمده و شهاب‌سنگ‌های داغ به سمت خانه‌های مردم سرازیر شده‌اند.', color: C.nar },
      { speaker: SER, text: 'سنگ‌های آسمانی را قبل از رسیدن به زمین با آتش کله‌آتشی یا کریستال‌های الماسی نابود کن!', color: C.ser },
    ],
    outro: [{ speaker: P, text: 'اِکس داره نزدیک می‌شه... این شهاب‌سنگ‌ها رو اون فرستاده.', color: C.p }],
  },
  {
    id: 16, name: 'نبرد در ایستگاه متروی زیرزمینی', subtitle: 'فضای بسته و تاریک', theme: 'subway', length: 5200, seed: 176,
    enemies: { grunt: 10, brute: 3, scout: 6 }, kevinAlly: true, available: A10,
    intro: [{ speaker: BEL, text: 'دشمنان به عمق مترو نفوذ کرده‌اند تا زیرساخت‌های شهر را بمب‌گذاری کنند. تونل را با ضربه‌ی قاچ زمین پاکسازی کن.', color: C.bel }],
    outro: [{ speaker: KEVIN, text: 'بمب‌ها خنثی شدن! ولی یه سایه‌ی بزرگ روی آسمون افتاده...', color: C.kevin }],
  },
  {
    id: 17, name: 'پیش‌قراول هیولای گودزیلایی', subtitle: 'مینی‌باس: نگهبان کریستالی', theme: 'sunset', length: 4200, seed: 187,
    enemies: { scout: 4 }, boss: 'goliath', bossHp: 450, kevinAlly: true, available: A10,
    intro: [
      { speaker: NAR, text: 'سایه‌ای عظیم بر آسمان می‌افتد. غولِ دست راست اِکس با قد ۲۰ متری وارد میدان می‌شود!', color: C.nar },
      { speaker: BEL, text: 'نگهبان کریستالی اِکس — گولیات. با ضربات ترکیبی چهاردست و ایلان ایکس شکستش بده!', color: C.bel },
    ],
    outro: [{ speaker: SER, text: 'نگهبان شکست خورد. اما این فقط پیش‌قراول بود...', color: C.ser }],
  },
  {
    id: 18, name: 'اتحاد دوستان شهر برای نجات دنیا', subtitle: 'دفاع از برج مخابراتی', theme: 'day', length: 3400, seed: 198,
    enemies: { scout: 4 }, defend: 75, kevinAlly: true, available: A10,
    intro: [
      { speaker: NAR, text: 'کوین، سارا، علی، برفی و همه‌ی بچه‌ها کنار پارسا جمع شده‌اند تا انرژی ساعت را به ۱۰۰٪ برسانند.', color: C.nar },
      { speaker: 'علی', text: 'من برج مخابراتی رو به ساعتت وصل می‌کنم. ۷۵ ثانیه ازش دفاع کن تا شارژ کامل بشه!', color: C.npc },
      { speaker: 'سارا', text: 'ما هم سلامتی‌ات رو پر می‌کنیم. تو فقط بجنگ پارسا!', color: C.npc },
    ],
    outro: [
      { speaker: 'علی', text: 'شارژ ۱۰۰٪! ساعتت حالا قوی‌تر از همیشه‌ست.', color: C.npc },
      { speaker: P, text: 'با دوستام هیچی نمی‌تونه جلومو بگیره!', color: C.p },
    ],
  },
  {
    id: 19, name: 'سایه‌ی اِکس آسمان را می‌بلعد', subtitle: 'ارتش محافظ غول', theme: 'ruins', length: 5600, seed: 209,
    enemies: { grunt: 10, brute: 4, tank: 3, scout: 8 }, exBackground: true, kevinAlly: true, available: A10,
    intro: [
      { speaker: NAR, text: 'زمین می‌لرزد. آسمان‌خراش‌ها مثل اسباب‌بازی زیر پای «اِکس» خرد می‌شوند! موجودی به اندازه‌ی گودزیلا با چشم‌های خونین ظاهر شد!', color: C.nar },
      { speaker: EX, text: 'کــودک... ســاعــت را بــده!', color: C.ex },
      { speaker: P, text: 'هیچ‌وقت! این شهر خونه‌ی منه!', color: C.p },
      { speaker: BEL, text: 'ارتش محافظش را نابود کن تا راه به سمت او باز شود.', color: C.bel },
    ],
    outro: [{ speaker: KEVIN, text: 'راه بازه. حالا نوبت خودشه. آماده‌ای رفیق؟', color: C.kevin }, { speaker: P, text: 'آماده‌ام!', color: C.p }],
  },
  {
    id: 20, name: 'نبرد نهایی علیه اِکس غول‌پیکر', subtitle: 'Titan Godzilla X', theme: 'rooftop', length: 4600, seed: 220,
    enemies: { scout: 4 }, boss: 'ex', bossHp: 1000, kevinAlly: true, available: A10,
    intro: [
      { speaker: EX, text: 'بغرّم تا آسمان بشکافد! ساعت را از دستت در می‌آورم، کوچولو!', color: C.ex },
      { speaker: SER, text: 'پارسا، هسته‌ی سرخ روی سینه‌اش نقطه‌ی ضعف اوست. موج زمینی → بپر. چشم‌های سفید → بنشین. شهاب‌سنگ‌ها را بزن!', color: C.ser },
      { speaker: BEL, text: 'وقت قاچ‌کردن زمین و قدرت نهایی ایلان ایکس است. ما با توییم.', color: C.bel },
      { speaker: P, text: 'اِکس! برو بیرون از شهر من!', color: C.p },
    ],
    outro: [
      { speaker: EX, text: 'نــــــه! غیرممکن... یک بچه‌ی چهارساله...!', color: C.ex },
      { speaker: NAR, text: 'هسته‌ی اِکس خاموش شد و غول عظیم در نور سبز ساعت ناپدید شد. زمین نجات یافت.', color: C.nar },
      { speaker: BEL, text: 'تو ثابت کردی قدرت واقعی در عدالت همراه با مهربانی است.', color: C.bel },
      { speaker: SER, text: 'و در دوستی. ما به تو افتخار می‌کنیم پارسا.', color: C.ser },
      { speaker: KEVIN, text: 'رفیق... تو بهترین دوستی هستی که تا حالا داشتم.', color: C.kevin },
      { speaker: NAR, text: 'اما... از میان دود، اِکس زخمی به سمت دریا خزید و در اعماق آب ناپدید شد.', color: C.nar },
      { speaker: EX, text: 'این پایان نیست کوچولو... در اعماق دریا قوی‌تر برمی‌گردم!', color: C.ex },
      { speaker: P, text: 'باید بریم دریا! ولی... من که شنا بلد نیستم! آهان، ساعتم بلده!', color: C.p },
    ],
  },
  ...buildLaterLevels(),
];

/* ---------------- Chapters 2 & 3 (levels 21–50) ---------------- */
function buildLaterLevels(): LevelDef[] {
  const MAX = 'بابابزرگ مکس';
  const GWEN = 'گوئن';
  const cm = '#fdba74';
  const cg = '#f9a8d4';
  const ALL: FormId[] = ['heat', 'fourarms', 'xlr8', 'diamond', 'jetray', 'alienx'];
  const OCEAN = (len: number) => [{ from: 0, to: len, surface: 130 }];
  type Spec = Partial<LevelDef> & { name: string; subtitle: string; theme: Theme; enemies: LevelDef['enemies']; intro: DialogLine[] };
  const specs: Spec[] = [
    // ---- Chapter 2: beach & sea (21–35)
    { name: 'بابابزرگ مکس و گوئن', subtitle: 'ساحل نورآباد', theme: 'beach', enemies: { scout: 4, grunt: 4 }, seaZones: 1, friendOnComplete: 'گوئن', intro: [
      { speaker: NAR, text: 'صبح روز بعد، یک ماشین کاروان نقره‌ای کنار ساحل ترمز کرد: «رَست باکِت».', color: C.nar },
      { speaker: MAX, text: 'سلام قهرمان کوچولو! من بابابزرگ مکس هستم. سال‌ها پیش من هم با ساعت‌های فضایی سروکار داشتم.', color: cm },
      { speaker: GWEN, text: 'و من گوئن هستم، نوه‌ی بابابزرگ! می‌تونم بشقاب‌های انرژی صورتی پرت کنم. ویـــژ!', color: cg },
      { speaker: KEVIN, text: 'گوئن! بالاخره اومدی! پارسا، گوئن بهترین دوست منه. حالا سه‌تایی هستیم!', color: C.kevin },
      { speaker: MAX, text: 'هر وقت خسته شدی بیا کنار کاروان و ↑ بزن، یه چیز خوشمزه بهت می‌دم. حالا برو تو آب: Space شنا، S شیرجه!', color: cm },
    ], outro: [{ speaker: GWEN, text: 'تیم ما حالا کامله! کوین، پارسا، من و بابابزرگ!', color: cg }] },
    { name: 'اولین شیرجه', subtitle: 'آب‌های کم‌عمق', theme: 'beach', enemies: { scout: 4, shark: 4, grunt: 2 }, seaZones: 3, intro: [
      { speaker: MAX, text: 'ربات‌کوسه‌های اِکس توی آب‌های کم‌عمق هستن. شنا کن و بزنشون، ولی مراقب دندوناشون باش!', color: cm },
    ] },
    { name: 'جت‌ری، شکارچی آسمان و دریا', subtitle: 'موجود جدید', theme: 'beach', enemies: { scout: 9, shark: 2, grunt: 3 }, seaZones: 2, unlock: 'jetray', intro: [
      { speaker: SER, text: 'ساعت یک امضای ژنتیکی جدید از اعماق دریا حس می‌کند... چیزی که هم پرواز می‌کند و هم شنا!', color: C.ser },
    ], outro: [
      { speaker: BEL, text: 'جت‌ری آزاد شد! پرش را نگه دار تا پرواز کنی. در آب از همه سریع‌تر است و لیزر عصبی شلیک می‌کند.', color: C.bel },
      { speaker: P, text: 'من پرواز می‌کنم! مثل یه بادبادک قرمز!', color: C.p },
    ] },
    { name: 'زیر دریا', subtitle: 'اولین ماجرای زیرآبی', theme: 'ocean', enemies: { shark: 7, grunt: 3 }, intro: [
      { speaker: GWEN, text: 'یه حباب جادویی دورت درست کردم تا بتونی زیر آب نفس بکشی! Space شنا کن، S برو پایین.', color: cg },
      { speaker: P, text: 'وای! ماهی‌های رنگی! سلام ماهی‌ها!', color: C.p },
    ] },
    { name: 'اسکله‌ی ماهیگیرها', subtitle: 'نجات ناخدا', theme: 'beach', enemies: { grunt: 7, brute: 2, tank: 1, shark: 2 }, seaZones: 2,
      npc: { name: 'ناخدا بهرام', role: 'ملوان پیر', kind: 'adult', atFrac: 0.6, color: '#38bdf8', dialog: [
        { speaker: 'ناخدا بهرام', text: 'پسرجان، ربات‌ها قایقم رو گرفته بودن! تو و دوستات قهرمان دریا هستین.', color: C.npc },
        { speaker: P, text: 'خواهش می‌کنم ناخدا! حالا با هم دوستیم.', color: C.p } ] },
      intro: [{ speaker: MAX, text: 'سربازهای اِکس اسکله رو گرفتن. ناخدا بهرام وسطشون گیر افتاده!', color: cm }] },
    { name: 'غار مرجانی', subtitle: 'رنگین‌کمان زیر آب', theme: 'ocean', enemies: { shark: 8, grunt: 3, brute: 1 }, intro: [
      { speaker: SER, text: 'مرجان‌ها از ترس اِکس رنگشان پریده. با هر دشمنی که شکست بدهی، دوباره رنگی می‌شوند.', color: C.ser },
    ] },
    { name: 'طوفان ساحلی', subtitle: 'باد و باران', theme: 'beach', enemies: { scout: 10, shark: 3, grunt: 2 }, seaZones: 2, storm: true, intro: [
      { speaker: GWEN, text: 'طوفان شده! ربات‌ها توی باران پنهان می‌شن. من با بشقاب‌هام کمکت می‌کنم!', color: cg },
    ] },
    { name: 'کراکن مکانیکی', subtitle: 'مینی‌باس زیر آب', theme: 'ocean', enemies: { shark: 3 }, boss: 'goliath', bossHp: 600, intro: [
      { speaker: BEL, text: 'نگهبان کریستالی دوباره ساخته شده، این بار برای اعماق دریا!', color: C.bel },
      { speaker: KEVIN, text: 'من کریستالش رو لمس می‌کنم و الماسی می‌شم. بزن بریم!', color: C.kevin },
    ] },
    { name: 'جزیره‌ی گنج', subtitle: 'نقشه‌ی دزدان دریایی', theme: 'beach', enemies: { grunt: 8, brute: 2, tank: 2 }, seaZones: 2,
      npc: { name: 'آرش', role: 'ماهی‌گیر کوچولو', kind: 'boy', atFrac: 0.5, color: '#22c55e', dialog: [
        { speaker: 'آرش', text: 'من نقشه‌ی گنج رو پیدا کرده بودم که ربات‌ها اومدن! بیا، گنج مال همه‌ی بچه‌های شهره!', color: C.npc },
        { speaker: P, text: 'تقسیم کردن از گنج هم بهتره! ممنون آرش!', color: C.p } ] },
      intro: [{ speaker: MAX, text: 'می‌گن روی این جزیره گنج هست... و یه پسربچه که کمک لازم داره.', color: cm }] },
    { name: 'شهر غرق‌شده', subtitle: 'خرابه‌های باستانی', theme: 'ocean', enemies: { shark: 9, grunt: 5, brute: 2 }, intro: [
      { speaker: SER, text: 'این شهر باستانی هزاران سال زیر آب بوده. اِکس دنبال یک شهاب‌سنگ قدیمی اینجاست.', color: C.ser },
    ] },
    { name: 'خرابکاری زیر آب', subtitle: 'ساعت اتصالی کرد!', theme: 'ocean', enemies: { shark: 8, grunt: 4 }, malfunction: true, intro: [
      { speaker: NAR, text: 'آب شور وارد ساعت شد! زززت! موجودها دوباره خودبه‌خود عوض می‌شوند!', color: C.nar },
      { speaker: GWEN, text: 'نگران نباش پارسا، من و کوین هواتو داریم!', color: cg },
    ] },
    { name: 'فانوس دریایی', subtitle: 'دفاع ۷۰ ثانیه', theme: 'beach', enemies: { scout: 3 }, defend: 70, intro: [
      { speaker: MAX, text: 'اگه نور فانوس خاموش بشه، کشتی‌ها گم می‌شن! ۷۰ ثانیه ازش دفاع کن تا برق اضطراری وصل بشه.', color: cm },
    ] },
    { name: 'شهاب‌سنگ‌های دریایی', subtitle: 'آسمان آتشین', theme: 'beach', enemies: { scout: 6, shark: 3 }, seaZones: 2, meteorRain: true, intro: [
      { speaker: BEL, text: 'اِکس از اعماق، شهاب‌سنگ احضار می‌کند! آن‌ها را در هوا نابود کن. جت‌ری بهترین انتخاب است.', color: C.bel },
    ] },
    { name: 'عمیق‌ترین نقطه', subtitle: 'تاریکی اقیانوس', theme: 'ocean', enemies: { shark: 12, brute: 3, grunt: 2 }, dark: true, intro: [
      { speaker: SER, text: 'اینجا آن‌قدر عمیق است که نور نمی‌رسد. قلب اِکس را حس می‌کنم... خیلی نزدیک است.', color: C.ser },
    ] },
    { name: 'اِکس از دریا برمی‌خیزد', subtitle: 'باس فصل دوم', theme: 'beach', enemies: { scout: 4 }, boss: 'ex', bossHp: 1100, intro: [
      { speaker: EX, text: 'دریا مرا قوی‌تر کرده! این بار ساحل شما را می‌بلعم!', color: C.ex },
      { speaker: GWEN, text: 'هر سه با هم! کوین، من و پارسا!', color: cg },
      { speaker: P, text: 'اِکس! دریا مال ماهی‌هاست، نه تو!', color: C.p },
    ], outro: [
      { speaker: EX, text: 'آاااخ! ...به جنگل باستانی می‌روم. هسته‌ی شهاب‌سنگ اصلی آنجاست. آنجا شکست‌ناپذیر می‌شوم!', color: C.ex },
      { speaker: MAX, text: 'همه سوار کاروان! مقصد بعدی: جنگل باستانی.', color: cm },
    ] },
    // ---- Chapter 3: forest (36–50)
    { name: 'ورود به جنگل باستانی', subtitle: 'درختان هزارساله', theme: 'forest', enemies: { grunt: 6, scout: 4 }, intro: [
      { speaker: MAX, text: 'این جنگل پر از رازهاست. مراقب باشید بچه‌ها، و از حیوانات محافظت کنید.', color: cm },
      { speaker: P, text: 'چه درختای بلندی! شبیه آسمون‌خراشن!', color: C.p },
    ] },
    { name: 'رودخانه‌ی جنگلی', subtitle: 'شنا در رود', theme: 'forest', enemies: { shark: 3, grunt: 5, scout: 3 }, seaZones: 3, intro: [
      { speaker: GWEN, text: 'رباط‌کوسه‌ها از دریا تا رودخونه اومدن! باید از آب رد بشیم.', color: cg },
    ] },
    { name: 'درختان غول‌پیکر', subtitle: 'پرواز بین شاخه‌ها', theme: 'forest', enemies: { scout: 10, grunt: 4 }, intro: [
      { speaker: BEL, text: 'ربات‌های دیده‌بان روی سکوهای میان درخت‌ها ایستاده‌اند. از شاخه‌ها بپر یا با جت‌ری پرواز کن!', color: C.bel },
    ] },
    { name: 'برفی گم شده!', subtitle: 'نجات دوباره‌ی برفی', theme: 'forest', enemies: { grunt: 7, scout: 4, brute: 1 },
      npc: { name: 'برفی', role: 'گربه‌ی بازیگوش', kind: 'cat', atFrac: 0.6, color: '#fff', dialog: [
        { speaker: 'برفی', text: 'میـــو! میو! (برفی دنبال کاروان اومده بود و گم شده بود)', color: C.npc },
        { speaker: P, text: 'برفی! چطوری تا اینجا اومدی؟ بیا بغلم، دیگه گم نمی‌شی!', color: C.p } ] },
      intro: [{ speaker: KEVIN, text: 'صدای میو میو میاد... این صدای برفیه!', color: C.kevin }] },
    { name: 'نفرین ساعت', subtitle: 'جادوی جنگل', theme: 'forest', enemies: { scout: 6, grunt: 6, brute: 2 }, malfunction: true, noAlienX: true, intro: [
      { speaker: GWEN, text: 'یه انرژی عجیب توی جنگله که ساعتت رو به هم می‌ریزه. ایلان ایکس در دسترس نیست!', color: cg },
    ] },
    { name: 'آبشار بزرگ', subtitle: 'شیرجه از بلندی', theme: 'forest', enemies: { shark: 4, grunt: 6, scout: 4 }, seaZones: 2, intro: [
      { speaker: MAX, text: 'پشت آبشار یه غار مخفیه. شنا کنید و از سنگ‌ها بالا برید!', color: cm },
    ] },
    { name: 'گولیات جنگلی', subtitle: 'مینی‌باس', theme: 'forest', enemies: { scout: 4 }, boss: 'goliath', bossHp: 750, intro: [
      { speaker: BEL, text: 'نگهبان کریستالی با پوسته‌ای از چوب سخت برگشته. قوی‌تر از قبل!', color: C.bel },
    ] },
    { name: 'شب جنگل', subtitle: 'کرم‌های شب‌تاب', theme: 'forest', enemies: { grunt: 8, scout: 8, brute: 2 }, dark: true, intro: [
      { speaker: P, text: 'هوا تاریک شد... ولی کرم‌های شب‌تاب راه رو نشونم می‌دن!', color: C.p },
      { speaker: GWEN, text: 'بشقاب‌های من توی تاریکی می‌درخشن. نزدیکم بمون!', color: cg },
    ] },
    { name: 'معبد شهاب‌سنگ', subtitle: 'تانک‌ها و سربازان', theme: 'forest', enemies: { tank: 3, grunt: 8, brute: 3 }, intro: [
      { speaker: SER, text: 'معبدی باستانی... ساخته‌شده دور یک شهاب‌سنگ سبز. همان نوری که ساعتت را آورد!', color: C.ser },
    ] },
    { name: 'باران شهاب‌سنگ جنگلی', subtitle: 'آتش در آسمان', theme: 'forest', enemies: { scout: 6, grunt: 6 }, meteorRain: true, intro: [
      { speaker: MAX, text: 'اگه شهاب‌سنگ‌ها به درخت‌ها بخورن جنگل آتیش می‌گیره! همه رو در هوا بزن!', color: cm },
    ] },
    { name: 'دوستان قدیمی', subtitle: 'علی و سارا می‌آیند', theme: 'forest', enemies: { grunt: 8, brute: 3, scout: 6 },
      npc: { name: 'علی', role: 'مکانیک کوچک', kind: 'boy', atFrac: 0.5, color: '#3b82f6', dialog: [
        { speaker: 'علی', text: 'پارسا! من و سارا با اتوبوس آقا رحیم اومدیم! یه ارتقای جدید برای ساعتت آوردم.', color: C.npc },
        { speaker: 'سارا', text: 'ما هم می‌خوایم کمک کنیم! بیا این آب‌میوه رو بخور.', color: C.npc },
        { speaker: P, text: 'همه‌ی دوستام اینجان! حالا هیچی نمی‌تونه شکستمون بده!', color: C.p } ] },
      intro: [{ speaker: GWEN, text: 'یه اتوبوس داره میاد... دوستای شهرت هستن!', color: cg }] },
    { name: 'دفاع از درخت زندگی', subtitle: 'دفاع ۸۰ ثانیه', theme: 'forest', enemies: { scout: 3 }, defend: 80, intro: [
      { speaker: SER, text: 'درخت زندگی قلب این جنگل است. اگر اِکس آن را نابود کند، همه‌ی جنگل می‌میرد. ۸۰ ثانیه از آن محافظت کن!', color: C.ser },
    ] },
    { name: 'ارتش نهایی', subtitle: 'سایه‌ی اِکس', theme: 'ruins', enemies: { grunt: 12, brute: 5, tank: 4, scout: 8 }, exBackground: true, intro: [
      { speaker: EX, text: 'همه‌ی ارتشم را فرستادم! هسته‌ی شهاب‌سنگ تقریباً مال من است!', color: C.ex },
      { speaker: KEVIN, text: 'بیا جلو اگه جرئت داری!', color: C.kevin },
    ] },
    { name: 'قلب جنگل', subtitle: 'طوفان و تاریکی', theme: 'forest', enemies: { grunt: 10, brute: 4, scout: 10 }, storm: true, dark: true, intro: [
      { speaker: MAX, text: 'یک قدم دیگه تا قلب جنگل. بچه‌ها، من بهتون افتخار می‌کنم.', color: cm },
    ] },
    { name: 'نبرد افسانه‌ای', subtitle: 'فینال بزرگ — اِکس با هسته‌ی شهاب‌سنگ', theme: 'forest', enemies: { scout: 4 }, boss: 'ex', bossHp: 1600, storm: true, intro: [
      { speaker: EX, text: 'هسته‌ی شهاب‌سنگ در من است! حالا از همیشه قوی‌ترم!', color: C.ex },
      { speaker: BEL, text: 'پارسا، همه‌ی قدرت‌ها: آتش، چهار دست، سرعت، الماس، جت‌ری و ایلان ایکس. وقتش رسیده.', color: C.bel },
      { speaker: GWEN, text: 'ما همه با توییم!', color: cg },
      { speaker: P, text: 'اِکس! این جنگل، این دریا، این شهر — خونه‌ی همه‌ی ماست!', color: C.p },
    ], outro: [
      { speaker: EX, text: 'نــه... هسته... دارد... از من جدا می‌شود...!', color: C.ex },
      { speaker: NAR, text: 'هسته‌ی شهاب‌سنگ با نور سبز به ساعت پارسا برگشت و اِکس برای همیشه به فضا پرتاب شد.', color: C.nar },
      { speaker: SER, text: 'تو نه‌تنها شهر، بلکه دریا و جنگل را هم نجات دادی.', color: C.ser },
      { speaker: MAX, text: 'پارسا، تو واقعی‌ترین قهرمانی هستی که دیدم. بیا سوار کاروان شیم، بستنی مهمون من!', color: cm },
      { speaker: GWEN, text: 'و کوین هم پول بستنی منو می‌ده!', color: cg },
      { speaker: KEVIN, text: 'هی! ...باشه، باشه. برای قهرمان‌ها هر کاری می‌کنم.', color: C.kevin },
      { speaker: P, text: 'آخ جوووون! بستنی! بهترین روز دنیا! 🍦', color: C.p },
    ] },
  ];
  return specs.map((sp, i) => {
    const id = 21 + i;
    const length = sp.boss ? 4400 : sp.defend ? 3400 : 4300 + i * 45;
    const { name, subtitle, theme, enemies, intro, ...rest } = sp;
    return {
      id,
      name,
      subtitle,
      theme,
      enemies,
      intro,
      length,
      seed: id * 13 + 5,
      outro: [{ speaker: P, text: 'هورا! یه مرحله‌ی دیگه رو هم با دوستام بردیم!', color: C.p }],
      kevinAlly: true,
      gwenAlly: true,
      maxRV: theme !== 'ocean',
      chapter: id <= 35 ? 2 : 3,
      water: theme === 'ocean' ? OCEAN(length) : undefined,
      available: id >= 23 ? (rest.noAlienX ? ALL.filter((f) => f !== 'alienx') : ALL) : A10,
      ...rest,
    } as LevelDef;
  });
}

export const CONTROLS = [
  { action: 'حرکت چپ/راست', key: 'A / D یا ← →', pad: 'استیک چپ / D-Pad' },
  { action: 'پرش', key: 'Space یا W', pad: 'A (Cross)' },
  { action: 'نشستن / جاخالی', key: 'S یا ↓', pad: 'استیک پایین / D-Pad پایین' },
  { action: 'حمله', key: 'J یا Z', pad: 'X (Square)' },
  { action: 'قاچ کردن زمین (کوبش ساعت)', key: 'K یا X', pad: 'B (Circle)' },
  { action: 'چرخاندن صفحه ساعت', key: 'Q یا Tab', pad: 'Y (Triangle) / LB' },
  { action: 'تبدیل / تأیید', key: 'E یا Enter', pad: 'RB' },
  { action: 'نجات دوست / صحبت / کاروان مکس', key: '↑', pad: 'D-Pad بالا' },
  { action: 'شنا به بالا / پرواز جت‌ری', key: 'Space (نگه دار)', pad: 'A (نگه دار)' },
  { action: 'شیرجه در آب', key: 'S یا ↓', pad: 'استیک پایین' },
  { action: 'حرکت ویژه (چهاردست/ایلان ایکس)', key: 'S + J', pad: 'پایین + X' },
  { action: 'توقف', key: 'Esc یا P', pad: 'Start' },
];
