// Links to the offline builds (temporary anonymous hosts — files are also in the release/ folder).
export interface Link {
  main: string;
  mirror: string;
  sha: string;
}
export const DOWNLOADS: { version: string; mobile: Link; box: Link; exe: Link } = {
  version: '1.0.1',
  mobile: {
    main: 'https://gofile.io/d/Ase2yzK9',
    mirror: 'https://temp.sh/qVJVI/ParsaGreenWatch-1.0.1-Mobile.apk',
    sha: 'b4e7f4f7f1e384689ede15bec1b7d3a481950315b4714f62bc69f71f7be157ca',
  },
  box: {
    main: 'https://gofile.io/d/dP16ZyXm',
    mirror: 'https://temp.sh/ahuSb/ParsaGreenWatch-1.0.1-AndroidBox.apk',
    sha: '78143f0451324dce0c76bca1fc28e7b6595865d10ecda2877979182b111ce32e',
  },
  exe: {
    main: 'https://gofile.io/d/2NMjgPw8',
    mirror: 'https://temp.sh/vGyyT/ParsaGreenWatch-Setup-1.0.1-Windows.exe',
    sha: '19cdd3efd34456ecac4c0ac7a6b95cb06b0da5e86594ff91e45f6884df961639',
  },
};
