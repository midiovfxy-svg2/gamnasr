import { FormId, Theme } from './data';
import { cityLook, hexA, makeBuilding, Look, BSprite } from './city';

export interface Anim {
  t: number;
  moving: boolean;
  onGround: boolean;
  crouch: boolean;
  attack: number; // 0..1 remaining attack animation
  hurt: boolean;
  vy: number;
}

type Ctx = CanvasRenderingContext2D;

export function rr(ctx: Ctx, x: number, y: number, w: number, h: number, r: number) {
  const rad = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.arcTo(x + w, y, x + w, y + h, rad);
  ctx.arcTo(x + w, y + h, x, y + h, rad);
  ctx.arcTo(x, y + h, x, y, rad);
  ctx.arcTo(x, y, x + w, y, rad);
  ctx.closePath();
}

function limb(ctx: Ctx, x1: number, y1: number, x2: number, y2: number, w: number, color: string) {
  ctx.strokeStyle = color;
  ctx.lineWidth = w;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
}

export function drawWatch(ctx: Ctx, x: number, y: number, r: number, state: 'ready' | 'active' | 'recharge' | 'broken' | 'none', t: number) {
  if (state === 'none') return;
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = '#1f2937';
  ctx.beginPath();
  ctx.arc(0, 0, r * 1.25, 0, Math.PI * 2);
  ctx.fill();
  let col = '#39ff14';
  if (state === 'recharge') col = '#ff3b3b';
  if (state === 'broken') col = '#555';
  if (state === 'active') col = '#39ff14';
  const pulse = state === 'active' ? 0.7 + 0.3 * Math.sin(t * 8) : 1;
  ctx.shadowColor = col;
  ctx.shadowBlur = state === 'broken' ? 0 : 12 * pulse;
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  // hourglass
  ctx.fillStyle = '#0b0f14';
  ctx.beginPath();
  ctx.moveTo(-r * 0.75, -r * 0.75);
  ctx.lineTo(r * 0.75, -r * 0.75);
  ctx.lineTo(-r * 0.75, r * 0.75);
  ctx.lineTo(r * 0.75, r * 0.75);
  ctx.closePath();
  ctx.fill();
  if (state === 'broken') {
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-r, -r * 0.4);
    ctx.lineTo(-r * 0.2, 0.1 * r);
    ctx.lineTo(r * 0.3, -r * 0.5);
    ctx.lineTo(r, r * 0.6);
    ctx.stroke();
  }
  ctx.restore();
}

/* ---------------- Parsa (human) ---------------- */
export function drawParsa(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim, watch: 'ready' | 'active' | 'recharge' | 'broken' | 'none') {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sw = a.moving && a.onGround ? Math.sin(a.t * 12) : 0;
  const jumpTuck = !a.onGround ? 0.5 : 0;
  const crouch = a.crouch ? 16 : 0;
  const skin = '#e9b990';
  const purple = '#8d3f6a';
  const purpleDark = '#6c2e52';
  const hair = '#3a2518';
  const bob = a.moving && a.onGround ? Math.abs(Math.sin(a.t * 12)) * 2 : 0;

  if (a.hurt) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a.t * 40);

  // legs
  const hipY = -22 + crouch;
  limb(ctx, -6, hipY, -6 - sw * 8 - jumpTuck * 4, -2 - (sw > 0 ? Math.abs(sw) * 6 : 0), 9, purpleDark);
  limb(ctx, 6, hipY, 6 + sw * 8 + jumpTuck * 6, -2 - (sw < 0 ? Math.abs(sw) * 6 : 0), 9, purple);
  // feet
  ctx.fillStyle = skin;
  ctx.beginPath();
  ctx.ellipse(-6 - sw * 8 + 2, -1 - (sw > 0 ? Math.abs(sw) * 6 : 0), 6, 3.2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(6 + sw * 8 + 2, -1 - (sw < 0 ? Math.abs(sw) * 6 : 0), 6, 3.2, 0, 0, Math.PI * 2);
  ctx.fill();

  // torso
  const torsoTop = -46 + crouch - bob;
  ctx.fillStyle = purple;
  rr(ctx, -15, torsoTop, 30, 26, 7);
  ctx.fill();
  // sleeves
  ctx.fillStyle = purpleDark;
  rr(ctx, -20, torsoTop + 2, 9, 11, 4);
  ctx.fill();
  rr(ctx, 11, torsoTop + 2, 9, 11, 4);
  ctx.fill();
  // "allo" logo
  ctx.fillStyle = '#e9c46a';
  ctx.font = 'bold 6px sans-serif';
  ctx.textAlign = 'center';
  ctx.save();
  ctx.scale(facing, 1);
  ctx.fillText('allo', facing * 6, torsoTop + 11);
  ctx.restore();

  // arms
  const shY = torsoTop + 6;
  const punch = a.attack > 0 ? (1 - a.attack) : 0;
  // back arm (right side of body, drawn first)
  limb(ctx, -14, shY, -14 - sw * 7 + (a.onGround ? 0 : 4), shY + 20 - Math.abs(sw) * 3, 6.5, skin);
  // front arm (left arm, has the watch)
  const ax2 = 14 + sw * 7 + punch * 14;
  const ay2 = shY + 20 - punch * 14 - (a.onGround ? 0 : 10);
  limb(ctx, 14, shY, ax2, ay2, 6.5, skin);
  drawWatch(ctx, ax2, ay2 - 2, 4.5, watch, a.t);

  // head
  const hy = torsoTop - 14;
  ctx.fillStyle = skin;
  ctx.beginPath();
  ctx.arc(0, hy, 16, 0, Math.PI * 2);
  ctx.fill();
  // ear
  ctx.beginPath();
  ctx.arc(-15, hy + 1, 4, 0, Math.PI * 2);
  ctx.fill();
  // hair (messy)
  ctx.fillStyle = hair;
  ctx.beginPath();
  ctx.moveTo(-17, hy - 2);
  ctx.quadraticCurveTo(-18, hy - 20, -4, hy - 20);
  ctx.lineTo(-7, hy - 25);
  ctx.lineTo(0, hy - 19);
  ctx.lineTo(4, hy - 26);
  ctx.lineTo(7, hy - 18);
  ctx.lineTo(13, hy - 23);
  ctx.quadraticCurveTo(19, hy - 14, 17, hy - 2);
  ctx.quadraticCurveTo(14, hy - 10, 8, hy - 8);
  ctx.quadraticCurveTo(0, hy - 6, -8, hy - 9);
  ctx.quadraticCurveTo(-14, hy - 10, -17, hy - 2);
  ctx.closePath();
  ctx.fill();
  // eyes
  const ex = 6;
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.ellipse(ex, hy + 1, 4.2, 4.6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-3, hy + 1, 3.6, 4.2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#3b2314';
  ctx.beginPath();
  ctx.arc(ex + 1, hy + 1.5, 2.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(-2, hy + 1.5, 2.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(ex + 2, hy + 0.5, 0.9, 0, Math.PI * 2);
  ctx.fill();
  // eyebrows
  ctx.strokeStyle = hair;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(ex - 4, hy - 5);
  ctx.lineTo(ex + 4, hy - 5.5);
  ctx.stroke();
  // smile
  ctx.strokeStyle = '#8b4a3a';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(4, hy + 7, 4.5, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.stroke();
  // nose
  ctx.beginPath();
  ctx.arc(8, hy + 4, 1.2, 0, Math.PI * 2);
  ctx.fillStyle = '#d9a07a';
  ctx.fill();
  ctx.restore();
}

/* ---------------- Aliens ---------------- */
function emblem(ctx: Ctx, x: number, y: number, r: number, t: number) {
  drawWatch(ctx, x, y, r, 'active', t);
}

export function drawHeat(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sw = a.moving && a.onGround ? Math.sin(a.t * 11) : 0;
  const crouch = a.crouch ? 18 : 0;
  const rock = '#4a2c1e';
  const lava = '#ff7a00';
  if (a.hurt) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a.t * 40);
  // legs
  limb(ctx, -8, -28 + crouch, -8 - sw * 10, -3, 11, rock);
  limb(ctx, 8, -28 + crouch, 8 + sw * 10, -3, 11, rock);
  // torso
  const top = -58 + crouch;
  ctx.fillStyle = rock;
  rr(ctx, -18, top, 36, 32, 8);
  ctx.fill();
  // lava cracks
  ctx.strokeStyle = lava;
  ctx.lineWidth = 2;
  ctx.shadowColor = lava;
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.moveTo(-10, top + 4);
  ctx.lineTo(-4, top + 14);
  ctx.lineTo(-9, top + 26);
  ctx.moveTo(8, top + 2);
  ctx.lineTo(4, top + 12);
  ctx.lineTo(10, top + 24);
  ctx.stroke();
  ctx.shadowBlur = 0;
  // arms
  const punch = a.attack > 0 ? 1 - a.attack : 0;
  limb(ctx, -16, top + 6, -18 - sw * 8, top + 30, 8, rock);
  limb(ctx, 16, top + 6, 20 + punch * 16 + sw * 8, top + 26 - punch * 14, 8, rock);
  if (punch > 0) {
    ctx.fillStyle = `rgba(255,170,0,${0.6 * (1 - punch)})`;
    ctx.beginPath();
    ctx.arc(20 + punch * 16, top + 26 - punch * 14, 10 + punch * 10, 0, Math.PI * 2);
    ctx.fill();
  }
  emblem(ctx, 0, top + 16, 5, a.t);
  // head: flaming
  const hy = top - 16;
  ctx.fillStyle = rock;
  ctx.beginPath();
  ctx.arc(0, hy, 13, 0, Math.PI * 2);
  ctx.fill();
  // flames
  for (let i = 0; i < 6; i++) {
    const ph = a.t * 9 + i * 1.1;
    const fx = -10 + i * 4;
    const fh = 18 + Math.sin(ph) * 7;
    const g = ctx.createLinearGradient(0, hy, 0, hy - fh - 10);
    g.addColorStop(0, 'rgba(255,220,80,0.95)');
    g.addColorStop(0.5, 'rgba(255,120,0,0.85)');
    g.addColorStop(1, 'rgba(255,40,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(fx - 5, hy - 4);
    ctx.quadraticCurveTo(fx + Math.sin(ph) * 4, hy - fh, fx + 5, hy - 4);
    ctx.closePath();
    ctx.fill();
  }
  // face
  ctx.fillStyle = '#ffe066';
  ctx.shadowColor = '#ffd000';
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.ellipse(6, hy - 1, 3.5, 2.2, -0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-3, hy - 1, 3, 2, 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.restore();
}

export function drawDiamond(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sw = a.moving && a.onGround ? Math.sin(a.t * 10) : 0;
  const crouch = a.crouch ? 20 : 0;
  const c1 = '#2fd27a';
  const c2 = '#17a85a';
  const c3 = '#b9ffd9';
  if (a.hurt) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a.t * 40);
  limb(ctx, -9, -32 + crouch, -9 - sw * 10, -3, 12, c2);
  limb(ctx, 9, -32 + crouch, 9 + sw * 10, -3, 12, c2);
  const top = -66 + crouch;
  ctx.fillStyle = c1;
  ctx.beginPath();
  ctx.moveTo(-20, top + 4);
  ctx.lineTo(20, top + 4);
  ctx.lineTo(16, top + 36);
  ctx.lineTo(-16, top + 36);
  ctx.closePath();
  ctx.fill();
  // back shards
  ctx.fillStyle = c2;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(-18 + i * 6, top + 6);
    ctx.lineTo(-24 + i * 6, top - 16 - i * 4);
    ctx.lineTo(-12 + i * 6, top + 6);
    ctx.closePath();
    ctx.fill();
  }
  // facets
  ctx.strokeStyle = c3;
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(-12, top + 8);
  ctx.lineTo(0, top + 22);
  ctx.lineTo(12, top + 8);
  ctx.moveTo(0, top + 22);
  ctx.lineTo(0, top + 36);
  ctx.stroke();
  const punch = a.attack > 0 ? 1 - a.attack : 0;
  limb(ctx, -18, top + 8, -22 - sw * 8, top + 34, 9, c1);
  limb(ctx, 18, top + 8, 22 + punch * 14 + sw * 8, top + 30 - punch * 16, 9, c1);
  // arm blade when attacking
  if (punch > 0) {
    ctx.fillStyle = c3;
    ctx.beginPath();
    ctx.moveTo(22 + punch * 14, top + 30 - punch * 16);
    ctx.lineTo(44 + punch * 14, top + 24 - punch * 16);
    ctx.lineTo(24 + punch * 14, top + 36 - punch * 16);
    ctx.closePath();
    ctx.fill();
  }
  emblem(ctx, 0, top + 18, 5, a.t);
  // head — crystal
  const hy = top - 12;
  ctx.fillStyle = c1;
  ctx.beginPath();
  ctx.moveTo(-11, hy + 10);
  ctx.lineTo(-13, hy - 6);
  ctx.lineTo(-4, hy - 20);
  ctx.lineTo(6, hy - 22);
  ctx.lineTo(13, hy - 8);
  ctx.lineTo(11, hy + 10);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = c3;
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.ellipse(5, hy, 3.5, 2.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-4, hy, 3, 2.2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function drawXlr8(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sw = a.moving && a.onGround ? Math.sin(a.t * 20) : 0;
  const crouch = a.crouch ? 14 : 0;
  const blue = '#1e4fd8';
  const dark = '#0b1b4a';
  if (a.hurt) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a.t * 40);
  // speed lines
  if (a.moving) {
    ctx.strokeStyle = 'rgba(140,200,255,0.5)';
    ctx.lineWidth = 2;
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(-20 - i * 8, -50 + i * 12 + crouch);
      ctx.lineTo(-50 - i * 10, -50 + i * 12 + crouch);
      ctx.stroke();
    }
  }
  // tail
  ctx.strokeStyle = blue;
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-10, -34 + crouch);
  ctx.quadraticCurveTo(-30, -36 + crouch + sw * 4, -42, -22 + crouch + sw * 6);
  ctx.stroke();
  // legs (wheel feet)
  limb(ctx, -6, -30 + crouch, -6 - sw * 12, -6, 8, dark);
  limb(ctx, 6, -30 + crouch, 6 + sw * 12, -6, 8, dark);
  ctx.fillStyle = '#9fd3ff';
  ctx.beginPath();
  ctx.arc(-6 - sw * 12, -5, 5, 0, Math.PI * 2);
  ctx.arc(6 + sw * 12, -5, 5, 0, Math.PI * 2);
  ctx.fill();
  // body (leaning forward)
  const top = -58 + crouch;
  ctx.fillStyle = blue;
  rr(ctx, -12, top, 26, 30, 10);
  ctx.fill();
  ctx.fillStyle = dark;
  rr(ctx, -12, top + 8, 10, 22, 5);
  ctx.fill();
  const punch = a.attack > 0 ? 1 - a.attack : 0;
  limb(ctx, -8, top + 8, -10 - sw * 6, top + 26, 6, blue);
  limb(ctx, 10, top + 8, 16 + punch * 18 + sw * 6, top + 20 - punch * 10, 6, blue);
  if (punch > 0) {
    ctx.strokeStyle = 'rgba(160,220,255,0.8)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(16 + punch * 18, top + 20 - punch * 10, 14, -1, 1);
    ctx.stroke();
  }
  emblem(ctx, 2, top + 16, 5, a.t);
  // head with visor
  const hy = top - 10;
  ctx.fillStyle = blue;
  ctx.beginPath();
  ctx.moveTo(-12, hy + 8);
  ctx.lineTo(-16, hy - 10);
  ctx.lineTo(4, hy - 14);
  ctx.lineTo(22, hy - 2);
  ctx.lineTo(14, hy + 8);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#0ff';
  ctx.shadowColor = '#0ff';
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.moveTo(-6, hy - 4);
  ctx.lineTo(16, hy - 2);
  ctx.lineTo(10, hy + 4);
  ctx.lineTo(-6, hy + 2);
  ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.restore();
}

export function drawFourArms(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sw = a.moving && a.onGround ? Math.sin(a.t * 9) : 0;
  const crouch = a.crouch ? 22 : 0;
  const red = '#d6342c';
  const dark = '#8f1f1a';
  if (a.hurt) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a.t * 40);
  limb(ctx, -14, -38 + crouch, -14 - sw * 10, -4, 16, dark);
  limb(ctx, 14, -38 + crouch, 14 + sw * 10, -4, 16, dark);
  const top = -82 + crouch;
  ctx.fillStyle = red;
  rr(ctx, -30, top, 60, 48, 14);
  ctx.fill();
  ctx.fillStyle = dark;
  ctx.beginPath();
  ctx.moveTo(-6, top + 2);
  ctx.lineTo(6, top + 2);
  ctx.lineTo(3, top + 46);
  ctx.lineTo(-3, top + 46);
  ctx.closePath();
  ctx.fill();
  // belt
  ctx.fillStyle = '#222';
  rr(ctx, -30, top + 42, 60, 8, 3);
  ctx.fill();
  const punch = a.attack > 0 ? 1 - a.attack : 0;
  // four arms: two back, two front
  limb(ctx, -26, top + 10, -34 - sw * 6, top + 38, 12, red);
  limb(ctx, -24, top + 26, -36 + sw * 6, top + 54, 11, red);
  limb(ctx, 26, top + 10, 36 + punch * 22 + sw * 6, top + 36 - punch * 22, 12, red);
  limb(ctx, 24, top + 26, 38 + punch * 18 - sw * 6, top + 52 - punch * 10, 11, red);
  // fists
  ctx.fillStyle = dark;
  ctx.beginPath();
  ctx.arc(36 + punch * 22 + sw * 6, top + 36 - punch * 22, 9, 0, Math.PI * 2);
  ctx.arc(38 + punch * 18 - sw * 6, top + 52 - punch * 10, 8, 0, Math.PI * 2);
  ctx.arc(-34 - sw * 6, top + 38, 9, 0, Math.PI * 2);
  ctx.arc(-36 + sw * 6, top + 54, 8, 0, Math.PI * 2);
  ctx.fill();
  if (punch > 0.4) {
    ctx.strokeStyle = `rgba(255,200,120,${punch})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(36 + punch * 22, top + 36 - punch * 22, 16 + punch * 8, -0.8, 0.8);
    ctx.stroke();
  }
  emblem(ctx, 0, top + 22, 6, a.t);
  // head (small, on big body)
  const hy = top - 8;
  ctx.fillStyle = red;
  rr(ctx, -13, hy - 14, 26, 26, 8);
  ctx.fill();
  ctx.fillStyle = '#ffd54a';
  ctx.beginPath();
  ctx.ellipse(6, hy - 2, 3.5, 2.2, 0, 0, Math.PI * 2);
  ctx.ellipse(-4, hy - 2, 3.5, 2.2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#222';
  ctx.beginPath();
  ctx.ellipse(1, hy + 6, 7, 2, 0, 0, Math.PI);
  ctx.fill();
  ctx.restore();
}

export function drawForm(ctx: Ctx, form: FormId, cx: number, fy: number, facing: number, a: Anim, watch: 'ready' | 'active' | 'recharge' | 'broken' | 'none') {
  switch (form) {
    case 'human':
      return drawParsa(ctx, cx, fy, facing, a, watch);
    case 'heat':
      return drawHeat(ctx, cx, fy, facing, a);
    case 'diamond':
      return drawDiamond(ctx, cx, fy, facing, a);
    case 'xlr8':
      return drawXlr8(ctx, cx, fy, facing, a);
    case 'fourarms':
      return drawFourArms(ctx, cx, fy, facing, a);
    case 'alienx':
      return drawAlienX(ctx, cx, fy, facing, a);
    case 'jetray':
      return drawJetray(ctx, cx, fy, facing, a);
  }
}

/* ---------------- Kevin ---------------- */
export function drawKevin(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim, absorb: string | null) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sw = a.moving && a.onGround ? Math.sin(a.t * 11) : 0;
  const skin = absorb ?? '#f1c9a5';
  const hoodie = '#4b5563';
  const jeans = '#1e3a8a';
  if (a.hurt) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a.t * 40);
  limb(ctx, -7, -30, -7 - sw * 9, -2, 10, jeans);
  limb(ctx, 7, -30, 7 + sw * 9, -2, 10, jeans);
  ctx.fillStyle = '#111';
  ctx.beginPath();
  ctx.ellipse(-7 - sw * 9 + 2, -1, 7, 3.5, 0, 0, Math.PI * 2);
  ctx.ellipse(7 + sw * 9 + 2, -1, 7, 3.5, 0, 0, Math.PI * 2);
  ctx.fill();
  const top = -60;
  ctx.fillStyle = hoodie;
  rr(ctx, -17, top, 34, 32, 8);
  ctx.fill();
  // lightning symbol
  ctx.fillStyle = '#fbbf24';
  ctx.beginPath();
  ctx.moveTo(2, top + 6);
  ctx.lineTo(-4, top + 17);
  ctx.lineTo(1, top + 17);
  ctx.lineTo(-2, top + 27);
  ctx.lineTo(5, top + 14);
  ctx.lineTo(0, top + 14);
  ctx.closePath();
  ctx.fill();
  const punch = a.attack > 0 ? 1 - a.attack : 0;
  limb(ctx, -15, top + 6, -17 - sw * 7, top + 30, 7, hoodie);
  limb(ctx, 15, top + 6, 18 + punch * 16 + sw * 7, top + 28 - punch * 16, 7, hoodie);
  // absorbed arm
  ctx.fillStyle = skin;
  ctx.beginPath();
  ctx.arc(18 + punch * 16 + sw * 7, top + 30 - punch * 16, 6, 0, Math.PI * 2);
  ctx.fill();
  if (absorb) {
    ctx.shadowColor = absorb;
    ctx.shadowBlur = 10;
    ctx.fill();
    ctx.shadowBlur = 0;
  }
  // head
  const hy = top - 14;
  ctx.fillStyle = '#f1c9a5';
  ctx.beginPath();
  ctx.arc(0, hy, 15, 0, Math.PI * 2);
  ctx.fill();
  // spiky black hair
  ctx.fillStyle = '#111';
  ctx.beginPath();
  ctx.moveTo(-16, hy - 2);
  for (let i = 0; i < 6; i++) {
    ctx.lineTo(-14 + i * 6, hy - 22 - (i % 2) * 6);
    ctx.lineTo(-11 + i * 6, hy - 12);
  }
  ctx.lineTo(16, hy - 4);
  ctx.quadraticCurveTo(0, hy - 10, -16, hy - 2);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.ellipse(6, hy + 1, 3.5, 3.8, 0, 0, Math.PI * 2);
  ctx.ellipse(-3, hy + 1, 3, 3.4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#222';
  ctx.beginPath();
  ctx.arc(7, hy + 1.5, 2, 0, Math.PI * 2);
  ctx.arc(-2, hy + 1.5, 1.8, 0, Math.PI * 2);
  ctx.fill();
  // smirk
  ctx.strokeStyle = '#8b4a3a';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(0, hy + 8);
  ctx.quadraticCurveTo(5, hy + 10, 9, hy + 6);
  ctx.stroke();
  ctx.restore();
}

/* ---------------- Enemies ---------------- */
export function drawScout(ctx: Ctx, cx: number, fy: number, facing: number, t: number, moving: boolean, flash: boolean) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  if (flash) ctx.filter = 'brightness(2)';
  const bob = moving ? Math.sin(t * 14) * 1.5 : 0;
  // chassis + wheels
  ctx.fillStyle = '#1b1030';
  rr(ctx, -23, -17, 46, 12, 6);
  ctx.fill();
  for (const wx of [-14, 14]) {
    ctx.fillStyle = '#241440';
    ctx.beginPath();
    ctx.arc(wx, -9, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#7c3aed';
    ctx.lineWidth = 2;
    const a = moving ? t * 9 : 0;
    ctx.beginPath();
    ctx.moveTo(wx + Math.cos(a) * 7, -9 + Math.sin(a) * 7);
    ctx.lineTo(wx - Math.cos(a) * 7, -9 - Math.sin(a) * 7);
    ctx.moveTo(wx + Math.cos(a + 1.57) * 7, -9 + Math.sin(a + 1.57) * 7);
    ctx.lineTo(wx - Math.cos(a + 1.57) * 7, -9 - Math.sin(a + 1.57) * 7);
    ctx.stroke();
  }
  // dome body
  ctx.fillStyle = '#4c1d95';
  ctx.beginPath();
  ctx.arc(0, -22 + bob, 19, Math.PI, 0);
  ctx.lineTo(19, -17);
  ctx.lineTo(-19, -17);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#6d28d9';
  rr(ctx, -15, -30 + bob, 30, 7, 3);
  ctx.fill();
  // eye visor
  ctx.fillStyle = '#ff2d2d';
  ctx.shadowColor = '#ff2d2d';
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.ellipse(7, -25 + bob, 6, 3.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  // cannon
  ctx.fillStyle = '#2e1065';
  rr(ctx, 14, -23 + bob, 17, 7, 3);
  ctx.fill();
  ctx.fillStyle = '#ff6b6b';
  ctx.fillRect(29, -21 + bob, 3, 3);
  // antenna
  ctx.strokeStyle = '#a78bfa';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-9, -40 + bob);
  ctx.lineTo(-9, -52 + bob);
  ctx.stroke();
  ctx.fillStyle = '#ff2d2d';
  ctx.beginPath();
  ctx.arc(-9, -53 + bob, 2.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function drawGrunt(ctx: Ctx, cx: number, fy: number, facing: number, t: number, moving: boolean, flash: boolean) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  if (flash) ctx.filter = 'brightness(2)';
  const sw = moving ? Math.sin(t * 9) : 0;
  const armor = '#4c1d95';
  const trim = '#a855f7';
  limb(ctx, -8, -30, -8 - sw * 9, -3, 10, '#2e1065');
  limb(ctx, 8, -30, 8 + sw * 9, -3, 10, '#2e1065');
  ctx.fillStyle = armor;
  rr(ctx, -18, -62, 36, 34, 6);
  ctx.fill();
  ctx.strokeStyle = trim;
  ctx.lineWidth = 2;
  ctx.strokeRect(-12, -56, 24, 20);
  limb(ctx, -16, -56, -22 - sw * 6, -32, 8, armor);
  limb(ctx, 16, -56, 24 + sw * 6, -34, 8, armor);
  // claw
  ctx.fillStyle = trim;
  ctx.beginPath();
  ctx.moveTo(24 + sw * 6, -34);
  ctx.lineTo(36 + sw * 6, -40);
  ctx.lineTo(34 + sw * 6, -28);
  ctx.closePath();
  ctx.fill();
  // head
  ctx.fillStyle = '#2e1065';
  rr(ctx, -12, -86, 24, 26, 6);
  ctx.fill();
  ctx.fillStyle = '#ff2d2d';
  ctx.shadowColor = '#ff2d2d';
  ctx.shadowBlur = 8;
  ctx.fillRect(-6, -78, 16, 4);
  ctx.restore();
}

export function drawBrute(ctx: Ctx, cx: number, fy: number, facing: number, t: number, moving: boolean, flash: boolean, charging: boolean) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  if (flash) ctx.filter = 'brightness(2)';
  const sw = moving ? Math.sin(t * 8) : 0;
  const body = '#3f1d5c';
  const plate = '#7e22ce';
  limb(ctx, -18, -44, -18 - sw * 12, -4, 18, body);
  limb(ctx, 18, -44, 18 + sw * 12, -4, 18, body);
  ctx.fillStyle = body;
  rr(ctx, -36, -104, 72, 64, 16);
  ctx.fill();
  ctx.fillStyle = plate;
  rr(ctx, -28, -98, 56, 24, 8);
  ctx.fill();
  limb(ctx, -32, -92, -44 - sw * 8, -40, 16, body);
  limb(ctx, 32, -92, 46 + sw * 8 + (charging ? 10 : 0), -42, 16, body);
  ctx.fillStyle = plate;
  ctx.beginPath();
  ctx.arc(-44 - sw * 8, -40, 12, 0, Math.PI * 2);
  ctx.arc(46 + sw * 8 + (charging ? 10 : 0), -42, 12, 0, Math.PI * 2);
  ctx.fill();
  // head
  ctx.fillStyle = '#2a103f';
  rr(ctx, -16, -124, 36, 28, 8);
  ctx.fill();
  ctx.fillStyle = charging ? '#ffd000' : '#ff2d2d';
  ctx.shadowColor = ctx.fillStyle;
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.arc(4, -112, 5, 0, Math.PI * 2);
  ctx.arc(14, -112, 5, 0, Math.PI * 2);
  ctx.fill();
  // horns
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#c4b5fd';
  ctx.beginPath();
  ctx.moveTo(-14, -122);
  ctx.lineTo(-22, -140);
  ctx.lineTo(-6, -124);
  ctx.moveTo(18, -122);
  ctx.lineTo(28, -140);
  ctx.lineTo(10, -124);
  ctx.fill();
  ctx.restore();
}

export function drawSaboteur(ctx: Ctx, cx: number, fy: number, facing: number, t: number) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  limb(ctx, -6, -28, -6, -2, 8, '#222');
  limb(ctx, 6, -28, 6, -2, 8, '#222');
  ctx.fillStyle = '#e5e7eb';
  rr(ctx, -15, -62, 30, 36, 6);
  ctx.fill();
  limb(ctx, 14, -56, 30, -50 + Math.sin(t * 3) * 2, 6, '#e5e7eb');
  ctx.fillStyle = '#c084fc';
  rr(ctx, 26, -58, 16, 10, 3);
  ctx.fill();
  ctx.fillStyle = '#f1c9a5';
  ctx.beginPath();
  ctx.arc(0, -76, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#9ca3af';
  ctx.beginPath();
  ctx.arc(0, -84, 13, Math.PI, 0);
  ctx.fill();
  ctx.fillStyle = '#c084fc';
  ctx.fillRect(-8, -80, 16, 5);
  ctx.restore();
}

/** EX: the giant kaiju boss. fy = feet y. height ≈ 460 */
export function drawEx(ctx: Ctx, cx: number, fy: number, facing: number, t: number, state: 'idle' | 'stomp' | 'beam' | 'hurt' | 'dead', stateT: number, hpRatio: number) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sway = Math.sin(t * 1.3) * 6;
  const body = '#0e0e14';
  const plate = '#1c1c26';
  const edge = '#ff4500';
  if (state === 'hurt') ctx.filter = 'brightness(1.8)';
  if (state === 'dead') ctx.globalAlpha = Math.max(0, 1 - stateT / 3);
  const stompLift = state === 'stomp' ? Math.sin(Math.min(stateT / 0.8, 1) * Math.PI) * 70 : 0;

  // tail
  ctx.strokeStyle = body;
  ctx.lineWidth = 46;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-60, -140);
  ctx.quadraticCurveTo(-200, -120 + sway * 2, -300, -40 + sway * 3);
  ctx.stroke();
  // tail spikes
  ctx.fillStyle = edge;
  for (let i = 0; i < 5; i++) {
    const px = -90 - i * 45;
    const py = -160 + i * 18 + sway * (i / 4) * 2;
    ctx.beginPath();
    ctx.moveTo(px - 12, py + 10);
    ctx.lineTo(px, py - 24);
    ctx.lineTo(px + 12, py + 10);
    ctx.fill();
  }
  // legs
  ctx.fillStyle = body;
  rr(ctx, -110, -200, 70, 200, 26);
  ctx.fill();
  ctx.save();
  ctx.translate(0, -stompLift);
  rr(ctx, 30, -200, 76, 200, 26);
  ctx.fill();
  // claws
  ctx.fillStyle = '#9ca3af';
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(60 + i * 18, 0);
    ctx.lineTo(70 + i * 18, -16);
    ctx.lineTo(80 + i * 18, 0);
    ctx.fill();
  }
  ctx.restore();
  // torso
  ctx.fillStyle = body;
  rr(ctx, -120, -400 + sway, 220, 230, 50);
  ctx.fill();
  ctx.fillStyle = plate;
  rr(ctx, -90, -380 + sway, 160, 60, 20);
  ctx.fill();
  // godzilla dorsal fins
  for (let i = 0; i < 6; i++) {
    const fx = -125 + i * 22;
    const fh = 70 + Math.sin(i * 1.3) * 30 + (i < 3 ? i * 15 : (5 - i) * 15);
    ctx.fillStyle = '#15151d';
    ctx.beginPath();
    ctx.moveTo(fx - 14, -380 + sway);
    ctx.lineTo(fx - 4, -380 - fh + sway);
    ctx.lineTo(fx + 12, -380 + sway);
    ctx.fill();
    ctx.strokeStyle = `rgba(255,80,0,${0.5 + 0.5 * Math.sin(t * 4 + i)})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(fx - 4, -380 - fh + 10 + sway);
    ctx.lineTo(fx - 2, -385 + sway);
    ctx.stroke();
  }
  // lava veins
  ctx.strokeStyle = `rgba(255,70,0,${0.6 + 0.4 * Math.sin(t * 3)})`;
  ctx.shadowColor = '#ff4500';
  ctx.shadowBlur = 14;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(-90, -300 + sway); ctx.lineTo(-60, -270 + sway); ctx.lineTo(-70, -230 + sway); ctx.lineTo(-40, -200 + sway);
  ctx.moveTo(70, -320 + sway); ctx.lineTo(50, -280 + sway); ctx.lineTo(80, -240 + sway); ctx.lineTo(60, -200 + sway);
  ctx.moveTo(-80, -120); ctx.lineTo(-70, -70); ctx.lineTo(-90, -30);
  ctx.moveTo(60, -140); ctx.lineTo(80, -90); ctx.lineTo(60, -40);
  ctx.stroke();
  ctx.shadowBlur = 0;
  // core (weak point)
  const coreGlow = 0.6 + 0.4 * Math.sin(t * 5);
  ctx.fillStyle = `rgba(255,40,60,${coreGlow})`;
  ctx.shadowColor = '#ff2040';
  ctx.shadowBlur = 30 * coreGlow;
  ctx.beginPath();
  ctx.moveTo(0, -330 + sway);
  ctx.lineTo(30, -290 + sway);
  ctx.lineTo(0, -240 + sway);
  ctx.lineTo(-30, -290 + sway);
  ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;
  // core cracks by damage
  if (hpRatio < 0.6) {
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-10, -300 + sway);
    ctx.lineTo(5, -285 + sway);
    ctx.lineTo(-4, -265 + sway);
    ctx.stroke();
  }
  // arms
  const armSwing = Math.sin(t * 1.3 + 1) * 10;
  limb(ctx, -100, -360 + sway, -150, -250 + armSwing, 40, body);
  limb(ctx, 80, -360 + sway, 150, -250 - armSwing, 40, body);
  ctx.fillStyle = '#9ca3af';
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(135 + i * 12, -250 - armSwing);
    ctx.lineTo(140 + i * 12, -215 - armSwing);
    ctx.lineTo(150 + i * 12, -250 - armSwing);
    ctx.fill();
  }
  // head
  ctx.fillStyle = body;
  rr(ctx, -50, -480 + sway, 150, 100, 36);
  ctx.fill();
  // jaw
  ctx.fillStyle = plate;
  rr(ctx, 20, -420 + sway, 90, 36, 12);
  ctx.fill();
  // teeth
  ctx.fillStyle = '#eee';
  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.moveTo(30 + i * 15, -420 + sway);
    ctx.lineTo(37 + i * 15, -405 + sway);
    ctx.lineTo(44 + i * 15, -420 + sway);
    ctx.fill();
  }
  // horns
  ctx.fillStyle = edge;
  ctx.beginPath();
  ctx.moveTo(-40, -470 + sway);
  ctx.lineTo(-70, -540 + sway);
  ctx.lineTo(-10, -478 + sway);
  ctx.moveTo(20, -478 + sway);
  ctx.lineTo(10, -550 + sway);
  ctx.lineTo(50, -478 + sway);
  ctx.fill();
  // eyes
  const beamCharge = state === 'beam' ? Math.min(1, stateT / 1.2) : 0;
  ctx.fillStyle = beamCharge > 0 ? '#fff' : '#ff2d2d';
  ctx.shadowColor = '#ff2d2d';
  ctx.shadowBlur = 20 + beamCharge * 40;
  ctx.beginPath();
  ctx.arc(40, -445 + sway, 12 + beamCharge * 6, 0, Math.PI * 2);
  ctx.arc(80, -445 + sway, 12 + beamCharge * 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.restore();
}

/* ---------------- NPC ---------------- */
export function drawNpc(ctx: Ctx, cx: number, fy: number, t: number, color: string, talked: boolean, kind: 'girl' | 'boy' | 'cat' | 'adult' = 'adult') {
  if (kind === 'cat') return drawCat(ctx, cx, fy, t, talked);
  ctx.save();
  ctx.translate(cx, fy);
  if (kind === 'girl' || kind === 'boy') {
    ctx.translate(0, 0);
    ctx.scale(0.8, 0.8);
  }
  limb(ctx, -6, -28, -6, -2, 8, '#374151');
  limb(ctx, 6, -28, 6, -2, 8, '#374151');
  ctx.fillStyle = color;
  rr(ctx, -15, -60, 30, 34, 7);
  ctx.fill();
  const wave = talked ? 0 : Math.sin(t * 6) * 10;
  limb(ctx, -14, -54, -20, -32, 6, color);
  limb(ctx, 14, -54, 24, -70 - wave, 6, color);
  ctx.fillStyle = '#f1c9a5';
  ctx.beginPath();
  ctx.arc(0, -74, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#3a2518';
  ctx.beginPath();
  ctx.arc(0, -80, 13, Math.PI, 0);
  ctx.fill();
  if (kind === 'girl') {
    ctx.beginPath();
    ctx.arc(-15, -70, 6, 0, Math.PI * 2);
    ctx.arc(15, -70, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.arc(-15, -76, 3, 0, Math.PI * 2);
    ctx.arc(15, -76, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  if (kind === 'boy') {
    ctx.fillStyle = '#ef4444';
    rr(ctx, -14, -92, 28, 8, 3);
    ctx.fill();
    ctx.fillRect(0, -90, 20, 5);
    // wrench
    ctx.fillStyle = '#9ca3af';
    ctx.fillRect(22, -74, 5, 24);
  }
  ctx.fillStyle = '#222';
  ctx.beginPath();
  ctx.arc(-4, -74, 1.8, 0, Math.PI * 2);
  ctx.arc(4, -74, 1.8, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#8b4a3a';
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  ctx.arc(0, -70, 4, 0.2 * Math.PI, 0.8 * Math.PI);
  ctx.stroke();
  if (!talked) {
    // speech bubble hint
    ctx.fillStyle = '#fff';
    rr(ctx, -18, -124 + Math.sin(t * 3) * 3, 36, 22, 8);
    ctx.fill();
    ctx.fillStyle = '#111';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('↑ !', 0, -108 + Math.sin(t * 3) * 3);
  }
  ctx.restore();
}

/* ---------------- City background ---------------- */
export interface CityBuilding {
  x: number;
  w: number;
  h: number;
  c: string;
  img: HTMLCanvasElement | null;
  pad: number;
  lights: BSprite['lights'];
}

export interface CityScene {
  far: CityBuilding[];
  mid: CityBuilding[];
  props: { x: number; kind: number }[];
  stars: { x: number; y: number; s: number }[];
  clouds: { x: number; y: number; s: number }[];
  look: Look;
}

export function seededRandom(seed: number) {
  let s = seed >>> 0 || 1;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function buildCity(seed: number, length: number, theme: Theme): CityScene {
  const rnd = seededRandom(seed * 7919);
  const look = cityLook(theme);
  const needSprites = ['day', 'sunset', 'night', 'park', 'ruins', 'rooftop'].indexOf(theme) >= 0;
  const far: CityBuilding[] = [];
  const mid: CityBuilding[] = [];
  const props: CityScene['props'] = [];
  const stars: CityScene['stars'] = [];
  const clouds: CityScene['clouds'] = [];
  const mk = (layer: 'far' | 'mid', w: number, h: number, body: string): CityBuilding => {
    const spr = needSprites ? makeBuilding({ w, h, layer, body, style: Math.floor(rnd() * 4), roof: Math.floor(rnd() * 5), seed: Math.floor(rnd() * 1e9) }, look) : null;
    return { x: 0, w, h, c: body, img: spr ? spr.img : null, pad: spr ? spr.pad : 0, lights: spr ? spr.lights : [] };
  };
  let x = -400;
  while (x < length * 0.3 + 1600) {
    const w = 90 + rnd() * 140;
    const b = mk('far', Math.ceil(w), Math.ceil(170 + rnd() * 270), look.far[Math.floor(rnd() * look.far.length)]);
    b.x = x;
    far.push(b);
    x += w + rnd() * 30;
  }
  x = -400;
  while (x < length * 0.6 + 1600) {
    const w = 150 + rnd() * 190;
    const b = mk('mid', Math.ceil(w), Math.ceil(140 + rnd() * 190), look.mid[Math.floor(rnd() * look.mid.length)]);
    b.x = x;
    mid.push(b);
    x += w + 8 + rnd() * 40;
  }
  x = 200;
  while (x < length && theme !== 'cosmic') {
    props.push({ x, kind: Math.floor(rnd() * 5) });
    x += 220 + rnd() * 260;
  }
  for (let i = 0; i < 120; i++) stars.push({ x: rnd() * 1600, y: rnd() * 400, s: rnd() * 1.6 + 0.4 });
  for (let i = 0; i < 8; i++) clouds.push({ x: rnd() * 2400, y: 40 + rnd() * 180, s: 0.6 + rnd() * 1 });
  return { far, mid, props, stars, clouds, look };
}

export const SKY: Record<Theme, [string, string, string]> = {
  day: ['#4aa3f0', '#9fd4ff', '#e8f4ff'],
  park: ['#0f1a3a', '#263a6b', '#5b4a7a'],
  sunset: ['#2b1b4d', '#c2497a', '#ffb067'],
  night: ['#05070f', '#0d1430', '#1c2a55'],
  ruins: ['#2c2a33', '#5f5765', '#9c8d8c'],
  rooftop: ['#060a16', '#14204a', '#2a3a70'],
  ship: ['#07030f', '#1a0b2e', '#2a1446'],
  subway: ['#0d0d12', '#1d1d26', '#2b2b38'],
  cosmic: ['#03010a', '#150a33', '#3b1d6e'],
  beach: ['#38bdf8', '#7dd3fc', '#fef3c7'],
  forest: ['#5eb3e8', '#a7e0f5', '#e0f7e9'],
  ocean: ['#0c4a6e', '#075985', '#0e7490'],
};

export function drawSky(ctx: Ctx, W: number, H: number, theme: Theme, t: number, scene: CityScene, camX: number) {
  const [a, b, c] = SKY[theme];
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, a);
  g.addColorStop(0.6, b);
  g.addColorStop(1, c);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  const dark = theme === 'night' || theme === 'park' || theme === 'rooftop' || theme === 'ship' || theme === 'cosmic';
  if (dark) {
    ctx.fillStyle = '#fff';
    for (const s of scene.stars) {
      const sx = ((s.x - camX * 0.02) % 1600 + 1600) % 1600;
      ctx.globalAlpha = 0.5 + 0.5 * Math.sin(t * 2 + s.x);
      ctx.fillRect(sx, s.y, s.s, s.s);
    }
    ctx.globalAlpha = 1;
    // moon
    ctx.fillStyle = '#f5f3ce';
    ctx.shadowColor = '#f5f3ce';
    ctx.shadowBlur = 40;
    ctx.beginPath();
    ctx.arc(W - 200 - camX * 0.01, 110, 42, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  } else if (theme === 'sunset') {
    ctx.fillStyle = '#ffd98a';
    ctx.shadowColor = '#ffb067';
    ctx.shadowBlur = 60;
    ctx.beginPath();
    ctx.arc(W * 0.7 - camX * 0.01, H * 0.62, 70, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  } else if (theme === 'day' || theme === 'beach' || theme === 'forest') {
    ctx.fillStyle = '#fff6b0';
    ctx.shadowColor = '#fff';
    ctx.shadowBlur = 50;
    ctx.beginPath();
    ctx.arc(200 - camX * 0.01, 100, 50, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  }
  if (theme !== 'subway' && theme !== 'ship' && theme !== 'cosmic' && theme !== 'ocean') {
    ctx.fillStyle = dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.75)';
    for (const cl of scene.clouds) {
      const cx = ((cl.x - camX * 0.05 + t * 8) % 2400 + 2400) % 2400 - 200;
      ctx.beginPath();
      ctx.ellipse(cx, cl.y, 60 * cl.s, 18 * cl.s, 0, 0, Math.PI * 2);
      ctx.ellipse(cx + 40 * cl.s, cl.y - 10 * cl.s, 45 * cl.s, 20 * cl.s, 0, 0, Math.PI * 2);
      ctx.ellipse(cx - 40 * cl.s, cl.y - 4 * cl.s, 40 * cl.s, 16 * cl.s, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

export function drawBuildings(ctx: Ctx, scene: CityScene, camX: number, groundY: number, theme: Theme, t: number) {
  if (theme === 'beach') return drawBeachBG(ctx, camX, groundY, t);
  if (theme === 'forest') return drawForestBG(ctx, camX, groundY, t);
  if (theme === 'ocean') return drawOceanBG(ctx, camX, groundY, t);
  const L = scene.look;
  // far skyline (hazy, slow parallax) — pre-rendered sprites, snapped to whole pixels so nothing shimmers
  for (const b of scene.far) {
    const sx = Math.round(b.x - camX * 0.15);
    if (sx + b.w < -10 || sx > 1290) continue;
    if (b.img) ctx.drawImage(b.img, sx, groundY - b.h - b.pad);
    else {
      ctx.fillStyle = b.c;
      ctx.fillRect(sx, groundY - b.h, b.w, b.h);
    }
  }
  // haze between the layers
  const hz = ctx.createLinearGradient(0, groundY - 360, 0, groundY);
  hz.addColorStop(0, hexA(L.haze, 0));
  hz.addColorStop(1, hexA(L.haze, 0.38));
  ctx.fillStyle = hz;
  ctx.fillRect(0, groundY - 360, 1280, 360);
  // near skyline
  for (const b of scene.mid) {
    const sx = Math.round(b.x - camX * 0.4);
    if (sx + b.w < -10 || sx > 1290) continue;
    if (b.img) {
      ctx.drawImage(b.img, sx, groundY - b.h - b.pad);
      for (const li of b.lights) {
        const a = 0.35 + 0.65 * Math.abs(Math.sin(t * 2.2 + b.x * 0.01));
        ctx.fillStyle = 'rgba(255,50,50,' + a + ')';
        ctx.beginPath();
        ctx.arc(sx + li.x, groundY - b.h - b.pad + li.y, 2.6, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      ctx.fillStyle = b.c;
      ctx.fillRect(sx, groundY - b.h, b.w, b.h);
    }
  }
  // soft street fog
  const fg = ctx.createLinearGradient(0, groundY - 110, 0, groundY);
  fg.addColorStop(0, hexA(L.haze, 0));
  fg.addColorStop(1, hexA(L.haze, 0.22));
  ctx.fillStyle = fg;
  ctx.fillRect(0, groundY - 110, 1280, 110);
}

export function drawGroundAndProps(ctx: Ctx, scene: CityScene, camX: number, groundY: number, W: number, H: number, theme: Theme, t = 0) {
  if (theme === 'beach' || theme === 'forest' || theme === 'ocean') return drawNatureGround(ctx, scene, camX, groundY, W, H, theme, t);
  const dark = theme === 'night' || theme === 'park' || theme === 'rooftop' || theme === 'ship' || theme === 'subway' || theme === 'cosmic';
  // sidewalk
  const walk = theme === 'cosmic' ? '#2a1a5a' : theme === 'ship' ? '#2a2244' : theme === 'subway' ? '#5a5f6b' : theme === 'park' ? '#3f6b3a' : theme === 'ruins' ? '#6b6560' : '#9aa0a8';
  ctx.fillStyle = walk;
  ctx.fillRect(0, groundY, W, 26);
  // curb
  ctx.fillStyle = theme === 'park' ? '#2f5230' : '#6b7280';
  ctx.fillRect(0, groundY + 24, W, 6);
  // road
  const road = theme === 'cosmic' ? '#0a0618' : theme === 'ship' ? '#140f26' : theme === 'park' ? '#2a4428' : '#2f3136';
  ctx.fillStyle = road;
  ctx.fillRect(0, groundY + 30, W, H - groundY - 30);
  // lane dashes
  ctx.fillStyle = theme === 'park' ? 'rgba(255,255,255,0.08)' : '#e5c04b';
  const off = ((-camX) % 80 + 80) % 80;
  for (let xx = off - 80; xx < W; xx += 80) ctx.fillRect(xx, groundY + 70, 40, 5);
  // paving lines
  ctx.strokeStyle = 'rgba(0,0,0,0.15)';
  ctx.lineWidth = 1;
  const off2 = ((-camX) % 60 + 60) % 60;
  for (let xx = off2; xx < W; xx += 60) {
    ctx.beginPath();
    ctx.moveTo(xx, groundY);
    ctx.lineTo(xx, groundY + 24);
    ctx.stroke();
  }
  // props
  for (const p of scene.props) {
    const sx = p.x - camX;
    if (sx < -120 || sx > W + 120) continue;
    switch (p.kind) {
      case 0: {
        // lamp post
        ctx.fillStyle = '#374151';
        ctx.fillRect(sx - 3, groundY - 170, 6, 170);
        ctx.fillRect(sx - 3, groundY - 170, 30, 5);
        ctx.fillStyle = dark ? '#ffe9a8' : '#cbd5e1';
        if (dark) {
          ctx.shadowColor = '#ffe9a8';
          ctx.shadowBlur = 25;
        }
        ctx.beginPath();
        ctx.arc(sx + 27, groundY - 160, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        if (dark) {
          const g = ctx.createRadialGradient(sx + 27, groundY - 160, 0, sx + 27, groundY - 160, 160);
          g.addColorStop(0, 'rgba(255,233,168,0.25)');
          g.addColorStop(1, 'rgba(255,233,168,0)');
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.moveTo(sx + 27, groundY - 160);
          ctx.lineTo(sx - 60, groundY + 2);
          ctx.lineTo(sx + 120, groundY + 2);
          ctx.fill();
        }
        break;
      }
      case 1: {
        // tree
        ctx.fillStyle = '#5b3a1e';
        ctx.fillRect(sx - 6, groundY - 80, 12, 80);
        ctx.fillStyle = theme === 'ruins' ? '#4a5a3a' : '#2f9e44';
        ctx.beginPath();
        ctx.arc(sx, groundY - 100, 38, 0, Math.PI * 2);
        ctx.arc(sx - 28, groundY - 80, 28, 0, Math.PI * 2);
        ctx.arc(sx + 28, groundY - 82, 30, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 2: {
        // parked car
        const cc = ['#ef4444', '#3b82f6', '#eab308', '#f8fafc'][Math.floor(p.x / 100) % 4];
        ctx.fillStyle = cc;
        rr(ctx, sx - 50, groundY + 36, 100, 26, 8);
        ctx.fill();
        rr(ctx, sx - 30, groundY + 18, 60, 24, 8);
        ctx.fill();
        ctx.fillStyle = '#93c5fd';
        rr(ctx, sx - 24, groundY + 22, 22, 14, 3);
        ctx.fill();
        rr(ctx, sx + 2, groundY + 22, 22, 14, 3);
        ctx.fill();
        ctx.fillStyle = '#111';
        ctx.beginPath();
        ctx.arc(sx - 30, groundY + 62, 9, 0, Math.PI * 2);
        ctx.arc(sx + 30, groundY + 62, 9, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 3: {
        // bench / bus stop
        ctx.fillStyle = '#8b5a2b';
        ctx.fillRect(sx - 30, groundY - 22, 60, 6);
        ctx.fillRect(sx - 30, groundY - 36, 60, 5);
        ctx.fillStyle = '#374151';
        ctx.fillRect(sx - 26, groundY - 22, 4, 22);
        ctx.fillRect(sx + 22, groundY - 22, 4, 22);
        break;
      }
      case 4: {
        // hydrant / trash
        ctx.fillStyle = theme === 'ship' ? '#7c3aed' : '#dc2626';
        rr(ctx, sx - 8, groundY - 30, 16, 30, 4);
        ctx.fill();
        ctx.fillRect(sx - 12, groundY - 20, 24, 5);
        break;
      }
    }
  }
}

/* ---------------- Alien X ---------------- */
export function drawAlienX(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sw = a.moving && a.onGround ? Math.sin(a.t * 10) : 0;
  const crouch = a.crouch ? 20 : 0;
  const body = '#07071a';
  if (a.hurt) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a.t * 40);
  // aura
  const g = ctx.createRadialGradient(0, -46 + crouch, 10, 0, -46 + crouch, 70);
  g.addColorStop(0, 'rgba(167,139,250,0.35)');
  g.addColorStop(1, 'rgba(167,139,250,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, -46 + crouch, 70, 0, Math.PI * 2);
  ctx.fill();
  limb(ctx, -8, -34 + crouch, -8 - sw * 10, -3, 11, body);
  limb(ctx, 8, -34 + crouch, 8 + sw * 10, -3, 11, body);
  const top = -70 + crouch;
  ctx.fillStyle = body;
  rr(ctx, -18, top, 36, 40, 10);
  ctx.fill();
  const punch = a.attack > 0 ? 1 - a.attack : 0;
  limb(ctx, -16, top + 8, -20 - sw * 8, top + 36, 8, body);
  limb(ctx, 16, top + 8, 22 + punch * 16 + sw * 8, top + 30 - punch * 16, 8, body);
  // head
  const hy = top - 14;
  ctx.fillStyle = body;
  ctx.beginPath();
  ctx.ellipse(0, hy, 13, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  // three horns
  ctx.fillStyle = '#1b1b3a';
  for (const [hx, hh] of [[-9, 18], [0, 26], [9, 18]] as const) {
    ctx.beginPath();
    ctx.moveTo(hx - 4, hy - 12);
    ctx.lineTo(hx, hy - 12 - hh);
    ctx.lineTo(hx + 4, hy - 12);
    ctx.fill();
  }
  // stars inside body
  ctx.fillStyle = '#fff';
  for (let i = 0; i < 18; i++) {
    const px = Math.sin(i * 12.9 + a.t * 0.5) * 14;
    const py = top - 20 + ((i * 37 + a.t * 10) % 90);
    ctx.globalAlpha = 0.5 + 0.5 * Math.sin(a.t * 3 + i);
    ctx.fillRect(px, py, 1.6, 1.6);
  }
  ctx.globalAlpha = a.hurt ? ctx.globalAlpha : 1;
  // eyes
  ctx.fillStyle = '#7CFC00';
  ctx.shadowColor = '#7CFC00';
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.ellipse(6, hy - 2, 3.5, 2, -0.3, 0, Math.PI * 2);
  ctx.ellipse(-4, hy - 2, 3, 1.8, 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  drawWatch(ctx, 0, top + 18, 5, 'active', a.t);
  // attack glow
  if (punch > 0) {
    ctx.fillStyle = `rgba(167,139,250,${0.6 * (1 - punch)})`;
    ctx.beginPath();
    ctx.arc(22 + punch * 16, top + 30 - punch * 16, 12 + punch * 14, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/* ---------------- Goliath drone (mini boss, ~200px) ---------------- */
export function drawGoliath(ctx: Ctx, cx: number, fy: number, facing: number, t: number, flash: boolean, state: string, stateT: number) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  if (flash) ctx.filter = 'brightness(2)';
  const body = '#2a1250';
  const plate = '#4c1d95';
  const crys = '#22d3ee';
  const step = Math.sin(t * 4) * 10;
  const slam = state === 'slam' ? Math.sin(Math.min(1, stateT / 0.7) * Math.PI) : 0;
  // legs
  limb(ctx, -40, -100, -50 - step, -6, 24, body);
  limb(ctx, 40, -100, 50 + step, -6, 24, body);
  ctx.fillStyle = plate;
  rr(ctx, -70 - step, -14, 40, 14, 5);
  ctx.fill();
  rr(ctx, 30 + step, -14, 40, 14, 5);
  ctx.fill();
  // torso
  ctx.fillStyle = body;
  rr(ctx, -70, -200, 140, 110, 24);
  ctx.fill();
  ctx.fillStyle = plate;
  rr(ctx, -55, -190, 110, 40, 12);
  ctx.fill();
  // crystals on back/shoulders
  ctx.fillStyle = crys;
  ctx.shadowColor = crys;
  ctx.shadowBlur = 14;
  for (let i = 0; i < 5; i++) {
    const x = -60 + i * 30;
    ctx.beginPath();
    ctx.moveTo(x - 8, -195);
    ctx.lineTo(x, -240 - (i % 2) * 20);
    ctx.lineTo(x + 8, -195);
    ctx.fill();
  }
  // core
  ctx.beginPath();
  ctx.moveTo(0, -165);
  ctx.lineTo(16, -140);
  ctx.lineTo(0, -115);
  ctx.lineTo(-16, -140);
  ctx.fill();
  ctx.shadowBlur = 0;
  // arms: cannon + fist
  limb(ctx, -60, -180, -85, -110 + slam * 40, 20, body);
  ctx.fillStyle = plate;
  ctx.beginPath();
  ctx.arc(-85, -110 + slam * 40, 20, 0, Math.PI * 2);
  ctx.fill();
  limb(ctx, 60, -180, 90, -130, 20, body);
  ctx.fillStyle = '#111';
  rr(ctx, 80, -150, 50, 36, 8);
  ctx.fill();
  ctx.fillStyle = state === 'shoot' ? crys : '#333';
  ctx.beginPath();
  ctx.arc(128, -132, 10, 0, Math.PI * 2);
  ctx.fill();
  // head
  ctx.fillStyle = '#1b0b36';
  rr(ctx, -30, -240, 60, 44, 12);
  ctx.fill();
  ctx.fillStyle = '#ff2d2d';
  ctx.shadowColor = '#ff2d2d';
  ctx.shadowBlur = 12;
  ctx.fillRect(-18, -226, 36, 8);
  ctx.restore();
}

/* ---------------- Tank ---------------- */
export function drawTank(ctx: Ctx, cx: number, fy: number, facing: number, t: number, flash: boolean) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  if (flash) ctx.filter = 'brightness(2)';
  ctx.fillStyle = '#1f1235';
  rr(ctx, -56, -30, 112, 30, 14);
  ctx.fill();
  // treads
  ctx.fillStyle = '#111';
  for (let i = 0; i < 7; i++) {
    const off = ((t * 60) % 16);
    ctx.fillRect(-50 + i * 16 + off - 8, -8, 8, 6);
  }
  ctx.fillStyle = '#4c1d95';
  rr(ctx, -40, -58, 80, 30, 10);
  ctx.fill();
  ctx.fillStyle = '#2e1065';
  rr(ctx, -16, -82, 44, 26, 8);
  ctx.fill();
  // barrel
  ctx.fillStyle = '#6d28d9';
  ctx.fillRect(20, -74, 60, 10);
  ctx.fillStyle = '#ff2d2d';
  ctx.shadowColor = '#ff2d2d';
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.arc(0, -70, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* ---------------- Meteor ---------------- */
export function drawMeteor(ctx: Ctx, x: number, y: number, r: number, t: number) {
  ctx.save();
  ctx.translate(x, y);
  // trail
  const g = ctx.createLinearGradient(0, 0, 30, -90);
  g.addColorStop(0, 'rgba(255,140,0,0.8)');
  g.addColorStop(1, 'rgba(255,0,80,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(-r, 0);
  ctx.lineTo(40, -110);
  ctx.lineTo(r, 0);
  ctx.fill();
  ctx.fillStyle = '#4a3a3a';
  ctx.shadowColor = '#ff6a00';
  ctx.shadowBlur = 20;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ff6a00';
  ctx.beginPath();
  ctx.arc(-r * 0.3, r * 0.2, r * 0.3, 0, Math.PI * 2);
  ctx.arc(r * 0.3, -r * 0.2, r * 0.22 + Math.sin(t * 20) * 1, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* ---------------- Cat (Barfi) ---------------- */
export function drawCat(ctx: Ctx, cx: number, fy: number, t: number, talked: boolean) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(0, -14, 20, 13, 0, 0, Math.PI * 2);
  ctx.fill();
  // tail
  ctx.strokeStyle = '#f8fafc';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-18, -14);
  ctx.quadraticCurveTo(-34, -30 + Math.sin(t * 4) * 6, -26, -40);
  ctx.stroke();
  // head
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.arc(14, -28, 12, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(4, -36); ctx.lineTo(6, -48); ctx.lineTo(13, -38);
  ctx.moveTo(24, -36); ctx.lineTo(22, -48); ctx.lineTo(15, -38);
  ctx.fill();
  ctx.fillStyle = '#38bdf8';
  ctx.beginPath();
  ctx.arc(10, -29, 2.2, 0, Math.PI * 2);
  ctx.arc(19, -29, 2.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#f9a8d4';
  ctx.beginPath();
  ctx.arc(15, -24, 1.5, 0, Math.PI * 2);
  ctx.fill();
  if (!talked) {
    ctx.fillStyle = '#fff';
    rr(ctx, -4, -84 + Math.sin(t * 3) * 3, 40, 22, 8);
    ctx.fill();
    ctx.fillStyle = '#111';
    ctx.font = 'bold 12px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('↑ میو!', 16, -69 + Math.sin(t * 3) * 3);
  }
  ctx.restore();
}

/* ---------------- Cosmic dimension background ---------------- */
export function drawCosmic(ctx: Ctx, W: number, groundY: number, camX: number, t: number) {
  for (let i = 0; i < 6; i++) {
    const x = ((i * 530 - camX * 0.1) % (W + 600) + W + 600) % (W + 600) - 300;
    const y = 120 + (i % 3) * 120;
    const g = ctx.createRadialGradient(x, y, 0, x, y, 220);
    g.addColorStop(0, i % 2 ? 'rgba(236,72,153,0.25)' : 'rgba(99,102,241,0.3)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - 220, y - 220, 440, 440);
  }
  // floating crystals
  for (let i = 0; i < 10; i++) {
    const x = ((i * 310 - camX * 0.3) % (W + 400) + W + 400) % (W + 400) - 200;
    const y = groundY - 180 - (i % 4) * 70 + Math.sin(t + i) * 10;
    ctx.fillStyle = 'rgba(167,139,250,0.5)';
    ctx.beginPath();
    ctx.moveTo(x, y - 30); ctx.lineTo(x + 14, y); ctx.lineTo(x, y + 30); ctx.lineTo(x - 14, y);
    ctx.fill();
  }
  // giant faces of Bellicus (red) and Serena (pink)
  const faces: [number, string][] = [[W * 0.22, 'rgba(248,113,113,'], [W * 0.78, 'rgba(249,168,212,']];
  faces.forEach(([fx, col], i) => {
    const a = 0.12 + 0.05 * Math.sin(t * 0.8 + i * 2);
    ctx.fillStyle = col + a + ')';
    ctx.beginPath();
    ctx.ellipse(fx, 200, 120, 160, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = col + a * 3 + ')';
    ctx.beginPath();
    ctx.ellipse(fx - 40, 170, 18, 10, 0, 0, Math.PI * 2);
    ctx.ellipse(fx + 40, 170, 18, 10, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = col + a * 3 + ')';
    ctx.lineWidth = 4;
    ctx.beginPath();
    if (i === 0) ctx.arc(fx, 270, 40, 1.2 * Math.PI, 1.8 * Math.PI);
    else ctx.arc(fx, 230, 40, 0.2 * Math.PI, 0.8 * Math.PI);
    ctx.stroke();
  });
}

/* ---------------- Ex far-background silhouette (level 19) ---------------- */
export function drawExBackground(ctx: Ctx, W: number, groundY: number, camX: number, t: number) {
  ctx.save();
  const x = W * 0.75 - camX * 0.05;
  ctx.translate(x, groundY + 20);
  ctx.scale(1.6, 1.6);
  ctx.globalAlpha = 0.55;
  drawEx(ctx, 0, 0, -1, t, 'idle', 0, 1);
  ctx.restore();
}

/* ---------------- Jetray ---------------- */
export function drawJetray(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const flying = !a.onGround;
  const flap = flying ? Math.sin(a.t * 14) : Math.sin(a.t * 2) * 0.2;
  const sw = a.moving && a.onGround ? Math.sin(a.t * 11) : 0;
  const crouch = a.crouch ? 16 : 0;
  const red = '#c81e1e';
  const dark = '#1a0505';
  if (a.hurt) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a.t * 40);
  // tail
  ctx.strokeStyle = red;
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-6, -30 + crouch);
  ctx.quadraticCurveTo(-30, -20 + Math.sin(a.t * 5) * 6, -48, -8 + Math.sin(a.t * 5) * 10);
  ctx.stroke();
  // wings (back)
  const top = -66 + crouch;
  ctx.fillStyle = dark;
  ctx.beginPath();
  ctx.moveTo(-6, top + 6);
  ctx.quadraticCurveTo(-46, top - 10 - flap * 24, -62, top + 14 - flap * 30);
  ctx.quadraticCurveTo(-36, top + 30, -6, top + 32);
  ctx.fill();
  ctx.fillStyle = red;
  ctx.beginPath();
  ctx.moveTo(-6, top + 10);
  ctx.quadraticCurveTo(-36, top - 2 - flap * 20, -50, top + 16 - flap * 24);
  ctx.quadraticCurveTo(-30, top + 26, -6, top + 28);
  ctx.fill();
  // legs
  limb(ctx, -6, -30 + crouch, -6 - sw * 9 - (flying ? 6 : 0), -3 - (flying ? 6 : 0), 8, red);
  limb(ctx, 6, -30 + crouch, 6 + sw * 9 - (flying ? 4 : 0), -3 - (flying ? 4 : 0), 8, red);
  // torso
  ctx.fillStyle = red;
  rr(ctx, -14, top, 28, 38, 10);
  ctx.fill();
  ctx.fillStyle = '#facc15';
  rr(ctx, -6, top + 6, 12, 26, 5);
  ctx.globalAlpha *= 0.4;
  ctx.fill();
  ctx.globalAlpha = a.hurt ? 0.8 : 1;
  // front wing
  ctx.fillStyle = dark;
  ctx.beginPath();
  ctx.moveTo(8, top + 6);
  ctx.quadraticCurveTo(42, top - 8 - flap * 22, 56, top + 14 - flap * 26);
  ctx.quadraticCurveTo(34, top + 28, 8, top + 30);
  ctx.fill();
  const punch = a.attack > 0 ? 1 - a.attack : 0;
  drawWatch(ctx, 0, top + 16, 5, 'active', a.t);
  // head (manta shape)
  const hy = top - 10;
  ctx.fillStyle = red;
  ctx.beginPath();
  ctx.moveTo(-14, hy + 8);
  ctx.quadraticCurveTo(-18, hy - 10, 0, hy - 14);
  ctx.quadraticCurveTo(20, hy - 12, 20, hy + 2);
  ctx.quadraticCurveTo(14, hy + 10, -14, hy + 8);
  ctx.fill();
  ctx.fillStyle = '#d9f99d';
  ctx.shadowColor = '#a3e635';
  ctx.shadowBlur = 10 + punch * 20;
  ctx.beginPath();
  ctx.ellipse(10, hy - 3, 4, 2.6, -0.2, 0, Math.PI * 2);
  ctx.ellipse(1, hy - 3, 3.4, 2.3, 0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* ---------------- Gwen ---------------- */
export function drawGwen(ctx: Ctx, cx: number, fy: number, facing: number, a: Anim) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  const sw = a.moving && a.onGround ? Math.sin(a.t * 11) : 0;
  const skin = '#f3c9a6';
  limb(ctx, -6, -28, -6 - sw * 8, -3, 8, '#f1f5f9');
  limb(ctx, 6, -28, 6 + sw * 8, -3, 8, '#e2e8f0');
  ctx.fillStyle = '#1e293b';
  ctx.beginPath();
  ctx.ellipse(-6 - sw * 8 + 2, -1, 6, 3, 0, 0, Math.PI * 2);
  ctx.ellipse(6 + sw * 8 + 2, -1, 6, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  const top = -56;
  ctx.fillStyle = '#2563eb';
  rr(ctx, -14, top, 28, 30, 8);
  ctx.fill();
  // cat logo
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(2, top + 14, 4, 0, Math.PI * 2);
  ctx.moveTo(-2, top + 11); ctx.lineTo(-1, top + 7); ctx.lineTo(1, top + 11);
  ctx.moveTo(3, top + 11); ctx.lineTo(5, top + 7); ctx.lineTo(6, top + 11);
  ctx.fill();
  const cast = a.attack > 0 ? 1 - a.attack : 0;
  limb(ctx, -13, top + 6, -15 - sw * 6, top + 26, 6, skin);
  const hx = 16 + cast * 14;
  const hyy = top + 24 - cast * 16;
  limb(ctx, 13, top + 6, hx, hyy, 6, skin);
  // pink glow hands
  ctx.fillStyle = `rgba(244,114,182,${0.5 + 0.4 * Math.sin(a.t * 6) + cast * 0.4})`;
  ctx.shadowColor = '#f472b6';
  ctx.shadowBlur = 14;
  ctx.beginPath();
  ctx.arc(hx, hyy, 5 + cast * 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  // head
  const hy = top - 13;
  ctx.fillStyle = skin;
  ctx.beginPath();
  ctx.arc(0, hy, 14, 0, Math.PI * 2);
  ctx.fill();
  // orange hair (short bob)
  ctx.fillStyle = '#ea580c';
  ctx.beginPath();
  ctx.moveTo(-16, hy + 8);
  ctx.quadraticCurveTo(-20, hy - 18, 0, hy - 17);
  ctx.quadraticCurveTo(18, hy - 18, 16, hy - 2);
  ctx.quadraticCurveTo(8, hy - 10, -2, hy - 8);
  ctx.quadraticCurveTo(-10, hy - 4, -12, hy + 10);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#60a5fa';
  ctx.fillRect(4, hy - 13, 7, 3);
  ctx.fillStyle = '#16a34a';
  ctx.beginPath();
  ctx.arc(6, hy + 1, 2.2, 0, Math.PI * 2);
  ctx.arc(-2, hy + 1, 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#9f4a3a';
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  ctx.arc(3, hy + 6, 3.5, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.stroke();
  ctx.restore();
}

/* ---------------- Grandpa Max ---------------- */
export function drawMax(ctx: Ctx, cx: number, fy: number, facing: number, t: number, wave: boolean) {
  ctx.save();
  ctx.translate(cx, fy);
  ctx.scale(facing, 1);
  limb(ctx, -9, -34, -9, -3, 12, '#a8875a');
  limb(ctx, 9, -34, 9, -3, 12, '#a8875a');
  ctx.fillStyle = '#3f2a14';
  ctx.beginPath();
  ctx.ellipse(-7, -1, 8, 3.5, 0, 0, Math.PI * 2);
  ctx.ellipse(11, -1, 8, 3.5, 0, 0, Math.PI * 2);
  ctx.fill();
  const top = -76;
  ctx.fillStyle = '#dc2626';
  rr(ctx, -22, top, 44, 44, 14);
  ctx.fill();
  // flowers
  ctx.fillStyle = '#fde68a';
  for (const [fx, fyy] of [[-12, 10], [8, 6], [-4, 26], [12, 30], [-16, 34]] as const) {
    ctx.beginPath();
    ctx.arc(fx, top + fyy, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  const w = wave ? Math.sin(t * 6) * 10 : 0;
  limb(ctx, -20, top + 8, -26, top + 36, 9, '#e8b98f');
  limb(ctx, 20, top + 8, 30, wave ? top - 14 - w : top + 36, 9, '#e8b98f');
  // head
  const hy = top - 14;
  ctx.fillStyle = '#e8b98f';
  ctx.beginPath();
  ctx.arc(0, hy, 15, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#d1d5db';
  rr(ctx, -14, hy - 20, 28, 10, 3);
  ctx.fill();
  ctx.fillStyle = '#222';
  ctx.beginPath();
  ctx.arc(6, hy, 1.8, 0, Math.PI * 2);
  ctx.arc(-3, hy, 1.8, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#7c4a32';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(2, hy + 5, 5, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.stroke();
  ctx.restore();
}

/* ---------------- RV "Rust Bucket" ---------------- */
export function drawRV(ctx: Ctx, x: number, fy: number, t: number, used: boolean) {
  ctx.save();
  ctx.translate(x, fy);
  ctx.fillStyle = '#cbd5e1';
  rr(ctx, -110, -110, 220, 92, 16);
  ctx.fill();
  ctx.fillStyle = '#94a3b8';
  rr(ctx, 70, -90, 50, 72, 10);
  ctx.fill();
  ctx.fillStyle = '#1d4ed8';
  ctx.fillRect(-110, -54, 230, 10);
  ctx.fillStyle = '#16a34a';
  ctx.fillRect(-110, -42, 230, 4);
  ctx.fillStyle = '#7dd3fc';
  for (let i = 0; i < 3; i++) {
    rr(ctx, -96 + i * 52, -96, 40, 28, 5);
    ctx.fill();
  }
  rr(ctx, 84, -84, 30, 26, 5);
  ctx.fill();
  ctx.fillStyle = '#475569';
  rr(ctx, 50, -92, 16, 56, 3);
  ctx.fill();
  ctx.fillStyle = '#111';
  ctx.beginPath();
  ctx.arc(-70, -16, 16, 0, Math.PI * 2);
  ctx.arc(70, -16, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#9ca3af';
  ctx.beginPath();
  ctx.arc(-70, -16, 6, 0, Math.PI * 2);
  ctx.arc(70, -16, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#334155';
  ctx.font = 'bold 11px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('RUST BUCKET', -20, -60);
  drawMax(ctx, -150, 0, 1, t, !used);
  if (!used) {
    ctx.fillStyle = '#fff';
    rr(ctx, -176, -150 + Math.sin(t * 3) * 3, 52, 22, 8);
    ctx.fill();
    ctx.fillStyle = '#111';
    ctx.font = 'bold 13px sans-serif';
    ctx.fillText('↑ ❤', -150, -134 + Math.sin(t * 3) * 3);
  }
  ctx.restore();
}

/* ---------------- Robo shark ---------------- */
export function drawShark(ctx: Ctx, cx: number, cy: number, facing: number, t: number, flash: boolean) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(facing, 1);
  if (flash) ctx.filter = 'brightness(2)';
  const tail = Math.sin(t * 8) * 6;
  ctx.fillStyle = '#475569';
  ctx.beginPath();
  ctx.moveTo(-34, 0);
  ctx.lineTo(-50, -14 + tail);
  ctx.lineTo(-48, 14 + tail);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#64748b';
  ctx.beginPath();
  ctx.ellipse(0, 0, 38, 15, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#cbd5e1';
  ctx.beginPath();
  ctx.ellipse(4, 6, 30, 7, 0, 0, Math.PI);
  ctx.fill();
  ctx.fillStyle = '#475569';
  ctx.beginPath();
  ctx.moveTo(-6, -13);
  ctx.lineTo(4, -30);
  ctx.lineTo(12, -12);
  ctx.fill();
  // bolts
  ctx.fillStyle = '#334155';
  ctx.fillRect(-14, -6, 3, 3);
  ctx.fillRect(-4, -8, 3, 3);
  ctx.fillStyle = '#fff';
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(22 + i * 4, 5);
    ctx.lineTo(24 + i * 4, 9);
    ctx.lineTo(26 + i * 4, 5);
    ctx.fill();
  }
  ctx.fillStyle = '#ff2d2d';
  ctx.shadowColor = '#ff2d2d';
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.arc(24, -3, 3.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* ---------------- Nature backgrounds ---------------- */
function wrapX(x: number, span: number) {
  return ((x % span) + span) % span;
}

export function drawBeachBG(ctx: Ctx, camX: number, groundY: number, t: number) {
  const W = 1280;
  const seaTop = groundY - 190;
  // distant island + lighthouse
  const ix = wrapX(900 - camX * 0.05, 2200) - 300;
  ctx.fillStyle = '#4d7c5a';
  ctx.beginPath();
  ctx.ellipse(ix, seaTop + 4, 220, 40, 0, Math.PI, 0);
  ctx.fill();
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(ix + 90, seaTop - 80, 16, 80);
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(ix + 90, seaTop - 60, 16, 12);
  ctx.fillRect(ix + 90, seaTop - 30, 16, 12);
  ctx.fillStyle = `rgba(255,240,150,${0.5 + 0.5 * Math.sin(t * 2)})`;
  ctx.beginPath();
  ctx.arc(ix + 98, seaTop - 86, 7, 0, Math.PI * 2);
  ctx.fill();
  // sea
  const g = ctx.createLinearGradient(0, seaTop, 0, groundY);
  g.addColorStop(0, '#0ea5e9');
  g.addColorStop(1, '#0369a1');
  ctx.fillStyle = g;
  ctx.fillRect(0, seaTop, W, groundY - seaTop);
  // sparkle lines
  ctx.strokeStyle = 'rgba(255,255,255,0.45)';
  ctx.lineWidth = 2;
  for (let i = 0; i < 26; i++) {
    const x = wrapX(i * 97 - camX * 0.2 + Math.sin(t + i) * 10, W + 100) - 50;
    const y = seaTop + 12 + (i % 6) * 26;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + 18 + (i % 3) * 8, y);
    ctx.stroke();
  }
  // sailboats
  for (let i = 0; i < 3; i++) {
    const bx = wrapX(i * 700 - camX * 0.12 + t * (10 + i * 4), 2100) - 200;
    const by = seaTop + 30 + i * 30 + Math.sin(t * 1.5 + i) * 3;
    ctx.fillStyle = '#7c2d12';
    ctx.beginPath();
    ctx.moveTo(bx - 30, by);
    ctx.lineTo(bx + 30, by);
    ctx.lineTo(bx + 20, by + 10);
    ctx.lineTo(bx - 20, by + 10);
    ctx.fill();
    ctx.fillStyle = i === 1 ? '#fde68a' : '#f8fafc';
    ctx.beginPath();
    ctx.moveTo(bx, by - 50);
    ctx.lineTo(bx + 24, by - 4);
    ctx.lineTo(bx, by - 4);
    ctx.fill();
  }
  // seagulls
  ctx.strokeStyle = '#1f2937';
  ctx.lineWidth = 2;
  for (let i = 0; i < 6; i++) {
    const sx = wrapX(i * 260 + t * 40 - camX * 0.1, W + 200) - 100;
    const sy = 120 + (i % 3) * 40 + Math.sin(t * 2 + i) * 10;
    const f = Math.sin(t * 8 + i) * 4;
    ctx.beginPath();
    ctx.moveTo(sx - 10, sy - f);
    ctx.quadraticCurveTo(sx - 5, sy - 6, sx, sy);
    ctx.quadraticCurveTo(sx + 5, sy - 6, sx + 10, sy - f);
    ctx.stroke();
  }
  // shore foam
  ctx.fillStyle = 'rgba(255,255,255,0.7)';
  for (let x = -40; x < W + 40; x += 40) {
    const xx = x - wrapX(camX * 0.4, 40);
    ctx.beginPath();
    ctx.ellipse(xx, groundY - 4 + Math.sin(t * 2 + x) * 2, 24, 6, 0, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function drawForestBG(ctx: Ctx, camX: number, groundY: number, t: number) {
  const W = 1280;
  // sun rays
  ctx.fillStyle = 'rgba(255,250,200,0.12)';
  for (let i = 0; i < 5; i++) {
    const x = wrapX(i * 320 - camX * 0.05, W + 300) - 150;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 60, 0);
    ctx.lineTo(x + 260, groundY);
    ctx.lineTo(x + 120, groundY);
    ctx.fill();
  }
  const layers: [number, string, number][] = [
    [0.12, '#2f5d3a', 340],
    [0.25, '#24502f', 280],
    [0.45, '#1a3f23', 220],
  ];
  layers.forEach(([par, col, hgt], li) => {
    ctx.fillStyle = col;
    const span = 160 + li * 30;
    const off = wrapX(camX * par, span);
    for (let x = -span; x < W + span; x += span) {
      const xx = x - off;
      const seed = Math.floor((x + camX * par) / span);
      const h = hgt + ((((seed * 37) % 80) + 80) % 80);
      if ((seed + li) % 2 === 0) {
        // pine
        ctx.beginPath();
        ctx.moveTo(xx, groundY - h);
        ctx.lineTo(xx + 60, groundY);
        ctx.lineTo(xx - 60, groundY);
        ctx.fill();
      } else {
        ctx.fillRect(xx - 8, groundY - h * 0.6, 16, h * 0.6);
        ctx.beginPath();
        ctx.arc(xx, groundY - h * 0.65, 60, 0, Math.PI * 2);
        ctx.arc(xx - 40, groundY - h * 0.5, 45, 0, Math.PI * 2);
        ctx.arc(xx + 40, groundY - h * 0.52, 48, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  });
  // falling leaves
  for (let i = 0; i < 18; i++) {
    const x = wrapX(i * 83 + Math.sin(t + i) * 30 - camX * 0.6, W);
    const y = wrapX(i * 47 + t * 40, groundY);
    ctx.fillStyle = i % 3 === 0 ? '#f59e0b' : '#84cc16';
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(t * 2 + i);
    ctx.beginPath();
    ctx.ellipse(0, 0, 5, 2.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

export function drawOceanBG(ctx: Ctx, camX: number, groundY: number, t: number) {
  const W = 1280;
  // god rays
  for (let i = 0; i < 6; i++) {
    const x = wrapX(i * 260 - camX * 0.1 + Math.sin(t * 0.4 + i) * 30, W + 300) - 150;
    ctx.fillStyle = `rgba(200,240,255,${0.06 + 0.04 * Math.sin(t + i)})`;
    ctx.beginPath();
    ctx.moveTo(x, 100);
    ctx.lineTo(x + 50, 100);
    ctx.lineTo(x + 200, groundY);
    ctx.lineTo(x + 80, groundY);
    ctx.fill();
  }
  // distant rocks / sunken city
  ctx.fillStyle = '#0b3b55';
  for (let x = -200; x < W + 200; x += 180) {
    const xx = x - wrapX(camX * 0.2, 180);
    const seed = Math.floor((x + camX * 0.2) / 180);
    const h = 100 + ((((seed * 53) % 140) + 140) % 140);
    if (seed % 3 === 0) {
      ctx.fillRect(xx, groundY - h, 60, h);
      ctx.beginPath();
      ctx.moveTo(xx - 6, groundY - h);
      ctx.lineTo(xx + 30, groundY - h - 30);
      ctx.lineTo(xx + 66, groundY - h);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.ellipse(xx + 40, groundY, 90, h * 0.7, 0, Math.PI, 0);
      ctx.fill();
    }
  }
  // fish school
  for (let s = 0; s < 3; s++) {
    const bx = wrapX(s * 600 + t * (30 + s * 10) - camX * 0.3, W + 300) - 150;
    const by = 220 + s * 90 + Math.sin(t + s) * 20;
    ctx.fillStyle = ['#fbbf24', '#f472b6', '#a3e635'][s];
    for (let i = 0; i < 7; i++) {
      const fx = bx + (i % 4) * 18;
      const fy = by + Math.floor(i / 4) * 14 + Math.sin(t * 4 + i) * 3;
      ctx.beginPath();
      ctx.ellipse(fx, fy, 7, 4, 0, 0, Math.PI * 2);
      ctx.moveTo(fx - 6, fy);
      ctx.lineTo(fx - 12, fy - 4);
      ctx.lineTo(fx - 12, fy + 4);
      ctx.fill();
    }
  }
  // bubbles
  ctx.strokeStyle = 'rgba(255,255,255,0.5)';
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 30; i++) {
    const x = wrapX(i * 61 - camX * 0.5 + Math.sin(t * 2 + i) * 8, W);
    const y = groundY - wrapX(i * 37 + t * 50, groundY - 120);
    ctx.beginPath();
    ctx.arc(x, y, 2 + (i % 3), 0, Math.PI * 2);
    ctx.stroke();
  }
}

export function drawNatureGround(ctx: Ctx, scene: CityScene, camX: number, groundY: number, W: number, H: number, theme: Theme, t: number) {
  if (theme === 'beach') {
    const g = ctx.createLinearGradient(0, groundY, 0, H);
    g.addColorStop(0, '#fde68a');
    g.addColorStop(1, '#eab308');
    ctx.fillStyle = g;
    ctx.fillRect(0, groundY, W, H - groundY);
    ctx.fillStyle = 'rgba(180,120,40,0.25)';
    for (let i = 0; i < 40; i++) {
      const x = wrapX(i * 71 - camX, W);
      ctx.fillRect(x, groundY + 20 + (i % 5) * 26, 3, 2);
    }
  } else if (theme === 'forest') {
    ctx.fillStyle = '#5b3a1e';
    ctx.fillRect(0, groundY, W, H - groundY);
    ctx.fillStyle = '#3f8f2f';
    ctx.fillRect(0, groundY, W, 14);
    ctx.fillStyle = '#4caf3a';
    for (let x = -10; x < W + 10; x += 10) {
      const xx = x - wrapX(camX, 10);
      ctx.beginPath();
      ctx.moveTo(xx, groundY + 2);
      ctx.lineTo(xx + 4, groundY - 8 - (Math.floor(x + camX) % 3) * 3);
      ctx.lineTo(xx + 8, groundY + 2);
      ctx.fill();
    }
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    for (let i = 0; i < 30; i++) ctx.fillRect(wrapX(i * 97 - camX, W), groundY + 30 + (i % 4) * 30, 10, 5);
  } else {
    // ocean floor
    const g = ctx.createLinearGradient(0, groundY, 0, H);
    g.addColorStop(0, '#c2a36b');
    g.addColorStop(1, '#6b5530');
    ctx.fillStyle = g;
    ctx.fillRect(0, groundY, W, H - groundY);
  }
  for (const p of scene.props) {
    const sx = p.x - camX;
    if (sx < -150 || sx > W + 150) continue;
    if (theme === 'beach') {
      if (p.kind === 0 || p.kind === 1) {
        // palm tree
        ctx.strokeStyle = '#8b5a2b';
        ctx.lineWidth = 12;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(sx, groundY);
        ctx.quadraticCurveTo(sx + 20, groundY - 100, sx + 10, groundY - 190);
        ctx.stroke();
        ctx.fillStyle = '#16a34a';
        for (let i = 0; i < 6; i++) {
          const ang = -Math.PI / 2 + (i - 2.5) * 0.55 + Math.sin(t * 1.5 + i) * 0.05;
          ctx.save();
          ctx.translate(sx + 10, groundY - 190);
          ctx.rotate(ang);
          ctx.beginPath();
          ctx.ellipse(40, 0, 44, 10, 0.3, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
        ctx.fillStyle = '#78350f';
        ctx.beginPath();
        ctx.arc(sx + 4, groundY - 182, 6, 0, Math.PI * 2);
        ctx.arc(sx + 16, groundY - 180, 6, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.kind === 2) {
        // umbrella + towel
        ctx.fillStyle = '#e5e7eb';
        ctx.fillRect(sx - 2, groundY - 110, 4, 110);
        const cols = ['#ef4444', '#fff', '#3b82f6', '#fff', '#ef4444'];
        cols.forEach((c, i) => {
          ctx.fillStyle = c;
          ctx.beginPath();
          ctx.moveTo(sx, groundY - 120);
          ctx.arc(sx, groundY - 104, 60, Math.PI + (i / 5) * Math.PI, Math.PI + ((i + 1) / 5) * Math.PI);
          ctx.fill();
        });
        ctx.fillStyle = '#f472b6';
        ctx.fillRect(sx + 10, groundY + 6, 70, 18);
      } else if (p.kind === 3) {
        // sandcastle
        ctx.fillStyle = '#d6a64a';
        ctx.fillRect(sx - 30, groundY - 30, 60, 30);
        ctx.fillRect(sx - 36, groundY - 50, 18, 50);
        ctx.fillRect(sx + 18, groundY - 50, 18, 50);
        ctx.fillRect(sx - 10, groundY - 60, 20, 30);
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.moveTo(sx, groundY - 60);
        ctx.lineTo(sx, groundY - 80);
        ctx.lineTo(sx + 14, groundY - 74);
        ctx.lineTo(sx, groundY - 70);
        ctx.fill();
      } else {
        // crab
        const cx = sx + Math.sin(t * 2 + p.x) * 20;
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.ellipse(cx, groundY + 10, 14, 8, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx - 16, groundY + 2, 5, 0, Math.PI * 2);
        ctx.arc(cx + 16, groundY + 2, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#111';
        ctx.fillRect(cx - 5, groundY, 2, 4);
        ctx.fillRect(cx + 3, groundY, 2, 4);
      }
    } else if (theme === 'forest') {
      if (p.kind === 0 || p.kind === 1) {
        ctx.fillStyle = '#4a2c14';
        ctx.fillRect(sx - 14, groundY - 170, 28, 170);
        ctx.fillStyle = p.kind === 0 ? '#2e7d32' : '#388e3c';
        ctx.beginPath();
        ctx.arc(sx, groundY - 190, 60, 0, Math.PI * 2);
        ctx.arc(sx - 46, groundY - 160, 44, 0, Math.PI * 2);
        ctx.arc(sx + 46, groundY - 162, 46, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(sx - 20, groundY - 180, 5, 0, Math.PI * 2);
        ctx.arc(sx + 26, groundY - 160, 5, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.kind === 2) {
        // mushrooms
        for (let i = 0; i < 3; i++) {
          const mx = sx + i * 22;
          const mh = 18 + i * 6;
          ctx.fillStyle = '#f5f5f4';
          ctx.fillRect(mx - 3, groundY - mh, 6, mh);
          ctx.fillStyle = '#dc2626';
          ctx.beginPath();
          ctx.arc(mx, groundY - mh, 12, Math.PI, 0);
          ctx.fill();
          ctx.fillStyle = '#fff';
          ctx.beginPath();
          ctx.arc(mx - 4, groundY - mh - 5, 2, 0, Math.PI * 2);
          ctx.arc(mx + 4, groundY - mh - 3, 2, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (p.kind === 3) {
        // log
        ctx.fillStyle = '#6b4423';
        rr(ctx, sx - 50, groundY - 22, 100, 22, 10);
        ctx.fill();
        ctx.fillStyle = '#c69c6d';
        ctx.beginPath();
        ctx.ellipse(sx + 50, groundY - 11, 8, 11, 0, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // bush with flowers
        ctx.fillStyle = '#2f7a2a';
        ctx.beginPath();
        ctx.arc(sx, groundY - 16, 24, 0, Math.PI * 2);
        ctx.arc(sx + 26, groundY - 12, 20, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f472b6';
        ctx.beginPath();
        ctx.arc(sx - 6, groundY - 26, 3.5, 0, Math.PI * 2);
        ctx.arc(sx + 20, groundY - 22, 3.5, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      // ocean props
      const sway = Math.sin(t * 1.5 + p.x) * 10;
      if (p.kind === 0 || p.kind === 3) {
        ctx.strokeStyle = '#15803d';
        ctx.lineWidth = 6;
        ctx.lineCap = 'round';
        for (let i = 0; i < 3; i++) {
          ctx.beginPath();
          ctx.moveTo(sx + i * 10, groundY);
          ctx.quadraticCurveTo(sx + i * 10 + sway, groundY - 70, sx + i * 10 - sway, groundY - 130 - i * 20);
          ctx.stroke();
        }
      } else if (p.kind === 1) {
        ctx.fillStyle = '#fb7185';
        for (let i = 0; i < 5; i++) {
          ctx.save();
          ctx.translate(sx, groundY);
          ctx.rotate(-0.8 + i * 0.4);
          rr(ctx, -4, -60, 8, 60, 4);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(0, -60, 7, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      } else if (p.kind === 2) {
        ctx.fillStyle = '#92400e';
        rr(ctx, sx - 26, groundY - 30, 52, 30, 4);
        ctx.fill();
        ctx.fillStyle = '#facc15';
        ctx.fillRect(sx - 26, groundY - 20, 52, 4);
        ctx.shadowColor = '#facc15';
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.arc(sx, groundY - 32, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      } else {
        ctx.fillStyle = '#57534e';
        ctx.beginPath();
        ctx.ellipse(sx, groundY, 50, 26, 0, Math.PI, 0);
        ctx.fill();
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.arc(sx + 10, groundY - 26, 8, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
}
