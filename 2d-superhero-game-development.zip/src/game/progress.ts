import { FormId } from './data';

export interface Progress {
  maxLevel: number; // highest unlocked level
  unlocked: FormId[];
  friends: string[];
  completed: number[];
}

const KEY = 'parsa-omnicore-progress-v1';

export const DEFAULT_PROGRESS: Progress = { maxLevel: 1, unlocked: [], friends: [], completed: [] };

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_PROGRESS };
    const p = JSON.parse(raw) as Progress;
    return { ...DEFAULT_PROGRESS, ...p };
  } catch {
    return { ...DEFAULT_PROGRESS };
  }
}

export function saveProgress(p: Progress) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
  } catch {
    /* ignore */
  }
}
