export type Action =
  | 'left'
  | 'right'
  | 'up'
  | 'down'
  | 'jump'
  | 'attack'
  | 'split'
  | 'watch'
  | 'transform'
  | 'pause'
  | 'confirm';

const KEYMAP: Record<string, Action[]> = {
  ArrowLeft: ['left'],
  KeyA: ['left'],
  ArrowRight: ['right'],
  KeyD: ['right'],
  ArrowUp: ['up', 'confirm'],
  KeyW: ['up'],
  ArrowDown: ['down'],
  KeyS: ['down'],
  Space: ['jump', 'confirm'],
  KeyJ: ['attack', 'confirm'],
  KeyZ: ['attack', 'confirm'],
  KeyK: ['split'],
  KeyX: ['split'],
  KeyQ: ['watch'],
  Tab: ['watch'],
  KeyE: ['transform', 'confirm'],
  Enter: ['transform', 'confirm'],
  Escape: ['pause'],
  KeyP: ['pause'],
};

// Standard gamepad mapping
const PADMAP: Record<number, Action[]> = {
  0: ['jump', 'confirm'], // A / Cross
  1: ['split'], // B / Circle
  2: ['attack', 'confirm'], // X / Square
  3: ['watch'], // Y / Triangle
  4: ['watch'], // LB
  5: ['transform', 'confirm'], // RB
  9: ['pause'], // Start
  12: ['up', 'confirm'],
  13: ['down'],
  14: ['left'],
  15: ['right'],
};

export class Input {
  private held = new Set<Action>();
  private prev = new Set<Action>();
  private keyHeld = new Set<Action>();
  private padHeld = new Set<Action>();
  public gamepadConnected = false;
  public gamepadName = '';
  public axisX = 0;
  private attached = false;
  private touchSources = new Map<string, Action[]>();
  public touchActive = false;

  /** Hold (actions) or release (null) a named on-screen control. */
  setTouchSource(id: string, actions: Action[] | null) {
    if (actions && actions.length) this.touchSources.set(id, actions);
    else this.touchSources.delete(id);
  }

  /** Short press, used for taps on the canvas / pause button. */
  tap(action: Action) {
    const id = 'tap-' + action;
    this.touchSources.set(id, action === 'confirm' ? ['confirm'] : [action]);
    setTimeout(() => this.touchSources.delete(id), 90);
  }

  clearTouch() {
    this.touchSources.clear();
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const acts = KEYMAP[e.code];
    if (!acts) return;
    if (e.code === 'Tab' || e.code === 'Space' || e.code.startsWith('Arrow')) e.preventDefault();
    acts.forEach((a) => this.keyHeld.add(a));
  };
  private onKeyUp = (e: KeyboardEvent) => {
    const acts = KEYMAP[e.code];
    if (!acts) return;
    acts.forEach((a) => this.keyHeld.delete(a));
  };
  private onBlur = () => {
    this.keyHeld.clear();
  };

  attach() {
    if (this.attached) return;
    this.attached = true;
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    // native gamepad bridge (Android-box APK forwards buttons / sticks from Java)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const w = window as any;
    w.__padBtn = (i: number, down: boolean) => {
      const a = PADMAP[i];
      this.setTouchSource('nb' + i, down && a ? a : null);
    };
    w.__padAxis = (x: number, y: number) => {
      const a: Action[] = [];
      if (x < -0.35) a.push('left');
      if (x > 0.35) a.push('right');
      if (y < -0.5) a.push('up');
      if (y > 0.5) a.push('down');
      this.setTouchSource('nax', a);
    };
  }

  detach() {
    if (!this.attached) return;
    this.attached = false;
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    this.touchSources.clear();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const w = window as any;
    w.__padBtn = undefined;
    w.__padAxis = undefined;
  }

  /** Call once per frame before reading input. */
  poll() {
    this.prev = new Set(this.held);
    this.padHeld.clear();
    this.axisX = 0;
    this.gamepadConnected = false;
    const pads = typeof navigator !== 'undefined' && navigator.getGamepads ? navigator.getGamepads() : [];
    for (const pad of pads) {
      if (!pad) continue;
      this.gamepadConnected = true;
      this.gamepadName = pad.id;
      pad.buttons.forEach((b, i) => {
        if (b.pressed || b.value > 0.5) {
          const acts = PADMAP[i];
          if (acts) acts.forEach((a) => this.padHeld.add(a));
        }
      });
      const ax = pad.axes[0] ?? 0;
      const ay = pad.axes[1] ?? 0;
      if (Math.abs(ax) > 0.3) {
        this.axisX = ax;
        this.padHeld.add(ax < 0 ? 'left' : 'right');
      }
      if (ay < -0.5) this.padHeld.add('up');
      if (ay > 0.5) this.padHeld.add('down');
      break;
    }
    const touch: Action[] = [];
    this.touchSources.forEach((a) => touch.push(...a));
    this.held = new Set<Action>([...this.keyHeld, ...this.padHeld, ...touch]);
  }

  isDown(a: Action) {
    return this.held.has(a);
  }

  justPressed(a: Action) {
    return this.held.has(a) && !this.prev.has(a);
  }

  vibrate(ms = 120, strong = 0.6) {
    try {
      if (this.touchActive && navigator.vibrate) navigator.vibrate(Math.min(ms, 120));
    } catch {
      /* ignore */
    }
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (const pad of pads) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const act = (pad as any)?.vibrationActuator;
      if (act?.playEffect) {
        act.playEffect('dual-rumble', { duration: ms, strongMagnitude: strong, weakMagnitude: strong * 0.5 }).catch(() => {});
      }
    }
  }
}
