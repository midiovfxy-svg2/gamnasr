import { CSSProperties, PointerEvent, ReactNode, useEffect, useRef, useState } from 'react';
import { Action, Input } from '../game/input';

const calcU = () => Math.max(40, Math.min(window.innerHeight * 0.14, 68));

const Ico = ({ children, fill = false }: { children: ReactNode; fill?: boolean }) => (
  <svg viewBox="0 0 24 24" width="100%" height="100%" fill={fill ? '#fff' : 'none'} stroke="#fff" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
    {children}
  </svg>
);
const ICONS = {
  watch: (
    <Ico>
      <path d="M6 3h12M6 21h12M7 3c0 6 5 6 5 9s-5 3-5 9M17 3c0 6-5 6-5 9s5 3 5 9" />
    </Ico>
  ),
  transform: (
    <Ico>
      <path d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3M18 3v4h-4M6 21v-4h4" />
    </Ico>
  ),
  attack: (
    <Ico fill>
      <path d="M12 2l2.6 7.4H22l-6 4.6 2.3 7.4L12 17l-6.3 4.4L8 14 2 9.4h7.4z" />
    </Ico>
  ),
  split: (
    <Ico fill>
      <path d="M13 2L4 14h7l-1 8 9-12h-7z" />
    </Ico>
  ),
  jump: (
    <Ico>
      <path d="M12 20V5M5 12l7-7 7 7" />
    </Ico>
  ),
};

function Btn({ input, id, actions, label, sub, x, y, size, tone, u }: { input: Input; id: string; actions: Action[]; label: ReactNode; sub: string; x: number; y: number; size: number; tone: string; u: number }) {
  const [down, setDown] = useState(false);
  const press = (e: PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
    input.touchActive = true;
    input.setTouchSource(id, actions);
    setDown(true);
  };
  const release = () => {
    input.setTouchSource(id, null);
    setDown(false);
  };
  const style: CSSProperties = {
    position: 'absolute',
    left: Math.round(u * x),
    top: Math.round(u * y),
    width: Math.round(u * size),
    height: Math.round(u * size),
    background: down ? tone : 'rgba(10,14,30,0.45)',
    borderColor: tone,
    transform: down ? 'scale(0.92)' : 'none',
  };
  return (
    <div
      onPointerDown={press}
      onPointerUp={release}
      onPointerCancel={release}
      onLostPointerCapture={release}
      onContextMenu={(e) => e.preventDefault()}
      style={style}
      className="pointer-events-auto flex touch-none select-none flex-col items-center justify-center rounded-full border-[3px] text-white shadow-lg transition-transform"
    >
      <span style={{ width: Math.round(u * size * 0.42), height: Math.round(u * size * 0.42), display: 'block' }}>{label}</span>
      <span style={{ fontSize: Math.max(8, Math.round(u * size * 0.17)), lineHeight: 1.1 }} className="mt-0.5 font-bold opacity-90">
        {sub}
      </span>
    </div>
  );
}

function DPad({ input, u }: { input: Input; u: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [dirs, setDirs] = useState<Action[]>([]);
  const update = (e: PointerEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2);
    const dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
    const a: Action[] = [];
    if (dx < -0.28) a.push('left');
    if (dx > 0.28) a.push('right');
    if (dy < -0.4) a.push('up');
    if (dy > 0.4) a.push('down');
    input.touchActive = true;
    input.setTouchSource('dpad', a);
    setDirs(a);
  };
  const end = () => {
    input.setTouchSource('dpad', null);
    setDirs([]);
  };
  const arrow = (d: Action, ch: string, pos: CSSProperties) => (
    <span style={{ position: 'absolute', ...pos, fontSize: Math.round(u * 0.55), opacity: dirs.includes(d) ? 1 : 0.45, color: dirs.includes(d) ? '#7CFC00' : '#fff' }}>{ch}</span>
  );
  const kx = dirs.includes('left') ? -0.5 : dirs.includes('right') ? 0.5 : 0;
  const ky = dirs.includes('up') ? -0.5 : dirs.includes('down') ? 0.5 : 0;
  const knob = Math.round(u * 1.1);
  return (
    <div
      ref={ref}
      onPointerDown={(e) => {
        e.preventDefault();
        try {
          e.currentTarget.setPointerCapture(e.pointerId);
        } catch {
          /* ignore */
        }
        update(e);
      }}
      onPointerMove={(e) => (e.buttons !== 0 || e.pointerType === 'touch' ? update(e) : undefined)}
      onPointerUp={end}
      onPointerCancel={end}
      onLostPointerCapture={end}
      onContextMenu={(e) => e.preventDefault()}
      style={{ width: Math.round(u * 3.1), height: Math.round(u * 3.1) }}
      className="pointer-events-auto relative touch-none select-none rounded-full border-[3px] border-white/40 bg-[rgba(10,14,30,0.4)]"
    >
      {arrow('up', '▲', { top: '4%', left: '50%', transform: 'translateX(-50%)' })}
      {arrow('down', '▼', { bottom: '4%', left: '50%', transform: 'translateX(-50%)' })}
      {arrow('left', '◀', { left: '8%', top: '50%', transform: 'translateY(-50%)' })}
      {arrow('right', '▶', { right: '8%', top: '50%', transform: 'translateY(-50%)' })}
      <div
        style={{
          position: 'absolute',
          width: knob,
          height: knob,
          left: '50%',
          top: '50%',
          marginLeft: -knob / 2 + kx * u,
          marginTop: -knob / 2 + ky * u,
        }}
        className="rounded-full bg-white/25"
      />
    </div>
  );
}

export default function TouchControls({ input }: { input: Input }) {
  const [u, setU] = useState(calcU);
  useEffect(() => {
    const f = () => setU(calcU());
    window.addEventListener('resize', f);
    window.addEventListener('orientationchange', f);
    return () => {
      window.removeEventListener('resize', f);
      window.removeEventListener('orientationchange', f);
    };
  }, []);
  const S = Math.round(u * 3.2);
  return (
    <div className="pointer-events-none fixed inset-0 z-20 select-none" dir="ltr">
      <div className="tc-left absolute">
        <DPad input={input} u={u} />
      </div>
      <div className="tc-right absolute" style={{ width: S, height: S }}>
        <Btn u={u} input={input} id="watch" actions={['watch']} label={ICONS.watch} sub="ساعت" x={1.15} y={0} size={0.95} tone="#7CFC00" />
        <Btn u={u} input={input} id="transform" actions={['transform', 'confirm']} label={ICONS.transform} sub="تبدیل" x={0.05} y={0.08} size={0.85} tone="#a3e635" />
        <Btn u={u} input={input} id="attack" actions={['attack', 'confirm']} label={ICONS.attack} sub="حمله" x={0} y={1.1} size={1.05} tone="#fb7185" />
        <Btn u={u} input={input} id="split" actions={['split']} label={ICONS.split} sub="قاچ زمین" x={2.1} y={1.1} size={1.05} tone="#38bdf8" />
        <Btn u={u} input={input} id="jump" actions={['jump', 'confirm']} label={ICONS.jump} sub="پرش" x={1.05} y={2.1} size={1.1} tone="#fde047" />
      </div>
    </div>
  );
}
