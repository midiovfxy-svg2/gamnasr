import { useEffect, useRef, useState } from 'react';
import { FORMS, FormId, LEVELS } from '../game/data';
import { Game, GameEvent, H, LevelResult, W } from '../game/engine';
import { Input } from '../game/input';
import TouchControls from './TouchControls';

interface Props {
  levelId: number;
  unlocked: FormId[];
  onComplete: (r: LevelResult) => void;
  onUnlock: (f: FormId) => void;
  onFriend: (name: string) => void;
  onExit: () => void;
  onNext: () => void;
  onRetry: () => void;
}

function useFit() {
  const calc = () => {
    const w = window.innerWidth;
    const h = window.innerHeight;
    const cw = Math.floor(Math.min(w, (h * 16) / 9));
    return { w: cw, h: Math.floor((cw * 9) / 16), vh: h };
  };
  const [s, setS] = useState(calc);
  useEffect(() => {
    const f = () => setS(calc());
    window.addEventListener('resize', f);
    window.addEventListener('orientationchange', f);
    return () => {
      window.removeEventListener('resize', f);
      window.removeEventListener('orientationchange', f);
    };
  }, []);
  return s;
}

// Set at build time for the Android-box edition (weak GPUs): start with cheaper effects.
const BOX = (import.meta as unknown as { env?: { VITE_BOX?: string } }).env?.VITE_BOX === '1';

export default function GameScreen({ levelId, unlocked, onComplete, onUnlock, onFriend, onExit, onNext, onRetry }: Props) {
  const fit = useFit();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const inputRef = useRef<Input>(null as unknown as Input);
  if (!inputRef.current) inputRef.current = new Input();
  const input = inputRef.current;
  const [result, setResult] = useState<LevelResult | null>(null);
  const [dead, setDead] = useState(false);
  const [dlg, setDlg] = useState<{ open: boolean; choices: string[] | null }>({ open: false, choices: null });
  const gameRef = useRef<Game | null>(null);
  const [touch, setTouch] = useState(() => typeof matchMedia !== 'undefined' && matchMedia('(pointer: coarse)').matches);
  const stateRef = useRef<{ result: LevelResult | null; dead: boolean }>({ result: null, dead: false });
  const cbRef = useRef({ onComplete, onUnlock, onFriend, onNext, onRetry });
  cbRef.current = { onComplete, onUnlock, onFriend, onNext, onRetry };

  useEffect(() => {
    input.touchActive = touch;
  }, [touch, input]);

  useEffect(() => {
    const on = () => setTouch(true);
    window.addEventListener('touchstart', on, { once: true, passive: true });
    return () => window.removeEventListener('touchstart', on);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setResult(null);
    setDead(false);
    setDlg({ open: false, choices: null });
    stateRef.current = { result: null, dead: false };
    const game = new Game(canvas, input, {
      levelId,
      unlocked,
      lowFx: BOX,
      onEvent: (e: GameEvent) => {
        if (e.type === 'complete') {
          stateRef.current.result = e.result;
          setResult(e.result);
          cbRef.current.onComplete(e.result);
        } else if (e.type === 'dialog') {
          setDlg({ open: e.open, choices: e.choices });
        } else if (e.type === 'dead') {
          stateRef.current.dead = true;
          setTimeout(() => setDead(true), 600);
        } else if (e.type === 'unlock') {
          cbRef.current.onUnlock(e.form);
        } else if (e.type === 'friend') {
          cbRef.current.onFriend(e.name);
        } else if (e.type === 'confirm') {
          if (stateRef.current.result) cbRef.current.onNext();
          else if (stateRef.current.dead) cbRef.current.onRetry();
        }
      },
    });
    gameRef.current = game;
    game.start();
    return () => game.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [levelId]);

  const level = LEVELS.find((l) => l.id === levelId)!;

  return (
    <div className="relative flex w-screen items-center justify-center overflow-hidden bg-black" dir="rtl" style={{ touchAction: 'none', height: fit.vh }}>
      <div className="relative" style={{ width: fit.w, height: fit.h }}>
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          onPointerDown={() => input.tap('confirm')}
          className="h-full w-full rounded-lg shadow-2xl shadow-emerald-900/40"
          style={{ imageRendering: 'auto' }}
        />

        {touch && dlg.choices && (
          <div className="absolute left-1/2 top-[22%] z-40 flex w-[70%] -translate-x-1/2 flex-col gap-2">
            {dlg.choices.map((c, i) => (
              <button key={i} onClick={() => gameRef.current?.pickChoice(i)} className="rounded-2xl border-2 border-violet-300 bg-violet-950/90 px-4 py-3 text-base font-bold text-white shadow-xl active:bg-violet-700">
                {c}
              </button>
            ))}
          </div>
        )}

        {touch && !dlg.open ? (
          <div className="absolute right-2 top-[22%] z-30 flex flex-col items-end gap-2">
            <button onPointerDown={() => input.tap('pause')} className="rounded-lg bg-black/50 px-3 py-1 text-sm text-white">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="#fff" className="inline">
                <rect x="6" y="4" width="4" height="16" rx="1" />
                <rect x="14" y="4" width="4" height="16" rx="1" />
              </svg>
            </button>
            <button onClick={onExit} className="rounded-lg bg-black/50 px-3 py-1 text-xs text-white">
              ✕ منو
            </button>
          </div>
        ) : (
          !touch && (
            <button onClick={onExit} className="absolute left-3 bottom-4 rounded-lg bg-white/10 px-3 py-1 text-xs text-white backdrop-blur hover:bg-white/20">
              خروج به منو
            </button>
          )
        )}

        {result && (
          <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/60 backdrop-blur-sm">
            <div className="max-h-[96%] w-[520px] max-w-[94%] overflow-y-auto rounded-3xl border border-emerald-400/40 bg-gradient-to-b from-slate-900 to-slate-950 p-4 text-center text-white shadow-2xl sm:p-8">
              <div className="text-sm tracking-widest text-emerald-300">مرحله {level.id} تمام شد</div>
              <h2 className="mt-1 text-2xl font-black sm:text-3xl">{level.name} ✔</h2>
              <div className="mt-3 grid grid-cols-3 gap-2 text-sm sm:mt-6 sm:gap-3">
                <Stat label="دشمنان شکست‌خورده" value={String(result.kills)} />
                <Stat label="زمان" value={`${result.timeSec} ثانیه`} />
                <Stat label="سلامتی باقی‌مانده" value={`${result.hpLeft}%`} />
              </div>
              {result.unlock && (
                <div className="mt-3 rounded-2xl border border-lime-400/40 bg-lime-400/10 p-3">
                  <div className="text-xs text-lime-300">موجود جدید به ساعت اضافه شد!</div>
                  <div className="mt-1 text-xl font-black" style={{ color: FORMS[result.unlock].glow }}>
                    {FORMS[result.unlock].name}
                  </div>
                  <div className="text-xs text-slate-300">{FORMS[result.unlock].desc}</div>
                </div>
              )}
              {result.friend && (
                <div className="mt-2 rounded-2xl border border-pink-400/40 bg-pink-400/10 p-2 text-sm">
                  دوست جدید: <b>{result.friend}</b> 💛
                </div>
              )}
              <div className="mt-4 flex justify-center gap-3">
                {level.id < LEVELS.length ? (
                  <button onClick={onNext} className="rounded-xl bg-emerald-500 px-6 py-3 font-bold text-black hover:bg-emerald-400">
                    مرحله بعد ←
                  </button>
                ) : (
                  <button onClick={onExit} className="rounded-xl bg-emerald-500 px-6 py-3 font-bold text-black hover:bg-emerald-400">
                    🎉 تمام شد! بازگشت به منو
                  </button>
                )}
                <button onClick={onExit} className="rounded-xl bg-white/10 px-5 py-3 font-bold hover:bg-white/20">
                  منو
                </button>
              </div>
            </div>
          </div>
        )}

        {dead && !result && (
          <div className="absolute inset-0 z-40 flex items-center justify-center bg-red-950/60 backdrop-blur-sm">
            <div className="max-h-[96%] w-[460px] max-w-[94%] overflow-y-auto rounded-3xl border border-red-400/40 bg-slate-950 p-4 text-center text-white shadow-2xl sm:p-8">
              <h2 className="text-2xl font-black sm:text-3xl">آخ! پارسا خسته شد</h2>
              <p className="mt-2 text-sm text-slate-300">بلیکوس و سرینا می‌گویند: «هر قهرمانی گاهی زمین می‌خورد، مهم اینه که دوباره بلند بشه.»</p>
              <div className="mt-4 flex justify-center gap-3">
                <button onClick={onRetry} className="rounded-xl bg-emerald-500 px-6 py-3 font-bold text-black hover:bg-emerald-400">
                  دوباره تلاش کن
                </button>
                <button onClick={onExit} className="rounded-xl bg-white/10 px-5 py-3 font-bold hover:bg-white/20">
                  منو
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {touch && !dlg.open && !result && !dead && <TouchControls input={input} />}

      {touch && (
        <div className="fixed inset-0 z-50 hidden flex-col items-center justify-center gap-3 bg-slate-950 text-center text-white portrait:flex">
          <div className="text-6xl">📱↻</div>
          <div className="text-xl font-black">گوشی را افقی بگیر</div>
          <div className="text-sm text-slate-400">بازی در حالت عمودی قابل بازی نیست</div>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-white/5 p-2 sm:p-3">
      <div className="text-lg font-black text-emerald-300">{value}</div>
      <div className="text-[11px] text-slate-400">{label}</div>
    </div>
  );
}
