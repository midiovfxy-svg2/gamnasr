import { DOWNLOADS, Link } from '../game/downloads';

export default function InstallPage({ onBack }: { onBack: () => void }) {
  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black p-6 text-white">
      <div className="mx-auto max-w-3xl">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-3xl font-black text-emerald-300">نصب و دانلود (آفلاین)</h1>
          <button onClick={onBack} className="rounded-xl bg-white/10 px-4 py-2 hover:bg-white/20">
            → بازگشت
          </button>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          <Card icon="📱" title="اندروید — موبایل (APK)" link={DOWNLOADS.mobile} cta="دانلود APK موبایل">
            برای گوشی و تبلت (اندروید ۶ به بالا) با دکمه‌های لمسی. «نصب از منابع ناشناس» را روشن کن. آفلاین اجرا می‌شود.
          </Card>
          <Card icon="📺" title="اندروید باکس / تلویزیون (APK)" link={DOWNLOADS.box} cta="دانلود APK اندروید باکس">
            برای اندروید باکس، تی‌وی‌باکس و دستگاه‌های قدیمی (اندروید ۵ به بالا، WebView قدیمی هم پشتیبانی می‌شود). با ریموت، دسته و کیبورد کار می‌کند.
          </Card>
          <Card icon="💻" title="ویندوز (EXE)" link={DOWNLOADS.exe} cta="دانلود نصب‌کننده">
            فایل Setup را اجرا کن. اگر ویندوز هشدار SmartScreen داد: «More info» ← «Run anyway». دسته‌ی PC هم پشتیبانی می‌شود.
          </Card>
        </div>
        <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-5 text-sm leading-7 text-slate-300">
          <b className="text-emerald-300">بدون نصب فایل:</b> همین صفحه را در Chrome گوشی باز کن و از منو «Add to Home screen» را بزن؛ بعد از یک بار باز شدن، آفلاین هم کار می‌کند.
          <div className="mt-2 text-xs text-slate-500">نسخه {DOWNLOADS.version}</div>
        </div>
      </div>
    </div>
  );
}

function Card({ icon, title, link, cta, children }: { icon: string; title: string; link: Link; cta: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
      <div className="text-4xl">{icon}</div>
      <h2 className="mt-2 text-xl font-black">{title}</h2>
      <p className="mt-2 text-sm leading-7 text-slate-300">{children}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        <a href={link.main} target="_blank" rel="noreferrer" className="inline-block rounded-xl bg-emerald-500 px-5 py-2 font-bold text-black hover:bg-emerald-400">
          {cta}
        </a>
        <a href={link.mirror} target="_blank" rel="noreferrer" className="inline-block rounded-xl bg-white/10 px-4 py-2 text-sm hover:bg-white/20">
          لینک دوم
        </a>
      </div>
      <div className="mt-3 text-[11px] text-amber-300/80">لینک‌ها موقتی‌اند؛ اگر باز نشد از پوشه‌ی release پروژه استفاده کن.</div>
      <div className="mt-2 break-all text-left text-[10px] text-slate-500" dir="ltr">SHA-256: {link.sha}</div>
    </div>
  );
}
