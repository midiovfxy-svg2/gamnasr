import { useState } from 'react';
import { FORMS, LEVELS } from '../game/data';

const SCRIPT_FA = `# سند جامع بازی دو بعدی ۲۰ مرحله‌ای: محمد پارسا و ساعت بن‌تن
رفرنس تولید و پیاده‌سازی برای استرا (Astra) / Unity / Unreal Engine
ژانر: پلتفرمر اکشن دوبعدی | ۲۰ مرحله | مناسب همه‌ی سنین | کنترل: کیبورد + دسته‌ی PC

## ۱. کاراکتر اصلی (Mohammad Parsa)
- سن: ۴ سال | موهای فر قهوه‌ای تیره، چشمان درشت قهوه‌ای گرم و کنجکاو، لبخند پرانرژی و معصوم.
- لباس: تی‌شرت ارغوانی با جیب سینه و لوگوی allô (#873C68)، شلوار راحتی ارغوانی ست، پابرهنه.
- ساعت بن‌تن فضایی با هسته نئون سبز (#00FF7F) چسبیده به مچ چپ.
- قدرت اختصاصی: «قاچ کردن زمین» — کوبیدن ساعت به آسفالت و باز شدن گسل نوری.
- انیمیشن‌ها: Idle، Run، Jump، Crouch، Punch، Earth-Crack، Watch-Dial، Transform.

## ۲. دشمن اصلی: اِکس غول‌پیکر (Titan Godzilla X)
- بیش از ۱۰۰ متر ارتفاع؛ هیولای بیومکانیکال با پوست ابسیدین سیاه، تیغه‌های گودزیلایی پشت، رگه‌های گدازه‌ی سرخ و چشم‌های سرخ.
- هدف: خرد کردن شهر و ربودن ساعت. فازها: باران شهاب‌سنگ، لیزر چشم، زلزله‌ی کوبشی با پا، احضار ربات. جان: ۱۰۰۰.

## ۳. کوین لوین — جذب خواص فیزیکی هر جسم؛ همراه وفادار از مرحله ۵.
## ۴. ایلان ایکس — بلیکوس (مرد؛ عدالت) و سرینا (زن؛ محبت). تصمیم سه‌نفره در مرحله ۱۰.
## موجودات ساعت: کله‌آتشی (م۱)، چهاردست (م۲)، XLR8 (م۴)، کله‌الماسی (م۶)، ایلان ایکس (م۱۰).
## دوستان: سارا (م۳)، کوین (م۵)، علی (م۸)، برفی (م۱۲).
## خرابی ساعت: م۷ (تعویض تصادفی موجود) و م۱۴ (نوسان؛ ایلان ایکس در دسترس نیست).

## مکانیک‌ها
حرکت، پرش، نشستن (جاخالی لیزر/کریستال)، حمله، قاچ‌کردن زمین (۶ ثانیه خنک‌شدن)، چرخاندن صفحه ساعت (حرکت آهسته)، تبدیل (۲۶ ثانیه؛ بعد از مرحله ۱۸: ۳۸ ثانیه؛ ایلان ایکس ۱۶ ثانیه + کند کردن زمان)، شارژ ۸ ثانیه، نجات دوستان (اول دشمنان دورشان، بعد ↑)، کوین همراه (جذب قدرت با لمس)، باران شهاب‌سنگ (زدن سنگ‌ها در هوا)، دفاع از برج (۷۵ ثانیه)، باس گولیات (۴۵۰) و اِکس (۱۰۰۰).
دسته‌ی PC: استیک حرکت، A پرش، X حمله، B قاچ زمین، Y ساعت، RB تبدیل، Start توقف، لرزش دسته.

## فیلم‌نامه ۲۰ مرحله
${LEVELS.map((l) => `مرحله ${l.id}: ${l.name} — ${l.subtitle} | محیط: ${l.theme}${l.boss ? ' | باس: ' + (l.boss === 'ex' ? 'اِکس (' + l.bossHp + ')' : 'گولیات (' + l.bossHp + ')') : ''}${l.unlock ? ' | باز شدن: ' + FORMS[l.unlock].name : ''}${l.npc ? ' | دوست: ' + l.npc.name : ''}${l.friendOnComplete ? ' | دوست: ' + l.friendOnComplete : ''}${l.malfunction ? ' | ساعت: خرابی/اتصال کوتاه' : ''}${l.meteorRain ? ' | باران شهاب‌سنگ' : ''}${l.defend ? ' | دفاع ' + l.defend + ' ثانیه' : ''}\n  موجودات در دسترس: ${l.available.map((f) => FORMS[f].name).join('، ')}`).join('\n')}

## دیالوگ‌های کامل
${LEVELS.map((l) => `### مرحله ${l.id}: ${l.name}\n[شروع]\n${l.intro.map((d) => `${d.speaker}: ${d.text}`).join('\n')}${l.craterDialog ? `\n[کشف ساعت]\n${l.craterDialog.map((d) => `${d.speaker}: ${d.text}`).join('\n')}` : ''}${l.questions ? `\n[پرسش‌های کیهانی]\n${l.questions.map((q) => `${q.speaker}: ${q.text}\n${(q.choices ?? []).map((c, i) => `  گزینه ${i + 1}: ${c.text}\n${c.reply.map((r) => `    ${r.speaker}: ${r.text}`).join('\n')}`).join('\n')}`).join('\n')}` : ''}${l.npc ? `\n[نجات ${l.npc.name} — ${l.npc.role}]\n${l.npc.dialog.map((d) => `${d.speaker}: ${d.text}`).join('\n')}` : ''}\n[پایان]\n${l.outro.map((d) => `${d.speaker}: ${d.text}`).join('\n')}`).join('\n\n')}
`;

const PROMPTS_EN = `# Reference prompts for image tools (English)

## Hero — Mohammad Parsa
Cute 4-year-old slim boy, natural curly dark brown hair, big warm brown curious eyes, energetic innocent smile, purple t-shirt with chest pocket and golden "allô" logo (#873C68), matching purple comfy pants, barefoot, alien Omnitrix-style wristwatch with neon green core (#00FF7F) locked on left wrist. Cel-shaded 2D game style, thick outlines. Sheet: turnaround, expressions, animations Idle / Run / Jump / Crouch / Punch / Earth-Crack (slamming watch into asphalt opening a glowing green fault line) / Watch-Dial / Transform (green flash).

## Villain — Titan Godzilla X ("EX")
Biomechanical alien kaiju over 100 m tall, hard obsidian-black skin, godzilla-like dorsal shark fins, boiling molten red lava veins, focused red eyes, red core on chest (weak point). Attacks: meteor rain, deadly eye laser beams, stomping earthquakes. Towering over skyscrapers, side-scroller boss composition.

## Alien X — Bellicus & Serena
Tall humanoid of black cosmic void filled with stars, three horns, green eyes, green hourglass emblem. Two giant floating cosmic faces: Bellicus (stern male, red light — justice) and Serena (kind female, pink light — love). Cosmic dimension background with nebulae and floating crystals.

## Friends
Kevin Levin: 10-year-old, spiky black hair, grey hoodie with lightning symbol, arms turning to metal/stone/diamond on touch. Sara: 4-year-old girl, pigtails, yellow dress. Ali: energetic boy with red cap, blue overalls, wrench. Barfi: fluffy white kitten with blue eyes.

## Enemies
Purple alien scout drones (red eye, lasers), armored grunts with claws, heavy brutes (charge attack), purple alien tanks (arcing shells), falling fiery meteors, Goliath Drone: 20 m crystal-armored purple guardian with cyan crystal spikes, cannon arm and shockwave slam.

## Environments
Night city park with meteor crater glowing green; sunny downtown; sunset bridge; night streets; ruined street with purple sky and meteor rain; rooftops at night; subway station; cosmic dimension; telecom tower defense; final rooftop battle in storm under the Titan.
`;

export default function StoryPage({ onBack }: { onBack: () => void }) {
  const [tab, setTab] = useState<'story' | 'script' | 'prompts'>('story');
  const [copied, setCopied] = useState(false);
  const copy = (txt: string) => {
    navigator.clipboard?.writeText(txt).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };
  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black p-6 text-white">
      <div className="mx-auto max-w-5xl">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-black text-emerald-300">داستان و اسکریپت بازی</h1>
          <button onClick={onBack} className="rounded-xl bg-white/10 px-4 py-2 hover:bg-white/20">
            → بازگشت
          </button>
        </div>
        <div className="mt-6 flex gap-2">
          {(
            [
              ['story', 'داستان'],
              ['script', 'اسکریپت کامل'],
              ['prompts', 'پرامپت‌های رفرنس (EN)'],
            ] as const
          ).map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className={`rounded-xl px-4 py-2 font-bold ${tab === k ? 'bg-emerald-500 text-black' : 'bg-white/10 hover:bg-white/20'}`}>
              {l}
            </button>
          ))}
        </div>

        {tab === 'story' && (
          <div className="mt-6 space-y-6 leading-8">
            <Section title="۱. سقوط شهاب‌سنگ و کشف ساعت (مرحله ۱)">
              شهاب‌سنگی مرموز وسط پارک شهر سقوط می‌کند. محمد پارسای ۴ ساله جلو می‌رود، دست به آن می‌زند و ساعت سبزرنگ بن‌تن به مچ دست چپش قفل می‌شود! از درون ساعت دو صدا با او حرف می‌زنند:{' '}
              <b className="text-red-300">بلیکوس</b> (مرد کیهانی؛ عدالت سخت‌گیرانه) و <b className="text-pink-300">سرینا</b> (زن کیهانی؛ محبت و صلح). پارسا یاد می‌گیرد زمین را قاچ کند و به کله‌آتشی تبدیل شود.
            </Section>
            <Section title="۲. هجوم بیگانگان و دوستان شهر (مراحل ۲ تا ۹)">
              سیگنال ساعت در فضا پخش می‌شود و ربات‌ها و تانک‌های اِکس به شهر می‌ریزند. پارسا چهاردست، XLR8 و کله‌الماسی را به دست می‌آورد، سارا (همکلاسی مهدکودک) را نجات می‌دهد، با{' '}
              <b>کوین لوین</b> — پسری که به هرچه دست بزند همان می‌شود — هم‌تیمی می‌شود و وقتی ربات هکر ساعتش را خراب می‌کند، علیِ مکانیک کوچک آن را کالیبره می‌کند. در بزرگراه با قاچ‌کردن زمین تانک‌ها را از جا می‌کَند.
            </Section>
            <Section title="۳. ورود به ذهن ایلان ایکس (مرحله ۱۰)">
              هوشیاری پارسا وارد بُعد کیهانی می‌شود. بلیکوس و سرینا سه پرسش اخلاقی می‌پرسند: با دشمنِ شکست‌خورده چه می‌کنی؟ با قدرت توقف زمان چه می‌کنی؟ حاضری برای ترمیم ابعاد جهان، قدرتت را بدهی؟ تصمیم سه‌نفره گرفته می‌شود و
              ژن کیهانی <b className="text-violet-300">ایلان ایکس</b> آزاد می‌شود: انفجار ستاره‌ای و کند کردن زمان.
            </Section>
            <Section title="۴. شهر زیر سایه (مراحل ۱۱ تا ۱۶)">
              تعقیب ربات‌های نینجا روی بام‌ها، نجات برفی گربه‌ی محله از میان کانتینرهای در آتش، ارتش ربات‌های زره‌پوش که فقط چهاردست و کوینِ آهنی حریفشان می‌شوند، موج دوم هک ساعت توسط ماهواره‌ی اِکس، باران
              شهاب‌سنگ‌ها زیر آسمان بنفش و نبرد در تاریکی مترو.
            </Section>
            <Section title="۵. پیش‌قراول و اتحاد دوستان (مراحل ۱۷ و ۱۸)">
              گولیات، نگهبان کریستالی ۲۰ متری اِکس، وارد میدان می‌شود. سپس کوین، سارا، علی، برفی و همه‌ی بچه‌ها کنار پارسا جمع می‌شوند تا با دفاع از برج مخابراتی، انرژی ساعت را به ۱۰۰٪ برسانند.
            </Section>
            <Section title="۷. فصل ۲ — ساحل و دریا (مراحل ۲۱ تا ۳۵)">
              اِکس زخمی به اعماق دریا فرار می‌کند. <b className="text-orange-300">بابابزرگ مکس</b> با کاروان «رست باکت» از راه می‌رسد و نوه‌اش <b className="text-pink-300">گوئن</b> — که بشقاب‌های انرژی صورتی پرتاب می‌کند و بهترین دوست کوین است — به تیم می‌پیوندد. پارسا در آب‌های ساحلی شنا می‌کند، <b className="text-red-300">جت‌ری</b> (پرنده و شناگر) را به دست می‌آورد، به زیر دریا، غار مرجانی و شهر غرق‌شده می‌رود، کراکن مکانیکی را شکست می‌دهد و در ساحل دوباره با اِکس می‌جنگد.
            </Section>
            <Section title="۸. فصل ۳ — جنگل باستانی (مراحل ۳۶ تا ۵۰)">
              اِکس به جنگل باستانی می‌رود تا هسته‌ی شهاب‌سنگ اصلی را بدزدد. تیم از رودخانه و آبشار شنا می‌کند، بین درختان غول‌پیکر پرواز می‌کند، برفی گم‌شده را پیدا می‌کند، شب جنگل را با کرم‌های شب‌تاب طی می‌کند، از درخت زندگی دفاع می‌کند و علی و سارا هم به کمک می‌آیند. در نبرد افسانه‌ای، هسته‌ی شهاب‌سنگ به ساعت پارسا برمی‌گردد و اِکس برای همیشه به فضا پرتاب می‌شود — و همه با کاروان مکس بستنی می‌خورند!
            </Section>
            <Section title="۶. نبرد بزرگ فصل اول (مراحل ۱۹ و ۲۰)">
              زمین می‌لرزد و آسمان‌خراش‌ها مثل اسباب‌بازی زیر پای اِکس خرد می‌شوند. پارسا ارتش محافظ او را شکست می‌دهد و در اوج طوفان روی بام‌ها با Titan Godzilla X روبه‌رو می‌شود: باران شهاب‌سنگ، لیزر چشم و زلزله‌ی
              کوبشی. با قاچ‌کردن زمین و قدرت نهایی ایلان ایکس، هسته‌ی سرخ اِکس خاموش می‌شود. بلیکوس: «قدرت واقعی در عدالت همراه با مهربانی است.» سرینا: «و در دوستی.» و پارسا باید برود بخوابد — فردا مهدکودک دارد!
            </Section>
          </div>
        )}

        {tab === 'script' && (
          <div className="mt-6">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm text-slate-400">این متن را می‌توانی کپی کنی و به ابزار تولید تصویر/انیمیشن بدهی.</span>
              <button onClick={() => copy(SCRIPT_FA)} className="rounded-lg bg-emerald-500 px-4 py-2 text-sm font-bold text-black">
                {copied ? 'کپی شد ✔' : 'کپی اسکریپت'}
              </button>
            </div>
            <pre dir="rtl" className="max-h-[70vh] overflow-auto whitespace-pre-wrap rounded-2xl border border-white/10 bg-black/50 p-5 text-right text-sm leading-7 text-slate-200">
              {SCRIPT_FA}
            </pre>
          </div>
        )}

        {tab === 'prompts' && (
          <div className="mt-6">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm text-slate-400">پرامپت‌های انگلیسی برای ساخت رفرنس تصویری</span>
              <button onClick={() => copy(PROMPTS_EN)} className="rounded-lg bg-emerald-500 px-4 py-2 text-sm font-bold text-black">
                {copied ? 'Copied ✔' : 'Copy prompts'}
              </button>
            </div>
            <pre dir="ltr" className="max-h-[70vh] overflow-auto whitespace-pre-wrap rounded-2xl border border-white/10 bg-black/50 p-5 text-left text-sm leading-7 text-slate-200">
              {PROMPTS_EN}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
      <h3 className="mb-2 text-xl font-black text-emerald-300">{title}</h3>
      <p className="text-slate-200">{children}</p>
    </div>
  );
}
