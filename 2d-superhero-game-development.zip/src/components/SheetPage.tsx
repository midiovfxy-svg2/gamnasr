import { useEffect, useRef } from 'react';
import { FORMS, FORM_ORDER } from '../game/data';
import { Anim, drawEx, drawForm, drawKevin, drawBrute, drawScout, drawGrunt, drawGoliath, drawTank, drawMeteor, drawNpc, drawGwen, drawMax, drawShark } from '../game/draw';

const IMAGES = [
  { src: 'ref/gwen-max-jetray.jpg', title: 'جت‌ری، گوئن، بابابزرگ مکس و کوین', desc: 'جت‌ری پرنده و شناگر، گوئن با بشقاب صورتی، مکس و کاروان رست باکت' },
  { src: 'ref/beach-ocean-forest.jpg', title: 'محیط‌های جدید: ساحل، زیر دریا، جنگل', desc: 'ساحل، شنا در دریا، اعماق اقیانوس، جنگل روز و شب، معبد شهاب‌سنگ' },
  { src: 'ref/parsa-master-sheet.jpg', title: 'کاراکتر شیت اصلی — ۳۰ نما (پارسا، دشمن، محیط)', desc: 'نماهای مختلف، حالات چهره، پوزهای اکشن، ساعت، اِکس و محیط شهر در یک تصویر' },
  { src: 'ref/ex-titan.jpg', title: 'اِکس غول‌پیکر — Titan Godzilla X', desc: 'بیش از ۱۰۰ متر، پوست ابسیدین، تیغه‌های گودزیلایی، رگه‌های گدازه و چشم‌های سرخ' },
  { src: 'ref/alienx-friends.jpg', title: 'ایلان ایکس، بلیکوس و سرینا، دوستان و گولیات', desc: 'ایلان ایکس کیهانی، سارا، علی، برفی، کوین، نگهبان کریستالی، تانک و شهاب‌سنگ' },
  { src: 'ref/aliens-sheet.jpg', title: 'موجودات داخل ساعت', desc: 'کله‌آتشی، کله‌الماسی، XLR8، چهاردست' },
  { src: 'ref/kevin-mentors.jpg', title: 'کوین لوین', desc: 'دوست صمیمی با قدرت جذب ماده' },
  { src: 'ref/city-env.jpg', title: 'محیط بازی — شهر', desc: 'خیابان، بام، پارک، ساختمان‌سازی، مترو، خرابه' },
  { src: 'ref/ex-boss.jpg', title: 'اِکس — کانسپت اولیه', desc: 'نسخه‌ی اول طراحی (بنفش) برای مقایسه' },
];

function Preview({ draw, w = 160, h = 160 }: { draw: (ctx: CanvasRenderingContext2D, t: number) => void; w?: number; h?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext('2d')!;
    let raf = 0;
    const start = performance.now();
    const loop = () => {
      const t = (performance.now() - start) / 1000;
      ctx.clearRect(0, 0, w, h);
      draw(ctx, t);
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [draw, w, h]);
  return <canvas ref={ref} width={w} height={h} className="rounded-xl bg-slate-800/60" />;
}

const idle = (t: number, moving = false): Anim => ({ t, moving, onGround: true, crouch: false, attack: 0, hurt: false, vy: 0 });

export default function SheetPage({ onBack }: { onBack: () => void }) {
  const forms = ['human', ...FORM_ORDER] as const;
  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black p-6 text-white">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-black text-emerald-300">کاراکتر شیت و رفرنس‌ها</h1>
          <button onClick={onBack} className="rounded-xl bg-white/10 px-4 py-2 hover:bg-white/20">
            → بازگشت
          </button>
        </div>
        <p className="mt-2 text-sm text-slate-400">
          طراحی کاراکتر بر اساس شیت ارائه‌شده (موی قهوه‌ای تیره، چشم قهوه‌ای، تیشرت و شلوار بنفش «allo»، پابرهنه، ۴ ساله، لاغر) به سبک کارتونی بازی ساخته شده است. تصاویر را می‌توانی ذخیره کنی و به‌عنوان رفرنس استفاده کنی.
        </p>

        {/* In-game sprites */}
        <h2 className="mt-8 text-xl font-black">اسپرایت‌های داخل بازی (زنده)</h2>
        <div className="mt-3 grid grid-cols-2 gap-4 md:grid-cols-6">
          {forms.map((f) => (
            <div key={f} className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
              <Preview draw={(ctx, t) => drawForm(ctx, f, 80, 145, 1, idle(t, true), 'ready')} />
              <div className="mt-2 font-bold" style={{ color: FORMS[f].glow }}>
                {FORMS[f].name}
              </div>
              <div className="text-[11px] text-slate-400">{FORMS[f].desc}</div>
            </div>
          ))}
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawKevin(ctx, 80, 145, 1, idle(t), '#9ca3af')} />
            <div className="mt-2 font-bold text-slate-200">کوین لوین</div>
            <div className="text-[11px] text-slate-400">دوست جذب‌کننده‌ی ماده</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawGwen(ctx, 80, 150, 1, { ...idle(t, true), attack: (Math.sin(t * 2) + 1) / 2 })} />
            <div className="mt-2 font-bold text-pink-300">گوئن</div>
            <div className="text-[11px] text-slate-400">نوه‌ی مکس — بشقاب انرژی صورتی</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawMax(ctx, 80, 150, 1, t, true)} />
            <div className="mt-2 font-bold text-orange-300">بابابزرگ مکس</div>
            <div className="text-[11px] text-slate-400">کاروان رست باکت — شفا و راهنمایی</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawShark(ctx, 80, 80, 1, t, false)} />
            <div className="mt-2 font-bold text-slate-300">ربات‌کوسه</div>
            <div className="text-[11px] text-slate-400">دشمن زیر آب</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawNpc(ctx, 80, 150, t, '#facc15', true, 'girl')} />
            <div className="mt-2 font-bold text-yellow-200">سارا</div>
            <div className="text-[11px] text-slate-400">همکلاسی مهدکودک</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawNpc(ctx, 80, 150, t, '#3b82f6', true, 'boy')} />
            <div className="mt-2 font-bold text-blue-200">علی</div>
            <div className="text-[11px] text-slate-400">مکانیک کوچک</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawNpc(ctx, 70, 120, t, '#fff', true, 'cat')} />
            <div className="mt-2 font-bold text-slate-100">برفی</div>
            <div className="text-[11px] text-slate-400">گربه‌ی بازیگوش محله</div>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-6">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawScout(ctx, 80, 135, 1, t, true, false)} />
            <div className="mt-2 font-bold text-purple-300">ربات دیده‌بان اِکس</div>
            <div className="text-[11px] text-slate-400">زمینی — لیزر</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawGrunt(ctx, 80, 145, 1, t, true, false)} />
            <div className="mt-2 font-bold text-purple-300">سرباز اِکس</div>
            <div className="text-[11px] text-slate-400">پیاده — پنجه</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawBrute(ctx, 80, 150, 1, t, false, false, false)} />
            <div className="mt-2 font-bold text-purple-300">غول‌تشن</div>
            <div className="text-[11px] text-slate-400">حمله‌ی شارژی</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawTank(ctx, 80, 150, 1, t, false)} />
            <div className="mt-2 font-bold text-purple-300">تانک اِکس</div>
            <div className="text-[11px] text-slate-400">گلوله‌ی کمانی</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview draw={(ctx, t) => drawMeteor(ctx, 70, 100, 22, t)} />
            <div className="mt-2 font-bold text-orange-300">شهاب‌سنگ</div>
            <div className="text-[11px] text-slate-400">در هوا بزنش!</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview
              draw={(ctx, t) => {
                ctx.save();
                ctx.translate(80, 155);
                ctx.scale(0.55, 0.55);
                drawGoliath(ctx, 0, 0, 1, t, false, 'walk', 0);
                ctx.restore();
              }}
            />
            <div className="mt-2 font-bold text-cyan-300">گولیات</div>
            <div className="text-[11px] text-slate-400">مینی‌باس ۲۰ متری</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
            <Preview
              draw={(ctx, t) => {
                ctx.save();
                ctx.translate(90, 158);
                ctx.scale(0.27, 0.27);
                drawEx(ctx, 0, 0, -1, t, 'idle', 0, 1);
                ctx.restore();
              }}
            />
            <div className="mt-2 font-bold text-red-300">اِکس</div>
            <div className="text-[11px] text-slate-400">Titan Godzilla X</div>
          </div>
        </div>

        {/* Textual sheet */}
        <h2 className="mt-10 text-xl font-black">مشخصات کاراکتر اصلی</h2>
        <div className="mt-3 grid gap-4 md:grid-cols-2">
          <Card title="محمد پارسا">
            <Row k="سن" v="۴ سال" />
            <Row k="قد / اندام" v="حدود ۱۰۵ سانتی‌متر / لاغر" />
            <Row k="مو / چشم" v="قهوه‌ای تیره ژولیده / قهوه‌ای تیره" />
            <Row k="لباس" v="تیشرت گشاد بنفش با لوگوی طلایی «allo» روی جیب، شلوار بنفش، پابرهنه" />
            <Row k="ساعت" v="ساعت بن‌تن فضایی با هسته نئون سبز #00FF7F، چسبیده به مچ چپ" />
            <Row k="شخصیت" v="مهربان، کنجکاو، بازیگوش، شجاع" />
            <Row k="حالات چهره" v="شاد، کنجکاو، جدی، عصبی (باحال)، می‌خنده" />
            <Row k="پالت رنگ" v="#873C68 • #b07aa0 • #e9c46a • #3a2518 • #e9b990 • #00FF7F" />
            <Row k="انیمیشن‌ها" v="Idle, Run, Jump, Crouch, Punch, Earth-Crack, Watch-Dial, Transform" />
          </Card>
          <Card title="اِکس غول‌پیکر (Titan Godzilla X)">
            <Row k="اندازه" v="بیش از ۱۰۰ متر — بزرگ‌تر از آسمان‌خراش‌ها" />
            <Row k="ظاهر" v="هیولای بیومکانیکال، پوست ابسیدین سیاه، تیغه‌های گودزیلایی پشت، رگه‌های گدازه‌ی سرخ، چشم‌های سرخ" />
            <Row k="نقطه‌ی ضعف" v="هسته‌ی سرخ روی سینه (۲ برابر آسیب)" />
            <Row k="فازهای نبرد" v="باران شهاب‌سنگ، لیزر چشم (→ بنشین)، زلزله‌ی کوبشی با پا (→ بپر)، احضار ربات" />
            <Row k="جان" v="۱۰۰۰ (مرحله ۲۰) — گولیات: ۴۵۰ (مرحله ۱۷)" />
            <Row k="پالت رنگ" v="#0e0e14 • #1c1c26 • #ff4500 • #ff2040" />
          </Card>
          <Card title="ایلان ایکس — بلیکوس و سرینا">
            <Row k="بلیکوس" v="مرد کیهانی — صدای عدالت سخت‌گیرانه، داوری و خشم منطقی (رنگ سرخ)" />
            <Row k="سرینا" v="زن کیهانی — صدای محبت، صلح و درک قلبی کودکان (رنگ صورتی)" />
            <Row k="تصمیم سه‌نفره" v="در مرحله ۱۰ با پاسخ به ۳ پرسش اخلاقی، ژن کیهانی آزاد می‌شود" />
            <Row k="قدرت" v="انفجار ستاره‌ای نافذ، کند شدن زمان دشمنان (۱۶ ثانیه)" />
          </Card>
          <Card title="کوین لوین">
            <Row k="قدرت" v="جذب خواص فیزیکی هر جسمی که لمس کند (آهن، فولاد، بتن، الماس، سنگ کیهانی)" />
            <Row k="نقش" v="همراه وفادار از مرحله ۵؛ با لمس پارسای تبدیل‌شده قدرتش را جذب می‌کند" />
          </Card>
        </div>

        {/* Reference images */}
        <h2 className="mt-10 text-xl font-black">تصاویر رفرنس</h2>
        <div className="mt-3 space-y-6">
          {IMAGES.map((im) => (
            <div key={im.src} className="overflow-hidden rounded-2xl border border-white/10 bg-white/5">
              <img src={im.src} alt={im.title} className="w-full" loading="lazy" />
              <div className="flex items-center justify-between p-4">
                <div>
                  <div className="font-bold">{im.title}</div>
                  <div className="text-xs text-slate-400">{im.desc}</div>
                </div>
                <a href={im.src} download className="rounded-lg bg-emerald-500 px-3 py-1.5 text-sm font-bold text-black">
                  دانلود
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
      <h3 className="mb-3 text-lg font-black text-emerald-300">{title}</h3>
      <div className="space-y-2 text-sm">{children}</div>
    </div>
  );
}
function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex gap-3 border-b border-white/5 pb-2">
      <span className="w-28 shrink-0 text-slate-400">{k}</span>
      <span className="text-slate-100">{v}</span>
    </div>
  );
}
