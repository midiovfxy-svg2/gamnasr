import { useEffect, useMemo, useRef, useState } from 'react';
import { App as CapApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import GameScreen from './components/GameScreen';
import SheetPage from './components/SheetPage';
import StoryPage from './components/StoryPage';
import InstallPage from './components/InstallPage';
import { CONTROLS, FORMS, FORM_ORDER, FormId, LEVELS } from './game/data';
import { LevelResult } from './game/engine';
import { loadProgress, Progress, saveProgress } from './game/progress';
import { startMenuNav } from './game/menuNav';

type Screen = 'menu' | 'levels' | 'game' | 'story' | 'sheet' | 'controls' | 'install';

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [progress, setProgress] = useState<Progress>(() => loadProgress());
  const [levelId, setLevelId] = useState(1);
  const [gameKey, setGameKey] = useState(0);
  const [padName, setPadName] = useState<string | null>(null);

  useEffect(() => saveProgress(progress), [progress]);

  useEffect(() => {
    if (screen === 'game') return;
    return startMenuNav();
  }, [screen]);

  // Android hardware back button
  const screenRef = useRef(screen);
  screenRef.current = screen;
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const sub = CapApp.addListener('backButton', () => {
      const sc = screenRef.current;
      if (sc === 'game') setScreen('levels');
      else if (sc !== 'menu') setScreen('menu');
      else CapApp.exitApp();
    });
    return () => {
      sub.then((h) => h.remove());
    };
  }, []);
  const isWeb = typeof location !== 'undefined' && location.protocol.startsWith('http') && !Capacitor.isNativePlatform();

  useEffect(() => {
    const on = (e: GamepadEvent) => setPadName(e.gamepad.id);
    const off = () => setPadName(null);
    window.addEventListener('gamepadconnected', on);
    window.addEventListener('gamepaddisconnected', off);
    return () => {
      window.removeEventListener('gamepadconnected', on);
      window.removeEventListener('gamepaddisconnected', off);
    };
  }, []);

  const unlockedForms = useMemo<FormId[]>(() => progress.unlocked, [progress.unlocked]);

  const startLevel = (id: number) => {
    setLevelId(id);
    setGameKey((k) => k + 1);
    setScreen('game');
  };

  const onComplete = (r: LevelResult) => {
    setProgress((p) => ({
      ...p,
      maxLevel: Math.max(p.maxLevel, Math.min(LEVELS.length, r.levelId + 1)),
      completed: p.completed.includes(r.levelId) ? p.completed : [...p.completed, r.levelId],
    }));
  };
  const onUnlock = (f: FormId) => setProgress((p) => (p.unlocked.includes(f) ? p : { ...p, unlocked: [...p.unlocked, f] }));
  const onFriend = (name: string) => setProgress((p) => (p.friends.includes(name) ? p : { ...p, friends: [...p.friends, name] }));

  if (screen === 'game') {
    return (
      <GameScreen
        key={gameKey}
        levelId={levelId}
        unlocked={unlockedForms}
        onComplete={onComplete}
        onUnlock={onUnlock}
        onFriend={onFriend}
        onExit={() => setScreen('levels')}
        onNext={() => (levelId < LEVELS.length ? startLevel(levelId + 1) : setScreen('menu'))}
        onRetry={() => startLevel(levelId)}
      />
    );
  }
  if (screen === 'story') return <StoryPage onBack={() => setScreen('menu')} />;
  if (screen === 'sheet') return <SheetPage onBack={() => setScreen('menu')} />;
  if (screen === 'install') return <InstallPage onBack={() => setScreen('menu')} />;

  if (screen === 'controls') {
    return (
      <Shell title="کنترل‌ها" onBack={() => setScreen('menu')}>
        <div className="overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-sm">
            <thead className="bg-white/10 text-emerald-300">
              <tr>
                <th className="p-3 text-right">عمل</th>
                <th className="p-3 text-right">کیبورد</th>
                <th className="p-3 text-right">دسته‌ی PC (Xbox / PS)</th>
              </tr>
            </thead>
            <tbody>
              {CONTROLS.map((c) => (
                <tr key={c.action} className="border-t border-white/5 odd:bg-white/[0.03]">
                  <td className="p-3 font-bold">{c.action}</td>
                  <td className="p-3 text-slate-300" dir="ltr" style={{ textAlign: 'right' }}>
                    {c.key}
                  </td>
                  <td className="p-3 text-slate-300">{c.pad}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-6 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-4 text-sm leading-7">
          <b>نکته‌ها:</b> دسته را قبل از شروع وصل کن و یک دکمه بزن تا مرورگر آن را بشناسد. وقتی ساعت باز است، زمان آهسته می‌شود تا راحت انتخاب کنی. برای جاخالی از لیزر اِکس <b>بنشین</b> و برای موج زمینی <b>بپر</b>.
          هسته‌ی قرمز روی سینه‌ی اِکس دو برابر آسیب می‌بیند — گلوله‌های کله‌آتشی را به سمتش بزن!
        </div>
        <div className="mt-3 text-xs text-slate-400">{padName ? `🎮 دسته‌ی متصل: ${padName}` : 'دسته‌ای متصل نیست (برای شناسایی یک دکمه فشار بده)'}</div>
      </Shell>
    );
  }

  if (screen === 'levels') {
    return (
      <Shell title="انتخاب مرحله" onBack={() => setScreen('menu')}>
        <div className="mb-4 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400">موجودات داخل ساعت:</span>
          {FORM_ORDER.map((f) => (
            <span key={f} className={`rounded-full px-3 py-1 font-bold ${progress.unlocked.includes(f) ? (f === 'alienx' ? 'text-white' : 'text-black') : 'bg-white/10 text-slate-500'}`} style={progress.unlocked.includes(f) ? { background: f === 'alienx' ? '#4c1d95' : FORMS[f].color } : {}}>
              {FORMS[f].name}
            </span>
          ))}
          <span className="mr-auto text-slate-400">دوستان: {progress.friends.length ? progress.friends.join('، ') : '—'}</span>
        </div>
        {[
          { ch: 1, title: 'فصل ۱ — شهر نورآباد', range: [1, 20], color: 'text-emerald-300' },
          { ch: 2, title: 'فصل ۲ — ساحل و دریا 🌊', range: [21, 35], color: 'text-sky-300' },
          { ch: 3, title: 'فصل ۳ — جنگل باستانی 🌲', range: [36, 50], color: 'text-lime-300' },
        ].map((chap) => (
          <div key={chap.ch} className="mb-8">
            <h2 className={`mb-3 text-xl font-black ${chap.color}`}>{chap.title}</h2>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {LEVELS.filter((l) => l.id >= chap.range[0] && l.id <= chap.range[1]).map((l) => {
                const locked = l.id > progress.maxLevel;
                const done = progress.completed.includes(l.id);
                const icon = locked ? '🔒' : done ? '⭐' : l.boss ? '👹' : l.theme === 'ocean' ? '🐠' : l.water || l.seaZones ? '🏊' : l.defend ? '🛡️' : '▶';
                return (
                  <button
                    key={l.id}
                    disabled={locked}
                    onClick={() => startLevel(l.id)}
                    className={`group relative overflow-hidden rounded-2xl border p-4 text-right transition ${locked ? 'cursor-not-allowed border-white/5 bg-white/[0.03] text-slate-600' : 'border-white/10 bg-gradient-to-br from-slate-800 to-slate-900 hover:border-emerald-400/60 hover:shadow-lg hover:shadow-emerald-900/40'}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-2xl font-black ${locked ? '' : chap.color}`}>{l.id}</span>
                      <span className="text-lg">{icon}</span>
                    </div>
                    <div className="mt-2 font-bold">{l.name}</div>
                    <div className="text-[11px] text-slate-400">{l.subtitle}</div>
                    {l.unlock && !locked && (
                      <div className="mt-2 text-[10px]" style={{ color: FORMS[l.unlock].glow }}>
                        ✦ {FORMS[l.unlock].name}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
        <button
          onClick={() => {
            if (confirm('پیشرفت بازی پاک شود؟')) setProgress({ maxLevel: 1, unlocked: [], friends: [], completed: [] });
          }}
          className="mt-6 text-xs text-slate-500 hover:text-red-400"
        >
          پاک کردن پیشرفت
        </button>
      </Shell>
    );
  }

  // MENU
  return (
    <div dir="rtl" className="relative min-h-screen overflow-hidden bg-[#06091a] text-white">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 right-1/4 h-[520px] w-[520px] rounded-full bg-emerald-500/20 blur-3xl" />
        <div className="absolute bottom-0 left-0 h-[420px] w-[420px] rounded-full bg-fuchsia-600/20 blur-3xl" />
        <img src="ref/ex-titan.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#06091a] via-[#06091a]/70 to-transparent" />
      </div>
      <div className="relative mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center px-6 py-12 [@media(max-height:520px)]:py-3">
        <div className="mb-3 [@media(max-height:520px)]:mb-1 rounded-full border border-emerald-400/40 bg-emerald-400/10 px-4 py-1 text-xs tracking-widest text-emerald-300">بازی پلتفرمر دوبعدی — ۵۰ مرحله در شهر، دریا و جنگل</div>
        <h1 className="text-center text-5xl font-black leading-tight md:text-7xl [@media(max-height:520px)]:text-4xl!">
          <span className="bg-gradient-to-l from-emerald-300 via-lime-300 to-emerald-400 bg-clip-text text-transparent">محمد پارسا</span>
          <br />
          <span className="text-3xl text-white/90 md:text-5xl [@media(max-height:520px)]:text-2xl!">و ساعت بن‌تن</span>
        </h1>
        <p className="mt-5 max-w-2xl text-center leading-8 text-slate-300 [@media(max-height:520px)]:hidden">
          شهاب‌سنگی در پارک افتاد و ساعت بن‌تن روی مچ پارسای ۴ ساله قفل شد. بلیکوس و سرینا از درون ساعت با او حرف می‌زنند و «اِکس» غول‌پیکرِ گودزیلایی برای ربودن ساعت می‌آید. تبدیل شو، زمین را قاچ کن، با کوین، گوئن، بابابزرگ مکس، سارا، علی و برفی دوست شو، در دریا شنا کن و زمین را نجات بده!
        </p>

        <div className="mt-10 grid w-full max-w-3xl grid-cols-2 gap-3 md:grid-cols-3 [@media(max-height:520px)]:mt-3 [@media(max-height:520px)]:gap-2">
          <MenuBtn primary onClick={() => startLevel(progress.maxLevel)} title={progress.maxLevel > 1 ? `ادامه — مرحله ${progress.maxLevel}` : 'شروع بازی'} sub="▶ Space / A" />
          <MenuBtn onClick={() => setScreen('levels')} title="انتخاب مرحله" sub={`${progress.completed.length}/${LEVELS.length} تمام شده`} />
          <MenuBtn onClick={() => setScreen('story')} title="داستان و اسکریپت" sub="برای تولید رفرنس" />
          <MenuBtn onClick={() => setScreen('sheet')} title="کاراکتر شیت" sub="۳۰ نما + دشمن + محیط" />
          <MenuBtn onClick={() => setScreen('controls')} title="کنترل‌ها" sub={padName ? '🎮 دسته متصل است' : 'کیبورد + دسته'} />
          <MenuBtn onClick={() => startLevel(1)} title="شروع از اول" sub="مرحله ۱: سقوط شهاب‌سنگ" />
          {isWeb && <MenuBtn onClick={() => setScreen('install')} title="نصب / دانلود آفلاین" sub="APK اندروید • EXE ویندوز" />}
        </div>

        <div className="mt-10 grid w-full max-w-3xl grid-cols-3 gap-3 text-center text-xs md:grid-cols-6 [@media(max-height:520px)]:hidden">
          {FORM_ORDER.map((f) => (
            <div key={f} className="rounded-xl border border-white/10 bg-white/5 p-3">
              <div className="font-black" style={{ color: FORMS[f].glow }}>
                {FORMS[f].name}
              </div>
              <div className="mt-1 text-slate-400">{progress.unlocked.includes(f) ? 'داخل ساعت ✔' : 'قفل 🔒'}</div>
            </div>
          ))}
        </div>
        <div className="mt-8 text-[11px] text-slate-500 [@media(max-height:520px)]:hidden">اندروید: دکمه‌های لمسی • A/D حرکت • Space پرش • S نشستن • J حمله • K قاچ زمین • Q ساعت • E تبدیل • ↑ نجات دوست</div>
      </div>
    </div>
  );
}

function MenuBtn({ title, sub, onClick, primary }: { title: string; sub: string; onClick: () => void; primary?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-2xl border p-4 text-right transition hover:-translate-y-0.5 ${primary ? 'border-emerald-300 bg-gradient-to-br from-emerald-400 to-lime-400 text-black shadow-lg shadow-emerald-500/30' : 'border-white/10 bg-white/5 hover:bg-white/10'}`}
    >
      <div className="text-lg font-black">{title}</div>
      <div className={`text-xs ${primary ? 'text-black/70' : 'text-slate-400'}`}>{sub}</div>
    </button>
  );
}

function Shell({ title, onBack, children }: { title: string; onBack: () => void; children: React.ReactNode }) {
  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black p-6 text-white">
      <div className="mx-auto max-w-5xl">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-3xl font-black text-emerald-300">{title}</h1>
          <button onClick={onBack} className="rounded-xl bg-white/10 px-4 py-2 hover:bg-white/20">
            → بازگشت
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
