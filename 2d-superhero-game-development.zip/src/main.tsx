import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Capacitor } from "@capacitor/core";
import "@fontsource/vazirmatn/arabic-400.css";
import "@fontsource/vazirmatn/arabic-700.css";
import "@fontsource/vazirmatn/arabic-900.css";
import "@fontsource/vazirmatn/latin-400.css";
import "@fontsource/vazirmatn/latin-700.css";
import "@fontsource/vazirmatn/latin-900.css";
import "./index.css";
import "./extra.css";
import App from "./App";

// make sure the bundled (offline) font is ready before the canvas draws text
["400 16px Vazirmatn", "700 16px Vazirmatn", "900 16px Vazirmatn"].forEach((f) => document.fonts?.load(f, "محمد پارسا Parsa").catch(() => {}));

// Offline support when opened as a normal website (installable PWA)
if ("serviceWorker" in navigator && location.protocol.startsWith("http") && !Capacitor.isNativePlatform() && location.hostname !== "localhost") {
  window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
