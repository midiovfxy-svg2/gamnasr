import {
  clamp01,
  drawCosmicParticles,
  drawGlowingText,
  drawRoundedRect,
  drawSacredMandala,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  formatTimeFa,
  lerpColor,
  withAlpha,
} from './drawPrimitives';
import {
  drawSceneBodyOceans,
  drawSceneCityFilter,
  drawSceneCosmosBismillah,
  drawSceneDawnTasdiq,
} from './scenesPart1';
import {
  drawSceneCinemaGhayb,
  drawSceneFasanuyassiruhu,
  drawSceneMindGym,
  drawSceneRootsSigns,
} from './scenesPart2';
import {
  DURATION_4MIN,
  DURATION_FULL,
  getCaptionAtTime,
  getChapterAtTime,
  mapFullTimeToVisualTime,
  MOTION_CHAPTERS,
  type MotionChapter,
} from './timelineData';

export interface RenderOptions {
  mode: '4min' | 'full';
  showSubtitles: boolean;
  showHud?: boolean;
}

const VIRTUAL_W = 1280;
const VIRTUAL_H = 720;

function renderSceneByKey(
  ctx: CanvasRenderingContext2D,
  chapter: MotionChapter,
  visualT: number,
  energy: number,
) {
  const localT = Math.max(0, visualT - chapter.start4m);
  switch (chapter.sceneKey) {
    case 'dawn_tasdiq':
      drawSceneDawnTasdiq(ctx, localT, visualT, energy);
      break;
    case 'city_filter':
      drawSceneCityFilter(ctx, localT, visualT, energy);
      break;
    case 'cosmos_bismillah':
      drawSceneCosmosBismillah(ctx, localT, visualT, energy);
      break;
    case 'body_oceans':
      drawSceneBodyOceans(ctx, localT, visualT, energy);
      break;
    case 'mind_gym':
      drawSceneMindGym(ctx, localT, visualT, energy);
      break;
    case 'cinema_ghayb':
      drawSceneCinemaGhayb(ctx, localT, visualT, energy);
      break;
    case 'fasanuyassiruhu':
      drawSceneFasanuyassiruhu(ctx, localT, visualT, energy);
      break;
    case 'roots_signs':
      drawSceneRootsSigns(ctx, localT, visualT, energy);
      break;
  }
}

/** Word-wrap RTL Persian text cleanly into <= 2 lines for the subtitle capsule */
function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const word of words) {
    const test = cur ? `${cur} ${word}` : word;
    if (ctx.measureText(test).width <= maxWidth) {
      cur = test;
    } else {
      if (cur) lines.push(cur);
      cur = word;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 2);
}

export function drawMotionFrame(
  ctx: CanvasRenderingContext2D,
  timeSec: number,
  pixelWidth: number,
  pixelHeight: number,
  audioEnergy: number,
  options: RenderOptions,
) {
  const mode = options.mode;
  const totalDur = mode === '4min' ? DURATION_4MIN : DURATION_FULL;
  const visualT = mode === '4min' ? clamp01(timeSec / totalDur) * DURATION_4MIN : mapFullTimeToVisualTime(timeSec);

  const chapter = getChapterAtTime(visualT, '4min');
  const chIdx = MOTION_CHAPTERS.findIndex((c) => c.id === chapter.id);
  const nextChapter = MOTION_CHAPTERS[Math.min(MOTION_CHAPTERS.length - 1, chIdx + 1)];

  // Smoothly blend background colors in the last 1.5s of each chapter
  const timeToEnd = chapter.end4m - visualT;
  const blend = timeToEnd < 1.5 && nextChapter.id !== chapter.id ? easeInOutCubic(1 - timeToEnd / 1.5) : 0;
  const bgTop = lerpColor(chapter.bgTop, nextChapter.bgTop, blend);
  const bgBottom = lerpColor(chapter.bgBottom, nextChapter.bgBottom, blend);

  ctx.save();
  // Scale virtual 1280x720 coordinate system onto target pixel canvas
  const scaleX = pixelWidth / VIRTUAL_W;
  const scaleY = pixelHeight / VIRTUAL_H;
  ctx.scale(scaleX, scaleY);

  // Set RTL direction for proper Canvas2D Persian & Arabic shaping
  if ('direction' in ctx) {
    ctx.direction = 'rtl';
  }

  // 1. Deep Atmospheric Gradient Backdrop
  const bgGrad = ctx.createLinearGradient(0, 0, 0, VIRTUAL_H);
  bgGrad.addColorStop(0, bgTop);
  bgGrad.addColorStop(1, bgBottom);
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);

  // Radial vignette + soft center light
  const radGlow = ctx.createRadialGradient(640, 345, 40, 640, 345, 760);
  radGlow.addColorStop(0, withAlpha(chapter.accent, 0.14 + audioEnergy * 0.08));
  radGlow.addColorStop(1, 'rgba(3, 6, 18, 0.65)');
  ctx.fillStyle = radGlow;
  ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);

  // 2. Slowly rotating sacred mandala & drifting dust particles
  drawSacredMandala(ctx, 640, 355, 310, visualT * 0.045, chapter.accent, 0.075);
  drawSacredMandala(ctx, 640, 355, 220, -visualT * 0.06, chapter.accentSecondary, 0.065);
  drawCosmicParticles(ctx, VIRTUAL_W, VIRTUAL_H, visualT, chapter.accent, audioEnergy);

  // 3. Active Element-Oriented Motion Scene (with gentle crossfade near boundary)
  const localT = visualT - chapter.start4m;
  const fadeIn = clamp01(localT / 0.6);
  const fadeOut = timeToEnd < 0.5 && nextChapter.id !== chapter.id ? clamp01(timeToEnd / 0.5) : 1;

  ctx.save();
  ctx.globalAlpha = Math.min(fadeIn, fadeOut);
  renderSceneByKey(ctx, chapter, visualT, audioEnergy);
  ctx.restore();

  // 4. Opening Intro Flash Card (0.0 -> 1.8s)
  if (visualT < 1.8) {
    const alpha = visualT < 1.2 ? 1 : 1 - clamp01((visualT - 1.2) / 0.6);
    const pop = easeOutBack(clamp01(visualT / 0.65));
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = 'rgba(6, 9, 20, 0.72)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
    ctx.translate(640, 340);
    ctx.scale(pop, pop);
    drawGlowingText(
      ctx,
      'صَدَّقَ بِالْحُسْنَىٰ',
      0,
      -42,
      '700 64px "Amiri", serif',
      '#fde68a',
      'rgba(251, 191, 36, 0.65)',
      24,
    );
    drawGlowingText(
      ctx,
      'تصدیقِ نیکی‌ها و به تصویر کشیدنِ غیب • استاد حاج نصرالله باستین',
      0,
      36,
      '700 24px "Vazirmatn", sans-serif',
      '#e2e8f0',
      'rgba(56, 189, 248, 0.35)',
      12,
    );
    ctx.restore();
  }

  // 5. Closing End Crest (233.5 -> 240.0s in visualT)
  if (visualT > 233.5) {
    const cp = easeOutCubic(clamp01((visualT - 233.5) / 2.0));
    ctx.save();
    ctx.globalAlpha = cp * 0.92;
    ctx.fillStyle = 'rgba(5, 10, 22, 0.78)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
    drawSacredMandala(ctx, 640, 330, 210, visualT * 0.12, '#fbbf24', 0.25);
    drawGlowingText(
      ctx,
      'وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
      640,
      295,
      '700 44px "Amiri", serif',
      '#fde68a',
      'rgba(251, 191, 36, 0.6)',
      22,
    );
    drawGlowingText(
      ctx,
      'هر روز با چشمِ بیننده فراوانی و شکرگزاری آغاز کن',
      640,
      370,
      '700 26px "Vazirmatn", sans-serif',
      '#4ade80',
      'rgba(74, 222, 128, 0.4)',
      14,
    );
    drawGlowingText(
      ctx,
      'برگرفته از بیانات استاد حاج نصرالله باستین',
      640,
      428,
      '500 18px "Vazirmatn", sans-serif',
      '#cbd5e1',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  // 6. Top Chapter Header HUD & Progress Bar
  if (options.showHud !== false) {
    // Top subtle gradient bar
    const topBar = ctx.createLinearGradient(0, 0, 0, 78);
    topBar.addColorStop(0, 'rgba(4, 7, 18, 0.78)');
    topBar.addColorStop(1, 'rgba(4, 7, 18, 0)');
    ctx.fillStyle = topBar;
    ctx.fillRect(0, 0, VIRTUAL_W, 78);

    // Chapter badge pill (Top Right in RTL)
    ctx.save();
    ctx.font = '700 16px "Vazirmatn", sans-serif';
    const badgeLabel = `${chapter.badge}  |  ${chapter.title}`;
    const bw = Math.min(680, ctx.measureText(badgeLabel).width + 46);
    drawRoundedRect(ctx, VIRTUAL_W - bw - 34, 18, bw, 40, 20);
    ctx.fillStyle = 'rgba(11, 17, 36, 0.78)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(chapter.accent, 0.62);
    ctx.lineWidth = 1.4;
    ctx.stroke();

    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = chapter.accent;
    ctx.fillText(badgeLabel, VIRTUAL_W - 56, 39);
    ctx.restore();

    // Time indicator pill (Top Left in RTL)
    ctx.save();
    drawRoundedRect(ctx, 34, 18, 160, 40, 20);
    ctx.fillStyle = 'rgba(11, 17, 36, 0.78)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.font = '700 15px "Vazirmatn", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText(`${formatTimeFa(timeSec)} / ${formatTimeFa(totalDur)}`, 114, 39);
    ctx.restore();

    // Slim timeline progress line at very top
    const pct = clamp01(timeSec / totalDur);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.fillRect(0, 0, VIRTUAL_W, 4);
    const barG = ctx.createLinearGradient(VIRTUAL_W, 0, 0, 0);
    barG.addColorStop(0, chapter.accent);
    barG.addColorStop(1, chapter.accentSecondary);
    ctx.fillStyle = barG;
    ctx.fillRect(VIRTUAL_W * (1 - pct), 0, VIRTUAL_W * pct, 4);
  }

  // 7. Bottom Frosted Persian Subtitle Capsule
  if (options.showSubtitles) {
    const cue = getCaptionAtTime(timeSec, mode);
    if (cue) {
      ctx.save();
      ctx.font = '600 22px "Vazirmatn", sans-serif';
      const lines = wrapText(ctx, cue.text, 940);
      const boxH = lines.length === 2 ? 78 : 52;
      const boxY = VIRTUAL_H - boxH - 22;
      const boxW = Math.min(1040, Math.max(...lines.map((l) => ctx.measureText(l).width)) + 74);
      const boxX = (VIRTUAL_W - boxW) / 2;

      drawRoundedRect(ctx, boxX, boxY, boxW, boxH, 18);
      ctx.fillStyle = 'rgba(6, 10, 24, 0.84)';
      ctx.fill();
      ctx.strokeStyle = withAlpha(chapter.accent, 0.55);
      ctx.lineWidth = 1.4;
      ctx.stroke();

      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = cue.highlight ? '#fde68a' : '#f8fafc';
      if (lines.length === 1) {
        ctx.fillText(lines[0], 640, boxY + boxH / 2 + 1);
      } else {
        ctx.fillText(lines[0], 640, boxY + 23);
        ctx.fillText(lines[1], 640, boxY + 54);
      }
      ctx.restore();
    }
  }

  ctx.restore();
}
