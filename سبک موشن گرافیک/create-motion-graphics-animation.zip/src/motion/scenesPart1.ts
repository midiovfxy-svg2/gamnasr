import {
  clamp01,
  drawAudioAuraRing,
  drawGlowingText,
  drawKineticPill,
  drawRoundedRect,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  lerp,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';

/** SCENE 1 (0 - 24.8s): صدق بالحسنی، طلوع صبح، تصدیق نیکی‌ها و شکرگزاری در طول روز */
export function drawSceneDawnTasdiq(
  ctx: CanvasRenderingContext2D,
  t: number, // local time in scene (0..24.8)
  globalT: number,
  energy: number,
) {
  const cx = 640;
  const cy = 355;

  // Horizon arc + rising golden sun
  const sunRise = easeOutCubic(clamp01((t - 0.8) / 6.0));
  const sunY = lerp(520, 290, sunRise);
  const sunR = 78 + energy * 8;

  // Warm dawn glow behind hills
  const dawnGrad = ctx.createRadialGradient(cx, sunY, 10, cx, sunY, 380);
  dawnGrad.addColorStop(0, 'rgba(251, 191, 36, 0.34)');
  dawnGrad.addColorStop(0.5, 'rgba(251, 146, 60, 0.14)');
  dawnGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = dawnGrad;
  ctx.beginPath();
  ctx.arc(cx, sunY, 380, 0, Math.PI * 2);
  ctx.fill();

  // Rotating sunbeams
  ctx.save();
  ctx.translate(cx, sunY);
  ctx.rotate(globalT * 0.18);
  for (let i = 0; i < 16; i++) {
    const a = (i * Math.PI * 2) / 16;
    ctx.save();
    ctx.rotate(a);
    const beamLen = 140 + Math.sin(globalT * 2 + i) * 18 + energy * 30;
    const g = ctx.createLinearGradient(sunR, 0, sunR + beamLen, 0);
    g.addColorStop(0, 'rgba(253, 224, 71, 0.48)');
    g.addColorStop(1, 'rgba(253, 224, 71, 0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(sunR * 0.85, -7);
    ctx.lineTo(sunR + beamLen, 0);
    ctx.lineTo(sunR * 0.85, 7);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  // Golden sun disc + audio aura
  drawAudioAuraRing(ctx, cx, sunY, sunR + 18, globalT, energy, '#fbbf24');
  const orbGrad = ctx.createRadialGradient(cx - 18, sunY - 20, 8, cx, sunY, sunR);
  orbGrad.addColorStop(0, '#fef9c3');
  orbGrad.addColorStop(0.55, '#fbbf24');
  orbGrad.addColorStop(1, '#ea580c');
  ctx.fillStyle = orbGrad;
  ctx.beginPath();
  ctx.arc(cx, sunY, sunR, 0, Math.PI * 2);
  ctx.fill();

  // Quranic verse inside sun halo at start
  const titlePop = easeOutBack(clamp01(t / 1.4));
  ctx.save();
  ctx.globalAlpha = clamp01(t / 1.0);
  drawGlowingText(
    ctx,
    'وَصَدَّقَ بِالْحُسْنَىٰ',
    cx,
    sunY - 6,
    `700 ${Math.round(32 * titlePop)}px "Amiri", serif`,
    '#1e1b4b',
    'rgba(255,255,255,0.6)',
    6,
  );
  ctx.restore();

  // Stylized rolling dawn hills at lower third (safe above subtitle capsule)
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(120, 565);
  ctx.quadraticCurveTo(360, 460, 640, 520);
  ctx.quadraticCurveTo(920, 575, 1160, 480);
  ctx.lineTo(1160, 575);
  ctx.lineTo(120, 575);
  ctx.closePath();
  const hillGrad = ctx.createLinearGradient(0, 470, 0, 575);
  hillGrad.addColorStop(0, 'rgba(30, 41, 82, 0.92)');
  hillGrad.addColorStop(1, 'rgba(13, 18, 42, 0.96)');
  ctx.fillStyle = hillGrad;
  ctx.fill();
  ctx.strokeStyle = 'rgba(251, 191, 36, 0.35)';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // Orbiting "Tasdiq" elements popping in synced to speech:
  // 2s: نیکی‌ها, 6.5s: خوبی‌ها, 9s: فراوانی‌ها, 11.5s: داشته‌ها, 14.5s: شکر اول صبح, 19s: یاد خدا در طول روز
  const pills = [
    { x: 290, y: 235, label: 'تصدیقِ نیکی‌ها', icon: '✓', at: 2.0, color: '#fbbf24' },
    { x: 990, y: 235, label: 'دیدنِ خوبی‌ها', icon: '✦', at: 6.2, color: '#fde047' },
    { x: 245, y: 365, label: 'فراوانی‌های هستی', icon: '◈', at: 8.5, color: '#fb923c' },
    { x: 1035, y: 365, label: 'شکرِ داشته‌ها', icon: '♥', at: 11.2, color: '#34d399' },
    { x: 350, y: 470, label: 'شکرِ اولِ صبح', icon: '☀', at: 14.8, color: '#fbbf24' },
    { x: 930, y: 470, label: 'یاد خدا در طولِ روز', icon: '☼', at: 18.8, color: '#38bdf8' },
  ];

  // Connecting light filaments from sun to active pills
  for (const p of pills) {
    const prog = clamp01((t - p.at) / 0.8);
    if (prog > 0) {
      const floatY = Math.sin(globalT * 2 + p.x * 0.01) * 5;
      ctx.save();
      ctx.strokeStyle = withAlpha(p.color, 0.35 * prog);
      ctx.lineWidth = 1.6;
      ctx.setLineDash([5, 6]);
      ctx.beginPath();
      ctx.moveTo(cx, sunY);
      ctx.lineTo(p.x, p.y + floatY);
      ctx.stroke();
      ctx.restore();
      drawKineticPill(ctx, p.x, p.y + floatY, p.label, prog, p.color, p.icon);
    }
  }

  // Daylight arc sweep from 14s..24s showing "از اول صبح تا طول روز"
  if (t > 14) {
    const arcP = easeInOutCubic((t - 14) / 9);
    ctx.save();
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.32)';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(cx, 480, 380, Math.PI * 1.12, Math.PI * (1.12 + 0.76 * arcP));
    ctx.stroke();
    const ang = Math.PI * (1.12 + 0.76 * arcP);
    const dotX = cx + Math.cos(ang) * 380;
    const dotY = 480 + Math.sin(ang) * 380;
    ctx.fillStyle = '#fde047';
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.arc(dotX, dotY, 7 + energy * 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  void cy;
}

/** SCENE 2 (24.8 - 55.6s): فراوانی شهر، ساختمان‌ها، شغل، فروشگاه‌ها و فیلتر ورودی ذهن */
export function drawSceneCityFilter(
  ctx: CanvasRenderingContext2D,
  t: number, // local time (0..30.8)
  globalT: number,
  energy: number,
) {
  // Phase A (0..17.5s): Isometric / Skyline City Growth (towers, crane, wealth flow)
  // Phase B (17.5..30.8s): Camera shifts smoothly to Mind Input Prism (تصدیق vs تکذیب)
  const shiftB = easeInOutCubic(clamp01((t - 16.5) / 2.2));

  // --- PHASE A: Growing City of Abundance ---
  if (shiftB < 0.99) {
    ctx.save();
    ctx.globalAlpha = 1 - shiftB;
    const slide = shiftB * -90;
    ctx.translate(slide, 0);

    // Horizon highway ribbon
    const roadY = 515;
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(140, roadY);
    ctx.lineTo(1140, roadY);
    ctx.stroke();

    // Flowing golden currency / light pulses along the city street
    for (let i = 0; i < 12; i++) {
      const fx = 160 + (((i * 95 + globalT * 110) % 960));
      ctx.fillStyle = i % 2 === 0 ? '#fbbf24' : '#38bdf8';
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.arc(fx, roadY, 4 + energy * 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.shadowBlur = 0;

    // 7 animated buildings rising floor-by-floor
    const buildings = [
      { x: 230, w: 72, maxH: 170, delay: 0.2, hue: '#0ea5e9', label: 'فروشگاه‌ها' },
      { x: 335, w: 86, maxH: 245, delay: 0.6, hue: '#38bdf8', label: 'مسکن' },
      { x: 455, w: 96, maxH: 300, delay: 1.0, hue: '#fbbf24', label: 'برج‌های جدید' },
      { x: 590, w: 108, maxH: 335, delay: 1.4, hue: '#2dd4bf', label: 'اشتغال' },
      { x: 735, w: 88, maxH: 265, delay: 1.8, hue: '#38bdf8', label: 'کارگاه‌ها' },
      { x: 855, w: 82, maxH: 215, delay: 2.2, hue: '#fbbf24', label: 'بازار' },
      { x: 965, w: 74, maxH: 165, delay: 2.6, hue: '#818cf8', label: 'مغازه‌ها' },
    ];

    buildings.forEach((b, idx) => {
      const grow = easeOutCubic(clamp01((t - b.delay) / 2.2));
      const bh = b.maxH * grow;
      const bx = b.x - b.w / 2;
      const by = roadY - bh;

      const grad = ctx.createLinearGradient(bx, by, bx, roadY);
      grad.addColorStop(0, withAlpha(b.hue, 0.38));
      grad.addColorStop(1, 'rgba(15, 23, 42, 0.92)');
      ctx.fillStyle = grad;
      drawRoundedRect(ctx, bx, by, b.w, bh, 8);
      ctx.fill();
      ctx.strokeStyle = withAlpha(b.hue, 0.85);
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Lit windows grid
      const rows = Math.floor(bh / 26);
      const cols = 3;
      const cellW = (b.w - 22) / cols;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const lit = ((r * 3 + c + idx) % 4 !== 0) || Math.sin(globalT * 2 + r + idx) > 0;
          ctx.fillStyle = lit ? withAlpha('#fde047', 0.72 + energy * 0.25) : 'rgba(148,163,184,0.18)';
          ctx.fillRect(bx + 10 + c * (cellW + 2), by + 14 + r * 24, cellW - 3, 12);
        }
      }
    });

    // Animated construction crane swinging gently over towers
    const craneProg = easeOutCubic(clamp01((t - 1.5) / 2.0));
    if (craneProg > 0.05) {
      ctx.save();
      ctx.globalAlpha *= craneProg;
      const cxCrane = 510;
      const topY = 140;
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(cxCrane, roadY);
      ctx.lineTo(cxCrane, topY);
      ctx.lineTo(cxCrane + 185, topY + 12);
      ctx.moveTo(cxCrane, topY);
      ctx.lineTo(cxCrane - 75, topY + 10);
      ctx.stroke();
      // Hanging hook oscillating
      const hookX = cxCrane + 130 + Math.sin(globalT * 1.4) * 28;
      const hookY = topY + 60 + Math.cos(globalT * 1.4) * 8;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(hookX, topY + 10);
      ctx.lineTo(hookX, hookY);
      ctx.stroke();
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(hookX - 12, hookY, 24, 16);
      ctx.restore();
    }

    // Abundance kinetic badges
    drawKineticPill(ctx, 250, 175, 'ساخت‌وسازِ هرروزه', clamp01((t - 2.2) / 0.8), '#38bdf8', '🏗');
    drawKineticPill(ctx, 640, 130, 'ثروت و پولِ در جریان', clamp01((t - 5.5) / 0.8), '#fbbf24', '✦');
    drawKineticPill(ctx, 1020, 175, 'شغل و روزیِ حلال', clamp01((t - 9.0) / 0.8), '#34d399', '✓');
    ctx.restore();
  }

  // --- PHASE B: Mind Input Gatekeeper (ورودی‌های ذهن: تصدیق vs تکذیب) ---
  if (shiftB > 0.01) {
    ctx.save();
    ctx.globalAlpha = shiftB;
    const cx = 640;
    const cy = 345;

    // Central Mind Prism / Diamond Shield
    drawAudioAuraRing(ctx, cx, cy, 110, globalT, energy, '#38bdf8');
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(Math.sin(globalT * 0.7) * 0.04);
    ctx.beginPath();
    ctx.moveTo(0, -115);
    ctx.lineTo(115, 0);
    ctx.lineTo(0, 115);
    ctx.lineTo(-115, 0);
    ctx.closePath();
    const prismG = ctx.createLinearGradient(-115, -115, 115, 115);
    prismG.addColorStop(0, 'rgba(56, 189, 248, 0.28)');
    prismG.addColorStop(1, 'rgba(251, 191, 36, 0.28)');
    ctx.fillStyle = prismG;
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2.6;
    ctx.stroke();
    ctx.restore();

    drawGlowingText(
      ctx,
      'ورودیِ ذهن',
      cx,
      cy - 10,
      '800 30px "Vazirmatn", sans-serif',
      '#f8fafc',
      '#38bdf8',
      16,
    );
    drawGlowingText(
      ctx,
      'مراقبِ صدّق بالحُسنی',
      cx,
      cy + 26,
      '600 18px "Vazirmatn", sans-serif',
      '#fbbf24',
      '#fbbf24',
      10,
    );

    // Left stream: Denied negativity bouncing off (تکذیب ✕)
    const lt = Math.max(0, t - 17.5);
    for (let i = 0; i < 4; i++) {
      const p = ((lt * 0.45 + i * 0.25) % 1);
      const ox = lerp(180, 495, p < 0.6 ? p / 0.6 : 1 - (p - 0.6) * 0.7);
      const oy = 345 + Math.sin(i * 2 + globalT * 2) * 35 + (p > 0.6 ? (p - 0.6) * 180 : 0);
      ctx.fillStyle = 'rgba(248, 113, 113, 0.75)';
      ctx.beginPath();
      ctx.arc(ox, oy, 7, 0, Math.PI * 2);
      ctx.fill();
    }
    drawKineticPill(ctx, 290, 230, 'تکذیبِ حُسنی ✕', clamp01((t - 22.5) / 0.8), '#f87171');

    // Right stream: Golden abundance rays accepted & amplified (تصدیق ✓)
    for (let i = 0; i < 6; i++) {
      const p = ((lt * 0.55 + i * 0.16) % 1);
      const ox = lerp(755, 1110, p);
      const oy = 345 + (i - 2.5) * 26 * p;
      ctx.fillStyle = '#fbbf24';
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(ox, oy, 6 + energy * 3, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.shadowBlur = 0;
    drawKineticPill(ctx, 990, 230, 'تصدیقِ حُسنی ✓', clamp01((t - 20.5) / 0.8), '#4ade80');
    ctx.restore();
  }
}

/** SCENE 3 (55.6 - 79.4s): خورشید و ماه و ستاره و دریا و کوه؛ بسم‌الله و الحمدلله */
export function drawSceneCosmosBismillah(
  ctx: CanvasRenderingContext2D,
  t: number, // local time (0..23.8)
  globalT: number,
  energy: number,
) {
  const cx = 640;
  // Phase 1 (0..13.5s): Cosmic Elements Diorama (Sun, Moon, Stars, Mountains, Gems, Sea, Plains)
  // Phase 2 (13.5..23.8s): Bismillah & Alhamdulillah glowing medallions descend smoothly
  const medallionPhase = easeInOutCubic(clamp01((t - 13.0) / 1.8));

  // Layered Earth Backdrop: Mountains -> Plains -> Ocean Waves
  ctx.save();
  ctx.globalAlpha = 1 - medallionPhase * 0.35;

  // Mountains (کوه‌ها)
  const mtnGrow = easeOutCubic(clamp01((t - 2.0) / 1.8));
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(110, 495);
  ctx.lineTo(295, 495 - 150 * mtnGrow);
  ctx.lineTo(445, 495 - 55 * mtnGrow);
  ctx.lineTo(620, 495 - 185 * mtnGrow);
  ctx.lineTo(800, 495 - 65 * mtnGrow);
  ctx.lineTo(975, 495 - 145 * mtnGrow);
  ctx.lineTo(1170, 495);
  ctx.closePath();
  const mtnGrad = ctx.createLinearGradient(0, 310, 0, 495);
  mtnGrad.addColorStop(0, '#1e3a5f');
  mtnGrad.addColorStop(1, '#0c192c');
  ctx.fillStyle = mtnGrad;
  ctx.fill();
  ctx.strokeStyle = 'rgba(52, 211, 153, 0.55)';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // Sparkling mine crystals (معادن) inside mountain peak
  if (t > 4.5) {
    const gemP = clamp01((t - 4.5) / 1.0);
    const gems = [
      [620, 415],
      [602, 432],
      [638, 434],
    ];
    for (const [gx, gy] of gems) {
      ctx.save();
      ctx.translate(gx, gy);
      ctx.scale(gemP, gemP);
      ctx.fillStyle = '#34d399';
      ctx.shadowColor = '#34d399';
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.moveTo(0, -12);
      ctx.lineTo(9, 0);
      ctx.lineTo(0, 12);
      ctx.lineTo(-9, 0);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  // Rolling Sea Waves (دریاها)
  for (let wv = 0; wv < 3; wv++) {
    ctx.beginPath();
    const baseY = 500 + wv * 20;
    ctx.moveTo(110, 575);
    for (let x = 110; x <= 1170; x += 24) {
      const y = baseY + Math.sin(x * 0.015 + globalT * (2.2 + wv * 0.5) + wv) * (8 + energy * 5);
      ctx.lineTo(x, y);
    }
    ctx.lineTo(1170, 575);
    ctx.closePath();
    ctx.fillStyle = wv === 0 ? 'rgba(14, 116, 144, 0.55)' : wv === 1 ? 'rgba(6, 182, 212, 0.35)' : 'rgba(52, 211, 153, 0.25)';
    ctx.fill();
  }

  // Sky bodies: Radiant Sun (left-top), Crescent Moon (right-top), Constellation Stars (center-top)
  const skyPop = easeOutBack(clamp01(t / 1.2));
  // Sun
  ctx.save();
  ctx.translate(310, 210);
  ctx.scale(skyPop, skyPop);
  ctx.fillStyle = '#fbbf24';
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 24;
  ctx.beginPath();
  ctx.arc(0, 0, 38 + energy * 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Crescent Moon (clean geometric arc path — no destination-out)
  ctx.save();
  ctx.translate(970, 210);
  ctx.scale(skyPop, skyPop);
  ctx.rotate(-0.35);
  ctx.fillStyle = '#fef08a';
  ctx.shadowColor = '#fde047';
  ctx.shadowBlur = 20;
  ctx.beginPath();
  ctx.arc(0, 0, 34, -Math.PI * 0.48, Math.PI * 0.48, false);
  ctx.quadraticCurveTo(22, 0, Math.cos(-Math.PI * 0.48) * 34, Math.sin(-Math.PI * 0.48) * 34);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // Constellation connected stars
  const starPts = [
    [535, 165],
    [605, 130],
    [675, 155],
    [740, 125],
    [650, 210],
  ];
  ctx.save();
  ctx.strokeStyle = 'rgba(253, 224, 71, 0.35)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  starPts.forEach(([sx, sy], i) => {
    if (i === 0) ctx.moveTo(sx, sy);
    else ctx.lineTo(sx, sy);
  });
  ctx.stroke();
  starPts.forEach(([sx, sy], i) => {
    const pulse = 3.5 + Math.sin(globalT * 3 + i) * 1.5;
    ctx.fillStyle = '#fef9c3';
    ctx.beginPath();
    ctx.arc(sx, sy, pulse, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.restore();

  // Orbiting cosmic labels timed to speech
  if (medallionPhase < 0.7) {
    drawKineticPill(ctx, 310, 285, 'خورشید', clamp01((t - 0.5) / 0.7) * (1 - medallionPhase), '#fbbf24');
    drawKineticPill(ctx, 970, 285, 'ماه و ستاره‌ها', clamp01((t - 1.5) / 0.7) * (1 - medallionPhase), '#fde047');
    drawKineticPill(ctx, 410, 445, 'دریاها', clamp01((t - 2.6) / 0.7) * (1 - medallionPhase), '#38bdf8');
    drawKineticPill(ctx, 640, 365, 'کوه‌ها و معادن', clamp01((t - 3.8) / 0.7) * (1 - medallionPhase), '#34d399');
    drawKineticPill(ctx, 880, 445, 'دشت‌ها و طبیعت', clamp01((t - 5.0) / 0.7) * (1 - medallionPhase), '#4ade80');
  }
  ctx.restore();

  // Phase 2: Bismillah & Alhamdulillah Calligraphic Cards
  if (medallionPhase > 0.02) {
    const bPop = easeOutBack(clamp01((t - 13.4) / 1.2));
    const hPop = easeOutBack(clamp01((t - 18.8) / 1.2));

    // Bismillah medallion
    if (bPop > 0.01) {
      ctx.save();
      const bx = cx;
      const by = hPop > 0.1 ? lerp(320, 235, hPop) : 320;
      ctx.translate(bx, by);
      ctx.scale(bPop, bPop);
      drawRoundedRect(ctx, -330, -68, 660, 136, 28);
      ctx.fillStyle = 'rgba(6, 22, 42, 0.9)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.85)';
      ctx.lineWidth = 2.2;
      ctx.stroke();

      drawGlowingText(
        ctx,
        'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
        0,
        -18,
        '700 38px "Amiri", serif',
        '#fde68a',
        'rgba(251, 191, 36, 0.55)',
        16,
      );
      drawGlowingText(
        ctx,
        'به نام خدایِ همه نعمت‌ها',
        0,
        34,
        '700 22px "Vazirmatn", sans-serif',
        '#34d399',
        'rgba(52, 211, 153, 0.35)',
        10,
      );
      ctx.restore();
    }

    // Alhamdulillah medallion
    if (hPop > 0.01) {
      ctx.save();
      ctx.translate(cx, 420);
      ctx.scale(hPop, hPop);
      drawRoundedRect(ctx, -330, -68, 660, 136, 28);
      ctx.fillStyle = 'rgba(7, 34, 38, 0.92)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(52, 211, 153, 0.9)';
      ctx.lineWidth = 2.4;
      ctx.stroke();

      drawGlowingText(
        ctx,
        'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
        0,
        -18,
        '700 38px "Amiri", serif',
        '#a7f3d0',
        'rgba(52, 211, 153, 0.5)',
        16,
      );
      drawGlowingText(
        ctx,
        'اوّلاً شکرِ خدایِ همه نعمت‌ها',
        0,
        34,
        '700 22px "Vazirmatn", sans-serif',
        '#fbbf24',
        'rgba(251, 191, 36, 0.4)',
        10,
      );
      ctx.restore();
    }
  }
}

/** SCENE 4 (79.4 - 121.8s): شگفتی درون جسم، عدد بی‌نهایت، هفت دریا مرکب و درختان قلم */
export function drawSceneBodyOceans(
  ctx: CanvasRenderingContext2D,
  t: number, // local time (0..42.4)
  globalT: number,
  energy: number,
) {
  // Part A (0..19.2s): Sacred Human Silhouette & Organs (چشم، گوش، قلب، کلیه، کبد، رگ‌ها و دست‌وپا)
  // Part B (19.2..27.5s): Uncountable Blessings Counter -> ∞
  // Part C (27.5..42.4s): Seven Oceans of Ink & Forest Trees as Calligraphy Pens (آیه هفت دریا)

  const partB = easeInOutCubic(clamp01((t - 18.6) / 1.4));
  const partC = easeInOutCubic(clamp01((t - 27.0) / 1.5));

  // --- PART A: Human Body Wonders ---
  if (partB < 0.98) {
    ctx.save();
    ctx.globalAlpha = 1 - partB;
    const cx = 640;
    const cy = 350;

    drawAudioAuraRing(ctx, cx, cy, 175, globalT, energy, '#fb7185');

    // Stylized Luminous Human Silhouette
    ctx.save();
    ctx.strokeStyle = 'rgba(251, 113, 133, 0.8)';
    ctx.fillStyle = 'rgba(136, 19, 55, 0.22)';
    ctx.lineWidth = 2.6;
    // Head
    ctx.beginPath();
    ctx.arc(cx, 185, 36, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // Torso + graceful arms & legs outline
    ctx.beginPath();
    ctx.moveTo(cx - 18, 224);
    ctx.lineTo(cx - 72, 248);
    ctx.lineTo(cx - 108, 370);
    ctx.lineTo(cx - 86, 378);
    ctx.lineTo(cx - 56, 285);
    ctx.lineTo(cx - 46, 415);
    ctx.lineTo(cx - 55, 535);
    ctx.lineTo(cx - 20, 535);
    ctx.lineTo(cx, 430);
    ctx.lineTo(cx + 20, 535);
    ctx.lineTo(cx + 55, 535);
    ctx.lineTo(cx + 46, 415);
    ctx.lineTo(cx + 56, 285);
    ctx.lineTo(cx + 86, 378);
    ctx.lineTo(cx + 108, 370);
    ctx.lineTo(cx + 72, 248);
    ctx.lineTo(cx + 18, 224);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    // Pulsing Heart inside chest
    const beat = 1 + Math.pow(Math.sin(globalT * 4.2), 6) * 0.22 + energy * 0.12;
    ctx.save();
    ctx.translate(cx + 10, 295);
    ctx.scale(beat, beat);
    ctx.fillStyle = '#fb7185';
    ctx.shadowColor = '#f43f5e';
    ctx.shadowBlur = 18;
    ctx.beginPath();
    ctx.moveTo(0, 12);
    ctx.bezierCurveTo(-18, -4, -18, -20, 0, -10);
    ctx.bezierCurveTo(18, -20, 18, -4, 0, 12);
    ctx.fill();
    ctx.restore();

    // Luminous glowing capillary lines
    ctx.save();
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.5)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(cx, 295);
    ctx.lineTo(cx - 88, 365);
    ctx.moveTo(cx, 295);
    ctx.lineTo(cx + 88, 365);
    ctx.moveTo(cx, 295);
    ctx.lineTo(cx - 34, 515);
    ctx.moveTo(cx, 295);
    ctx.lineTo(cx + 34, 515);
    ctx.stroke();
    ctx.restore();

    // Organ callouts timed to Ustad's voice (چشم، گوش، قلب، کلیه، کبد، رگ و دست و پا)
    const organs = [
      { x: 355, y: 175, label: 'چشم و بینایی', at: 2.0, col: '#38bdf8' },
      { x: 925, y: 175, label: 'گوش و شنوایی', at: 3.4, col: '#a78bfa' },
      { x: 330, y: 275, label: 'تپشِ قلب', at: 5.0, col: '#fb7185' },
      { x: 945, y: 275, label: 'کلیه و کبد', at: 6.8, col: '#fb923c' },
      { x: 340, y: 390, label: 'شبکه رگ‌ها و خون', at: 9.2, col: '#f43f5e' },
      { x: 940, y: 390, label: 'دست‌ها و پاها', at: 11.5, col: '#34d399' },
      { x: 640, y: 118, label: 'نعمت‌های درون تا بیرون جسم', at: 14.5, col: '#fbbf24' },
    ];
    for (const o of organs) {
      drawKineticPill(ctx, o.x, o.y, o.label, clamp01((t - o.at) / 0.7), o.col, '✦');
    }
    ctx.restore();
  }

  // --- PART B: Infinity Counter (نمی‌توانی بشماری -> ∞) ---
  if (partB > 0.02 && partC < 0.98) {
    ctx.save();
    ctx.globalAlpha = partB * (1 - partC);
    const cx = 640;
    const cy = 340;
    const lt = Math.max(0, t - 19.0);

    // Spinning numerical counter racing up then dissolving into glowing ∞
    const overflow = easeInOutCubic(clamp01((lt - 3.0) / 1.5));
    if (overflow < 0.95) {
      const val = Math.floor(Math.pow(10, 2 + lt * 1.4));
      ctx.save();
      ctx.globalAlpha *= 1 - overflow;
      drawGlowingText(
        ctx,
        toFaDigits(val.toLocaleString('en-US')),
        cx,
        cy - 40,
        '800 58px "Vazirmatn", sans-serif',
        '#fbbf24',
        'rgba(251, 191, 36, 0.55)',
        20,
      );
      ctx.restore();
    }

    // Glowing Infinity Symbol (∞)
    const infScale = easeOutBack(clamp01((lt - 2.6) / 1.2));
    if (infScale > 0.01) {
      ctx.save();
      ctx.translate(cx, cy - 35);
      ctx.scale(infScale, infScale);
      ctx.strokeStyle = '#38bdf8';
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 24;
      ctx.lineWidth = 8;
      ctx.beginPath();
      for (let i = 0; i <= 120; i++) {
        const a = (i / 120) * Math.PI * 2;
        const denom = 1 + Math.sin(a) * Math.sin(a);
        const ix = (145 * Math.cos(a)) / denom;
        const iy = (110 * Math.sin(a) * Math.cos(a)) / denom;
        if (i === 0) ctx.moveTo(ix, iy);
        else ctx.lineTo(ix, iy);
      }
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    }

    drawKineticPill(
      ctx,
      cx,
      cy + 100,
      'نمی‌توانی فراوانی‌های جهان را بشماری',
      clamp01((lt - 1.2) / 0.9),
      '#fb7185',
      '∞',
    );
    ctx.restore();
  }

  // --- PART C: Seven Oceans of Ink & Trees as Calligraphy Pens ---
  if (partC > 0.02) {
    ctx.save();
    ctx.globalAlpha = partC;
    const lt = Math.max(0, t - 27.2);

    // 7 layered deep indigo/cyan ink oceans
    for (let layer = 0; layer < 7; layer++) {
      const rise = easeOutCubic(clamp01((lt - layer * 0.45) / 1.2));
      const baseY = 560 - (6 - layer) * 20;
      const yOff = lerp(600, baseY, rise);
      ctx.beginPath();
      ctx.moveTo(100, 580);
      for (let x = 100; x <= 1180; x += 28) {
        const wave = Math.sin(x * 0.018 + globalT * (1.8 + layer * 0.25) + layer) * (7 + energy * 4);
        ctx.lineTo(x, yOff + wave);
      }
      ctx.lineTo(1180, 580);
      ctx.closePath();
      ctx.fillStyle = `rgba(${15 + layer * 6}, ${45 + layer * 16}, ${105 + layer * 18}, ${0.32 + layer * 0.06})`;
      ctx.fill();
    }

    // Badge for Seven Oceans
    drawKineticPill(ctx, 320, 215, 'هفت دریا مُرکب', clamp01((lt - 0.8) / 0.8), '#38bdf8', '🌊');

    // Trees rising and morphing into glowing golden Reed Pens (قلم)
    const treeProg = easeOutCubic(clamp01((lt - 3.5) / 1.8));
    if (treeProg > 0.01) {
      const penPositions = [780, 880, 980];
      penPositions.forEach((px, idx) => {
        const sc = easeOutBack(clamp01((lt - 3.5 - idx * 0.35) / 1.0));
        ctx.save();
        const wobble = Math.sin(globalT * 2.5 + idx) * 0.07;
        ctx.translate(px, 390);
        ctx.rotate(-0.35 + wobble);
        ctx.scale(sc, sc);
        // Stylus Qalam shaft
        const pg = ctx.createLinearGradient(0, -140, 0, 40);
        pg.addColorStop(0, '#fde047');
        pg.addColorStop(1, '#b45309');
        ctx.fillStyle = pg;
        ctx.beginPath();
        ctx.moveTo(-9, -135);
        ctx.lineTo(9, -135);
        ctx.lineTo(7, 10);
        ctx.lineTo(0, 42); // Nib
        ctx.lineTo(-7, 10);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      });
      drawKineticPill(ctx, 890, 215, 'تمامِ درختانِ جهان قلم', clamp01((lt - 4.5) / 0.8), '#fbbf24', '✒');
    }

    // Center Quranic Verse Banner
    const vPop = easeOutBack(clamp01((lt - 7.0) / 1.1));
    if (vPop > 0.01) {
      ctx.save();
      ctx.translate(640, 315);
      ctx.scale(vPop, vPop);
      drawRoundedRect(ctx, -380, -48, 760, 96, 22);
      ctx.fillStyle = 'rgba(10, 18, 42, 0.88)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.78)';
      ctx.lineWidth = 2;
      ctx.stroke();
      drawGlowingText(
        ctx,
        'مَّا نَفِدَتْ كَلِمَاتُ اللَّهِ — پایان نمی‌یابد',
        0,
        2,
        '700 28px "Amiri", serif',
        '#fef08a',
        'rgba(251, 191, 36, 0.45)',
        14,
      );
      ctx.restore();
    }
    ctx.restore();
  }
}
