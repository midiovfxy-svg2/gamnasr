import {
  clamp01,
  drawAudioAuraRing,
  drawGlowingText,
  drawKineticPill,
  drawRoundedRect,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  lerp,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';

/** SCENE 5 (121.8 - 143.7s): باشگاه ذهن، دمبل روزانه، ۱۰ دقیقه شکر اول صبح و آرامش در محل کار */
export function drawSceneMindGym(
  ctx: CanvasRenderingContext2D,
  t: number, // local time (0..21.9)
  globalT: number,
  energy: number,
) {
  const phaseB = easeInOutCubic(clamp01((t - 10.5) / 1.6));

  // --- PART A: Mind Dumbbell & Daily Brain Gym ---
  if (phaseB < 0.98) {
    ctx.save();
    ctx.globalAlpha = 1 - phaseB;
    const cx = 640;
    const cy = 345;

    drawAudioAuraRing(ctx, cx, cy, 145, globalT, energy, '#a78bfa');

    // Stylized Luminous Brain / Head Silhouette
    ctx.save();
    ctx.fillStyle = 'rgba(88, 28, 135, 0.35)';
    ctx.strokeStyle = '#c084fc';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, cy + 10, 88, Math.PI * 0.85, Math.PI * 2.15);
    ctx.quadraticCurveTo(cx + 85, cy + 95, cx + 38, cy + 115);
    ctx.lineTo(cx - 38, cy + 115);
    ctx.quadraticCurveTo(cx - 85, cy + 95, cx - 80, cy + 48);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    // Animated Golden Dumbbell lifting rhythmically above the mind
    const lift = Math.sin(globalT * 3.1) * 26;
    const dy = cy - 115 + lift;
    ctx.save();
    ctx.translate(cx, dy);
    // Bar
    ctx.fillStyle = '#fbbf24';
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 18;
    drawRoundedRect(ctx, -135, -7, 270, 14, 7);
    ctx.fill();
    // Plates Left & Right
    for (const side of [-1, 1]) {
      drawRoundedRect(ctx, side * 105 - 14, -46, 28, 92, 8);
      ctx.fill();
      drawRoundedRect(ctx, side * 136 - 10, -34, 20, 68, 7);
      ctx.fill();
    }
    ctx.restore();

    // Rep Counter Badge
    const reps = Math.max(1, Math.floor(t * 0.8) + 1);
    drawKineticPill(ctx, cx, cy + 165, `تمرین روزانه ذهن • تکرارِ ${toFaDigits(reps)}`, clamp01(t / 0.8), '#fbbf24', '🏋');
    drawKineticPill(ctx, 270, 265, 'باشگاهِ فراوانی', clamp01((t - 2.0) / 0.8), '#a78bfa', '⚡');
    drawKineticPill(ctx, 1010, 265, 'بازگو کردنِ نعمت‌ها', clamp01((t - 4.5) / 0.8), '#34d399', '✦');
    ctx.restore();
  }

  // --- PART B: 10-Minute Morning Gratitude & Calm Workplace Path ---
  if (phaseB > 0.02) {
    ctx.save();
    ctx.globalAlpha = phaseB;
    const lt = Math.max(0, t - 10.5);

    // Left Element: 10-Minute Morning Timer Ring
    const leftX = 390;
    const cy = 335;
    ctx.save();
    ctx.translate(leftX, cy);
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.25)';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.arc(0, 0, 92, 0, Math.PI * 2);
    ctx.stroke();

    const dialP = clamp01(lt / 6.0);
    ctx.strokeStyle = '#fbbf24';
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.arc(0, 0, 92, -Math.PI / 2, -Math.PI / 2 + dialP * Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;

    drawGlowingText(ctx, '۱۰ دقیقه', 0, -10, '800 32px "Vazirmatn", sans-serif', '#fef08a', '#fbbf24', 12);
    drawGlowingText(ctx, 'شکرِ اولِ صبح', 0, 26, '600 18px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
    ctx.restore();

    // Connecting Serene Flow Path from Morning Ritual -> Workplace Window
    const pathP = easeOutCubic(clamp01((lt - 2.0) / 3.0));
    ctx.save();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.setLineDash([8, 8]);
    ctx.beginPath();
    ctx.moveTo(500, cy);
    ctx.lineTo(lerp(500, 760, pathP), cy);
    ctx.stroke();
    ctx.restore();

    // Right Element: Calm Workplace / Bright Studio Window
    const rightX = 895;
    const winPop = easeOutBack(clamp01((lt - 3.2) / 1.2));
    if (winPop > 0.01) {
      ctx.save();
      ctx.translate(rightX, cy);
      ctx.scale(winPop, winPop);
      drawRoundedRect(ctx, -105, -95, 210, 190, 24);
      ctx.fillStyle = 'rgba(15, 32, 68, 0.9)';
      ctx.fill();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2.4;
      ctx.stroke();

      // Sunlit window panes + glowing abundance sparkles inside workplace
      for (const [wx, wy] of [
        [-45, -35],
        [45, -35],
        [-45, 35],
        [45, 35],
      ]) {
        drawRoundedRect(ctx, wx - 32, wy - 24, 64, 48, 10);
        ctx.fillStyle = 'rgba(56, 189, 248, 0.22)';
        ctx.fill();
      }
      drawGlowingText(ctx, 'ذهنِ آرام در کار', 0, 128, '700 22px "Vazirmatn", sans-serif', '#38bdf8', '#38bdf8', 10);
      ctx.restore();
    }

    drawKineticPill(ctx, 640, 155, 'بیدار شدن با شکرگزاری و آرامش', clamp01((lt - 0.8) / 0.8), '#a78bfa', '☀');
    ctx.restore();
  }
}

/** SCENE 6 (143.7 - 185.4s): هدف سال: به تصویر کشیدن غیب، هدایت قدم‌به‌قدم و تبدیل غیب به سینما */
export function drawSceneCinemaGhayb(
  ctx: CanvasRenderingContext2D,
  t: number, // local time (0..41.7)
  globalT: number,
  energy: number,
) {
  // Part A (0..12.5s): Target Goal & Unveiling the Unseen (به تصویر کشیدن غیب)
  // Part B (12.5..21.0s): Illuminated Stepping Stones (هر روز یک قدم روشن)
  // Part C (21.0..41.7s): Material vs Unseen + 1400 Years -> Cinema Projector (سینما و تصویر)

  const partB = easeInOutCubic(clamp01((t - 11.8) / 1.4));
  const partC = easeInOutCubic(clamp01((t - 20.5) / 1.6));

  // --- PART A: Target Compass & Unveiling the Unseen ---
  if (partB < 0.98) {
    ctx.save();
    ctx.globalAlpha = 1 - partB;
    const cx = 640;
    const cy = 340;
    drawAudioAuraRing(ctx, cx, cy, 135, globalT, energy, '#f59e0b');

    // Concentric Target Reticle
    for (let r = 1; r <= 3; r++) {
      const p = easeOutCubic(clamp01((t - r * 0.25) / 1.0));
      ctx.strokeStyle = withAlpha('#fbbf24', 0.28 + (4 - r) * 0.16);
      ctx.lineWidth = r === 1 ? 3 : 1.8;
      ctx.beginPath();
      ctx.arc(cx, cy, r * 46 * p, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Center Eye / Portal into the Unseen
    ctx.save();
    ctx.translate(cx, cy);
    ctx.beginPath();
    ctx.moveTo(-70, 0);
    ctx.quadraticCurveTo(0, -48, 70, 0);
    ctx.quadraticCurveTo(0, 48, -70, 0);
    ctx.closePath();
    ctx.fillStyle = 'rgba(251, 191, 36, 0.18)';
    ctx.fill();
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(0, 0, 16 + energy * 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    drawKineticPill(ctx, cx, 145, 'یک هدفِ بزرگ در سال', clamp01((t - 0.6) / 0.8), '#fbbf24', '🎯');
    drawKineticPill(ctx, cx, 505, 'به تصویر کشیدنِ غیب در عالم', clamp01((t - 3.5) / 0.9), '#c084fc', '✦');
    ctx.restore();
  }

  // --- PART B: Illuminated Stepping Stones ---
  if (partB > 0.02 && partC < 0.98) {
    ctx.save();
    ctx.globalAlpha = partB * (1 - partC);
    const lt = Math.max(0, t - 12.0);
    const steps = [
      { x: 240, y: 440, label: 'قدم اول' },
      { x: 440, y: 390, label: 'قدم بعدی' },
      { x: 640, y: 340, label: 'هدایت' },
      { x: 840, y: 290, label: 'نشانه‌ها' },
      { x: 1040, y: 240, label: 'راهِ درست' },
    ];

    // Golden trajectory beam connecting steps
    const litCount = Math.min(steps.length, 1 + lt * 0.65);
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    steps.forEach((s, idx) => {
      if (idx === 0) ctx.moveTo(s.x, s.y);
      else if (idx <= litCount) ctx.lineTo(s.x, s.y);
    });
    ctx.stroke();

    steps.forEach((s, idx) => {
      const active = clamp01(litCount - idx);
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.fillStyle = active > 0.2 ? 'rgba(251, 191, 36, 0.25)' : 'rgba(30, 41, 59, 0.7)';
      ctx.strokeStyle = active > 0.2 ? '#fbbf24' : 'rgba(148, 163, 184, 0.35)';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.ellipse(0, 0, 56, 22, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      if (active > 0.2) {
        drawGlowingText(
          ctx,
          s.label,
          0,
          -45,
          '700 20px "Vazirmatn", sans-serif',
          '#fef08a',
          '#fbbf24',
          12,
        );
      }
      ctx.restore();
    });

    drawKineticPill(ctx, 640, 140, 'هر روز یک قدم روشن می‌شود و نشانه‌ها می‌آیند', clamp01((lt - 0.6) / 0.9), '#fbbf24', '👣');
    ctx.restore();
  }

  // --- PART C: Material Cube vs Unseen Aura -> 1400 Years Cinema Projector ---
  if (partC > 0.02) {
    ctx.save();
    ctx.globalAlpha = partC;
    const lt = Math.max(0, t - 20.8);
    const toCinema = easeInOutCubic(clamp01((lt - 9.0) / 1.8));

    // Sub-phase C1: Material vs Unseen Split (lt < 10s)
    if (toCinema < 0.98) {
      ctx.save();
      ctx.globalAlpha *= 1 - toCinema;

      // Left: Cold Wireframe Cube (بُعد مادی)
      ctx.save();
      ctx.translate(380, 345);
      ctx.rotate(globalT * 0.35);
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.75)';
      ctx.lineWidth = 2;
      ctx.strokeRect(-55, -55, 110, 110);
      ctx.strokeRect(-35, -35, 110, 110);
      ctx.beginPath();
      ctx.moveTo(-55, -55); ctx.lineTo(-35, -35);
      ctx.moveTo(55, -55); ctx.lineTo(75, -35);
      ctx.moveTo(-55, 55); ctx.lineTo(-35, 75);
      ctx.moveTo(55, 55); ctx.lineTo(75, 75);
      ctx.stroke();
      ctx.restore();
      drawKineticPill(ctx, 380, 480, 'بُعد مادی (محدود)', clamp01((lt - 0.5) / 0.8), '#94a3b8');

      // Right: Multi-dimensional Radiant Starburst (بُعد غیبی)
      drawAudioAuraRing(ctx, 900, 345, 95, globalT, energy, '#c084fc');
      ctx.save();
      ctx.translate(900, 345);
      ctx.rotate(-globalT * 0.4);
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2.5;
      for (let i = 0; i < 8; i++) {
        ctx.rotate(Math.PI / 4);
        ctx.strokeRect(-52, -52, 104, 104);
      }
      ctx.restore();
      drawKineticPill(ctx, 900, 480, 'بُعد غیبی (بی‌نهایت)', clamp01((lt - 1.5) / 0.8), '#c084fc', '✦');
      ctx.restore();
    }

    // Sub-phase C2: 1400 Years -> Cinema Screen Projection of the Unseen
    if (toCinema > 0.02) {
      ctx.save();
      ctx.globalAlpha *= toCinema;
      const ct = Math.max(0, lt - 9.0);

      // Stylized Cinema Projector on right projecting golden beam to widescreen on left!
      const projX = 965;
      const projY = 340;
      const scrX = 430;
      const scrY = 340;

      // Golden Light Cone from Projector Lens -> Screen
      const beamG = ctx.createLinearGradient(projX - 40, projY, scrX - 240, scrY);
      beamG.addColorStop(0, withAlpha('#fbbf24', 0.45 + energy * 0.25));
      beamG.addColorStop(1, 'rgba(192, 132, 252, 0.06)');
      ctx.fillStyle = beamG;
      ctx.beginPath();
      ctx.moveTo(projX - 45, projY - 12);
      ctx.lineTo(scrX - 230, scrY - 145);
      ctx.lineTo(scrX - 230, scrY + 145);
      ctx.lineTo(projX - 45, projY + 12);
      ctx.closePath();
      ctx.fill();

      // Projector body + spinning film reels
      ctx.save();
      ctx.translate(projX, projY);
      drawRoundedRect(ctx, -45, -30, 95, 65, 12);
      ctx.fillStyle = '#1e293b';
      ctx.fill();
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2;
      ctx.stroke();
      for (const [rx, ry, rr] of [
        [-18, -56, 26],
        [32, -52, 22],
      ]) {
        ctx.save();
        ctx.translate(rx, ry);
        ctx.rotate(globalT * 2.5);
        ctx.strokeStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(0, 0, rr, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-rr, 0); ctx.lineTo(rr, 0);
        ctx.moveTo(0, -rr); ctx.lineTo(0, rr);
        ctx.stroke();
        ctx.restore();
      }
      ctx.restore();

      // Glowing Cinema Widescreen Frame
      drawRoundedRect(ctx, scrX - 235, scrY - 148, 470, 296, 18);
      ctx.fillStyle = 'rgba(12, 16, 40, 0.92)';
      ctx.fill();
      ctx.strokeStyle = '#c084fc';
      ctx.lineWidth = 3;
      ctx.stroke();

      drawGlowingText(
        ctx,
        '۱۴۰۰ سال گفتار ← اکنون تصویر و سینما',
        scrX,
        scrY - 36,
        '800 24px "Vazirmatn", sans-serif',
        '#fde047',
        'rgba(251, 191, 36, 0.5)',
        14,
      );
      drawGlowingText(
        ctx,
        'تبدیلِ غیب به تصویرِ زنده',
        scrX,
        scrY + 26,
        '700 28px "Vazirmatn", sans-serif',
        '#f8fafc',
        'rgba(192, 132, 252, 0.6)',
        16,
      );

      drawKineticPill(ctx, 965, 455, 'سینمایِ قرآنی', clamp01((ct - 1.2) / 0.9), '#fbbf24', '🎬');
      ctx.restore();
    }
    ctx.restore();
  }
}

/** SCENE 7 (185.4 - 205.0s): سوره لیل؛ تحلیل حرف به حرف فَسَنُيَسِّرُهُ (فَـ و سَـ) و تکرار روزانه */
export function drawSceneFasanuyassiruhu(
  ctx: CanvasRenderingContext2D,
  t: number, // local time (0..19.6)
  globalT: number,
  energy: number,
) {
  const cx = 640;
  const breakdown = easeInOutCubic(clamp01((t - 8.8) / 1.5));

  // Part A: Grand Calligraphic Verse Reveal
  if (breakdown < 0.98) {
    ctx.save();
    ctx.globalAlpha = 1 - breakdown;
    drawAudioAuraRing(ctx, cx, 325, 185, globalT, energy, '#2dd4bf');

    const pop1 = easeOutBack(clamp01(t / 1.2));
    ctx.save();
    ctx.translate(cx, 250);
    ctx.scale(pop1, pop1);
    drawGlowingText(
      ctx,
      'فَأَمَّا مَنْ أَعْطَىٰ وَاتَّقَىٰ ۝ وَصَدَّقَ بِالْحُسْنَىٰ',
      0,
      0,
      '700 38px "Amiri", serif',
      '#fde68a',
      'rgba(251, 191, 36, 0.45)',
      16,
    );
    ctx.restore();

    const pop2 = easeOutBack(clamp01((t - 3.0) / 1.2));
    if (pop2 > 0.01) {
      ctx.save();
      ctx.translate(cx, 355);
      ctx.scale(pop2, pop2);
      drawRoundedRect(ctx, -290, -52, 580, 104, 24);
      ctx.fillStyle = 'rgba(6, 40, 46, 0.92)';
      ctx.fill();
      ctx.strokeStyle = '#2dd4bf';
      ctx.lineWidth = 2.4;
      ctx.stroke();
      drawGlowingText(
        ctx,
        'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
        0,
        0,
        '700 44px "Amiri", serif',
        '#5eead4',
        'rgba(45, 212, 191, 0.65)',
        18,
      );
      ctx.restore();
    }

    drawKineticPill(ctx, cx, 475, 'آسان می‌شویم با آسانی‌ها', clamp01((t - 5.4) / 0.9), '#fbbf24', '✦');
    ctx.restore();
  }

  // Part B: Letter Breakdown (فَـ = پس، سَـ = به‌زودی) + Rhythmic Repetition Orbit
  if (breakdown > 0.02) {
    ctx.save();
    ctx.globalAlpha = breakdown;
    const lt = Math.max(0, t - 9.0);

    // Three floating morphological cards (RTL order: فَـ on right, سَـ in center, نُيَسِّرُهُ on left)
    const faPop = easeOutBack(clamp01((lt - 0.8) / 0.8));
    const saPop = easeOutBack(clamp01((lt - 2.6) / 0.8));
    const restPop = easeOutBack(clamp01((lt - 0.3) / 0.8));

    // Card: فَـ (پس)
    if (faPop > 0.01) {
      ctx.save();
      ctx.translate(880, 275);
      ctx.scale(faPop, faPop);
      drawRoundedRect(ctx, -95, -80, 190, 160, 24);
      ctx.fillStyle = 'rgba(19, 46, 52, 0.92)';
      ctx.fill();
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2.6;
      ctx.stroke();
      drawGlowingText(ctx, 'فَـ', 0, -24, '700 54px "Amiri", serif', '#fde047', '#fbbf24', 16);
      drawGlowingText(ctx, 'یعنی: پَس', 0, 42, '700 22px "Vazirmatn", sans-serif', '#f8fafc', 'rgba(0,0,0,0)', 0);
      ctx.restore();
    }

    // Card: سَـ (به‌زودی)
    if (saPop > 0.01) {
      ctx.save();
      ctx.translate(640, 275);
      ctx.scale(saPop, saPop);
      drawRoundedRect(ctx, -105, -80, 210, 160, 24);
      ctx.fillStyle = 'rgba(15, 52, 58, 0.92)';
      ctx.fill();
      ctx.strokeStyle = '#2dd4bf';
      ctx.lineWidth = 2.6;
      ctx.stroke();
      drawGlowingText(ctx, 'سَـ', 0, -24, '700 54px "Amiri", serif', '#5eead4', '#2dd4bf', 16);
      drawGlowingText(ctx, 'یعنی: به‌زودی', 0, 42, '700 22px "Vazirmatn", sans-serif', '#f8fafc', 'rgba(0,0,0,0)', 0);
      ctx.restore();
    }

    // Card: نُيَسِّرُهُ لِلْيُسْرَىٰ (آسان می‌کنیم)
    if (restPop > 0.01) {
      ctx.save();
      ctx.translate(365, 275);
      ctx.scale(restPop, restPop);
      drawRoundedRect(ctx, -135, -80, 270, 160, 24);
      ctx.fillStyle = 'rgba(13, 38, 52, 0.92)';
      ctx.fill();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2.4;
      ctx.stroke();
      drawGlowingText(ctx, 'نُيَسِّرُهُ لِلْيُسْرَىٰ', 0, -20, '700 32px "Amiri", serif', '#bae6fd', '#38bdf8', 14);
      drawGlowingText(ctx, 'آسان‌سازیِ مسیر', 0, 42, '700 21px "Vazirmatn", sans-serif', '#f8fafc', 'rgba(0,0,0,0)', 0);
      ctx.restore();
    }

    // Continuous Repetition Spiral below (تکرار کن، تکرار کن!)
    const repProg = clamp01((lt - 4.5) / 1.0);
    if (repProg > 0.01) {
      ctx.save();
      ctx.translate(cx, 455);
      ctx.strokeStyle = 'rgba(45, 212, 191, 0.45)';
      ctx.lineWidth = 2.5;
      for (let ring = 0; ring < 3; ring++) {
        ctx.save();
        ctx.rotate(globalT * (1.2 + ring * 0.4));
        ctx.beginPath();
        ctx.arc(0, 0, 32 + ring * 16, 0, Math.PI * 1.45);
        ctx.stroke();
        ctx.restore();
      }
      drawKineticPill(ctx, 0, 0, 'یک‌دفعه نمی‌شود ← تکرارِ هرروزه!', repProg, '#fbbf24', '↻');
      ctx.restore();
    }
    ctx.restore();
  }
}

/** SCENE 8 (205.0 - 240.0s): بذر و ریشه زیر خاک، ستون‌ها، برگ سبز، جمعیت غافل و نشانه‌های دست خدا */
export function drawSceneRootsSigns(
  ctx: CanvasRenderingContext2D,
  t: number, // local time (0..35.0)
  globalT: number,
  energy: number,
) {
  const groundY = 345;

  // Underground soil cross-section below groundY
  const soilGrad = ctx.createLinearGradient(0, groundY, 0, 585);
  soilGrad.addColorStop(0, 'rgba(30, 22, 16, 0.88)');
  soilGrad.addColorStop(1, 'rgba(10, 14, 18, 0.96)');
  ctx.fillStyle = soilGrad;
  drawRoundedRect(ctx, 110, groundY, 1060, 235, 16);
  ctx.fill();

  // Soil surface turf line
  ctx.strokeStyle = '#4ade80';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(110, groundY);
  ctx.lineTo(1170, groundY);
  ctx.stroke();

  // Architectural 4 Concrete Foundation Pillars on the left (چهار ستون فونداسیون)
  const pillarsX = [205, 275, 345, 415];
  pillarsX.forEach((px, idx) => {
    const pGrad = ctx.createLinearGradient(px - 14, 175, px + 14, groundY + 60);
    pGrad.addColorStop(0, 'rgba(148, 163, 184, 0.42)');
    pGrad.addColorStop(1, 'rgba(51, 65, 85, 0.65)');
    ctx.fillStyle = pGrad;
    drawRoundedRect(ctx, px - 13, 185 + idx * 8, 26, groundY - 185 - idx * 8 + 45, 4);
    ctx.fill();
    ctx.strokeStyle = 'rgba(203, 213, 225, 0.35)';
    ctx.lineWidth = 1.4;
    ctx.stroke();
  });

  // Glowing Golden Seed buried under soil (center-right at x=640, y=425)
  const seedX = 640;
  const seedY = 430;
  const rootGrow = easeOutCubic(clamp01((t - 0.8) / 7.5));

  // Branching underground roots spreading deep & wide (invisible to above-ground crowd!)
  ctx.save();
  ctx.strokeStyle = '#fbbf24';
  ctx.shadowColor = '#f59e0b';
  ctx.shadowBlur = 10;
  const rootBranches = [
    { dx: -130, dy: 95, cpx: -45, cpy: 60 },
    { dx: -75, dy: 120, cpx: -20, cpy: 75 },
    { dx: 0, dy: 132, cpx: 12, cpy: 65 },
    { dx: 82, dy: 118, cpx: 30, cpy: 70 },
    { dx: 145, dy: 90, cpx: 58, cpy: 55 },
  ];
  rootBranches.forEach((rb, i) => {
    const p = clamp01(rootGrow * 1.35 - i * 0.08);
    if (p <= 0) return;
    ctx.lineWidth = 3.2 - i * 0.25;
    ctx.beginPath();
    ctx.moveTo(seedX, seedY);
    ctx.quadraticCurveTo(
      seedX + rb.cpx * p,
      seedY + rb.cpy * p,
      seedX + rb.dx * p,
      seedY + rb.dy * p,
    );
    ctx.stroke();

    // Secondary fine rootlets
    if (p > 0.55) {
      const subP = (p - 0.55) / 0.45;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(seedX + rb.dx * 0.65, seedY + rb.dy * 0.65);
      ctx.lineTo(
        seedX + rb.dx * 0.65 + (i % 2 === 0 ? -28 : 28) * subP,
        seedY + rb.dy * 0.65 + 28 * subP,
      );
      ctx.stroke();
    }
  });
  ctx.restore();

  // Seed Core
  ctx.save();
  ctx.translate(seedX, seedY);
  ctx.fillStyle = '#fde047';
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 18 + energy * 10;
  ctx.beginPath();
  ctx.ellipse(0, 0, 14, 19, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  if (t < 10.5) {
    drawKineticPill(ctx, seedX, 535, 'ریشه‌دوانیِ پنهان در زیرِ خاک', clamp01((t - 1.2) / 0.9), '#fbbf24', '🌱');
  }

  // Stem & Emerald Leaf breaking through ground (t > 6.5s) & swaying gently!
  const sproutGrow = easeOutCubic(clamp01((t - 6.5) / 6.0));
  if (sproutGrow > 0.01) {
    const sway = Math.sin(globalT * 2.3) * (6 + energy * 10) * sproutGrow;
    const topX = seedX + sway;
    const topY = lerp(seedY, 178, sproutGrow);

    ctx.save();
    ctx.strokeStyle = '#4ade80';
    ctx.shadowColor = '#22c55e';
    ctx.shadowBlur = 16;
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(seedX, seedY - 12);
    ctx.quadraticCurveTo(seedX + sway * 0.4, (seedY + topY) / 2, topX, topY);
    ctx.stroke();

    // Vibrant Green Leaves opening as sprout passes surface
    if (sproutGrow > 0.48) {
      const leafP = easeOutBack(clamp01((sproutGrow - 0.48) / 0.52));
      for (const side of [-1, 1]) {
        ctx.save();
        ctx.translate(topX, topY + 26);
        ctx.rotate(side * 0.55 + sway * 0.015);
        ctx.scale(leafP, leafP);
        const lg = ctx.createLinearGradient(0, 0, side * 64, -32);
        lg.addColorStop(0, '#16a34a');
        lg.addColorStop(1, '#86efac');
        ctx.fillStyle = lg;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(side * 34, -44, side * 66, -10);
        ctx.quadraticCurveTo(side * 30, 18, 0, 0);
        ctx.fill();
        ctx.restore();
      }
      // Descending Divine Ray illuminating the sprout
      const rayAlpha = clamp01((t - 10.0) / 1.8) * (0.24 + energy * 0.14);
      if (rayAlpha > 0.01) {
        ctx.save();
        const rayG = ctx.createLinearGradient(seedX, 85, topX, groundY);
        rayG.addColorStop(0, withAlpha('#fde047', rayAlpha));
        rayG.addColorStop(1, withAlpha('#4ade80', 0));
        ctx.fillStyle = rayG;
        ctx.beginPath();
        ctx.moveTo(seedX - 28, 85);
        ctx.lineTo(seedX + 28, 85);
        ctx.lineTo(topX + 95, groundY);
        ctx.lineTo(topX - 95, groundY);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }

      // Crown Golden Blossom at finale
      if (t > 20) {
        const bloomP = easeOutBack(clamp01((t - 20) / 2.0));
        ctx.save();
        ctx.translate(topX, topY);
        ctx.scale(bloomP, bloomP);
        ctx.fillStyle = '#fde047';
        ctx.shadowColor = '#fbbf24';
        ctx.shadowBlur = 24;
        ctx.beginPath();
        ctx.arc(0, 0, 14 + energy * 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }
    ctx.restore();
  }

  // Oblivious gray crowd silhouettes walking past on right (t > 12s)
  if (t > 12.0) {
    const crowdP = clamp01((t - 12.0) / 1.5);
    ctx.save();
    ctx.globalAlpha = crowdP * 0.55;
    for (let c = 0; c < 4; c++) {
      const cxWalk = 860 + ((c * 75 + (t - 12) * 18) % 260);
      const cyWalk = groundY;
      ctx.fillStyle = '#475569';
      ctx.beginPath();
      ctx.arc(cxWalk, cyWalk - 52, 11, 0, Math.PI * 2);
      ctx.fill();
      drawRoundedRect(ctx, cxWalk - 10, cyWalk - 38, 20, 38, 6);
      ctx.fill();
    }
    ctx.restore();

    drawKineticPill(ctx, 975, 225, 'بقیه در جمعیت نمی‌بینند', clamp01((t - 16.0) / 0.9), '#94a3b8');
  }

  if (t > 9.5) {
    drawKineticPill(ctx, 315, 160, 'برگِ سبز = نشانه و دستِ خدا', clamp01((t - 9.8) / 0.9), '#4ade80', '✋');
  }
  if (t > 16.0 && t < 23.0) {
    drawKineticPill(ctx, 315, 225, 'چه کسی می‌بیند؟ من و تو', clamp01((t - 16.5) / 0.9), '#fde047', '👁');
  }
  if (t > 21.5) {
    drawKineticPill(ctx, 640, 128, 'برای هدفت هر روز از اول صبح بایست', clamp01((t - 22.0) / 1.0), '#fbbf24', '✦');
  }
}
