import { ArrayBufferTarget, Muxer } from 'mp4-muxer';
import { drawMotionFrame } from './renderer';
import { DURATION_4MIN, DURATION_FULL } from './timelineData';

export interface ExportProgress {
  phase: 'preparing' | 'encoding_audio' | 'rendering_video' | 'finalizing';
  percent: number;
  currentFrame: number;
  totalFrames: number;
  elapsedSec: number;
  etaSec: number;
  detail: string;
}

export interface ExportResult {
  blob: Blob;
  filename: string;
  sizeBytes: number;
  codecLabel: string;
  mimeType: string;
}

export interface ExportOptions {
  audioUrl: string;
  mode: '4min' | 'full';
  resolution: '720p' | '1080p';
  fps?: number;
  showSubtitles: boolean;
  showHud: boolean;
  signal?: AbortSignal;
  onProgress?: (p: ExportProgress) => void;
  onPreviewCanvas?: (canvas: HTMLCanvasElement) => void;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function pickSupportedVideoConfig(width: number, height: number, fps: number) {
  const candidates: Array<{ webCodec: string; muxCodec: 'avc' | 'vp9'; label: string }> = [
    { webCodec: 'avc1.640028', muxCodec: 'avc', label: 'H.264 High' },
    { webCodec: 'avc1.4d002a', muxCodec: 'avc', label: 'H.264 Main' },
    { webCodec: 'avc1.42E01F', muxCodec: 'avc', label: 'H.264 Baseline' },
    { webCodec: 'avc1.42001E', muxCodec: 'avc', label: 'H.264 Constrained' },
    { webCodec: 'vp09.00.10.08', muxCodec: 'vp9', label: 'VP9' },
  ];

  const bitrate = width >= 1920 ? 5_200_000 : 2_800_000;

  for (const c of candidates) {
    try {
      const cfg: VideoEncoderConfig = {
        codec: c.webCodec,
        width,
        height,
        bitrate,
        framerate: fps,
      };
      const res = await VideoEncoder.isConfigSupported(cfg);
      if (res.supported) {
        return { ...c, config: cfg };
      }
    } catch {
      // try next candidate
    }
  }
  return null;
}

async function pickSupportedAudioConfig() {
  const candidates: Array<{
    webCodec: string;
    muxCodec: 'aac' | 'opus';
    sampleRate: number;
    channels: number;
    bitrate: number;
    label: string;
  }> = [
    { webCodec: 'mp4a.40.2', muxCodec: 'aac', sampleRate: 44100, channels: 1, bitrate: 96_000, label: 'AAC-LC' },
    { webCodec: 'mp4a.40.2', muxCodec: 'aac', sampleRate: 48000, channels: 2, bitrate: 128_000, label: 'AAC-LC Stereo' },
    { webCodec: 'opus', muxCodec: 'opus', sampleRate: 48000, channels: 1, bitrate: 64_000, label: 'Opus' },
  ];

  for (const c of candidates) {
    try {
      const cfg: AudioEncoderConfig = {
        codec: c.webCodec,
        sampleRate: c.sampleRate,
        numberOfChannels: c.channels,
        bitrate: c.bitrate,
      };
      const res = await AudioEncoder.isConfigSupported(cfg);
      if (res.supported) {
        return { ...c, config: cfg };
      }
    } catch {
      // try next candidate
    }
  }
  return null;
}

/** Precompute a 10Hz smoothed RMS audio energy envelope from decoded PCM */
function buildEnergyEnvelope(channelData: Float32Array, sampleRate: number, durationSec: number): Float32Array {
  const buckets = Math.ceil(durationSec * 10) + 2;
  const out = new Float32Array(buckets);
  const step = Math.floor(sampleRate / 10);
  for (let b = 0; b < buckets; b++) {
    const start = b * step;
    const end = Math.min(channelData.length, start + step);
    if (end <= start) break;
    let sum = 0;
    for (let i = start; i < end; i++) {
      const s = channelData[i];
      sum += s * s;
    }
    const rms = Math.sqrt(sum / (end - start));
    out[b] = Math.min(1, rms * 3.4);
  }
  return out;
}

export function isWebCodecsSupported(): boolean {
  return (
    typeof VideoEncoder !== 'undefined' &&
    typeof AudioEncoder !== 'undefined' &&
    typeof VideoFrame !== 'undefined' &&
    typeof AudioData !== 'undefined'
  );
}

export async function exportMotionToMp4(opts: ExportOptions): Promise<ExportResult> {
  if (!isWebCodecsSupported()) {
    throw new Error(
      'مرورگر فعلی از WebCodecs (VideoEncoder/AudioEncoder) پشتیبانی نمی‌کند. لطفاً از نسخه جدید Chrome، Edge یا Safari استفاده کنید یا از حالت ضبط زنده استفاده نمایید.',
    );
  }

  const fps = opts.fps ?? 30;
  const width = opts.resolution === '1080p' ? 1920 : 1280;
  const height = opts.resolution === '1080p' ? 1080 : 720;
  const targetDur = opts.mode === '4min' ? DURATION_4MIN : DURATION_FULL;
  const totalFrames = Math.round(targetDur * fps);
  const startPerf = performance.now();

  opts.onProgress?.({
    phase: 'preparing',
    percent: 1,
    currentFrame: 0,
    totalFrames,
    elapsedSec: 0,
    etaSec: 0,
    detail: 'در حال آماده‌سازی فونت‌ها و بررسی کدک‌های ویدیو...',
  });

  await document.fonts.ready;

  const videoSupport = await pickSupportedVideoConfig(width, height, fps);
  if (!videoSupport) {
    throw new Error('کدک ویدیویی سازگار برای ساخت MP4 در این مرورگر یافت نشد.');
  }
  const audioSupport = await pickSupportedAudioConfig();
  if (!audioSupport) {
    throw new Error('کدک صوتی سازگار (AAC/Opus) در این مرورگر یافت نشد.');
  }

  // Fetch & decode audio
  opts.onProgress?.({
    phase: 'preparing',
    percent: 3,
    currentFrame: 0,
    totalFrames,
    elapsedSec: 0,
    etaSec: 0,
    detail: 'در حال پردازش و رمزگشایی فایل صوتی...',
  });

  const resp = await fetch(opts.audioUrl);
  if (!resp.ok) throw new Error('دریافت فایل صوتی برای رندر با خطا مواجه شد.');
  const audioBytes = await resp.arrayBuffer();

  const tempCtx = new AudioContext();
  let decoded: AudioBuffer;
  try {
    decoded = await tempCtx.decodeAudioData(audioBytes.slice(0));
  } finally {
    await tempCtx.close();
  }

  // Resample to target AudioEncoder sampleRate & channels
  const resampledLen = Math.ceil(targetDur * audioSupport.sampleRate);
  const offline = new OfflineAudioContext(audioSupport.channels, resampledLen, audioSupport.sampleRate);
  const src = offline.createBufferSource();
  src.buffer = decoded;
  src.connect(offline.destination);
  src.start(0);
  const pcmBuffer = await offline.startRendering();

  const envelope = buildEnergyEnvelope(pcmBuffer.getChannelData(0), audioSupport.sampleRate, targetDur);

  // Initialize MP4 Muxer
  const muxer = new Muxer({
    target: new ArrayBufferTarget(),
    video: {
      codec: videoSupport.muxCodec,
      width,
      height,
      frameRate: fps,
    },
    audio: {
      codec: audioSupport.muxCodec,
      numberOfChannels: audioSupport.channels,
      sampleRate: audioSupport.sampleRate,
    },
    fastStart: 'in-memory',
  });

  let encoderError: Error | null = null;

  const videoEncoder = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: (e) => {
      encoderError = e instanceof Error ? e : new Error(String(e));
    },
  });
  videoEncoder.configure(videoSupport.config);

  const audioEncoder = new AudioEncoder({
    output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
    error: (e) => {
      encoderError = e instanceof Error ? e : new Error(String(e));
    },
  });
  audioEncoder.configure(audioSupport.config);

  // 1. Encode all audio chunks first (fast)
  opts.onProgress?.({
    phase: 'encoding_audio',
    percent: 6,
    currentFrame: 0,
    totalFrames,
    elapsedSec: (performance.now() - startPerf) / 1000,
    etaSec: 0,
    detail: `در حال رمزگذاری صدای استاد با کدک ${audioSupport.label}...`,
  });

  const chunkFrames = 1024;
  const totalSamples = pcmBuffer.length;
  const channelsData: Float32Array[] = [];
  for (let ch = 0; ch < audioSupport.channels; ch++) {
    channelsData.push(pcmBuffer.getChannelData(Math.min(ch, pcmBuffer.numberOfChannels - 1)));
  }

  for (let offset = 0; offset < totalSamples; offset += chunkFrames) {
    if (opts.signal?.aborted) {
      videoEncoder.close();
      audioEncoder.close();
      throw new DOMException('تولید ویدیو توسط کاربر لغو شد.', 'AbortError');
    }
    if (encoderError) throw encoderError;

    const count = Math.min(chunkFrames, totalSamples - offset);
    const planar = new Float32Array(count * audioSupport.channels);
    for (let ch = 0; ch < audioSupport.channels; ch++) {
      planar.set(channelsData[ch].subarray(offset, offset + count), ch * count);
    }

    const audioData = new AudioData({
      format: 'f32-planar',
      sampleRate: audioSupport.sampleRate,
      numberOfFrames: count,
      numberOfChannels: audioSupport.channels,
      timestamp: Math.round((offset / audioSupport.sampleRate) * 1_000_000),
      data: planar,
    });
    audioEncoder.encode(audioData);
    audioData.close();

    if (audioEncoder.encodeQueueSize > 16) {
      await sleep(2);
    }
  }

  // 2. Render & encode every video frame sequentially
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) throw new Error('ایجاد بوم گرافیکی Canvas2D ممکن نشد.');

  for (let i = 0; i < totalFrames; i++) {
    if (opts.signal?.aborted) {
      videoEncoder.close();
      audioEncoder.close();
      throw new DOMException('تولید ویدیو توسط کاربر لغو شد.', 'AbortError');
    }
    if (encoderError) throw encoderError;

    const timeSec = i / fps;
    const envIdx = Math.min(envelope.length - 1, Math.floor(timeSec * 10));
    const energy = envelope[envIdx] ?? 0.2;

    drawMotionFrame(ctx, timeSec, width, height, energy, {
      mode: opts.mode,
      showSubtitles: opts.showSubtitles,
      showHud: opts.showHud,
    });

    const timestampUs = Math.round((i * 1_000_000) / fps);
    const durationUs = Math.round(1_000_000 / fps);
    const frame = new VideoFrame(canvas, { timestamp: timestampUs, duration: durationUs });
    videoEncoder.encode(frame, { keyFrame: i % (fps * 2) === 0 });
    frame.close();

    // Backpressure + UI breath every frame/few frames
    while (videoEncoder.encodeQueueSize > 6) {
      await sleep(4);
    }
    if (i % 12 === 0) {
      opts.onPreviewCanvas?.(canvas);
      const elapsedSec = (performance.now() - startPerf) / 1000;
      const frac = (i + 1) / totalFrames;
      const etaSec = frac > 0.01 ? (elapsedSec / frac) * (1 - frac) : 0;
      opts.onProgress?.({
        phase: 'rendering_video',
        percent: 8 + Math.round(frac * 88),
        currentFrame: i + 1,
        totalFrames,
        elapsedSec,
        etaSec,
        detail: `رندر المان‌های گرافیکی (${width}×${height}) • ${videoSupport.label}`,
      });
      await sleep(0);
    }
  }

  opts.onProgress?.({
    phase: 'finalizing',
    percent: 98,
    currentFrame: totalFrames,
    totalFrames,
    elapsedSec: (performance.now() - startPerf) / 1000,
    etaSec: 0,
    detail: 'بسته‌بندی نهایی فایل MP4 استاندارد (Fast-Start)...',
  });

  await videoEncoder.flush();
  await audioEncoder.flush();
  videoEncoder.close();
  audioEncoder.close();
  muxer.finalize();

  const buffer = muxer.target.buffer;
  const blob = new Blob([buffer], { type: 'video/mp4' });
  const filename =
    opts.mode === '4min'
      ? `sadagh-bil-husna-4min-${opts.resolution}.mp4`
      : `sadagh-bil-husna-full-${opts.resolution}.mp4`;

  return {
    blob,
    filename,
    sizeBytes: blob.size,
    codecLabel: `${videoSupport.label} + ${audioSupport.label}`,
    mimeType: 'video/mp4',
  };
}
