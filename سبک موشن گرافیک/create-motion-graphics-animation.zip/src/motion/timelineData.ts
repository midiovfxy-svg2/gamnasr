export interface MotionChapter {
  id: number;
  sceneKey:
    | 'dawn_tasdiq'
    | 'city_filter'
    | 'cosmos_bismillah'
    | 'body_oceans'
    | 'mind_gym'
    | 'cinema_ghayb'
    | 'fasanuyassiruhu'
    | 'roots_signs';
  title: string;
  subtitle: string;
  badge: string;
  start4m: number;
  end4m: number;
  startFull: number;
  endFull: number;
  bgTop: string;
  bgBottom: string;
  accent: string;
  accentSecondary: string;
  verseAr?: string;
  verseRef?: string;
}

export interface CaptionCue {
  start: number;
  end: number;
  text: string;
  highlight?: string;
}

export const FULL_AUDIO_URL =
  'https://raw.githubusercontent.com/midiovfxy-svg2/nasr/main/%D8%AD%D9%85%D8%AF%20%D9%88%20%D9%84%DB%8C%D9%8401-/%D8%B5%D8%AF%D9%82%D9%87%20%D8%A8%D8%A7%D9%84%D8%AD%D8%B3%D9%86%DB%8CWhatsApp%20Ptt%202026-10-07%20at%2012.09.27.ogg';

export const DURATION_4MIN = 240;
export const DURATION_FULL = 410.26;

export const MOTION_CHAPTERS: MotionChapter[] = [
  {
    id: 1,
    sceneKey: 'dawn_tasdiq',
    title: 'صدّق بالحُسنی و شکرِ اول صبح',
    subtitle: 'تصدیق نیکی‌ها، خوبی‌ها و فراوانی‌ها از آغاز روز',
    badge: 'فصل ۱ • طلوع تصدیق',
    start4m: 0,
    end4m: 24.8,
    startFull: 0,
    endFull: 24.1,
    bgTop: '#0d102b',
    bgBottom: '#2b193d',
    accent: '#fbbf24',
    accentSecondary: '#fb923c',
    verseAr: 'وَصَدَّقَ بِالْحُسْنَىٰ',
    verseRef: 'سوره لیل • آیه ۶',
  },
  {
    id: 2,
    sceneKey: 'city_filter',
    title: 'فراوانی شهر و نگهبانی از ورودی ذهن',
    subtitle: 'دیدن ثروت و اشتغال در جریان شهر؛ فیلتر تصدیق نه تکذیب',
    badge: 'فصل ۲ • مدارِ شهر',
    start4m: 24.8,
    end4m: 55.6,
    startFull: 24.1,
    endFull: 71.95,
    bgTop: '#08182e',
    bgBottom: '#102d4a',
    accent: '#38bdf8',
    accentSecondary: '#fbbf24',
    verseAr: 'فَلَا تَكْذِيبَ بَلْ تَصْدِيقٌ',
    verseRef: 'ورودی ذهن',
  },
  {
    id: 3,
    sceneKey: 'cosmos_bismillah',
    title: 'تسبیح آسمان و زمین؛ بسم‌الله و الحمدلله',
    subtitle: 'خورشید، ماه، ستاره، دریا، کوه و معادن؛ به نام و شکر خدای همه نعمت‌ها',
    badge: 'فصل ۳ • آفاق هستی',
    start4m: 55.6,
    end4m: 79.4,
    startFull: 71.95,
    endFull: 106.7,
    bgTop: '#05152b',
    bgBottom: '#0b3536',
    accent: '#34d399',
    accentSecondary: '#fcd34d',
    verseAr: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
    verseRef: 'سوره حمد • آیات ۱ و ۲',
  },
  {
    id: 4,
    sceneKey: 'body_oceans',
    title: 'شگفتیِ درون جسم تا بی‌کرانِ هفت دریا',
    subtitle: 'از چشم و گوش و قلب و رگ‌ها تا هفت دریا مرکب و درختان قلم',
    badge: 'فصل ۴ • انفس و بی‌نهایت',
    start4m: 79.4,
    end4m: 121.8,
    startFull: 106.7,
    endFull: 173.0,
    bgTop: '#1a0c26',
    bgBottom: '#0e2242',
    accent: '#fb7185',
    accentSecondary: '#38bdf8',
    verseAr: 'وَلَوْ أَنَّمَا فِي الْأَرْضِ مِن شَجَرَةٍ أَقْلَامٌ وَالْبَحْرُ يَمُدُّهُ مِن بَعْدِهِ سَبْعَةُ أَبْحُرٍ',
    verseRef: 'سوره لقمان • آیه ۲۷',
  },
  {
    id: 5,
    sceneKey: 'mind_gym',
    title: 'باشگاهِ روزانه ذهن و آرامشِ صبحگاهی',
    subtitle: 'ورزشِ هرروزه ذهن با فراوانی؛ ده دقیقه شکر و حضورِ آرام در کار',
    badge: 'فصل ۵ • تمرینِ ذهن',
    start4m: 121.8,
    end4m: 143.7,
    startFull: 173.0,
    endFull: 237.0,
    bgTop: '#171036',
    bgBottom: '#261a54',
    accent: '#a78bfa',
    accentSecondary: '#fbbf24',
  },
  {
    id: 6,
    sceneKey: 'cinema_ghayb',
    title: 'هدفِ سال: به تصویر کشیدنِ غیب در سینما',
    subtitle: 'روشن شدنِ قدم‌به‌قدم، بُعد غیبی در ۱۴۰۰ سال و تبدیل معارف به تصویر',
    badge: 'فصل ۶ • جهاد تبیین',
    start4m: 143.7,
    end4m: 185.4,
    startFull: 237.0,
    endFull: 304.8,
    bgTop: '#0b0c24',
    bgBottom: '#231642',
    accent: '#f59e0b',
    accentSecondary: '#c084fc',
    verseAr: 'يَهْدِي بِهِ اللَّهُ مَنِ اتَّبَعَ رِضْوَانَهُ سُبُلَ السَّلَامِ',
    verseRef: 'هدایت قدم‌به‌قدم',
  },
  {
    id: 7,
    sceneKey: 'fasanuyassiruhu',
    title: 'رازِ «فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ»؛ فَـ و سَـ و تکرار',
    subtitle: 'پس به‌زودی او را برای آسانی آماده می‌کنیم — با تکرارِ هرروزه',
    badge: 'فصل ۷ • رمز گشایش',
    start4m: 185.4,
    end4m: 205.0,
    startFull: 304.8,
    endFull: 324.4,
    bgTop: '#071b24',
    bgBottom: '#0c353b',
    accent: '#2dd4bf',
    accentSecondary: '#fbbf24',
    verseAr: 'فَأَمَّا مَنْ أَعْطَىٰ وَاتَّقَىٰ ۝ وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
    verseRef: 'سوره لیل • آیات ۵ تا ۷',
  },
  {
    id: 8,
    sceneKey: 'roots_signs',
    title: 'بذرِ زیر خاک، جوانه سبز و نشانه‌های دستِ خدا',
    subtitle: 'ریشه‌دوانیِ پنهان، روییدنِ برگ سبز کنار ستون‌ها و نگاهِ بیننده غیب',
    badge: 'فصل ۸ • ثمره و نشانه',
    start4m: 205.0,
    end4m: 240.0,
    startFull: 324.4,
    endFull: 410.26,
    bgTop: '#081c18',
    bgBottom: '#133827',
    accent: '#4ade80',
    accentSecondary: '#fbbf24',
    verseAr: 'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
    verseRef: 'سوره لیل • آیه ۷',
  },
];

export const CAPTIONS_4MIN: CaptionCue[] = [
  { start: 0.0, end: 1.0, text: 'موشن گرافیک «صدّق بالحُسنی» • استاد حاج نصرالله باستین', highlight: 'صدّق بالحُسنی' },
  { start: 1.0, end: 7.0, text: 'صدّق بالحُسنی یعنی تصدیق می‌کنی حُسنی‌ها را؛ یعنی نیکی‌ها را...' },
  { start: 7.0, end: 14.5, text: 'یعنی هر آنچه خوبی هست، فراوانی هست، وجود و داشته‌هایت را شکرگزاری می‌کنی.' },
  { start: 14.5, end: 24.8, text: 'از اول صبح که بلند می‌شوی شکر خدا می‌کنی و در طول روز یاد خدا می‌کنی و فراوانی‌ها را می‌بینی.' },
  { start: 24.8, end: 32.5, text: 'تعداد ساختمان‌هایی که هر روز ساخته می‌شود؛ چقدر پول، چقدر ثروت، چقدر فراوانی هست!' },
  { start: 32.5, end: 42.0, text: 'چقدر برای انسان‌ها شغل و اشتغال ایجاد می‌شود؛ چقدر آدم از ساخت این ساختمان‌ها روزی می‌خورند!' },
  { start: 42.0, end: 50.0, text: 'روزبه‌روز ثروت بیشتری تولید می‌شود و این‌ها را ورودیِ ذهنت قرار می‌دهی...' },
  { start: 50.0, end: 55.6, text: 'که مراقب «صدّق بالحُسنی» است؛ تصدیق کن حُسنی‌ها را، نه تکذیب کن حُسنی‌ها را!' },
  { start: 55.6, end: 64.5, text: 'وقتی نعمت‌های جهان را از خورشید و ماه و ستاره‌ها تا دریاها و کوه‌ها و معادن و دشت‌ها می‌بینی...' },
  { start: 64.5, end: 69.0, text: 'همه‌چیز و نعمت‌های درونشان را می‌بینی و تصدیق می‌کنی.' },
  { start: 69.0, end: 75.5, text: 'مثل همان «بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ»؛ یعنی به نام خدای همه نعمت‌ها.' },
  { start: 75.5, end: 79.4, text: 'و بعد می‌گویی «الْحَمْدُ لِلَّهِ»؛ یعنی اولاً شکرِ خدای همه نعمت‌ها!' },
  { start: 79.4, end: 90.0, text: 'اول فراوانی‌ها را از درون جسمِ خودت ببین: چشم و گوش و قلب و کلیه و کبد و رگ‌های بدن...' },
  { start: 90.0, end: 98.5, text: 'دست‌ها و پاها و مچ‌ها و همه این نعمت‌ها را ببین تا نعمت‌های بیرونِ بدن!' },
  { start: 98.5, end: 106.8, text: 'هر روز از فراوانی‌های جهان هستی بگو؛ نمی‌توانی بشماری، آیه داریم که نمی‌توانی فراوانی‌ها را بشماری!' },
  { start: 106.8, end: 115.0, text: 'به حدی که اگر هفت دریا به عنوان مرکب، و اگر تمام چوب‌ها و درختان جهان قلم شوند...' },
  { start: 115.0, end: 121.8, text: 'که بخواهند فراوانی‌ها و کلمات خدا را بنویسند، نمی‌توانند تمامش کنند!' },
  { start: 121.8, end: 132.5, text: 'ذهن روزانه ورزش می‌خواهد، انگار دمبل می‌زنی و باشگاه می‌روی؛ هر روز فراوانی‌ها را ببین و بازگو کن.' },
  { start: 132.5, end: 138.0, text: 'صبح که بیدار می‌شوی شکر کن، برای همه چیز یک ده دقیقه وقت بگذار...' },
  { start: 138.0, end: 143.7, text: 'با ذهنِ آرام برو سر کار؛ در محل کارت هم فراوانی‌ها را ببین و شکرش را بگو.' },
  { start: 143.7, end: 151.0, text: 'یک هدف در سال داشته باش؛ مثلاً: به تصویر کشیدنِ غیب در عالم!' },
  { start: 151.0, end: 156.2, text: 'چیزی که به چشمِ سر دیده نمی‌شود و کسی تا الان این‌طوری کار نکرده است.' },
  { start: 156.2, end: 164.4, text: 'هر روز یک قدمی به تو گفته می‌شود، قدم بعدی روشن می‌شود، تو هدایت می‌شوی و نشانه‌هایش می‌آید.' },
  { start: 164.4, end: 171.5, text: 'همه‌چیز بُعد مادی نیست؛ بُعد غیبی است!' },
  { start: 171.5, end: 178.8, text: 'و اگر بتوانی بُعد غیبی را به تصویر بکشی، کاری کرده‌ای که در ۱۴۰۰ سال کسی نتوانسته است.' },
  { start: 178.8, end: 185.4, text: 'تا حالا گفتار و منبر بوده؛ کسی نتوانسته غیب را به سینما تبدیل کند و به تصویر بکشد.' },
  { start: 185.4, end: 194.5, text: '«فَأَمَّا مَنْ أَعْطَىٰ وَاتَّقَىٰ وَصَدَّقَ بِالْحُسْنَىٰ» — هر روز کار کنیم، آسان می‌شویم با آسانی‌ها!' },
  { start: 194.5, end: 205.0, text: 'ببین «فَسَنُيَسِّرُهُ»؛ «فَـ» یعنی پس، «سَـ» یعنی به‌زودی! یک‌دفعه نمی‌شود، هی تکرار کن، تکرار کن!' },
  { start: 205.0, end: 214.5, text: 'ریشه زدن مثل دانه در زیر زمین دیده نمی‌شود؛ در خاک هی ریشه زده، زده، تا بعد برگِ سبز می‌زند!' },
  { start: 214.5, end: 221.0, text: 'اگه دیدی برگ سبز داد بیرون یا تکان خورد، این‌ها نشانه است؛ این‌ها دستِ خداست!' },
  { start: 221.0, end: 226.8, text: 'چه کسی می‌بیند؟ من و تو! بقیه توی جمعیت نمی‌بینند!' },
  { start: 226.8, end: 233.5, text: 'برای همین هدفت، هر روز، هر روز، هر روز از اولِ صبح‌ها بایست...' },
  { start: 233.5, end: 240.0, text: 'وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ', highlight: 'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ' },
];

export function getChapterAtTime(timeSec: number, mode: '4min' | 'full'): MotionChapter {
  for (const ch of MOTION_CHAPTERS) {
    const s = mode === '4min' ? ch.start4m : ch.startFull;
    const e = mode === '4min' ? ch.end4m : ch.endFull;
    if (timeSec >= s && timeSec < e) return ch;
  }
  return MOTION_CHAPTERS[MOTION_CHAPTERS.length - 1];
}

/** Maps a timestamp in 'full' mode (0..410.26s) into the equivalent visual scene timeline (0..240s) */
export function mapFullTimeToVisualTime(fullSec: number): number {
  const ch = getChapterAtTime(fullSec, 'full');
  const fullSpan = Math.max(0.01, ch.endFull - ch.startFull);
  const ratio = Math.min(1, Math.max(0, (fullSec - ch.startFull) / fullSpan));
  return ch.start4m + ratio * (ch.end4m - ch.start4m);
}

export function getCaptionAtTime(timeSec: number, mode: '4min' | 'full'): CaptionCue | null {
  const t = mode === '4min' ? timeSec : mapFullTimeToVisualTime(timeSec);
  return CAPTIONS_4MIN.find((c) => t >= c.start && t < c.end) ?? null;
}
