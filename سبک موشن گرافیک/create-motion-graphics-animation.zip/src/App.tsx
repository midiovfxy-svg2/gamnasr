import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Download,
  Film,
  Layers,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Subtitles,
  Volume2,
  VolumeX,
  XCircle,
} from 'lucide-react';
import audio4MinUrl from './assets/audio-4min.mp3';
import { formatTimeFa, toFaDigits } from './motion/drawPrimitives';
import {
  exportMotionToMp4,
  isWebCodecsSupported,
  type ExportProgress,
  type ExportResult,
} from './motion/mp4Exporter';
import { drawMotionFrame } from './motion/renderer';
import {
  CAPTIONS_4MIN,
  DURATION_4MIN,
  DURATION_FULL,
  FULL_AUDIO_URL,
  getChapterAtTime,
  mapFullTimeToVisualTime,
  MOTION_CHAPTERS,
} from './motion/timelineData';

export function App() {
  const [mode, setMode] = useState<'4min' | 'full'>('4min');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(DURATION_4MIN);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [showHud, setShowHud] = useState(true);
  const [muted, setMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState<1 | 1.25>(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [audioReady, setAudioReady] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  // MP4 Export State
  const [exportRes, setExportRes] = useState<'720p' | '1080p'>('720p');
  const [exportWithSubs, setExportWithSubs] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState<ExportProgress | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportResult, setExportResult] = useState<{
    result: ExportResult;
    objectUrl: string;
  } | null>(null);

  const stageWrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const freqDataRef = useRef<Uint8Array<ArrayBuffer> | null>(null);
  const sourceAttachedRef = useRef(false);
  const abortCtrlRef = useRef<AbortController | null>(null);
  const exportSectionRef = useRef<HTMLDivElement | null>(null);

  const activeAudioUrl = mode === '4min' ? audio4MinUrl : FULL_AUDIO_URL;
  const effectiveDuration = duration || (mode === '4min' ? DURATION_4MIN : DURATION_FULL);

  const activeChapter = useMemo(() => {
    const visualT = mode === '4min' ? currentTime : mapFullTimeToVisualTime(currentTime);
    return getChapterAtTime(visualT, '4min');
  }, [currentTime, mode]);

  const activeCaptionIndex = useMemo(() => {
    const t = mode === '4min' ? currentTime : mapFullTimeToVisualTime(currentTime);
    return CAPTIONS_4MIN.findIndex((c) => t >= c.start && t < c.end);
  }, [currentTime, mode]);

  // Clean up object URL on unmount or replacement
  useEffect(() => {
    return () => {
      if (exportResult?.objectUrl) {
        URL.revokeObjectURL(exportResult.objectUrl);
      }
    };
  }, [exportResult]);

  // Ensure fonts load cleanly before drawing
  useEffect(() => {
    document.fonts.ready.then(() => {
      const c = canvasRef.current;
      if (!c) return;
      const ctx = c.getContext('2d');
      if (ctx) {
        drawMotionFrame(ctx, currentTime, c.width, c.height, 0.15, {
          mode,
          showSubtitles,
          showHud,
        });
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Connect Web Audio Analyser once per <audio> element
  const ensureAudioAnalyser = useCallback(() => {
    const audioEl = audioRef.current;
    if (!audioEl) return;
    if (!audioCtxRef.current) {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      audioCtxRef.current = new Ctx();
    }
    if (audioCtxRef.current.state === 'suspended') {
      void audioCtxRef.current.resume();
    }
    if (!sourceAttachedRef.current) {
      try {
        const src = audioCtxRef.current.createMediaElementSource(audioEl);
        const analyser = audioCtxRef.current.createAnalyser();
        analyser.fftSize = 128;
        analyser.smoothingTimeConstant = 0.78;
        src.connect(analyser);
        analyser.connect(audioCtxRef.current.destination);
        analyserRef.current = analyser;
        freqDataRef.current = new Uint8Array(new ArrayBuffer(analyser.frequencyBinCount));
        sourceAttachedRef.current = true;
      } catch {
        // Fallback smoothly if cross-origin audio context attachment isn't allowed
      }
    }
  }, []);

  // Main 60fps Canvas Render Loop
  useEffect(() => {
    let rafId = 0;
    const renderLoop = () => {
      const c = canvasRef.current;
      const audioEl = audioRef.current;
      const t = audioEl ? audioEl.currentTime : currentTime;

      let energy = 0.12;
      if (isPlaying) {
        if (analyserRef.current && freqDataRef.current) {
          analyserRef.current.getByteFrequencyData(freqDataRef.current);
          let sum = 0;
          const len = Math.min(28, freqDataRef.current.length);
          for (let i = 0; i < len; i++) sum += freqDataRef.current[i];
          energy = Math.min(1, sum / (len * 180));
        } else {
          energy = 0.25 + 0.2 * Math.sin(t * 7.3) * Math.cos(t * 3.1);
        }
      }

      if (c) {
        const ctx = c.getContext('2d');
        if (ctx) {
          drawMotionFrame(ctx, t, c.width, c.height, energy, {
            mode,
            showSubtitles,
            showHud,
          });
        }
      }

      if (audioEl && !audioEl.paused) {
        setCurrentTime(audioEl.currentTime);
      }
      rafId = requestAnimationFrame(renderLoop);
    };

    rafId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(rafId);
  }, [currentTime, isPlaying, mode, showHud, showSubtitles]);

  // Handle mode switching cleanly
  const handleSwitchMode = (nextMode: '4min' | 'full') => {
    if (nextMode === mode) return;
    const audioEl = audioRef.current;
    if (audioEl) {
      audioEl.pause();
    }
    setIsPlaying(false);
    setCurrentTime(0);
    setAudioReady(false);
    setAudioError(null);
    setDuration(nextMode === '4min' ? DURATION_4MIN : DURATION_FULL);
    setMode(nextMode);
  };

  const togglePlay = async () => {
    const audioEl = audioRef.current;
    if (!audioEl) return;
    setAudioError(null);
    if (audioEl.paused) {
      ensureAudioAnalyser();
      try {
        await audioEl.play();
        setIsPlaying(true);
      } catch {
        setAudioError('مرورگر اجازه پخش خودکار نداد؛ لطفاً دوباره روی دکمه پخش کلیک کنید.');
      }
    } else {
      audioEl.pause();
      setIsPlaying(false);
    }
  };

  const seekTo = async (sec: number, autoPlay = false) => {
    const clamped = Math.max(0, Math.min(effectiveDuration, sec));
    setCurrentTime(clamped);
    const audioEl = audioRef.current;
    if (audioEl) {
      audioEl.currentTime = clamped;
      if (autoPlay && audioEl.paused) {
        ensureAudioAnalyser();
        try {
          await audioEl.play();
          setIsPlaying(true);
        } catch {
          // ignore autoplay error
        }
      }
    }
  };

  const toggleMute = () => {
    const audioEl = audioRef.current;
    const next = !muted;
    setMuted(next);
    if (audioEl) audioEl.muted = next;
  };

  const toggleRate = () => {
    const next = playbackRate === 1 ? 1.25 : 1;
    setPlaybackRate(next);
    if (audioRef.current) audioRef.current.playbackRate = next;
  };

  const toggleFullscreen = async () => {
    const el = stageWrapRef.current;
    if (!el) return;
    if (!document.fullscreenElement) {
      await el.requestFullscreen();
      setIsFullscreen(true);
    } else {
      await document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const onFs = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  // MP4 Export Handler
  const handleStartExport = async () => {
    if (isExporting) return;
    if (audioRef.current && !audioRef.current.paused) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
    setExportError(null);
    if (exportResult?.objectUrl) {
      URL.revokeObjectURL(exportResult.objectUrl);
      setExportResult(null);
    }

    const ctrl = new AbortController();
    abortCtrlRef.current = ctrl;
    setIsExporting(true);
    setExportProgress({
      phase: 'preparing',
      percent: 1,
      currentFrame: 0,
      totalFrames: Math.round((mode === '4min' ? DURATION_4MIN : DURATION_FULL) * 30),
      elapsedSec: 0,
      etaSec: 0,
      detail: 'شروع آماده‌سازی رندر MP4...',
    });

    try {
      const result = await exportMotionToMp4({
        audioUrl: activeAudioUrl,
        mode,
        resolution: exportRes,
        fps: 30,
        showSubtitles: exportWithSubs,
        showHud: true,
        signal: ctrl.signal,
        onProgress: (p) => setExportProgress(p),
        onPreviewCanvas: (srcCanvas) => {
          const pv = previewCanvasRef.current;
          if (!pv) return;
          const pctx = pv.getContext('2d');
          if (pctx) {
            pctx.drawImage(srcCanvas, 0, 0, pv.width, pv.height);
          }
        },
      });

      const objectUrl = URL.createObjectURL(result.blob);
      setExportResult({ result, objectUrl });

      // Trigger automatic direct download immediately
      const a = document.createElement('a');
      a.href = objectUrl;
      a.download = result.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') {
        setExportError('رندر ویدیو لغو شد.');
      } else {
        setExportError(err instanceof Error ? err.message : 'خطای غیرمنتظره در ساخت فایل MP4');
      }
    } finally {
      setIsExporting(false);
      abortCtrlRef.current = null;
    }
  };

  const handleCancelExport = () => {
    abortCtrlRef.current?.abort();
  };

  const webCodecsOk = useMemo(() => isWebCodecsSupported(), []);

  return (
    <div className="min-h-screen bg-[#060914] text-slate-100 pb-16">
      {/* Hidden Master Audio Element */}
      <audio
        ref={audioRef}
        src={activeAudioUrl}
        crossOrigin="anonymous"
        preload="auto"
        onLoadedMetadata={(e) => {
          const d = e.currentTarget.duration;
          if (Number.isFinite(d) && d > 0) setDuration(d);
          setAudioReady(true);
        }}
        onCanPlay={() => setAudioReady(true)}
        onEnded={() => setIsPlaying(false)}
        onError={() => {
          setAudioError(
            mode === 'full'
              ? 'بارگذاری فایل صوتی کامل از گیت‌هاب با اختلال مواجه شد؛ می‌توانید از نسخه ۴ دقیقه‌ای آفلاین استفاده کنید.'
              : 'خطا در بارگذاری فایل صوتی.',
          );
        }}
      />

      {/* Top Studio Header */}
      <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-[#060914]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-600 text-slate-950 shadow-lg shadow-amber-500/25">
              <Sparkles className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-base font-extrabold tracking-tight text-white sm:text-lg">
                موشن گرافیک المان‌محور «صدّق بالحُسنی»
              </h1>
              <p className="text-xs text-slate-400">
                برگرفته از بیانات استاد حاج نصرالله باستین • ۸ فصل تصویری هماهنگ با صوت
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Mode Switcher */}
            <div className="flex rounded-xl border border-slate-700/80 bg-slate-900/90 p-1 text-xs">
              <button
                type="button"
                onClick={() => handleSwitchMode('4min')}
                className={`rounded-lg px-3 py-1.5 font-semibold transition ${
                  mode === '4min'
                    ? 'bg-amber-500 text-slate-950 shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                نسخه ۴ دقیقه‌ای (۰۴:۰۰)
              </button>
              <button
                type="button"
                onClick={() => handleSwitchMode('full')}
                className={`rounded-lg px-3 py-1.5 font-semibold transition ${
                  mode === 'full'
                    ? 'bg-sky-500 text-slate-950 shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                نسخه کامل صوت (۰۶:۵۰)
              </button>
            </div>

            <button
              type="button"
              onClick={() => exportSectionRef.current?.scrollIntoView({ behavior: 'smooth' })}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-l from-amber-400 to-amber-500 px-4 py-2 text-xs font-extrabold text-slate-950 shadow-lg shadow-amber-500/25 transition hover:brightness-110"
            >
              <Download className="h-4 w-4" />
              ساخت و دانلود MP4
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto mt-6 max-w-7xl space-y-6 px-4 sm:px-6">
        {/* Main Cinema Stage + Live Side Panel */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Player Column (8 cols) */}
          <div className="space-y-4 lg:col-span-8">
            <div
              ref={stageWrapRef}
              className="group relative overflow-hidden rounded-2xl border border-slate-700/70 bg-[#050814] shadow-2xl shadow-black/60"
            >
              {/* 16:9 Motion Canvas */}
              <div className="relative aspect-video w-full cursor-pointer" onClick={togglePlay}>
                <canvas
                  ref={canvasRef}
                  width={1280}
                  height={720}
                  className="h-full w-full object-contain"
                />

                {/* Big Center Play Button when paused */}
                {!isPlaying && (
                  <div className="absolute inset-0 flex items-center justify-center bg-slate-950/35 backdrop-blur-[1px] transition">
                    <div className="flex flex-col items-center gap-3">
                      <div className="flex h-20 w-20 items-center justify-center rounded-full border border-amber-300/60 bg-amber-400/95 text-slate-950 shadow-2xl shadow-amber-500/40 transition-transform group-hover:scale-110">
                        <Play className="h-9 w-9 fill-slate-950 translate-x-[-2px]" />
                      </div>
                      <span className="rounded-full border border-white/15 bg-slate-900/85 px-4 py-1.5 text-xs font-bold text-amber-200 backdrop-blur">
                        {currentTime > 1
                          ? 'ادامه پخش موشن گرافیک'
                          : mode === '4min'
                            ? 'شروع تماشای موشن گرافیک ۴ دقیقه‌ای'
                            : 'شروع تماشای نسخه کامل ۶:۵۰'}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Control Deck */}
              <div className="border-t border-slate-800/90 bg-slate-950/95 px-4 py-3">
                {/* Timeline Slider */}
                <div className="mb-2.5 flex items-center gap-3" dir="ltr">
                  <span className="w-12 text-left text-xs font-bold tabular-nums text-amber-300">
                    {formatTimeFa(currentTime)}
                  </span>
                  <input
                    type="range"
                    min={0}
                    max={effectiveDuration}
                    step={0.1}
                    value={currentTime}
                    onChange={(e) => void seekTo(Number(e.target.value))}
                    style={{
                      background: `linear-gradient(to right, #fbbf24 ${(currentTime / effectiveDuration) * 100}%, #1e293b ${(currentTime / effectiveDuration) * 100}%)`,
                    }}
                    className="studio-slider h-1.5 flex-1 rounded-full"
                    aria-label="خط زمان انیمیشن"
                  />
                  <span className="w-12 text-right text-xs font-semibold tabular-nums text-slate-400">
                    {formatTimeFa(effectiveDuration)}
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={togglePlay}
                      className="flex items-center gap-1.5 rounded-xl bg-amber-500 px-3.5 py-2 text-xs font-extrabold text-slate-950 transition hover:bg-amber-400"
                    >
                      {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      <span>{isPlaying ? 'توقف' : 'پخش'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void seekTo(0, true)}
                      title="از ابتدا"
                      className="rounded-xl border border-slate-700/80 bg-slate-900 p-2 text-slate-300 transition hover:border-slate-600 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4" />
                    </button>

                    <button
                      type="button"
                      onClick={toggleMute}
                      title={muted ? 'وصل صدا' : 'قطع صدا'}
                      className="rounded-xl border border-slate-700/80 bg-slate-900 p-2 text-slate-300 transition hover:border-slate-600 hover:text-white"
                    >
                      {muted ? <VolumeX className="h-4 w-4 text-rose-400" /> : <Volume2 className="h-4 w-4" />}
                    </button>

                    <button
                      type="button"
                      onClick={toggleRate}
                      className="rounded-xl border border-slate-700/80 bg-slate-900 px-2.5 py-1.5 text-xs font-bold text-slate-200 transition hover:border-slate-600"
                    >
                      {toFaDigits(playbackRate)}×
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowSubtitles((s) => !s)}
                      className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-semibold transition ${
                        showSubtitles
                          ? 'border-amber-500/60 bg-amber-500/15 text-amber-300'
                          : 'border-slate-700/80 bg-slate-900 text-slate-400'
                      }`}
                    >
                      <Subtitles className="h-4 w-4" />
                      زیرنویس
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowHud((h) => !h)}
                      className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-semibold transition ${
                        showHud
                          ? 'border-sky-500/60 bg-sky-500/15 text-sky-300'
                          : 'border-slate-700/80 bg-slate-900 text-slate-400'
                      }`}
                    >
                      <Layers className="h-4 w-4" />
                      نوار فصل
                    </button>

                    <button
                      type="button"
                      onClick={() => void toggleFullscreen()}
                      title="تمام‌صفحه"
                      className="rounded-xl border border-slate-700/80 bg-slate-900 p-2 text-slate-300 transition hover:border-slate-600 hover:text-white"
                    >
                      {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                {audioError && (
                  <p className="mt-2 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-1.5 text-xs text-rose-300">
                    {audioError}
                  </p>
                )}
              </div>
            </div>

            {/* Active Chapter Quranic / Wisdom Card */}
            <div className="rounded-2xl border border-slate-800 bg-gradient-to-l from-slate-900/90 to-slate-900/50 p-4 sm:p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-xs font-bold text-amber-300">
                  <Film className="h-3.5 w-3.5" />
                  {activeChapter.badge}
                </span>
                <span className="text-xs text-slate-400">
                  {audioReady ? 'صوت آماده و همگام‌سازی‌شده' : 'در حال بارگذاری صوت...'}
                </span>
              </div>
              <h2 className="mt-2.5 text-base font-extrabold text-white sm:text-lg">
                {activeChapter.title}
              </h2>
              <p className="mt-1 text-sm text-slate-300">{activeChapter.subtitle}</p>
              {activeChapter.verseAr && (
                <div className="mt-3 rounded-xl border border-amber-500/20 bg-slate-950/70 px-4 py-3 text-center">
                  <p className="font-quran text-xl leading-relaxed text-amber-200 sm:text-2xl">
                    {activeChapter.verseAr}
                  </p>
                  {activeChapter.verseRef && (
                    <p className="mt-1 text-xs text-slate-400">{activeChapter.verseRef}</p>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Live Transcript & Quick Export Studio (4 cols) */}
          <div className="space-y-4 lg:col-span-4">
            {/* Direct MP4 Export Panel */}
            <div
              ref={exportSectionRef}
              className="rounded-2xl border border-amber-500/35 bg-gradient-to-b from-slate-900/95 to-slate-950/95 p-4 shadow-xl shadow-amber-950/20"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
                    <Download className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-white">تولید و دانلود مستقیم MP4</h3>
                    <p className="text-[11px] text-slate-400">رندر استاندارد H.264 + صدا مستقیم در مرورگر</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={isExporting}
                    onClick={() => setExportRes('720p')}
                    className={`rounded-xl border px-3 py-2 font-bold transition ${
                      exportRes === '720p'
                        ? 'border-amber-400 bg-amber-400/15 text-amber-200'
                        : 'border-slate-700 bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    720p HD (سریع)
                  </button>
                  <button
                    type="button"
                    disabled={isExporting}
                    onClick={() => setExportRes('1080p')}
                    className={`rounded-xl border px-3 py-2 font-bold transition ${
                      exportRes === '1080p'
                        ? 'border-amber-400 bg-amber-400/15 text-amber-200'
                        : 'border-slate-700 bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    1080p Full HD
                  </button>
                </div>

                <label className="flex cursor-pointer items-center justify-between rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-2.5">
                  <span className="font-semibold text-slate-200">ثبت زیرنویس فارسی در خروجی MP4</span>
                  <input
                    type="checkbox"
                    disabled={isExporting}
                    checked={exportWithSubs}
                    onChange={(e) => setExportWithSubs(e.target.checked)}
                    className="h-4 w-4 accent-amber-400"
                  />
                </label>

                {!webCodecsOk && (
                  <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-2.5 text-[11px] leading-relaxed text-amber-200">
                    توجه: مرورگر فعلی از موتور سریع WebCodecs پشتیبانی نمی‌کند. برای ساخت فایل MP4، لطفاً این صفحه را در مرورگر Chrome، Edge یا Safari جدید باز کنید.
                  </div>
                )}

                {!isExporting ? (
                  <button
                    type="button"
                    onClick={() => void handleStartExport()}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-amber-400 via-amber-500 to-orange-500 px-4 py-3 text-sm font-extrabold text-slate-950 shadow-lg shadow-amber-500/25 transition hover:brightness-110"
                  >
                    <Download className="h-4 w-4" />
                    تولید و دانلود فایل MP4 ({mode === '4min' ? '۴ دقیقه' : '۶:۵۰'})
                  </button>
                ) : (
                  <div className="space-y-3 rounded-xl border border-slate-700/80 bg-slate-900/90 p-3">
                    {/* Live encoding thumbnail preview */}
                    <canvas
                      ref={previewCanvasRef}
                      width={320}
                      height={180}
                      className="aspect-video w-full rounded-lg border border-slate-700 bg-black"
                    />
                    <div className="flex items-center justify-between text-[11px] font-bold">
                      <span className="text-amber-300">{exportProgress?.detail}</span>
                      <span className="tabular-nums text-white">
                        {toFaDigits(exportProgress?.percent ?? 0)}٪
                      </span>
                    </div>
                    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                      <div
                        className="h-full rounded-full bg-gradient-to-l from-amber-400 to-emerald-400 transition-all duration-150"
                        style={{ width: `${exportProgress?.percent ?? 0}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>
                        فریم {toFaDigits(exportProgress?.currentFrame ?? 0)} از{' '}
                        {toFaDigits(exportProgress?.totalFrames ?? 0)}
                      </span>
                      <span>
                        باقی‌مانده: ~{toFaDigits(Math.ceil(exportProgress?.etaSec ?? 0))} ثانیه
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={handleCancelExport}
                      className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-500/10 py-1.5 text-xs font-bold text-rose-300 hover:bg-rose-500/20"
                    >
                      <XCircle className="h-4 w-4" />
                      لغو ساخت ویدیو
                    </button>
                  </div>
                )}

                {exportError && (
                  <div className="rounded-xl border border-rose-500/40 bg-rose-500/10 p-3 text-xs text-rose-200">
                    {exportError}
                  </div>
                )}

                {exportResult && (
                  <div className="space-y-2 rounded-xl border border-emerald-500/45 bg-emerald-500/10 p-3">
                    <div className="flex items-center gap-2 text-emerald-300">
                      <CheckCircle2 className="h-4 w-4 shrink-0" />
                      <span className="text-xs font-extrabold">فایل MP4 آماده دانلود است!</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      حجم فایل: {toFaDigits((exportResult.result.sizeBytes / (1024 * 1024)).toFixed(1))} مگابایت •{' '}
                      {exportResult.result.codecLabel}
                    </p>
                    <a
                      href={exportResult.objectUrl}
                      download={exportResult.result.filename}
                      className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-500 px-3 py-2 text-xs font-extrabold text-slate-950 transition hover:bg-emerald-400"
                    >
                      <Download className="h-4 w-4" />
                      ذخیره مجدد {exportResult.result.filename}
                    </a>
                  </div>
                )}

                {/* Direct Audio Links */}
                <div className="flex items-center justify-between border-t border-slate-800 pt-2.5 text-[11px] text-slate-400">
                  <span>دانلود مستقیم صوت:</span>
                  <div className="flex gap-2">
                    <a
                      href={audio4MinUrl}
                      download="sadagh-bil-husna-4min.mp3"
                      className="font-semibold text-amber-300 hover:underline"
                    >
                      MP3 (۴ دقیقه)
                    </a>
                    <span>•</span>
                    <a
                      href={FULL_AUDIO_URL}
                      target="_blank"
                      rel="noreferrer"
                      className="font-semibold text-sky-300 hover:underline"
                    >
                      OGG اصلی
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Spoken Script / Transcript List */}
            <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-extrabold text-white">متن همگام‌سازی‌شده و زمان‌بندی</h3>
                <span className="text-[11px] text-slate-400">کلیک = پرش به لحظه</span>
              </div>
              <div className="max-h-72 space-y-1.5 overflow-y-auto pl-1">
                {CAPTIONS_4MIN.map((cue, idx) => {
                  const isActive = idx === activeCaptionIndex;
                  const jumpSec =
                    mode === '4min'
                      ? cue.start
                      : (() => {
                          const ch = getChapterAtTime(cue.start, '4min');
                          const r = (cue.start - ch.start4m) / Math.max(0.01, ch.end4m - ch.start4m);
                          return ch.startFull + r * (ch.endFull - ch.startFull);
                        })();
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => void seekTo(jumpSec, true)}
                      className={`w-full rounded-xl border px-3 py-2 text-right text-xs transition ${
                        isActive
                          ? 'border-amber-400/70 bg-amber-400/15 text-amber-100'
                          : 'border-slate-800/80 bg-slate-950/60 text-slate-300 hover:border-slate-700 hover:text-white'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="leading-relaxed">{cue.text}</span>
                        <span className="shrink-0 font-mono text-[10px] text-slate-400">
                          {formatTimeFa(jumpSec)}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* 8-Chapter Element-Oriented Storyboard Grid */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-base font-extrabold text-white sm:text-lg">
              <Clock className="h-5 w-5 text-amber-400" />
              ساختار ۸ فصل المان‌محور موشن گرافیک
            </h2>
            <span className="text-xs text-slate-400">برای پرش مستقیم روی هر فصل کلیک کنید</span>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {MOTION_CHAPTERS.map((ch) => {
              const s = mode === '4min' ? ch.start4m : ch.startFull;
              const e = mode === '4min' ? ch.end4m : ch.endFull;
              const isCurrent = activeChapter.id === ch.id;
              return (
                <button
                  key={ch.id}
                  type="button"
                  onClick={() => void seekTo(s, true)}
                  className={`flex flex-col justify-between rounded-2xl border p-4 text-right transition ${
                    isCurrent
                      ? 'border-amber-400/80 bg-slate-900 shadow-lg shadow-amber-500/10'
                      : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900/90'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className="rounded-full px-2.5 py-0.5 text-[11px] font-bold"
                        style={{
                          backgroundColor: `${ch.accent}22`,
                          color: ch.accent,
                        }}
                      >
                        {ch.badge}
                      </span>
                      <span className="text-[11px] font-semibold text-slate-400">
                        {formatTimeFa(s)} – {formatTimeFa(e)}
                      </span>
                    </div>
                    <h3 className="mt-2.5 text-sm font-extrabold text-white">{ch.title}</h3>
                    <p className="mt-1 text-xs leading-relaxed text-slate-400">{ch.subtitle}</p>
                  </div>
                  {ch.verseRef && (
                    <div className="mt-3 border-t border-slate-800/80 pt-2 text-[11px] text-amber-300/90">
                      {ch.verseRef}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </section>

        {/* Honest Capability & Download Clarification Note */}
        <section className="rounded-2xl border border-slate-800/90 bg-slate-900/40 p-4 text-xs leading-relaxed text-slate-400">
          <p className="font-bold text-slate-200">درباره خروجی MP4 و میزبانی در سایت عمومی خارجی:</p>
          <p className="mt-1">
            این استودیو صوت اصلی را مستقیماً تحلیل و در نسخه تدوین‌شده دقیقاً ۴ دقیقه‌ای (۰۴:۰۰) با ۸ صحنه المان‌محور همگام کرده است. از آنجا که محیط ساخت وب‌اپ دسترسی دائمی به حساب میزبانی ابری عمومی خارجی (مانند گوگل درایو یا گیت‌هاب شخصی شما) ندارد و سرویس‌های آپلود موقت عمومی لینک‌های ناپایدار و کوتاه‌مدت می‌دهند، فایل MP4 به‌صورت واقعی و آفلاین با موتور استاندارد <span className="text-amber-300">WebCodecs (H.264 + AAC)</span> دقیقاً روی دستگاه خودتان تولید و بلافاصله با لینک مستقیم دانلود می‌شود.
          </p>
        </section>
      </main>
    </div>
  );
}

export default App;
