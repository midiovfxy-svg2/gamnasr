#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
APP=/opt/bu-gamifi/app
SERVICE=bu-gamifi
ENVFILE=/root/bu-gamifi-deploy/app.env
BASE=https://bu.gamifi.ir
INCOMING=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
STAMP=$(date +%Y%m%d-%H%M%S)-$$
RELEASE=/opt/bu-gamifi/releases/$STAMP
BACKUP=/root/bu-gamifi-backups/$STAMP
OLD=/opt/bu-gamifi/previous-$STAMP
CHECKUNIT=bu-gamifi-check-$STAMP
CHECKPORT=13105
SWITCHED=0
STOPPED=0
STAGED=0
die() { printf '%s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 ]] || die 'Run as root.'
for command in node npm systemctl systemd-run ss tar cp mv curl pg_dump pg_restore flock ffprobe; do command -v "$command" >/dev/null || die "Missing command: $command (ffprobe is provided by ffmpeg)"; done
[[ -d "$APP" && ! -L "$APP" ]] || die 'Expected a real directory at /opt/bu-gamifi/app; inspect deployment first.'
[[ "$INCOMING" != "$APP" && "$INCOMING" != "$APP/"* ]] || die 'Upload into staging, never the live app.'
[[ -f "$ENVFILE" && -f "$INCOMING/package-lock.json" && -f "$INCOMING/scripts/migrate.mjs" ]] || die 'Environment or release files missing.'
node "$INCOMING/scripts/verify-release.mjs"
[[ $(systemctl show "$SERVICE" -p WorkingDirectory --value) == "$APP" ]] || die 'Unexpected WorkingDirectory; no changes made.'
[[ $(systemctl show "$SERVICE" -p User --value) == bugamifi ]] || die 'Unexpected service user; no changes made.'
systemctl show "$SERVICE" -p EnvironmentFiles --value | grep -Fq "$ENVFILE" || die 'Unexpected environment file.'
START=$(systemctl show "$SERVICE" -p ExecStart --value)
[[ "$START" == *"$APP/node_modules/.bin/next start -H 127.0.0.1 -p 3105"* ]] || die 'Unexpected ExecStart; inspect systemctl cat bu-gamifi.'
[[ $(node -p 'process.versions.node.split(".")[0]') == 22 ]] || die 'This deployment targets Node.js 22.'
systemctl is-active --quiet "$SERVICE" || die 'Existing service is not running; diagnose it first.'
ss -H -ltn 'sport = :13105' | grep -q . && die 'Staging port 13105 is occupied.'
curl --fail --silent --max-time 15 "$BASE/" >/dev/null || die 'Existing HTTPS site did not respond.'
printf 'Verified: %s | %s | port 3105 | existing environment\n' "$APP" "$SERVICE"
[[ ${1:-} != --check ]] || exit 0
mkdir -p /root/bu-gamifi-backups /opt/bu-gamifi/releases
exec 9>/root/bu-gamifi-backups/update.lock
flock -n 9 || die 'Another update is running.'
mkdir -p "$RELEASE" "$BACKUP"
rollback() {
  code=$?
  trap - ERR INT TERM
  if ((STAGED)); then systemctl stop "$CHECKUNIT" >/dev/null 2>&1 || true; fi
  if ((SWITCHED)); then
    systemctl stop "$SERVICE" || true
    mv -- "$APP" "$RELEASE-failed" || true
    mv -- "$OLD" "$APP" || true
    systemctl start "$SERVICE" || true
    printf 'Previous code restored. Additive migrations retained; no user data restored over newer writes. Backup: %s\n' "$BACKUP" >&2
  elif ((STOPPED)); then
    [[ -d "$APP" ]] || mv -- "$OLD" "$APP"
    systemctl start "$SERVICE" || true
  fi
  exit "${code:-1}"
}
trap rollback ERR INT TERM
tar -C "$INCOMING" --exclude='./node_modules' --exclude='./.next' --exclude='./.git' --exclude='./.env' --exclude='./.env.local' --exclude='./.env.production' --exclude='./.env.production.local' --exclude='./release' -cf - . | tar -C "$RELEASE" -xf -
cd "$RELEASE"
npm ci --no-audit --no-fund
NODE=$(command -v node)
"$NODE" scripts/env-run.mjs "$ENVFILE" "$NODE" scripts/db-backup.mjs "$BACKUP/database.dump"
tar -C /opt/bu-gamifi --exclude='app/node_modules' -czf "$BACKUP/code.tar.gz" app
"$NODE" scripts/env-run.mjs "$ENVFILE" "$NODE" scripts/prepare-uploads.mjs "$BACKUP"
"$NODE" node_modules/typescript/bin/tsc --noEmit
"$NODE" --experimental-strip-types tests/session-client.test.mjs
"$NODE" --experimental-strip-types tests/story-policy.test.mjs
"$NODE" scripts/env-run.mjs "$ENVFILE" "$NODE" node_modules/next/dist/bin/next build --webpack
# All shipped migrations are additive; the previous app remains compatible.
"$NODE" scripts/env-run.mjs "$ENVFILE" "$NODE" scripts/migrate.mjs
# Preserve uploaded/static files missing from the release and local environment files.
[[ ! -d "$APP/public" ]] || cp -an "$APP/public/." "$RELEASE/public/"
for file in .env .env.local .env.production .env.production.local; do
  [[ ! -f "$APP/$file" ]] || cp -p "$APP/$file" "$RELEASE/$file"
done
chown -R bugamifi:bugamifi "$RELEASE"
chmod 755 /opt/bu-gamifi/releases "$RELEASE"
STAGED=1
systemd-run --quiet --unit="$CHECKUNIT" --property=User=bugamifi --property=Group=bugamifi --property="WorkingDirectory=$RELEASE" --property="EnvironmentFile=$ENVFILE" "$NODE" "$RELEASE/node_modules/next/dist/bin/next" start -H 127.0.0.1 -p "$CHECKPORT"
healthy() {
  local endpoint=$1
  for attempt in {1..30}; do
    if curl --fail --silent --max-time 5 "$endpoint" | grep -Eq '"ok"[[:space:]]*:[[:space:]]*true'; then return 0; fi
    sleep 1
  done
  return 1
}
healthy "http://127.0.0.1:$CHECKPORT/api/health"
systemctl stop "$CHECKUNIT"
STAGED=0
STOPPED=1
systemctl stop "$SERVICE"
mv -- "$APP" "$OLD"
mv -- "$RELEASE" "$APP"
SWITCHED=1
systemctl start "$SERVICE"
healthy http://127.0.0.1:3105/api/health
healthy "$BASE/api/health"
curl --fail --silent --max-time 20 "$BASE/" >/dev/null
trap - ERR INT TERM
printf 'Update complete. Previous code: %s\nBackup: %s\nSite: %s\n' "$OLD" "$BACKUP" "$BASE"
