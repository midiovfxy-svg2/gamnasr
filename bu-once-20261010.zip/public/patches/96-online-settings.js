(function(){
 'use strict';var previous='',ready=false,busy=false;
 function headers(){var h={'Content-Type':'application/json'};var token=localStorage.getItem('gamify2-admin-token');if(token)h['x-admin-token']=token;return h;}
 async function initialize(){try{await window.__gamifyBootstrap;var response=await fetch('/api/me',{credentials:'include'}),me=await response.json();if(me.role!=='admin')return;var current=window.__gamifyLiveGet&&window.__gamifyLiveGet();if(!current)return setTimeout(initialize,1000);previous=JSON.stringify(current.settings);ready=true;}catch(e){setTimeout(initialize,3000);}}
 setInterval(async function(){if(!ready||busy||!window.__gamifyLiveGet)return;var store=window.__gamifyLiveGet(),signature=JSON.stringify(store.settings);if(signature===previous)return;busy=true;try{var response=await fetch('/api/admin?action=publish-settings',{method:'POST',credentials:'include',headers:headers(),body:JSON.stringify({settings:store.settings})});if(!response.ok)throw Error('ذخیره تنظیمات سرور انجام نشد');previous=signature;}catch(e){if(window.__gamifyToast)window.__gamifyToast(e.message);}finally{busy=false;}},1800);
 initialize();
})();
