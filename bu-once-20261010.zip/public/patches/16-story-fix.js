/* 📸 فیکس محتوا — نسخهٔ ۲ (پست + استوری)
   استوری‌ها و پست‌های کاربر به سرور آینه می‌شوند و بعد از انتشار برای خودش و همه دیده می‌شوند.

   چرا استوری لازم داشت؟ در باندل اصلی «پست» با authorId ساخته می‌شود ولی «استوری» بدون آن؛
   مکانیزم آینه‌کردن قبلی فقط authorId را می‌شناخت، پس استوری به سرور نمی‌رفت و چون پیش‌فرض
   مرورگر moderateStories=true است، حتی برای خود کاربر «در انتظار» می‌ماند و هیچ‌جا دیده نمی‌شد.

   چرا پست هم در این فیکس هست؟ پست‌های عادی کار می‌کنند، ولی این دو حالت گیر می‌کنند:
   ۱) پستی که قبل از ورود به سرور (یا قبل از نصب فیکس) ساخته شده و آینه نشده؛
   ۲) پستی که authorId ندارد یا شناسه‌اش با شناسهٔ محلی فعلی نمی‌خواند.
   این فیکس هر دو حالت را هم می‌گیرد + وضعیت «منتشرشده» را با سرور هم‌تراز می‌کند.

   بی‌خطر است: تکراری نمی‌فرستد، به محتوای نمایشی/ربات‌ها کاری ندارد، و فقط محتوای خودِ کاربر را. */
(function () {
  "use strict";
  if (window.__gamifyContentFix) return;
  window.__gamifyContentFix = true;

  var LS_KEY = "gamify2-store-v2";
  var META_KEY = "gamify2-server";
  var DAY = 86400000;
  var TICK_MS = 1500;
  var SYNC_EVERY = 20;      // هر چند تیک، وضعیت «تأییدشده»ها را از سرور همگام کن
  var POST_MAX_AGE = 8 * DAY;   // پست‌های قدیمی‌تر از این، دیگر آینه نمی‌شوند
  var STORY_MAX_AGE = DAY;      // عمر استوری

  var inFlight = {};
  var ticks = 0;

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function liveStore() {
    try { if (window.__gamifyLiveGet) { var s = window.__gamifyLiveGet(); if (s && typeof s === "object") return s; } } catch (e) {}
    return readStore();
  }
  function setStore(fn) {
    try {
      if (window.__gamifyLiveSet) { window.__gamifyLiveSet(function (s) { var n = fn(s); return n || s; }); return true; }
      var st = readStore(); if (!st) return false; var n2 = fn(st);
      if (n2) localStorage.setItem(LS_KEY, JSON.stringify(n2));
      return true;
    } catch (e) { return false; }
  }
  function meta() { try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch (e) { return {}; } }
  function saveMeta(m) { try { localStorage.setItem(META_KEY, JSON.stringify(m)); } catch (e) {} }
  function toast(m) { try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {} }
  function profile() { var s = liveStore(); return s && s.profile && s.profile.id ? s.profile : null; }
  function serverId() { return meta().serverId || null; }
  function mediaOf(x) {
    if (typeof x.image === "string" && x.image.length < 200000) return x.image;
    if (typeof x.media === "string" && x.media.length < 200000) return x.media;
    return "";
  }

  // محتوای خودِ کاربر است؟
  //  - شناسهٔ نویسنده دارد → با شناسهٔ محلی، شناسهٔ سروری، یا نام خودم باید بخواند
  //    (نام وقتی لازم می‌شود که شناسهٔ محلی مرورگر بعداً عوض شده باشد و پست قدیمی با
  //     شناسهٔ قبلی مانده باشد؛ در حافظهٔ مرورگر فقط محتوای خودِ کاربر بدون پیشوند srv-
  //     ذخیره می‌شود، پس تطبیق نام ریسکی ندارد)
  //  - شناسه ندارد (مثل استوری باندل اصلی) → فقط اگر نام نویسنده با نام خودم یکی باشد
  function mine(item, me, sid) {
    if (!item || !item.id) return false;
    if (String(item.id).indexOf("srv-") === 0) return false;
    if (item.demo || item.real) return false;
    if (item.authorId) return item.authorId === me.id || (!!sid && item.authorId === sid) || item.author === me.name;
    return item.author === me.name;
  }

  function markDone(id) { var m = meta(); m.contentFix = m.contentFix || {}; m.contentFix[id] = 1; saveMeta(m); }
  function isDone(id) { var m = meta(); return !!(m.contentFix && m.contentFix[id]); }

  function setApproved(kind, id) {
    setStore(function (x) {
      var key = kind === "post" ? "posts" : "stories";
      var ch = false;
      var ns = (x[key] || []).map(function (y) {
        if (y && y.id === id && y.status !== "approved") { ch = true; return Object.assign({}, y, { status: "approved" }); }
        return y;
      });
      return ch ? Object.assign({}, x, { posts: key === "posts" ? ns : x.posts, stories: key === "stories" ? ns : x.stories }) : x;
    });
  }

  function send(kind, id, body) {
    inFlight[id] = 1;
    fetch("/api/feed?type=" + kind, {
      method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
      body: JSON.stringify(body)
    }).then(function (r) { return r.json(); }).then(function (j) {
      delete inFlight[id]; markDone(id);
      if (j && j.status === "pending") { toast(kind === "post" ? "⏳ پستت برای تأیید مدیر فرستاده شد" : "⏳ استوری‌ات برای تأیید مدیر فرستاده شد"); return; }
      if (j && j.ok) setApproved(kind, id);
    }).catch(function () { delete inFlight[id]; });   // خطای شبکه → دفعهٔ بعد دوباره تلاش می‌شود
  }

  // ---------- آینه‌کردن محتوای خودم به سرور ----------
  function mirrorMine() {
    var s = liveStore(); if (!s || !s.profile || !s.profile.id) return;
    var me = s.profile, sid = serverId(), nowT = Date.now();

    var mineStories = (s.stories || []).filter(function (st) {
      if (!mine(st, me, sid) || inFlight[st.id] || isDone(st.id)) return false;
      if (!st.at || nowT - st.at > STORY_MAX_AGE) { markDone(st.id); return false; }
      return true;
    }).slice(0, 3);
    mineStories.forEach(function (st) {
      var title = String(st.title || st.text || st.body || "").slice(0, 500);
      if (title.length < 5) { markDone(st.id); return; }
      send("story", st.id, {
        id: String(st.id).slice(0, 60), category: st.category || "general", title: title,
        options: Array.isArray(st.options) ? st.options.slice(0, 4) : [],
        correct: Number(st.correct) || 0, explanation: String(st.explanation || "").slice(0, 1000), media: mediaOf(st)
      });
    });

    var minePosts = (s.posts || []).filter(function (p) {
      if (!mine(p, me, sid) || inFlight[p.id] || isDone(p.id)) return false;
      if (p.status === "approved" && p.mirrored) { markDone(p.id); return false; }
      if (!p.at || nowT - p.at > POST_MAX_AGE) { markDone(p.id); return false; }
      return true;
    }).slice(0, 3);
    minePosts.forEach(function (p) {
      var body = String(p.body || "");
      if (body.length < 3) { markDone(p.id); return; }
      send("post", p.id, {
        id: String(p.id).slice(0, 60), category: p.category || "work",
        body: body.slice(0, 4000), media: mediaOf(p)
      });
    });
  }

  // ---------- اگر روی سرور «منتشر» شده، در مرورگر خودم هم منتشر شود ----------
  // (مثلاً پست/استوریِ قدیمی که مدیر بعداً تأیید کرده یا در دستگاه دیگری آینه شده)
  function syncApproved() {
    var me = profile(); if (!me) return;
    [["posts", "post"], ["stories", "story"]].forEach(function (pair) {
      fetch("/api/feed?type=" + pair[0], { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
        if (!Array.isArray(rows) || !rows.length) return;
        var s = liveStore(); if (!s) return;
        var key = pair[0];
        var byId = {};
        rows.forEach(function (r) { if (r && r.id) byId[r.id] = r; });
        var changed = false;
        var ns = (s[key] || []).map(function (y) {
          if (y && y.id && byId[y.id] && y.status !== "approved") { changed = true; return Object.assign({}, y, { status: "approved", mirrored: true }); }
          return y;
        });
        if (changed) setStore(function (x) { var o = {}; o[key] = ns; return Object.assign({}, x, o); });
      }).catch(function () {});
    });
  }

  function tick() {
    ticks++;
    try { mirrorMine(); } catch (e) {}
    if (ticks % SYNC_EVERY === 0) { try { syncApproved(); } catch (e) {} }
  }

  setInterval(tick, TICK_MS);
  setTimeout(tick, 1200);
  setTimeout(syncApproved, 2500);
})();
