/* 🛠️ پنل مدیریت سرور — همه‌چیز آنلاین و برخط
   - ورود مدیر با کد مدیریت که سمت سرور بررسی می‌شود (توکن امضاشده؛ هدر x-admin-token)
   - کاربران واقعی/مهمان/ربات/مدیر جدا، جست‌وجو و صفحه‌بندی سمت سرور، نمایش موبایل/ایمیل با ثبت در لاگ ممیزی
   - تغییر آواتار، عضو کردن در قبیله، سازمان، سکه، بن، ادمین، حذف
   - ترتیب‌دادن مسابقهٔ زنده بین دو کاربر واقعی
   - اعلان سراسری (عکس + متن + لینک به بخش بازی) به‌صورت پنجره
   - تنظیمات سایت (عنوان، شعار، لوگو، بنرها، بخش‌های مخفی)، تأیید پست/استوری، تغییر هر متن و تصویر */
(function () {
  "use strict";
  if (window.__gamifyAdminPanel) return;
  window.__gamifyAdminPanel = true;

  var TOK_KEY = "gamify2-admin-token";
  var LS_KEY = "gamify2-store-v2";
  var S = { ov: null, tab: "users", kind: "real", q: "", page: 1, data: null, token: localStorage.getItem(TOK_KEY) || "", name: "", sel: {}, settings: null, categories: [], tribes: [], orgs: [], matchA: "", matchB: "", revealed: {} };

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function liveStore() { try { if (window.__gamifyLiveGet) return window.__gamifyLiveGet(); } catch (e) {} return readStore(); }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function toast(m) { try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {} alert(m); }
  function ago(ts) { if (!ts) return "—"; var d = Date.now() - ts; if (d < 60000) return "همین الان"; if (d < 3600000) return fa(Math.floor(d / 60000)) + " دقیقه پیش"; if (d < 86400000) return fa(Math.floor(d / 3600000)) + " ساعت پیش"; return fa(Math.floor(d / 86400000)) + " روز پیش"; }
  function avSrc(av) { var pad = function (n) { return String(n).padStart(2, "0"); }; if (av && typeof av === "object" && av.img) return "/assets/avatars/" + pad(av.img) + ".png"; if (typeof av === "number") return "/assets/avatars/" + pad(((av % 20) + 20) % 20 + 1) + ".png"; return "/assets/avatars/07.png"; }
  function headers() { var h = { "Content-Type": "application/json" }; if (S.token) h["x-admin-token"] = S.token; return h; }
  function api(path, method, body) {
    return fetch(path, { method: method || "GET", credentials: "include", headers: headers(), body: body ? JSON.stringify(body) : undefined })
      .then(function (r) { return r.text().then(function (t) { var j; try { j = JSON.parse(t); } catch (e) { j = { error: "server " + r.status }; } return { status: r.status, body: j }; }); })
      .catch(function () { return { status: 0, body: { error: "network" } }; });
  }
  function localAdmin() { var st = liveStore(); return !!(st && (st.admin === true || (st.profile && st.profile.role === "admin"))); }

  // ---------- ورود ----------
  function login(cb) {
    var code = prompt("کد مدیریت را وارد کن (سمت سرور بررسی می‌شود):");
    if (!code) return;
    var st = liveStore();
    api("/api/admin?action=login", "POST", { code: code, name: (st && st.adminName) || (st && st.profile && st.profile.name) || "مدیر" }).then(function (r) {
      if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "ورود ناموفق"));
      S.token = r.body.token; S.name = r.body.name; localStorage.setItem(TOK_KEY, S.token);
      toast("✅ ورود مدیر سرور انجام شد");
      if (cb) cb();
    });
  }
  window.__gamifyAdminHeaders = headers;
  window.__gamifyAdminToken = function () { return S.token; };

  // ---------- پنل ----------
  function ensure() {
    if (S.ov) return S.ov;
    var ov = document.createElement("div"); ov.className = "gamify-overlay"; ov.id = "gm-admin-overlay";
    ov.addEventListener("click", function (e) { if (e.target === ov) close(); });
    document.body.appendChild(ov); S.ov = ov; return ov;
  }
  function open() { var ov = ensure(); ov.classList.add("open"); render(); load(); }
  function close() { if (S.ov) S.ov.classList.remove("open"); }

  function load() {
    if (!S.token) { render(); return; }
    var p;
    if (S.tab === "users" || S.tab === "match") p = api("/api/admin?view=users&kind=" + encodeURIComponent(S.tab === "match" ? "real" : S.kind) + "&q=" + encodeURIComponent(S.q) + "&page=" + S.page + "&size=30");
    else if (S.tab === "overview") p = api("/api/admin?view=overview");
    else if (S.tab === "broadcast") p = api("/api/admin?view=broadcasts");
    else if (S.tab === "settings") p = api("/api/admin?view=settings");
    else if (S.tab === "categories") p = api("/api/admin?view=categories");
    else p = Promise.resolve({ body: {} });
    Promise.all([p, S.tribes.length ? null : api("/api/admin?view=tribes"), S.orgs.length ? null : api("/api/admin?view=orgs"), S.categories.length ? null : api("/api/admin?view=categories")]).then(function (res) {
      if (res[0].status === 403) { S.token = ""; localStorage.removeItem(TOK_KEY); render(); return; }
      S.data = res[0].body;
      if (res[1] && Array.isArray(res[1].body)) S.tribes = res[1].body;
      if (res[2] && Array.isArray(res[2].body)) S.orgs = res[2].body;
      if (res[3] && Array.isArray(res[3].body)) S.categories = res[3].body;
      if (S.tab === "categories" && Array.isArray(S.data)) S.categories = S.data;
      if (S.tab === "settings") S.settings = S.data;
      render();
    });
  }

  var TABS = [["overview", "📊 نمای کلی"], ["users", "👥 کاربران"], ["match", "🏟️ مسابقهٔ دونفره"], ["broadcast", "📣 اعلان سراسری"], ["settings", "⚙️ تنظیمات و متن‌ها"], ["categories", "🗂️ دسته‌ها"]];

  function render() {
    var ov = ensure(); if (!ov.classList.contains("open")) return;
    var head = '<div class="gamify-modal-head"><b>🛠️ پنل مدیریت سرور' + (S.name ? " — " + esc(S.name) : "") + '</b><button class="gamify-btn sm" data-x="1">✕</button></div>';
    if (!S.token) {
      ov.innerHTML = '<div class="gamify-modal gm-admin">' + head + '<div class="gamify-empty"><div style="font-size:48px">🔐</div><h3>ورود مدیر</h3><p>برای مدیریت کاربران واقعی، اعلان و تنظیمات آنلاین، کد مدیریت را وارد کن.</p><button class="gamify-btn primary" data-login="1">ورود با کد مدیریت</button></div></div>';
      ov.querySelector("[data-x]").addEventListener("click", close);
      ov.querySelector("[data-login]").addEventListener("click", function () { login(function () { render(); load(); }); });
      return;
    }
    var tabs = '<div class="gm-tabs">' + TABS.map(function (t) { return '<button class="gamify-btn sm ' + (S.tab === t[0] ? "primary" : "") + '" data-tab="' + t[0] + '">' + t[1] + "</button>"; }).join("") + "</div>";
    var body = "";
    var d = S.data || {};
    if (S.tab === "overview") body = renderOverview(d);
    else if (S.tab === "users") body = renderUsers(d);
    else if (S.tab === "match") body = renderMatch(d);
    else if (S.tab === "broadcast") body = renderBroadcast(d);
    else if (S.tab === "settings") body = renderSettings(d);
    else if (S.tab === "categories") body = renderCategories();
    ov.innerHTML = '<div class="gamify-modal gm-admin">' + head + tabs + '<div class="gamify-body">' + body + "</div></div>";
    bind(ov);
  }

  function renderOverview(d) {
    if (!d.stats) return '<div class="gamify-loading">در حال دریافت…</div>';
    var s = d.stats;
    var cards = [["👤 کاربران واقعی", s.realUsers], ["🟢 آنلاین (۲ دقیقه)", s.onlineUsers], ["📡 اتصال زنده", s.liveConnections], ["⚔️ دوئل زندهٔ فعال", s.liveDuels], ["🛡️ قبیله‌ها", s.totalTribes], ["📝 پست منتظر تأیید", s.pendingPosts], ["📸 استوری منتظر", s.pendingStories], ["🏆 تورنمنت‌ها", s.totalTournaments], ["👥 کل حساب‌ها", s.totalUsers]];
    var h = '<div class="gm-stats">' + cards.map(function (c) { return '<div class="gm-stat"><b>' + fa(c[1]) + "</b><span>" + c[0] + "</span></div>"; }).join("") + "</div>";
    h += '<div class="gm-card"><b>آخرین کاربران واقعی</b><table><tr><th>نام</th><th>نوع</th><th>سازمان</th><th>آخرین فعالیت</th><th>موبایل</th><th>ایمیل</th></tr>' + (d.recentUsers || []).map(function (u) { return "<tr><td>" + (u.online ? "🟢 " : "⚪ ") + esc(u.name) + "</td><td class=\"kind-" + u.kind + '">' + kindLabel(u.kind) + "</td><td>" + esc(u.orgId || "—") + "</td><td>" + ago(u.lastSeen) + "</td><td dir=\"ltr\">" + (u.hasPhone ? esc(u.phone) : "ثبت نشده") + "</td><td dir=\"ltr\">" + (u.hasEmail ? esc(u.email) : "ثبت نشده") + "</td></tr>"; }).join("") + "</table></div>";
    h += '<div class="gm-card"><b>لاگ ممیزی</b><div style="font-size:12px;color:#cdbde0;line-height:1.9">' + (d.logs || []).map(function (l) { return "• " + esc(l.actor) + " → " + esc(l.action) + " " + esc(l.target || "") + " <small>(" + ago(l.createdAt) + ")</small>"; }).join("<br>") + "</div></div>";
    return h;
  }
  function kindLabel(k) { return { real: "واقعی", guest: "مهمان", bot: "ربات", admin: "مدیر" }[k] || k; }

  function renderUsers(d) {
    var c = d.counts || {};
    var kinds = [["real", "👤 واقعی (" + fa(c.real) + ")"], ["online", "🟢 آنلاین (" + fa(c.online) + ")"], ["guest", "🌱 مهمان (" + fa(c.guest) + ")"], ["admin", "👑 مدیران (" + fa(c.admin) + ")"], ["bot", "🤖 ربات‌ها (" + fa(c.bot) + ")"], ["all", "همه"]];
    var h = '<div class="gm-row"><select data-kind>' + kinds.map(function (k) { return '<option value="' + k[0] + '"' + (S.kind === k[0] ? " selected" : "") + ">" + k[1] + "</option>"; }).join("") + '</select><input data-q placeholder="جست‌وجو: نام، موبایل، ایمیل، سازمان" value="' + esc(S.q) + '"><button class="gamify-btn sm" data-search>جست‌وجو</button><span style="font-size:12px;color:#cdbde0">' + fa(d.total || 0) + " نتیجه · اتصال زنده: " + fa(c.live || 0) + "</span></div>";
    if (!d.users) return h + '<div class="gamify-loading">در حال دریافت…</div>';
    h += '<table><tr><th></th><th>نام</th><th>نوع</th><th>موبایل</th><th>ایمیل</th><th>سازمان</th><th>قبیله</th><th>XP</th><th>آخرین فعالیت</th><th>عملیات</th></tr>';
    d.users.forEach(function (u) {
      var rv = S.revealed[u.id];
      h += "<tr" + (u.banned ? ' style="opacity:.5"' : "") + '><td><img src="' + avSrc(u.avatar) + '" style="width:30px;height:30px;border-radius:50%"></td><td>' + (u.online ? "🟢 " : "⚪ ") + esc(u.name) + (u.role === "admin" ? " 👑" : "") + '</td><td class="kind-' + u.kind + '">' + kindLabel(u.kind) + '</td>' +
        '<td dir="ltr">' + (u.hasPhone ? esc(rv ? rv.phone : u.phone) : '<span style="color:#888">ثبت نشده</span>') + '</td><td dir="ltr">' + (u.hasEmail ? esc(rv ? rv.email : u.email) : '<span style="color:#888">ثبت نشده</span>') + "</td>" +
        "<td>" + esc(u.orgId || "—") + "</td><td>" + esc(u.tribe ? u.tribe.name : "—") + "</td><td>" + fa(u.xp) + "</td><td>" + ago(u.lastSeen) + "</td>" +
        '<td><button class="gamify-btn sm" data-user="' + esc(u.id) + '">⚙️</button></td></tr>';
    });
    h += "</table>";
    var pages = Math.max(1, Math.ceil((d.total || 0) / (d.size || 30)));
    h += '<div class="gm-row"><button class="gamify-btn sm" data-page="' + (S.page - 1) + '"' + (S.page <= 1 ? " disabled" : "") + '>قبلی</button><span>صفحهٔ ' + fa(S.page) + " از " + fa(pages) + '</span><button class="gamify-btn sm" data-page="' + (S.page + 1) + '"' + (S.page >= pages ? " disabled" : "") + ">بعدی</button></div>";
    if (S.sel.id) h += renderUserCard(S.sel);
    return h;
  }
  function renderUserCard(u) {
    var rv = S.revealed[u.id];
    var avs = ""; for (var i = 1; i <= 20; i++) avs += '<img src="/assets/avatars/' + String(i).padStart(2, "0") + '.png" data-av="' + i + '" class="' + (u.avatar && u.avatar.img === i ? "sel" : "") + '" title="آواتار ' + i + '">';
    return '<div class="gm-card" id="gm-user-card"><div class="gm-row" style="justify-content:space-between"><b>⚙️ ' + esc(u.name) + ' <small class="kind-' + u.kind + '">(' + kindLabel(u.kind) + ")</small></b><button class=\"gamify-btn sm\" data-unsel>بستن</button></div>" +
      '<div class="gm-row"><span>موبایل: <b dir="ltr">' + (u.hasPhone ? esc(rv ? rv.phone : u.phone) : "ثبت نشده") + '</b></span><span>ایمیل: <b dir="ltr">' + (u.hasEmail ? esc(rv ? rv.email : u.email) : "ثبت نشده") + "</b></span>" + ((u.hasPhone || u.hasEmail) && !rv ? '<button class="gamify-btn sm" data-reveal>👁️ نمایش کامل (ثبت در لاگ)</button>' : "") + "<span>ورود: " + esc(u.provider || "guest") + "</span><span>عضویت: " + ago(u.createdAt) + "</span></div>" +
      '<div class="gm-row"><span>آخرین IP: <b dir="ltr">' + esc(u.lastIp || "ثبت نشده") + '</b></span><input data-phone placeholder="موبایل جدید؛ خالی = بدون تغییر" dir="ltr"><input data-email placeholder="ایمیل جدید؛ خالی = بدون تغییر" dir="ltr"><button class="gamify-btn sm" data-act="set-contact">ذخیره تماس</button></div>' +
      '<div class="gm-row"><label><input type="checkbox" data-user-video' + (u.allowVideo ? ' checked' : '') + '> اجازه ویدئوی حداکثر ۶۰ ثانیه</label><button class="gamify-btn sm" data-act="set-video-permission">ذخیره مجوز</button></div>' +
      '<div class="gm-row"><button class="gamify-btn sm" data-act="credentials">نام کاربری / رمز جدید</button></div>' + '<div class="gm-row"><input data-name value="' + esc(u.name) + '" placeholder="نام"><button class="gamify-btn sm" data-act="set-name">ذخیرهٔ نام</button>' +
      '<select data-org><option value="">بدون سازمان</option>' + S.orgs.map(function (o) { return '<option value="' + esc(o.id) + '"' + (o.id === u.orgId ? " selected" : "") + ">" + esc(o.name) + "</option>"; }).join("") + '</select><button class="gamify-btn sm" data-act="set-org">ذخیرهٔ سازمان</button></div>' +
      '<div class="gm-row"><select data-tribe><option value="">— انتخاب قبیله —</option>' + S.tribes.map(function (t) { return '<option value="' + esc(t.id) + '"' + (u.tribe && u.tribe.id === t.id ? " selected" : "") + ">" + esc(t.logo || "") + " " + esc(t.name) + "</option>"; }).join("") + '</select><button class="gamify-btn sm primary" data-act="add-to-tribe">🛡️ عضو قبیله کن</button><button class="gamify-btn sm" data-act="remove-from-tribe">خروج از قبیله</button>' +
      '<input data-coins type="number" value="100" style="width:90px"><button class="gamify-btn sm" data-act="set-coins">🪙 افزودن سکه</button></div>' +
      '<div class="gm-row"><input data-ntitle placeholder="عنوان پیام" style="width:160px"><input data-nbody placeholder="متن پیام خصوصی به این کاربر" style="flex:1"><button class="gamify-btn sm" data-act="notify-user">📩 ارسال</button></div>' +
      '<div class="gm-row">' + (u.banned ? '<button class="gamify-btn sm" data-act="unban">✅ رفع مسدودی</button>' : '<button class="gamify-btn sm danger" data-act="ban">⛔ مسدود</button>') + (u.role === "admin" ? '<button class="gamify-btn sm" data-act="remove-admin">حذف نقش مدیر</button>' : '<button class="gamify-btn sm" data-act="make-admin">👑 مدیر کن</button>') + '<button class="gamify-btn sm danger" data-act="delete-user">🗑️ حذف حساب</button><button class="gamify-btn sm" data-match-with="' + esc(u.id) + '">⚔️ مسابقه با…</button></div>' +
      '<div><b style="font-size:12px">آواتار:</b><div class="gm-avatars">' + avs + "</div></div></div>";
  }

  function renderMatch(d) {
    var users = (d.users || []);
    var opts = function (sel) { return '<option value="">— انتخاب بازیکن واقعی —</option>' + users.map(function (u) { return '<option value="' + esc(u.id) + '"' + (sel === u.id ? " selected" : "") + ">" + (u.online ? "🟢 " : "⚪ ") + esc(u.name) + (u.orgId ? " · " + esc(u.orgId) : "") + "</option>"; }).join(""); };
    return '<div class="gm-card"><h3 style="margin:0 0 6px">🏟️ ترتیب‌دادن مسابقهٔ زندهٔ دونفره</h3><p style="font-size:13px;color:#cdbde0;line-height:1.8">دو کاربر واقعی را انتخاب کن؛ برای هر دو همان لحظه پنجرهٔ دعوت باز می‌شود (مثل این‌که خودشان دعوت داده‌اند) و بعد از پذیرش، هم‌زمان با هم مسابقه می‌دهند.</p>' +
      '<div class="gm-row"><input data-mq placeholder="جست‌وجوی نام" value="' + esc(S.q) + '"><button class="gamify-btn sm" data-msearch>جست‌وجو</button></div>' +
      '<div class="gm-row"><label>بازیکن ۱ <select data-ma>' + opts(S.matchA) + "</select></label><label>بازیکن ۲ <select data-mb>" + opts(S.matchB) + '</select></label><label>دسته <select data-mcat>' + S.categories.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.name) + "</option>"; }).join("") + '</select></label><button class="gamify-btn primary" data-go-match>⚔️ ارسال درخواست مسابقه</button></div></div>';
  }

  function renderBroadcast(d) {
    var list = Array.isArray(d) ? d : [];
    var links = [["", "بدون لینک"], ["feed", "فید"], ["tournaments", "تورنمنت‌ها"], ["tribes", "قبیله‌ها"], ["pvp", "نبرد زنده"], ["arena", "مرکز پاداش"], ["leaderboard", "جدول رتبه‌بندی"], ["messages", "گفت‌وگو"], ["profile", "پروفایل"], ["shop", "فروشگاه"], ["settings", "تنظیمات"]];
    return '<div class="gm-card"><h3 style="margin:0 0 6px">📣 اعلان سراسری (پنجره روی صفحهٔ همه)</h3>' +
      '<div class="gm-row"><input data-bt placeholder="عنوان" style="flex:1"><select data-btarget><option value="all">همهٔ کاربران</option><option value="real">فقط کاربران واقعی</option>' + S.orgs.map(function (o) { return '<option value="org:' + esc(o.id) + '">سازمان ' + esc(o.name) + "</option>"; }).join("") + "</select></div>" +
      '<textarea data-bb placeholder="متن کوتاه"></textarea>' +
      '<div class="gm-row"><input data-bi placeholder="لینک عکس (اختیاری)" style="flex:1" dir="ltr"><input type="file" accept="image/*" data-bfile></div>' +
      '<div class="gm-row"><select data-bl>' + links.map(function (l) { return '<option value="' + l[0] + '">' + l[1] + "</option>"; }).join("") + '</select><input data-bcustom placeholder="یا آدرس دلخواه https://…" dir="ltr" style="flex:1"><input data-bh type="number" value="24" style="width:80px" title="ساعت"> ساعت<button class="gamify-btn primary" data-send-bc>🚀 ارسال زنده</button></div></div>' +
      '<div class="gm-card"><b>اعلان‌های اخیر</b><table><tr><th>عنوان</th><th>هدف</th><th>لینک</th><th>زمان</th><th></th></tr>' + list.map(function (b) { return "<tr" + (!b.active ? ' style="opacity:.5"' : "") + "><td class=\"wrap\">" + esc(b.title) + "</td><td>" + esc(b.target) + "</td><td>" + esc(b.link || "—") + "</td><td>" + ago(b.createdAt) + "</td><td>" + (b.active ? '<button class="gamify-btn sm" data-del-bc="' + esc(b.id) + '">حذف</button>' : "") + "</td></tr>"; }).join("") + "</table></div>";
  }

  function renderSettings(d) {
    if (!d || !d.site) return '<div class="gamify-loading">در حال دریافت…</div>';
    var st = liveStore(); var local = (st && st.settings) || {};
    var site = Object.assign({}, local, d.site);
    var txt = d.textOverrides || {}; var ass = d.assetOverrides || {};
    var sections = [["feed", "فید"], ["stories", "استوری"], ["tournaments", "تورنمنت"], ["leagues", "لیگ‌ها"], ["messages", "گفت‌وگو"], ["shop", "فروشگاه"], ["leaderboard", "رتبه‌بندی"], ["daily", "چالش روزانه"], ["events", "رویدادها"], ["support", "ارتباط با مدیر"]];
    var hidden = Array.isArray(site.hiddenSections) ? site.hiddenSections : [];
    var h = '<div class="gm-card"><h3 style="margin:0 0 6px">⚙️ تنظیمات اصلی (برای همه، فوری)</h3>' +
      '<div class="gm-row"><label>عنوان سایت <input data-s="siteTitle" value="' + esc(site.siteTitle || "") + '"></label><label>شعار <input data-s="tagline" value="' + esc(site.tagline || "") + '"></label></div>' +
      '<div class="gm-row"><label style="flex:1">متن خوش‌آمد <input data-s="welcome" value="' + esc(site.welcome || "") + '" style="width:100%"></label></div>' +
      '<div class="gm-row"><label>لوگو (لینک یا آپلود) <input data-s="logo" value="' + esc(site.logo || "") + '" dir="ltr"></label><input type="file" accept="image/*" data-logo-file>' + (site.logo ? '<img src="' + esc(site.logo) + '" style="height:36px;border-radius:8px">' : "") + "</div>" +
      '<div class="gm-row"><label>زمان هر سؤال (ثانیه) <input data-s="roundSeconds" type="number" value="' + esc(site.roundSeconds || 25) + '" style="width:80px"></label><label>تعداد سؤال چالش روزانه <input data-s="dailyCount" type="number" value="' + esc(site.dailyCount || 5) + '" style="width:80px"></label></div>' +
      '<div class="gm-row">' + [["allowPostImages", "پست عکس‌دار مجاز"], ["allowPostAudio", "پست صوتی مجاز"], ["allowPostVideo", "ویدئوی ۶۰ ثانیه‌ای برای افراد مجاز"], ["moderatePosts", "پست با تأیید مدیر منتشر شود"], ["moderateStories", "استوری با تأیید مدیر منتشر شود"], ["chatEnabled", "گفت‌وگو فعال"], ["shopEnabled", "فروشگاه فعال"], ["assistantEnabled", "دستیار هوشمند فعال"], ["staffActivity", "فعالیت ربات‌ها/کادر"], ["botEnabled", "حریف رایانه‌ای فعال"]].map(function (k) { return '<label class="gm-toggle"><input type="checkbox" data-b="' + k[0] + '"' + (site[k[0]] !== undefined ? (site[k[0]] ? " checked" : "") : (k[0].indexOf("moderate") === 0 || k[0] === "allowPostVideo" ? "" : " checked")) + "> " + k[1] + "</label>"; }).join("") + "</div>" +
      '<div><b style="font-size:13px">بخش‌های پنهان:</b><div class="gm-row">' + sections.map(function (s) { return '<label class="gm-toggle"><input type="checkbox" data-hide="' + s[0] + '"' + (hidden.indexOf(s[0]) >= 0 ? " checked" : "") + "> " + s[1] + "</label>"; }).join("") + "</div></div>" +
      '<div><b style="font-size:13px">بنر بالای صفحه:</b><div class="gm-row"><input data-banner-text placeholder="متن بنر" value="' + esc(site.banners && site.banners[0] ? site.banners[0].text : "") + '" style="flex:1"><input data-banner-link placeholder="بخش (مثلاً tournaments)" value="' + esc(site.banners && site.banners[0] ? site.banners[0].link : "") + '"><input data-banner-color type="color" value="' + esc(site.banners && site.banners[0] && /^#/.test(site.banners[0].color) ? site.banners[0].color : "#f2ca7c") + '"></div></div>' +
      '<div class="gm-row"><button class="gamify-btn primary" data-save-site>💾 ذخیره و انتشار آنلاین</button><button class="gamify-btn sm" data-push-local>⬆️ انتشار تنظیمات پنل داخلی بازی (مدال‌ها، بانک وضعیت، خطوط کمکی…)</button></div></div>';
    h += '<div class="gm-card"><details open><summary>✏️ تغییر هر متن/جملهٔ بازی (' + fa(Object.keys(txt).length) + ')</summary><p style="font-size:12px;color:#cdbde0">متن دقیق فعلی را در ستون چپ و متن جدید را در ستون راست بنویس؛ بلافاصله برای همه عوض می‌شود. (برای حذف، متن جدید را خالی بگذار)</p><div id="gm-txt">' +
      Object.keys(txt).map(function (k) { return '<div class="gm-row gm-txt-row"><input class="t-from" value="' + esc(k) + '" style="flex:1"><span>→</span><input class="t-to" value="' + esc(txt[k]) + '" style="flex:1"></div>'; }).join("") +
      '<div class="gm-row gm-txt-row"><input class="t-from" placeholder="متن فعلی (مثلاً: جام هفتگی گیمیفای)" style="flex:1"><span>→</span><input class="t-to" placeholder="متن جدید" style="flex:1"></div></div><div class="gm-row"><button class="gamify-btn sm" data-add-txt>+ ردیف</button><button class="gamify-btn primary sm" data-save-txt>💾 ذخیرهٔ متن‌ها</button></div></details></div>';
    h += '<div class="gm-card"><details><summary>🖼️ جایگزینی تصاویر (آواتارها، نماد دسته‌ها، جام…) (' + fa(Object.keys(ass).length) + ')</summary><p style="font-size:12px;color:#cdbde0">آدرس تصویر فعلی (مثلاً /assets/avatars/01.png یا /assets/trophy.svg) و تصویر جدید (لینک یا آپلود). هر img با این src به‌صورت زنده عوض می‌شود.</p><div id="gm-ass">' +
      Object.keys(ass).map(function (k) { return '<div class="gm-row gm-ass-row"><input class="a-from" value="' + esc(k) + '" dir="ltr" style="flex:1"><span>→</span><input class="a-to" value="' + esc(ass[k]) + '" dir="ltr" style="flex:1"><input type="file" accept="image/*" class="a-file"></div>'; }).join("") +
      '<div class="gm-row gm-ass-row"><input class="a-from" placeholder="/assets/..." dir="ltr" style="flex:1"><span>→</span><input class="a-to" placeholder="https://… یا آپلود" dir="ltr" style="flex:1"><input type="file" accept="image/*" class="a-file"></div></div><div class="gm-row"><button class="gamify-btn sm" data-add-ass>+ ردیف</button><button class="gamify-btn primary sm" data-save-ass>💾 ذخیرهٔ تصاویر</button></div></details></div>';
    return h;
  }

  function renderCategories() {
    return '<div class="gm-card"><h3 style="margin:0 0 6px">🗂️ دسته‌های سؤال (نام، نماد، رنگ، فعال)</h3><p style="font-size:12px;color:#cdbde0">نماد می‌تواند ایموجی یا لینک تصویر باشد. در نبرد زنده، قبیله و تورنمنت استفاده می‌شود.</p><table><tr><th>شناسه</th><th>نام</th><th>زیرعنوان</th><th>نماد</th><th>رنگ</th><th>فعال</th><th></th></tr>' +
      S.categories.map(function (c) { return '<tr data-cat="' + esc(c.id) + '"><td dir="ltr">' + esc(c.id) + '</td><td><input class="c-name" value="' + esc(c.name) + '" style="width:130px"></td><td><input class="c-sub" value="' + esc(c.subtitle || "") + '" style="width:150px"></td><td><input class="c-icon" value="' + esc(c.icon || "") + '" style="width:110px"></td><td><input class="c-color" type="color" value="' + esc(/^#/.test(c.color || "") ? c.color : "#a98cf7") + '"></td><td><input class="c-active" type="checkbox"' + (c.active !== 0 ? " checked" : "") + '></td><td><button class="gamify-btn sm" data-save-cat="' + esc(c.id) + '">ذخیره</button></td></tr>'; }).join("") +
      '</table><div class="gm-row"><input data-newcat placeholder="شناسهٔ دستهٔ جدید (انگلیسی)" dir="ltr"><input data-newcat-name placeholder="نام دسته"><button class="gamify-btn sm" data-add-cat>+ افزودن دسته</button></div></div>';
  }

  function fileToData(file, cb) { var r = new FileReader(); r.onload = function () { cb(String(r.result || "")); }; r.readAsDataURL(file); }
  function userAct(action, extra) {
    var body = Object.assign({ userId: S.sel.id }, extra || {});
    api("/api/admin?action=" + action, "POST", body).then(function (r) {
      if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا"));
      toast("✅ انجام شد");
      if (action === "delete-user") S.sel = {};
      load();
    });
  }

  function bind(ov) {
    ov.querySelector("[data-x]").addEventListener("click", close);
    ov.querySelectorAll("[data-tab]").forEach(function (b) { b.addEventListener("click", function () { S.tab = b.getAttribute("data-tab"); S.page = 1; S.data = null; render(); load(); }); });
    var kind = ov.querySelector("[data-kind]"); if (kind) kind.addEventListener("change", function () { S.kind = kind.value; S.page = 1; load(); });
    var q = ov.querySelector("[data-q]"); var doSearch = function () { S.q = q ? q.value.trim() : ""; S.page = 1; load(); };
    if (q) q.addEventListener("keydown", function (e) { if (e.key === "Enter") doSearch(); });
    var sb = ov.querySelector("[data-search]"); if (sb) sb.addEventListener("click", doSearch);
    ov.querySelectorAll("[data-page]").forEach(function (b) { b.addEventListener("click", function () { S.page = Number(b.getAttribute("data-page")); load(); }); });
    ov.querySelectorAll("[data-user]").forEach(function (b) { b.addEventListener("click", function () { var id = b.getAttribute("data-user"); S.sel = (S.data.users || []).filter(function (u) { return u.id === id; })[0] || {}; render(); var c = document.getElementById("gm-user-card"); if (c) c.scrollIntoView({ behavior: "smooth" }); }); });
    var un = ov.querySelector("[data-unsel]"); if (un) un.addEventListener("click", function () { S.sel = {}; render(); });
    var rv = ov.querySelector("[data-reveal]"); if (rv) rv.addEventListener("click", function () { api("/api/admin?action=reveal-contact", "POST", { userId: S.sel.id }).then(function (r) { if (r.body && r.body.ok) { S.revealed[S.sel.id] = r.body; render(); } }); });
    ov.querySelectorAll("[data-act]").forEach(function (b) {
      b.addEventListener("click", function () {
        var a = b.getAttribute("data-act");
        if (a === "set-contact") { var contact = {}; var phone = ov.querySelector("[data-phone]").value.trim(), email = ov.querySelector("[data-email]").value.trim(); if (phone) contact.phone = phone; if (email) contact.email = email; if (!phone && !email) return toast("موبایل یا ایمیل را وارد کن"); return userAct(a, contact); }
        if (a === "set-video-permission") return userAct(a, { allowed: ov.querySelector("[data-user-video]").checked });
        if (a === "credentials") { var username=prompt("نام کاربری یکتا:"); if(!username)return;var password=prompt("رمز جدید (حداقل ۴ نویسه):");if(!password)return;return api("/api/account","POST",{action:"admin-reset",userId:S.sel.id,username:username,password:password}).then(function(r){toast(r.body&&r.body.ok?"نام کاربری و رمز ذخیره شد":r.body&&r.body.error||"خطا");}); } if (a === "set-name") return userAct(a, { name: ov.querySelector("[data-name]").value });
        if (a === "set-org") return userAct(a, { orgId: ov.querySelector("[data-org]").value });
        if (a === "add-to-tribe") { var t = ov.querySelector("[data-tribe]").value; if (!t) return toast("قبیله را انتخاب کن"); return userAct(a, { tribeId: t }); }
        if (a === "set-coins") return userAct(a, { delta: Number(ov.querySelector("[data-coins]").value) || 0 });
        if (a === "notify-user") return userAct(a, { title: ov.querySelector("[data-ntitle]").value, body: ov.querySelector("[data-nbody]").value });
        if (a === "delete-user" && !confirm("حساب حذف شود؟ این کار برگشت‌پذیر نیست.")) return;
        userAct(a);
      });
    });
    ov.querySelectorAll("[data-av]").forEach(function (img) { img.addEventListener("click", function () { userAct("set-avatar", { img: Number(img.getAttribute("data-av")) }); }); });
    var mw = ov.querySelector("[data-match-with]"); if (mw) mw.addEventListener("click", function () { S.matchA = mw.getAttribute("data-match-with"); S.tab = "match"; S.q = ""; render(); load(); });
    // match
    var mq = ov.querySelector("[data-mq]"); var ms = ov.querySelector("[data-msearch]"); if (ms) ms.addEventListener("click", function () { S.q = mq.value.trim(); load(); });
    var ma = ov.querySelector("[data-ma]"), mb = ov.querySelector("[data-mb]");
    if (ma) ma.addEventListener("change", function () { S.matchA = ma.value; }); if (mb) mb.addEventListener("change", function () { S.matchB = mb.value; });
    var gm = ov.querySelector("[data-go-match]"); if (gm) gm.addEventListener("click", function () {
      if (!S.matchA || !S.matchB) return toast("هر دو بازیکن را انتخاب کن");
      api("/api/pvp?action=admin-match", "POST", { a: S.matchA, b: S.matchB, category: ov.querySelector("[data-mcat]").value }).then(function (r) {
        if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا"));
        toast("⚔️ درخواست مسابقه برای هر دو ارسال شد");
      });
    });
    // broadcast
    var bf = ov.querySelector("[data-bfile]"); if (bf) bf.addEventListener("change", function () { if (bf.files[0]) fileToData(bf.files[0], function (d) { if (d.length > 400000) return toast("عکس بزرگ است؛ لینک بگذار یا کوچکش کن"); ov.querySelector("[data-bi]").value = d; }); });
    var sbc = ov.querySelector("[data-send-bc]"); if (sbc) sbc.addEventListener("click", function () {
      var link = ov.querySelector("[data-bcustom]").value.trim() || ov.querySelector("[data-bl]").value;
      api("/api/admin?action=broadcast", "POST", { title: ov.querySelector("[data-bt]").value, body: ov.querySelector("[data-bb]").value, image: ov.querySelector("[data-bi]").value, link: link, target: ov.querySelector("[data-btarget]").value, hours: Number(ov.querySelector("[data-bh]").value) || 24 }).then(function (r) {
        if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا")); toast("📣 اعلان برای همه ارسال شد"); load();
      });
    });
    ov.querySelectorAll("[data-del-bc]").forEach(function (b) { b.addEventListener("click", function () { api("/api/admin?action=delete-broadcast", "POST", { id: b.getAttribute("data-del-bc") }).then(load); }); });
    // settings
    var lf = ov.querySelector("[data-logo-file]"); if (lf) lf.addEventListener("change", function () { if (lf.files[0]) fileToData(lf.files[0], function (d) { if (d.length > 150000) return toast("لوگو بزرگ است (حداکثر ~۱۰۰KB)"); ov.querySelector('[data-s="logo"]').value = d; }); });
    var ss = ov.querySelector("[data-save-site]"); if (ss) ss.addEventListener("click", function () {
      var settings = {};
      ov.querySelectorAll("[data-s]").forEach(function (i) { var k = i.getAttribute("data-s"); settings[k] = i.type === "number" ? Number(i.value) : i.value; });
      ov.querySelectorAll("[data-b]").forEach(function (i) { settings[i.getAttribute("data-b")] = i.checked; });
      settings.hiddenSections = Array.from(ov.querySelectorAll("[data-hide]")).filter(function (i) { return i.checked; }).map(function (i) { return i.getAttribute("data-hide"); });
      var bt = ov.querySelector("[data-banner-text]").value.trim();
      settings.banners = bt ? [{ id: "b1", text: bt, link: ov.querySelector("[data-banner-link]").value.trim(), color: ov.querySelector("[data-banner-color]").value }] : [];
      api("/api/admin?action=publish-settings", "POST", { settings: settings }).then(function (r) { if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا")); toast("✅ تنظیمات برای همه منتشر شد"); if (window.__gamifyRT) window.__gamifyRT.reloadConfig(); load(); });
    });
    var pl = ov.querySelector("[data-push-local]"); if (pl) pl.addEventListener("click", function () {
      var st = liveStore(); if (!st || !st.settings) return toast("تنظیمات محلی پیدا نشد");
      var copy = Object.assign({}, st.settings); delete copy.logo; // لوگو جداگانه
      api("/api/admin?action=publish-settings", "POST", { settings: copy }).then(function (r) { if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا")); toast("✅ تنظیمات پنل داخلی برای همه منتشر شد"); });
    });
    var at = ov.querySelector("[data-add-txt]"); if (at) at.addEventListener("click", function () { ov.querySelector("#gm-txt").insertAdjacentHTML("beforeend", '<div class="gm-row gm-txt-row"><input class="t-from" placeholder="متن فعلی" style="flex:1"><span>→</span><input class="t-to" placeholder="متن جدید" style="flex:1"></div>'); });
    var stx = ov.querySelector("[data-save-txt]"); if (stx) stx.addEventListener("click", function () {
      var map = {}; ov.querySelectorAll(".gm-txt-row").forEach(function (r) { var f = r.querySelector(".t-from").value.trim(), t = r.querySelector(".t-to").value; if (f && t !== "") map[f] = t; });
      api("/api/admin?action=publish-settings", "POST", { textOverrides: map }).then(function (r) { if (!r.body || r.body.error) return toast("⚠️ خطا"); toast("✅ متن‌ها برای همه عوض شد"); if (window.__gamifyRT) window.__gamifyRT.reloadConfig(); load(); });
    });
    var aa = ov.querySelector("[data-add-ass]"); if (aa) aa.addEventListener("click", function () { ov.querySelector("#gm-ass").insertAdjacentHTML("beforeend", '<div class="gm-row gm-ass-row"><input class="a-from" placeholder="/assets/..." dir="ltr" style="flex:1"><span>→</span><input class="a-to" placeholder="https://…" dir="ltr" style="flex:1"><input type="file" accept="image/*" class="a-file"></div>'); bindAssFiles(ov); });
    bindAssFiles(ov);
    var sas = ov.querySelector("[data-save-ass]"); if (sas) sas.addEventListener("click", function () {
      var map = {}; ov.querySelectorAll(".gm-ass-row").forEach(function (r) { var f = r.querySelector(".a-from").value.trim(), t = r.querySelector(".a-to").value.trim(); if (f && t) map[f] = t; });
      api("/api/admin?action=publish-settings", "POST", { assetOverrides: map }).then(function (r) { if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا")); toast("✅ تصاویر برای همه عوض شد"); if (window.__gamifyRT) window.__gamifyRT.reloadConfig(); load(); });
    });
    // categories
    ov.querySelectorAll("[data-save-cat]").forEach(function (b) { b.addEventListener("click", function () { var tr = b.closest("tr"); api("/api/admin?action=set-category", "POST", { id: b.getAttribute("data-save-cat"), name: tr.querySelector(".c-name").value, subtitle: tr.querySelector(".c-sub").value, icon: tr.querySelector(".c-icon").value, color: tr.querySelector(".c-color").value, active: tr.querySelector(".c-active").checked }).then(function (r) { toast(r.body && r.body.ok ? "✅ ذخیره شد" : "⚠️ خطا"); S.categories = []; load(); }); }); });
    var ac = ov.querySelector("[data-add-cat]"); if (ac) ac.addEventListener("click", function () { var id = ov.querySelector("[data-newcat]").value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, ""); if (!id) return toast("شناسهٔ انگلیسی لازم است"); api("/api/admin?action=set-category", "POST", { id: id, name: ov.querySelector("[data-newcat-name]").value || id, active: true }).then(function () { S.categories = []; load(); }); });
  }
  function bindAssFiles(ov) { ov.querySelectorAll(".a-file").forEach(function (f) { if (f.__b) return; f.__b = 1; f.addEventListener("change", function () { if (f.files[0]) fileToData(f.files[0], function (d) { if (d.length > 300000) return toast("تصویر بزرگ است؛ کوچکش کن"); f.parentNode.querySelector(".a-to").value = d; }); }); }); }

  // ---------- دکمهٔ شناور مدیر ----------
  function mountFab() {
    if (document.getElementById("gm-admin-fab")) return;
    var b = document.createElement("button"); b.id = "gm-admin-fab"; b.textContent = "🛠️"; b.title = "پنل مدیریت سرور";
    b.addEventListener("click", open); document.body.appendChild(b);
  }
  function unmountFab() { var b = document.getElementById("gm-admin-fab"); if (b) b.remove(); }
  function check() {
    if (localAdmin() || S.token) mountFab(); else unmountFab();
  }
  window.__gamifyAdmin = { open: open, login: login, token: function () { return S.token; } };

  function boot() {
    check(); setInterval(check, 4000);
    // اگر مدیر در پنل داخلی بازی وارد شد ولی هنوز توکن سرور ندارد → یک‌بار پیشنهاد ورود سرور
    var asked = false;
    setInterval(function () { if (!asked && localAdmin() && !S.token) { asked = true; setTimeout(function () { toast("🛠️ برای مدیریت سرور، روی دکمهٔ 🛠️ بزن و کد مدیریت را وارد کن"); }, 1500); } }, 3000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else setTimeout(boot, 300);
})();
// MOD-FIX-START — دست نزن؛ این بلوک را اسکریپت نصب (apply-mod-fix.sh) از نو می‌سازد
/* ================= مُدِرِیشن واقعی گیمیفای (نسخهٔ ۲) =================
   ریشهٔ مشکل (با شواهد قطعی):
     • خودِ سرور این قابلیت را دارد و پستِ تأییدنشده را برای دیگران منتشر نمی‌کند.
     • ولی تیک‌های «بررسی پست‌ها پیش از انتشار» و «بررسی استوری‌ها پیش از انتشار»
       در پنل، فقط در مرورگرِ همان دستگاه ذخیره می‌شوند (برنامهٔ اصلی هیچ تماس
       شبکه‌ای ندارد؛ حتی راهنمای خودش می‌گوید فایل admin-config.json را دستی
       آپلود کن). پس تنظیم سرور همیشه «خاموش» می‌مانْد و همه‌چیز فوری منتشر می‌شد.

   این قطعه (برای مدیر، بی‌نیاز از rebuild):
     ۱) هر تغییری در آن دو تیک — هر جا: «پروفایل و تنظیمات» بازی یا پنل مدیریت —
        **همان لحظه** (بدون تأخیر) می‌گیرد و روی سرور اعمال می‌کند؛ پس از آن سرور
        مرجعِ واقعی است: تا تأیید مدیر، پست/استوری در فید هیچ‌کس نمی‌نشیند.
     ۲) دوطرفه همگام است، ولی «تصمیم تازهٔ مدیر» برنده است: اگر مدیر همین حالا تیک
        را زده باشد، همگام‌سازی سرور تا ۱۰ ثانیه رویش نمی‌نشیند (تا دوباره خاموشش
        نکند) — بعد از آن سرور و مرورگر یکی می‌شوند.
     ۳) به کاربر بازخورد می‌دهد: اگر سرور پست/استوری‌اش را «در انتظار تأیید» ثبت
        کند، همان لحظه در فید خودش با برچسب «در انتظار تأیید» دیده می‌شود و پیام
        «⏳ برای تأیید مدیر رفت» می‌آید.
     ۴) وقتی تیک روشن است، یک‌بار به مدیر یادآوری می‌کند که لایک/کامنت زنده و
        ایموجی نبرد قبیله‌ای هم در صف می‌مانند (رکورد فنی) و ابزار drain هست.
   ==================================================================== */
(function () {
  try {
    if (window.__gamifyModFix) return;
    window.__gamifyModFix = true;

    var LS = "gamify2-store-v2";
    var KEY_P = "moderatePosts", KEY_S = "moderateStories";
    var POLL_MS = 2500;            // شبکهٔ اطمینان (در حالت عادی لازم نمی‌شود)
    var SRV_MS = 45000;            // نگاه به وضعیت سرور
    var DEBOUNCE_MS = 300;         // اعمال تقریباً آنی
    var FRESH_MS = 10000;          // تصمیم تازهٔ مدیر تا این مدت محترم است

    var me = { role: "", id: "", at: 0 };
    var lastLocal = null;          // {p,s}
    var srv = null;                // {p,s}
    var inited = false;
    var pushTimer = null, pushing = false, queuedIntent = null, lastLocalEditAt = 0;
    var hooked = false;
    var lastPush = null;           // {f, prev, at} — آخرین اعمالی که فرستادیم
    var STALE_MS = 5000;           // پنجرهٔ خنثی‌کردن همگام‌سازیِ دیررس
    var userIntentAt = 0;          // آخرین باری که کاربر واقعاً تیک را زد (کلیک/تغییر)
    var once = {};
    var stats = { pushed: 0, applied: 0, staleFetches: 0, reasserts: 0, lastPushAt: 0, lastPushOk: null, errors: 0, pendingSeen: 0, detectedBy: "" };

    /* ---------- ابزارها ---------- */
    function readStore() {
      try {
        if (typeof window.__gamifyLiveGet === "function") {
          var s = window.__gamifyLiveGet();
          if (s && typeof s === "object") return s;
        }
      } catch (e) {}
      try { return JSON.parse(localStorage.getItem(LS) || "null"); } catch (e) { return null; }
    }
    function writeStore(fn) {
      var done = false;
      try {
        if (typeof window.__gamifyLiveSet === "function") { window.__gamifyLiveSet(fn); done = true; }
      } catch (e) { done = false; }
      try {
        var raw = localStorage.getItem(LS);
        if (raw) { localStorage.setItem(LS, JSON.stringify(fn(JSON.parse(raw) || {}))); done = true; }
      } catch (e) {}
      return done;
    }
    function toast(msg) {
      try { if (typeof window.__gamifyToast === "function") { window.__gamifyToast(msg); return; } } catch (e) {}
      try {
        var d = document.createElement("div");
        d.textContent = msg;
        d.style.cssText = "position:fixed;z-index:99999;bottom:22px;right:22px;background:#2c2039;color:#fff;border:1px solid #a98cf7;border-radius:14px;padding:10px 14px;font:600 13px Tahoma;box-shadow:0 8px 30px #0008";
        document.body.appendChild(d);
        setTimeout(function () { d.style.opacity = "0"; d.style.transition = "opacity .4s"; setTimeout(function () { d.remove(); }, 450); }, 3200);
      } catch (e) {}
    }
    function noteUserIntent() { userIntentAt = Date.now(); }
    function toastOnce(key, msg) {
      if (once[key]) return;
      once[key] = 1;
      toast(msg);
    }
    var META_KEY = "gamify2-server";           // مثل ۱۰-sync: توکن نشست کاربر
    var ADMIN_TOK_KEY = "gamify2-admin-token"; // مثل ۹۰-admin: توکن مدیریتی امضاشده
    function hasAdminToken() {
      try { return !!localStorage.getItem(ADMIN_TOK_KEY); } catch (e) { return false; }
    }
    /* همان هدرهایی که خودِ پچ‌های برنامه می‌فرستند؛ بدون توکن، سرور جواب ۴۰۳ می‌دهد */
    function authHeaders() {
      var h = {};
      try { var meta = JSON.parse(localStorage.getItem(META_KEY) || "{}") || {}; if (meta.token) h["x-gamify-token"] = String(meta.token); } catch (e) {}
      try { var at = localStorage.getItem(ADMIN_TOK_KEY); if (at) h["x-admin-token"] = String(at); } catch (e) {}
      try {
        var st = readStore(), p = st && st.profile;
        if (p && p.id) { h["x-gamify-user-id"] = String(p.id); h["x-gamify-local-id"] = String(p.id); }
        if (p && p.phone) h["x-gamify-phone"] = String(p.phone);
        if (p && p.email) h["x-gamify-email"] = String(p.email);
      } catch (e) {}
      return h;
    }
    function api(path, method, body) {
      var o = { method: method || "GET", credentials: "include", headers: authHeaders() };
      if (body !== undefined) { o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(body); }
      return fetch(path, o).then(function (r) {
        return r.text().then(function (t) { var j; try { j = JSON.parse(t); } catch (e) { j = { error: "server " + r.status }; } return { status: r.status, body: j }; })
          .catch(function () { return { status: r.status, body: null }; });
      }).catch(function () { return { status: 0, body: { error: "network" } }; });
    }

    /* ---------- شناسایی نقش من ---------- */
    function refreshMe(force) {
      if (!force && me.role && Date.now() - me.at < 60000) return Promise.resolve(me);
      return api("/api/me").then(function (r) {
        var j = r && r.body;
        if (j && !j.error && j.id) me = { role: String(j.role || "player"), id: String(j.id), at: Date.now() };
        return me;
      });
    }
    function isAdminLocal() {
      try { var st = readStore(); return !!(st && (st.admin === true || (st.profile && st.profile.role === "admin"))); } catch (e) { return false; }
    }
    function canPush() { return me.role === "admin" || isAdminLocal() || hasAdminToken(); }

    /* ---------- خواندن/نوشتن دو تیک ---------- */
    function flagsFromStore(st) {
      var s = (st && st.settings) || {};
      return { p: s[KEY_P] === true, s: s[KEY_S] === true };
    }
    function readLocal() { return flagsFromStore(readStore()); }
    function same(a, b) { return !!a && !!b && a.p === b.p && a.s === b.s; }
    function applyLocal(f) {   // سرور → مرورگر (فقط همین دو کلید، بدون دست‌زدن به بقیه)
      lastLocal = { p: !!f.p, s: !!f.s };   // پیش از نوشتن: نوشتهٔ خودمان «تصمیم کاربر» نیست
      var changed = writeStore(function (st) {
        st = st || {};
        var settings = Object.assign({}, st.settings || {});
        if (settings[KEY_P] === f.p && settings[KEY_S] === f.s) return st;
        settings[KEY_P] = f.p; settings[KEY_S] = f.s;
        return Object.assign({}, st, { settings: settings });
      });
      lastLocal = readLocal();              // اگر نوشتن انجام نشد، دوباره همگام کن
      return changed;
    }

    /* ---------- وضعیت سرور ---------- */
    var fetchSeq = 0;
    function fetchServer() {
      var seq = ++fetchSeq;
      var started = Date.now();
      return fetch("/admin-config.json?t=" + started, { cache: "no-cache", credentials: "include" })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) {
          if (!j || !j.settings) return srv;
          /* پاسخِ دیررس: یا واکشیِ تازه‌تری بعدش شروع شده، یا بعد از آخرین اعمالِ ما آغاز شده
             بود (پس عکسِ قدیمی است) — به آن اعتماد نمی‌کنیم. */
          if (seq !== fetchSeq) { stats.staleFetches = (stats.staleFetches || 0) + 1; return srv; }
          if (lastPush && started < lastPush.at) { stats.staleFetches = (stats.staleFetches || 0) + 1; return srv; }
          srv = { p: j.settings[KEY_P] === true, s: j.settings[KEY_S] === true };
          return srv;
        }).catch(function () { return srv; });
    }

    /* ---------- فرستادن تیک‌ها به سرور ---------- */
    function drainQueue() {
      if (pushing || !queuedIntent) return;
      var q = queuedIntent; queuedIntent = null;
      var cur = lastPush ? lastPush.f : null;
      if (cur && same(q.f, cur)) return;           // همان چیزی است که همین حالا اعمال شد
      pushFlags(q.f, q.prev);
    }
    function pushFlags(f, prev) {
      if (pushing) { queuedIntent = { f: { p: !!f.p, s: !!f.s }, prev: prev || null }; return Promise.resolve(false); }
      pushing = true;
      return api("/api/admin?action=set-moderation", "POST", { moderatePosts: !!f.p, moderateStories: !!f.s }).then(function (r) {
        pushing = false;
        var j = r && r.body;
        if ((r && r.status === 403) || (j && String(j.error || "").includes("forbidden"))) {
          stats.errors++;
          stats.lastPushOk = false;
          toastOnce("noadmin", "⛔ سرور این حساب را «مدیر» نمی‌شناسد. یک‌بار در پنل مدیریت با کد مدیریت وارد شو، یا در کنسول سرور بزن: node /root/mod-fix/mod-fix.cjs both on");
          drainQueue();
          return false;
        }
        if (!j || j.error) {
          stats.errors++;
          stats.lastPushOk = false;
          toastOnce("pusherr", "⚠️ اعمال تیک روی سرور ناموفق بود؛ دوباره تلاش می‌شود.");
          drainQueue();
          return false;
        }
        stats.pushed++; stats.lastPushAt = Date.now(); stats.lastPushOk = true;
        lastPush = { f: { p: !!f.p, s: !!f.s }, prev: prev || null, at: Date.now() };
        srv = { p: !!f.p, s: !!f.s };
        lastLocal = { p: !!f.p, s: !!f.s };
        toast(f.p || f.s
          ? "🛡️ روی سرور اعمال شد: " + (f.p ? "پست‌ها" : "") + (f.p && f.s ? " و " : "") + (f.s ? "استوری‌ها" : "") + " فقط با تأیید تو منتشر می‌شوند."
          : "✅ روی سرور اعمال شد: پست و استوری بدون تأیید منتشر می‌شوند.");
        setTimeout(function () { verifyAfterPush(lastPush ? lastPush.f : { p: !!f.p, s: !!f.s }); }, 1500);
        drainQueue();
        if (f.p || f.s) toastOnce("carrier-warn", "ℹ️ یادت باشد: با روشن‌بودن این تیک، لایک/کامنت زنده و ایموجی نبرد قبیله‌ای هم در صف می‌مانند؛ برای رفعشان ابزار mod-fix (drain) یا بستهٔ E۲ است.");
        return true;
      });
    }
    /* راستی‌آزمایی: اگر کسی/چیزی بعد از اعمال ما مقدار را برگرداند، یک‌بار دوباره اعمال می‌کنیم */
    function verifyAfterPush(intent) {
      if (!intent) return;
      fetchServer().then(function (cur) {
        if (!cur || same(cur, intent)) return;
        if (Date.now() - lastLocalEditAt > 120000) return;      // تصمیم کهنه؛ دست نمی‌زنیم
        stats.reasserts = (stats.reasserts || 0) + 1;
        applyLocal(intent);
        lastLocal = intent;
        schedulePush(intent, cur);
      });
    }
    function schedulePush(f, prev) {
      if (!canPush()) return;
      if (pushTimer) clearTimeout(pushTimer);
      pushTimer = setTimeout(function () { pushTimer = null; pushFlags(f, prev); }, DEBOUNCE_MS);
    }

    /* ---------- تشخیص آنیِ تغییر تیک (بدون تأخیر) ----------
       برنامه هنگام هر تغییر، localStorage["gamify2-store-v2"] را می‌نویسد؛ پس با
       وصل‌شدن به Storage.prototype.setItem، تغییر تیک همان لحظه گرفته می‌شود. */
    function hookStorage() {
      try {
        var proto = window.Storage && window.Storage.prototype;
        var orig = proto && proto.setItem;
        if (typeof orig !== "function" || hooked) return hooked;
        proto.setItem = function (k, v) {
          var r = orig.apply(this, arguments);
          try { if (String(k) === LS) onChangeWrite(); } catch (e) {}
          return r;
        };
        hooked = true;
        return true;
      } catch (e) { return false; }
    }
    function onChangeWrite() {
      if (!inited) return;                                  // در حال همگام‌سازی اولیه
      var local = readLocal();
      if (same(local, lastLocal)) return;                    // تغییر بی‌ربط به این دو تیک
      var prev = lastLocal;
      lastLocal = local;
      /* سه حالت را از هم جدا می‌کنیم:
         ۱) کاربر همین حالا تیک را زده (کلیک) → تصمیم او، به سرور می‌رود.
         ۲) نوشته از همگام‌سازیِ تنظیمات سرور آمده (مقدارش همان چیزی است که سرور دارد) → کاری لازم نیست.
         ۳) همگام‌سازیِ دیررس، تصمیمِ تازهٔ مدیر را برگردانده → تصمیم مدیر را برمی‌گردانیم. */
      /* معیارِ ساده و دقیق: «آیا کاربر بعد از آخرین اعمالِ ما، تیک را دوباره زده؟»
         اگر نه و مقدارِ نوشته‌شده همان مقدارِ قبلی باشد، این نوشته از همگام‌سازیِ سرور
         آمده (snapshot دیررس) و نباید تصمیم تازهٔ مدیر را خراب کند. */
      var clickedSincePush = lastPush ? (userIntentAt > lastPush.at) : true;
      var looksStale = lastPush && !clickedSincePush && (Date.now() - lastPush.at) < STALE_MS && same(local, lastPush.prev) && !same(local, lastPush.f);
      if (looksStale) {
        stats.staleReverts = (stats.staleReverts || 0) + 1;
        stats.detectedBy = "stale-sync";
        applyLocal(lastPush.f);
        lastLocal = lastPush.f;
        schedulePush(lastPush.f, local);
        return;
      }
      if (!clickedSincePush && srv && same(local, srv)) { stats.cfgWrites = (stats.cfgWrites || 0) + 1; stats.detectedBy = "cfg-sync"; return; }
      lastLocalEditAt = Date.now();
      stats.detectedBy = "setItem";
      schedulePush(local, prev);
    }

    /* ---------- حلقهٔ دوطرفه ----------
       قاعده: در «اولین» همگام‌سازی، سرور مرجع است؛ بعد از آن هر تغییرِ محلیِ تازه
       به سرور می‌رود و تغییرِ سرور هم روی مرورگر می‌نشیند — جز تصمیم تازهٔ مدیر. */
    function startInit() {
      return fetchServer().then(function (s) {
        var local = readLocal();
        if (s && ((s.p !== local.p) || (s.s !== local.s))) { applyLocal(s); stats.applied++; }
        lastLocal = readLocal();
        inited = true;
        return lastLocal;
      });
    }
    function tick() {
      if (!inited) { startInit(); return; }
      var local = readLocal();
      if (!same(local, lastLocal)) {
        var prev = lastLocal;
        lastLocal = local;
        var clickedSincePushP = lastPush ? (userIntentAt > lastPush.at) : true;
        var staleRev = lastPush && !clickedSincePushP && (Date.now() - lastPush.at) < STALE_MS && same(local, lastPush.prev) && !same(local, lastPush.f);
        if (!clickedSincePushP && srv && same(local, srv)) { stats.cfgWrites = (stats.cfgWrites || 0) + 1; stats.detectedBy = "cfg-sync"; return; }
        if (staleRev) {
          stats.staleReverts = (stats.staleReverts || 0) + 1;
          stats.detectedBy = "stale-sync";
          applyLocal(lastPush.f);
          lastLocal = lastPush.f;
          schedulePush(lastPush.f, local);
          return;
        }
        lastLocalEditAt = Date.now();
        if (stats.detectedBy !== "setItem") stats.detectedBy = "poll";
        schedulePush(local, prev);
        return;
      }
      if (srv && ((srv.p !== local.p) || (srv.s !== local.s))) {
        /* خودترمیمی: اگر تصمیمِ تازهٔ مدیر با سرور ناهمخوان است (اعمالی گم شده)، دوباره می‌فرستیم */
        var mineFresh = lastPush && same(local, lastPush.f) && (Date.now() - lastPush.at) < 60000;
        if (mineFresh && canPush() && (Date.now() - (stats.lastPushAt || 0) > 2000)) {
          stats.selfHeals = (stats.selfHeals || 0) + 1;
          schedulePush(local, srv);
          return;
        }
        if (Date.now() - lastLocalEditAt < FRESH_MS) return;  // تصمیم تازهٔ مدیر محترم است
        applyLocal(srv);
        lastLocal = srv;
        stats.applied++;
      }
    }
    function srvTick() {
      fetchServer().then(function (s) {
        if (!s) return;
        if (!inited) { var l = readLocal(); if (s.p !== l.p || s.s !== l.s) { applyLocal(s); stats.applied++; } lastLocal = readLocal(); inited = true; }
        var local = readLocal();
        var fresh = Date.now() - lastLocalEditAt < FRESH_MS;
        if (!fresh && (s.p !== local.p || s.s !== local.s)) { applyLocal(s); lastLocal = s; stats.applied++; }
        if (s.p || s.s) toastOnce("mod-on", "🛡️ «بررسی پیش از انتشار» روشن است: پست/استوری تا تأیید مدیر منتشر نمی‌شود.");
      });
    }

    /* ---------- بازخورد «در انتظار تأیید» روی پست/استوری خودم ---------- */
    var PENDING_TEXT = {
      post: "⏳ پستت برای تأیید مدیر فرستاده شد؛ بعد از تأیید برای همه منتشر می‌شود.",
      story: "⏳ استوری‌ات برای تأیید مدیر فرستاده شد؛ بعد از تأیید برای همه منتشر می‌شود."
    };
    function markPending(kind, id) {
      if (!id) return false;
      var key = String(id);
      var changed = false;
      writeStore(function (st) {
        st = st || {};
        if (kind === "post") {
          var posts = Array.isArray(st.posts) ? st.posts : [];
          var np = posts.map(function (p) { if (p && String(p.id) === key && p.status !== "pending") { changed = true; return Object.assign({}, p, { status: "pending" }); } return p; });
          return changed ? Object.assign({}, st, { posts: np }) : st;
        }
        var stories = Array.isArray(st.stories) ? st.stories : [];
        var ns = stories.map(function (s) { if (s && String(s.id) === key && s.status !== "pending") { changed = true; return Object.assign({}, s, { status: "pending" }); } return s; });
        return changed ? Object.assign({}, st, { stories: ns }) : st;
      });
      if (changed) { stats.pendingSeen++; toastOnce("pend-" + kind, PENDING_TEXT[kind] || PENDING_TEXT.post); }
      return changed;
    }
    var origFetch = window.fetch;
    if (typeof origFetch === "function") {
      window.fetch = function (input, init) {
        var url = "";
        try { url = String((input && input.url) || input); } catch (e) { url = ""; }
        var method = String((init && init.method) || (input && input.method) || "GET").toUpperCase();
        var kind = null;
        if (method === "POST" && /\/api\/feed\?type=post\b/.test(url)) kind = "post";
        else if (method === "POST" && /\/api\/feed\?type=story\b/.test(url)) kind = "story";
        var p = origFetch.apply(window, arguments);
        if (kind) {
          p.then(function (resp) {
            try {
              if (!resp || !resp.clone) return;
              resp.clone().json().then(function (j) {
                if (j && j.status === "pending" && j.id) markPending(kind, j.id);
              }).catch(function () {});
            } catch (e) {}
          });
        }
        return p;
      };
    }

    /* ---------- راه‌اندازی ---------- */
    /* تسویه‌گر: اگر به هر دلیلی تصمیمِ مدیر به سرور نرسیده باشد، در نهایت می‌رسد */
    function reconcile() {
      if (!canPush() || pushing || queuedIntent) return;
      if (Date.now() - (stats.reconcileAt || 0) < 15000) return;
      var local = readLocal();
      if (!srv || same(local, srv)) return;
      if (!lastLocalEditAt || Date.now() - lastLocalEditAt > 300000) return;   // تصمیم کهنه
      if (Date.now() - lastLocalEditAt < 2000) return;                          // تازه؛ مسیر عادی
      stats.reconciles = (stats.reconciles || 0) + 1;
      stats.reconcileAt = Date.now();
      pushFlags(local, srv);
    }

    function boot() {
      hookStorage();
      refreshMe(true).then(function () {
        startInit().then(function () {
          if (srv && (srv.p || srv.s)) toastOnce("mod-on", "🛡️ «بررسی پیش از انتشار» روشن است: پست/استوری تا تأیید مدیر منتشر نمی‌شود.");
        });
        setInterval(tick, POLL_MS);
        setInterval(reconcile, 20000);
        setInterval(function () { if (!document.hidden) srvTick(); }, SRV_MS);
        document.addEventListener("visibilitychange", function () { if (!document.hidden) { tick(); srvTick(); } });
        /* شبکهٔ اطمینان دوم: اگر wrap نشد، تغییر تیک را از رویدادهای صفحه بگیر */
        document.addEventListener("change", function () { noteUserIntent(); setTimeout(tick, 150); }, true);
        document.addEventListener("click", function () { noteUserIntent(); setTimeout(tick, 250); }, true);
      });
    }

    /* ---------- دسترسی برای آزمون‌ها ---------- */
    window.__gamifyModFixTest = {
      readLocal: readLocal, applyLocal: applyLocal, fetchServer: fetchServer,
      pushFlags: pushFlags, tick: tick, srvTick: srvTick, startInit: startInit,
      markPending: markPending, refreshMe: refreshMe, canPush: canPush, isAdminLocal: isAdminLocal,
      hookStorage: hookStorage, onChangeWrite: onChangeWrite, noteUserIntent: noteUserIntent, hasAdminToken: hasAdminToken, authHeaders: authHeaders,
      getSrv: function () { return srv; }, getLastLocal: function () { return lastLocal; },
      setLastLocal: function (f) { lastLocal = f; }, setSrv: function (f) { srv = f; },
      setLastEditAt: function (t) { lastLocalEditAt = t; }, getLastEditAt: function () { return lastLocalEditAt; },
      stats: function () { return Object.assign({}, stats); },
      resetOnce: function () { once = {}; },
      isHooked: function () { return hooked; },
      keys: { P: KEY_P, S: KEY_S, LS: LS }
    };
    window.__gamifyModFixStatus = function () {
      return { role: me.role, local: readLocal(), server: srv, lastLocal: lastLocal, hooked: hooked, stats: Object.assign({}, stats) };
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
    try { console.log("%c[مُدِرِیشن واقعی] نسخهٔ ۲ روشن شد.", "color:#7cd7b6"); } catch (e) {}
  } catch (e) { try { console.warn("[مُدِرِیشن واقعی] خطا:", e && e.message); } catch (e2) {} }
})();
// MOD-FIX-END
// ADMIN-GATE-START
/* 🔒 «پنل مدیریت نامرئی» — کاربران عادی نه گزینهٔ منو را می‌بینند، نه دکمه‌های مدیر را
   ----------------------------------------------------------------------------------
   چرا لازم شد؟ گزینهٔ «پنل مدیریت» (و دو دکمهٔ شناور مدیر 🛠️ و 📋) برای همهٔ کاربران
   در منو دیده می‌شد و هر کسی می‌توانست با کد داخلِ بازی وارد «حالت مدیر» شود — که
   فقط روی همان دستگاه نمایشی بود.

   این بلوک چهار لایه دارد:
     ۱) منو (رندر): «admin» به «بخش‌های پنهانِ» استور اضافه/کم می‌شود تا آیتم منو
        برای کاربر عادی اصلاً ساخته نشود.
     ۲) DOM: هر آیتم منو با متن «پنل مدیریت» و دو دکمهٔ شناور مدیر (🛠️ و 📋) پاک می‌شوند.
     ۳) مسیر: اگر کاربر عادی آدرس #admin را باز کند، بی‌صدا به خانه برگردانده می‌شود.
     ۴) حالت مدیر جعلی: admin/role محلی برای کاربر غیرمدیر خاموش می‌شود.

   مدیرِ واقعی همه‌چیز را می‌بیند؛ تشخیص با سرور انجام می‌شود:
     • حساب با نقش admin در سرور  (node /root/mod-fix/mod-fix.cjs promote "…")
     • یا توکن مدیریتی امضاشده    (ورود با کد مدیریت در پنل 🛠️)

   ورود مدیر روی دستگاه تازه (بدون کد در کنسول):
     https://bu.gamifi.ir/?admin=1#admin     ← پنل باز می‌شود، کد مدیریت را وارد کن
   ----------------------------------------------------------------------------------
   خاموش‌کردن اضطراری همین بلوک: bash /root/admin-gate/rollback-admin-gate.sh
*/
(function () {
  "use strict";
  if (window.__gamifyAdminGate) return;
  window.__gamifyAdminGate = true;

  // ---------- تنظیمات ----------
  var TTL_OK = 10 * 60 * 1000;   // «مدیر تأییدشده» تا ۱۰ دقیقه بدون چک مجدد
  var TTL_NO = 45 * 1000;        // «مدیر نیست» فقط ۴۵ ثانیه معتبر است (تا اشتباه نماند)
  var ASK_GAP = 8000;            // حداقل فاصلهٔ بین دو پرسش از سرور
  var SWEEP = 500;               // هر چند میلی‌ثانیه DOM بازبینی شود
  var DEEP = 2500;               // هر چند میلی‌ثانیه جست‌وجوی سنگین‌تر (متن‌ها) انجام شود
  var PASS_KEY = "gamify2-admgate-pass";
  var ADMIN_TOK = "gamify2-admin-token";     // توکن مدیریتی (ورود با کد مدیریت)
  var REVOKE_KEY = "gamify2-admin-revoked";  // «خروج از مدیریت» — برای همین مرورگر
  var LOGOUT_ID = "gm-admgate-logout";       // دکمهٔ شناور 🚪 خروج از مدیریت
  var LS_STORE = "gamify2-store-v2";
  var LS_META = "gamify2-server";
  var ADMIN_TOKEN_KEY = "gamify2-admin-token";

  var st = {
    ready: false,      // آیا از سرور جواب گرفته‌ایم؟
    ok: false,         // مدیر تأییدشده؟
    by: "unknown",     // role | token | none | net | …
    at: 0,             // زمان آخرین پاسخ
    bypass: false,     // حالت ورود (?admin=1)
    sweeps: 0,
    hiddenItems: 0,
    hiddenFabs: 0,
    kicks: 0,          // چند بار کاربر عادی از #admin برگردانده شد
    reverts: 0,        // چند بار حالت مدیر محلی خاموش شد
    secFixes: 0,       // چند بار متن درزکننده پاک شد
    lastHideAt: 0,
    lastErr: "",
    revoked: false,        // این مرورگر «خروج از مدیریت» زده؟
    revokes: 0,            // چند بار خروج زده شده
    clearedRevokes: 0,     // چند بار با ورود کد، خروج باطل شد
    logoutBtn: 0,          // دکمهٔ خروج ساخته شده؟
    lastLogout: null,      // نتیجهٔ آخرین خروج
    meOmit: null,      // نتیجهٔ /api/me با توکن حساب (بدون کوکی)
    meCook: null,      // نتیجهٔ /api/me با کوکیِ نشست
    admTok: null       // نتیجهٔ بررسی توکن مدیریتی
  };
  var pending = false, lastAsk = 0, navWarned = 0, bypassWarned = false;

  // ---------- ابزارک‌ها ----------
  function toast(m) {
    try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {}
    try { console.log("[admgate]", m); } catch (e) {}
  }
  function warnNav(msg) {
    if (Date.now() - navWarned < 4000) return;
    navWarned = Date.now();
    toast(msg);
  }
  function ls(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function ssGet(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
  function ssSet(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }
  function meta() { try { return JSON.parse(ls(LS_META) || "{}") || {}; } catch (e) { return {}; } }
  function live() { try { return window.__gamifyLiveGet ? window.__gamifyLiveGet() : null; } catch (e) { return null; } }
  function deadStore() { try { return JSON.parse(ls(LS_STORE) || "null"); } catch (e) { return null; } }
  function profile() { var s = live() || deadStore(); return (s && s.profile) || null; }

  /* ---------- «خروج از مدیریت» — این مرورگر تا کد دوباره نده، مدیر نمی‌شود ---------- */
  function acctId() {
    var m = meta() || {}; if (m.serverId) return String(m.serverId);
    var p = profile(); return (p && p.id) ? String(p.id) : "";
  }
  function revokedRaw() {
    try { var j = JSON.parse(ls(REVOKE_KEY) || "null"); return (j && typeof j === "object") ? j : null; } catch (e) { return null; }
  }
  function isRevoked() {
    var r = revokedRaw(); if (!r) return false;
    var cur = acctId(); if (!r.id) return true;
    return !cur || String(r.id) === cur;
  }
  function markRevoked(id) {
    try { localStorage.setItem(REVOKE_KEY, JSON.stringify({ id: String(id || ""), at: Date.now() })); } catch (e) {}
    st.revoked = true;
  }
  function clearRevoked(why) {
    if (!revokedRaw()) return false;
    try { localStorage.removeItem(REVOKE_KEY); } catch (e) {}
    st.revoked = false;
    st.clearedRevokes = (st.clearedRevokes || 0) + 1;
    st.lastClearedBy = why || "";
    return true;
  }

  /* ---------- لایهٔ ۱: بخش‌های پنهانِ استور (رندر منو) ---------- */
  function hiddenList(store) {
    try {
      var s = store || live() || deadStore();
      var h = s && s.settings && s.settings.hiddenSections;
      return Array.isArray(h) ? h.slice() : [];
    } catch (e) { return []; }
  }
  function setHidden(add) {
    var s = live();
    var cur = hiddenList(s);
    var has = cur.indexOf("admin") >= 0;
    if (add === has) return false;                     // تغییری لازم نیست
    var next = add ? cur.concat(["admin"]) : cur.filter(function (x) { return x !== "admin"; });
    try {
      if (s && window.__gamifyLiveSet) {
        window.__gamifyLiveSet(function () {
          var l = live();
          var stg = Object.assign({}, (l && l.settings) || {});
          stg.hiddenSections = next;
          return Object.assign({}, l, { settings: stg });
        });
        return true;
      }
      var d = deadStore();
      if (d && d.settings) { d.settings.hiddenSections = next; localStorage.setItem(LS_STORE, JSON.stringify(d)); return true; }
    } catch (e) {}
    return false;
  }

  /* ---------- لایهٔ ۴: خاموش‌کردن «مدیر محلی» جعلی ---------- */
  function dropLocalAdmin(showToast) {
    var s = live() || deadStore();
    if (!s) return false;
    var isAdmin = s.admin === true || !!(s.profile && s.profile.role === "admin");
    if (!isAdmin) return false;
    var patched = false;
    try {
      if (window.__gamifyLiveSet) {
        window.__gamifyLiveSet(function (x) {
          if (!x) return x;
          var n = Object.assign({}, x);
          n.admin = false;
          if (n.profile && n.profile.role === "admin") n.profile = Object.assign({}, n.profile, { role: "user" });
          return n;
        });
        patched = true;
      } else {
        var d = deadStore();
        if (d) {
          d.admin = false;
          if (d.profile && d.profile.role === "admin") d.profile.role = "user";
          localStorage.setItem(LS_STORE, JSON.stringify(d));
          patched = true;
        }
      }
    } catch (e) {}
    if (patched) {
      st.reverts++;
      if (showToast !== false) warnNav("⛔ پنل مدیریت فقط برای مدیرِ سرور است (این حساب مدیر نیست).");
    }
    return patched;
  }

  /* ---------- لایهٔ ۲: پاک‌کردن منو و دکمه‌ها از DOM ---------- */
  function norm(t) { return String(t || "").replace(/\s+/g, " ").trim(); }
  function hideNode(el, tag) {
    if (!el || el.getAttribute("data-gm-admgate-hide") === "1") return false;
    el.setAttribute("data-gm-admgate-hide", "1");
    el.setAttribute("data-gm-admgate-kind", tag || "item");
    try { el.style.display = "none"; } catch (e) {}
    try { el.setAttribute("aria-hidden", "true"); } catch (e) {}
    return true;
  }
  function restoreNodes() {
    var n = 0;
    Array.prototype.forEach.call(document.querySelectorAll("[data-gm-admgate-hide='1']"), function (el) {
      try { el.style.display = ""; } catch (e) {}
      try { el.removeAttribute("aria-hidden"); } catch (e) {}
      el.removeAttribute("data-gm-admgate-hide");
      el.removeAttribute("data-gm-admgate-kind");
      n++;
    });
    return n;
  }
  function hideMenuItems() {
    var n = 0;
    // منوی راست داشبورد (دسکتاپ و کشوی موبایل هر دو همین عنصر است).
    // توجه: متن دکمه «پنل مدیریتمدیر» است (برچسب «مدیر» داخل همان دکمه)؛ پس با
    // «شروع‌شدن با» مقایسه می‌کنیم، نه تساوی کامل.
    Array.prototype.forEach.call(document.querySelectorAll("aside button, nav button, button.gm-nav-item"), function (b) {
      if (b.closest(".gamify-overlay")) return;             // دکمه‌های داخل پنل خودمان
      var t = norm(b.textContent);
      if (t.indexOf("پنل مدیریت") === 0 || t === "پنل زندهٔ مدیر" || t.indexOf("پنل مدیریت سرور") === 0) {
        if (hideNode(b, "nav")) n++;
      }
    });
    return n;
  }
  function hideFabs() {
    var n = 0;
    ["gm-admin-fab", "gamify-mod-fab", LOGOUT_ID].forEach(function (id) {
      var b = document.getElementById(id);
      if (b) { if (b.parentNode) b.parentNode.removeChild(b); n++; }
    });
    return n;
  }
  /* متنی که «پنل مدیریت» را به کاربر عادی نشان می‌دهد (راهنمای نصب اندروید) */
  function scrubTexts() {
    var n = 0;
    Array.prototype.forEach.call(document.querySelectorAll("p, small, span, div"), function (el) {
      if (el.childElementCount !== 0) return;
      var t = String(el.textContent || "");
      if (t.length > 400) return;
      if (t.indexOf("از پنل مدیریت") < 0) return;
      var cut = t.split(/فایل APK/)[0].replace(/\s+$/, "");
      try { el.textContent = cut; st.secFixes++; n++; } catch (e) {}
    });
    return n;
  }
  function closeAdminOverlay() {
    // اگر پنل مدیریتی باز بود ولی این حساب مدیر نیست، ببندش
    var n = 0;
    ["gm-admin-overlay", "gamify-mod-overlay"].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      var x = el.querySelector("[data-x='1'], [data-act='close'], [data-close]");
      if (x) { try { x.click(); n++; return; } catch (e) {} }
      try { el.classList.remove("open"); el.remove(); n++; } catch (e) {}
    });
    return n;
  }

  /* ---------- لایهٔ ۳: مسیر #admin ---------- */
  function guardHash() {
    if (st.ok || st.bypass) return false;
    var h = String(location.hash || "");
    if (!/^#admin/.test(h)) return false;
    /* تا وقتی سرور جواب قطعی نداده، کسی را بیرون نمی‌اندازیم (وگرنه مدیر هم در
       لحظهٔ اولِ بازشدن صفحه بیرون می‌افتد)؛ فقط فوری می‌پرسیم. */
    if (!st.ready) { ensure(true); return false; }
    st.kicks++;
    try { location.hash = "#home"; } catch (e) {}
    warnNav("⛔ پنل مدیریت فقط برای مدیر است.");
    return true;
  }

  /* ---------- تأیید از سرور ---------- */
  function headers() {
    var h = {};
    var m = meta();
    if (m && m.token) h["x-gamify-token"] = String(m.token);
    var p = profile();
    if (p && p.id) { h["x-gamify-user-id"] = String(p.id); h["x-gamify-local-id"] = String(p.id); }
    if (p && p.phone) h["x-gamify-phone"] = String(p.phone);
    if (p && p.email) h["x-gamify-email"] = String(p.email);
    return h;
  }
  function askMe(credentials, cb) {
    fetch("/api/me", { credentials: credentials, cache: "no-store", headers: headers() })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { s: r.status, j: j }; }); })
      .then(function (r) { cb(r.s, r.j); })
      .catch(function () { cb(0, null); });
  }
  function askAdminToken(cb) {
    var at = ls(ADMIN_TOKEN_KEY);
    if (!at) return cb(false, "none");
    fetch("/api/admin?view=settings", { credentials: "include", cache: "no-store", headers: { "x-admin-token": at } })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { s: r.status, j: j }; }); })
      .then(function (r) { cb(r.s === 200 && r.j && !r.j.error, r.s === 200 ? "token" : "none"); })
      .catch(function () { cb(null, "net"); });
  }
  /* سه مسیر تأیید — چون ممکن است کوکیِ قدیمیِ مرورگر کاربرِ دیگری را نشان دهد،
     اول با «توکنِ حساب» (بدون کوکی) می‌پرسیم؛ اگر نشد با کوکی؛ اگر نشد با توکن مدیریتی. */
  function ask(cb) {
    askMe("omit", function (s1, j1) {
      st.meOmit = { s: s1, role: (j1 && j1.role) || null, at: Date.now() };
      if (s1 === 200 && j1 && j1.role === "admin") { st.admTok = null; return cb(true, "role"); }
      askMe("include", function (s2, j2) {
        st.meCook = { s: s2, role: (j2 && j2.role) || null, at: Date.now() };
        if (s2 === 200 && j2 && j2.role === "admin") { st.admTok = null; return cb(true, "session"); }
        askAdminToken(function (ok3, why3) {
          st.admTok = { ok: !!ok3, why: why3, at: Date.now() };
          if (ok3) return cb(true, "token");
          if (!s1 && !s2) return cb(null, "net");       // شبکه قطع بود → تصمیم قبلی را نگه دار
          cb(false, "none");
        });
      });
    });
  }

  /* ---------- اعمال وضعیت ---------- */
  function apply(deep) {
    st.revoked = isRevoked();
    if ((st.ok && !st.revoked) || st.bypass) {
      // مدیر واقعی: همه‌چیز برگردد و «admin» از بخش‌های پنهان برداشته شود
      st.hiddenItems = 0;
      var back = restoreNodes();
      setHidden(false);
      document.documentElement.setAttribute("data-gm-admgate", "on");
      if (st.bypass && !st.ok && !bypassWarned && Date.now() - navWarned > 1500) {
        bypassWarned = true;                                   // فقط یک‌بار در هر بارِ باز شدن صفحه
        warnNav("🔓 حالت ورود مدیر: کد مدیریت را در پنل 🛠️ وارد کن تا برای همیشه تأیید شوی.");
      }
      if (st.ok) bypassWarned = false;                         // مدیر تأیید شد → برای دفعهٔ بعد دوباره‌ای لازم نیست
      return back;
    }
    // کاربر عادی: پنهان‌سازی کامل
    setHidden(true);
    var n = hideMenuItems();
    n += hideFabs();
    if (deep !== false) scrubTexts();
    closeAdminOverlay();
    dropLocalAdmin();
    guardHash();
    st.hiddenItems = n;
    st.lastHideAt = Date.now();
    document.documentElement.setAttribute("data-gm-admgate", "off");
    return n;
  }
  var lastMetaTok = "", lastLocalAdminSeen = false, lastAdmTok = "";
  function watchSignals() {
    var tok = String((meta() || {}).token || "");
    if (tok && tok !== lastMetaTok) {                 // حساب/توکن عوض شد → فوری دوباره بپرس
      lastMetaTok = tok;
      st.metaTok = tok.slice(0, 10);
      ensure(true);
    }
    var loc = live() || deadStore();
    var isLocal = !!(loc && (loc.admin === true || (loc.profile && loc.profile.role === "admin")));
    if (isLocal && !lastLocalAdminSeen && !st.ok) { clearRevoked("local-admin"); ensure(true); }
    lastLocalAdminSeen = isLocal;
    var at2 = ls(ADMIN_TOK);                       // ورودِ تازه با کد مدیریت → «خروج» باطل می‌شود
    if (at2 && at2 !== lastAdmTok) { lastAdmTok = at2; clearRevoked("admin-token"); ensure(true); }
    if (!at2) lastAdmTok = "";
  }
  function sweep(deep) {
    st.sweeps++;
    watchSignals();
    st.revoked = isRevoked();
    if (st.ok && !st.revoked) {
      /* مدیر: بازگردانی + برداشتن «admin» از بخش‌های پنهان (همگام‌سازی تنظیمات دوباره
         اضافه‌اش می‌کند؛ هر دور پاک می‌شود تا آیتم منو بماند) + دکمهٔ 🚪 خروج. */
      apply(deep);
      mountLogoutFab();
      mountLogoutInPanels();
      return;
    }
    apply(deep);
  }

  /* ---------- چرخهٔ بررسی ---------- */
  function ensure(force) {
    if (pending) return;
    var age = Date.now() - st.at;
    var ttl = st.ok ? TTL_OK : TTL_NO;
    if (!force && st.ready && age < ttl) return;
    if (!force && Date.now() - lastAsk < ASK_GAP) return;
    lastAsk = Date.now();
    pending = true;
    ask(function (ok, why) {
      pending = false;
      var changed = (ok === null) ? false : (st.ready ? st.ok !== !!ok : true);
      if (ok === null) { st.lastErr = why; }                 // شبکه/سرور: تصمیم قبلی را عوض نکن
      else { st.ready = true; st.ok = !!ok; st.by = why; st.at = Date.now(); st.lastErr = ""; }
      if (changed || !st.ready || ok === null) apply();
      else if (!st.ready) apply();
    });
  }

  /* ---------- 🚪 خروج از مدیریت (دکمه‌ها + لغو دسترسی) ---------- */
  function logoutFab() {
    var b = document.createElement("button");
    b.id = LOGOUT_ID; b.textContent = "🚪"; b.title = "خروج از مدیریت";
    b.style.cssText = "position:fixed;bottom:214px;right:16px;z-index:9998;width:44px;height:44px;" +
      "border-radius:50%;border:1px solid #e5485c;background:#2a1a22;color:#ffb3c0;font-size:19px;" +
      "cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.4)";
    b.addEventListener("click", function (e) { e.preventDefault(); e.stopPropagation(); askLogout(); });
    document.body.appendChild(b);
    st.logoutBtn = 1;
    return b;
  }
  function mountLogoutFab() { if (!document.getElementById(LOGOUT_ID)) logoutFab(); }
  function removeLogoutFab() { var b = document.getElementById(LOGOUT_ID); if (b) { try { b.remove(); } catch (e) {} } st.logoutBtn = 0; }
  function mountLogoutInPanels() {
    ["gm-admin-overlay", "gamify-mod-overlay"].forEach(function (id) {
      var ov = document.getElementById(id); if (!ov) return;
      var head = ov.querySelector(".gamify-modal-head"); if (!head) return;
      if (head.querySelector("[data-admgate-logout]")) return;
      var b = document.createElement("button");
      b.className = "gamify-btn sm danger";
      b.setAttribute("data-admgate-logout", "1");
      b.textContent = "🚪 خروج از مدیریت";
      b.addEventListener("click", function (e) { e.preventDefault(); e.stopPropagation(); askLogout(); });
      head.appendChild(b);
      st.logoutBtn = 1;
    });
  }
  function askLogout() {
    var ok = true;
    try {
      ok = window.confirm("از حالت «مدیر» خارج می‌شوی؟\n" +
        "از این به بعد این مرورگر تا وقتی کد مدیریت را دوباره وارد نکنی، دسترسی مدیر ندارد.");
    } catch (e) { ok = true; }
    if (ok) doLogout({ reload: true, delay: 900 });
  }
  /* خروج کامل: ۱) لغو نقش مدیر روی سرور ۲) پاک‌کردن توکن مدیریتی ۳) خاموش‌کردن حالت مدیر
     ۴) علامت‌گذاری این مرورگر تا کد دوباره نده، مدیر نشود. */
  function doLogout(opts) {
    opts = opts || {};
    var id = acctId();
    var h = headers();
    h["Content-Type"] = "application/json";
    var at = ls(ADMIN_TOK); if (at) h["x-admin-token"] = at;
    st.revokes = (st.revokes || 0) + 1;
    function done(srvOk, status) {
      try { localStorage.removeItem(ADMIN_TOK); } catch (e) {}
      markRevoked(id);
      dropLocalAdmin(false);
      st.ok = false; st.ready = true; st.by = "revoked"; st.at = Date.now(); st.revoked = true;
      removeLogoutFab();
      apply(true);
      st.lastLogout = { at: Date.now(), srv: !!srvOk, status: status, id: id };
      toast(srvOk ? "✅ از مدیریت خارج شدی — برای ورود دوباره، کد مدیریت لازم است"
                  : "✅ دسترسی مدیرِ این مرورگر بسته شد (برای برگشت، کد مدیریت را بزن)");
      if (opts.cb) opts.cb(srvOk, status);
      if (opts.reload !== false) setTimeout(function () { try { location.reload(); } catch (e) {} }, opts.delay || 900);
    }
    fetch("/api/admin?action=remove-admin", { method: "POST", credentials: "include", cache: "no-store", headers: h, body: JSON.stringify({ userId: id }) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { s: r.status, j: j }; }); })
      .then(function (r) { done(r.s === 200 && r.j && !r.j.error, r.s); })
      .catch(function () { done(false, 0); });
  }

  /* ---------- راه‌اندازی ---------- */
  function boot() {
    // ?admin=1 (یا ?panel=1 / ?mod=1) → حالت ورود مدیر برای همین تب
    try {
      if (/(^|[?&])(admin|panel|mod)=1(&|$)/.test(String(location.search || ""))) ssSet(PASS_KEY, "1");
    } catch (e) {}
    st.bypass = ssGet(PASS_KEY) === "1";
    apply(true);                   // پنهان‌سازی فوری (قبل از جواب سرور)
    ensure(true);
    setInterval(function () { ensure(false); sweep(false); }, SWEEP);
    setInterval(function () { ensure(false); }, 5000);
    setInterval(function () { sweep(true); }, DEEP);
    window.addEventListener("hashchange", function () { guardHash(); }, false);
    /* پنل داخلی بازی دکمهٔ «خروج از پنل» دارد؛ آن هم باید خروجِ واقعی باشد */
    document.addEventListener("click", function (e) {
      try {
        var b = e.target && e.target.closest ? e.target.closest("button") : null;
        if (!b) return;
        if (norm(b.textContent).indexOf("خروج از پنل") === 0) doLogout({ reload: true, delay: 500 });
      } catch (err) {}
    }, true);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) { ensure(false); sweep(); } }, false);
    window.addEventListener("storage", function (e) {
      try {
        if (e && (e.key === LS_META || e.key === ADMIN_TOKEN_KEY)) ensure(true);
      } catch (err) {}
    }, false);
    try { console.log("%c[gamify] پنل مدیریت برای کاربران عادی پنهان شد 🔒", "color:#f2a7c3"); } catch (e) {}
  }

  // ---------- ابزار تست/کنسول ----------
  window.__gamifyAdminGate = {
    state: st,
    status: function () { return JSON.parse(JSON.stringify(st)); },
    check: function (cb) { ask(function (ok, why) {
      if (ok !== null) { st.ready = true; st.ok = !!ok; st.by = why; st.at = Date.now(); }
      apply();
      if (cb) cb(ok, why);
    }); },
    hide: function () { st.ok = false; st.ready = true; apply(); },
    reveal: function () { st.ok = true; st.ready = true; apply(); },
    apply: apply,
    sweep: sweep,
    bypass: function (v) {
      if (v === undefined) return st.bypass;
      st.bypass = !!v;
      try { if (v) ssSet(PASS_KEY, "1"); else sessionStorage.removeItem(PASS_KEY); } catch (e) {}
      apply();
      return st.bypass;
    },
    hiddenSections: function () { return hiddenList(); },
    logout: doLogout,                                   // خروج از مدیریت (سرور + مرورگر)
    revoked: isRevoked,
    clearRevoked: clearRevoked,
    logoutFab: function () { mountLogoutFab(); mountLogoutInPanels(); }
  };
  window.__gamifyAdminGateStatus = function () { return JSON.parse(JSON.stringify(st)); };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else setTimeout(boot, 60);
})();
// ADMIN-GATE-END
// COINS-LIVE-START — دست نزن؛ این بلوک توسط /root/coins-live/apply-coins-live.sh نصب/به‌روز می‌شود
// ═══════════════════════════════════════════════════════════════════════════
//  «سکهٔ زنده» — تراز سکه مالکیتِ سرور + ضدتقلب + یکپارچه‌سازی فروشگاه/هدیه
//  - تراز قطعی سکه روی سرور است (Postgres)؛ این بلوک هر تغییر محلی را به
//    سرور گزارش می‌کند (op:delta) و هر خرید را تأیید می‌کند (op:buy).
//  - سرور سقف ساعتی/روزانه دارد → تقلبِ «سکه بی‌نهایت» بی‌اثر است.
//  - هدیهٔ روزانه: کلیکِ محلی → سرور /api/daily؛ هدیهٔ سروری جای هدیهٔ
//    محلی می‌نشیند و اگر امروز روی دستگاهِ دیگر گرفتی، اینجا داده نمی‌شود.
//  - هر sync، تراز سرور را برمی‌گرداند و این بلوک کیف محلی را روی آن می‌نشاند.
//  - بدون rebuild، بدون دست‌زدن به bundle.js اصلی.
// ═══════════════════════════════════════════════════════════════════════════
(function () {
  "use strict";
  if (window.__gamifyCoinsLive) return;
  window.__gamifyCoinsLive = true;

  var LS_STORE = "gamify2-store-v2";
  var LS_META = "gamify2-server";
  var SH = "sh:";

  // همان فهرست فروشگاه (فقط برای تشخیص اقلام قابل خرید)
  var ITEMS = {
    "title-mentor": 300, "title-safety": 250, "extra-life": 120,
    "frame-gold": 400, "theme-night": 200, "badge-fire": 150
  };

  var lastCoins = null;      // آخرین ترازِ تأییدشدهٔ سرور (یا خط‌باز محلی)
  var lastInv = null;        // آخرین inventory دیده‌شده
  var lastRewardDay = null;  // آخرین روز هدیه‌ای که به سرور گزارش شد
  var bootChecked = false;   // خط‌بازِ اولین دیدنِ پروفایل (هدیهٔ قبل از بارگذاری = بازگشتی نه)
  var noSessionUntil = 0;    // بعد از 401، تا این لحظه گزارش نده
  var chain = Promise.resolve();

  /* ---------- ابزارک‌ها ---------- */
  function meta() { try { return JSON.parse(localStorage.getItem(LS_META) || "{}") || {}; } catch (e) { return {}; } }
  function myServerId() { var m = meta(); return m.serverId ? String(m.serverId) : (m.id ? String(m.id) : ""); }
  function storeNow() {
    try { if (window.__gamifyLiveGet) return window.__gamifyLiveGet(); } catch (e) { }
    try { return JSON.parse(localStorage.getItem(LS_STORE) || "null"); } catch (e) { return null; }
  }
  function setStore(fn) {
    try { if (window.__gamifyLiveSet) { window.__gamifyLiveSet(fn); return true; } } catch (e) { }
    return false;
  }
  function isLoggedIn() { var s = storeNow(); return !!(s && s.profile && s.profile.id); }
  function dayKey() { return new Date().toISOString().slice(0, 10); }
  function realFetch() { try { return window.fetch.bind(window); } catch (e) { return null; } }
  var baseFetch = realFetch();

  function api(url, body) {
    if (typeof baseFetch !== "function") return Promise.resolve({ status: 0, body: null });
    return baseFetch(url, {
      method: "POST",
      credentials: "include",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body || {})
    }).then(function (r) {
      return r.json().then(function (j) { return { status: r.status, body: j }; }).catch(function () { return { status: r.status, body: null }; });
    }).catch(function () { return { status: 0, body: null }; });
  }

  function enqueue(fn) { chain = chain.then(fn).catch(function () { }); return chain; }

  function toast(msg) {
    try {
      var old = document.querySelector("[data-coinslive-toast='1']");
      if (old) old.remove();
      var d = document.createElement("div");
      d.setAttribute("data-coinslive-toast", "1");
      d.setAttribute("dir", "rtl");
      d.style.cssText = "position:fixed;right:50%;transform:translateX(50%);bottom:24px;z-index:99999;display:flex;align-items:center;gap:6px;padding:10px 16px;border-radius:14px;font-size:12px;font-weight:700;background:rgba(20,14,26,.95);color:#f2ca7c;border:1px solid rgba(242,202,124,.55);box-shadow:0 8px 30px rgba(0,0,0,.5);max-width:80vw";
      d.textContent = msg;
      document.body.appendChild(d);
      setTimeout(function () { try { d.remove(); } catch (e) { } }, 3800);
    } catch (e) { }
  }

  function adoptCoins(n) {
    if (!Number.isFinite(n) || n < 0) return;
    n = Math.round(n);
    setStore(function (cur) {
      if (!cur || !cur.profile) return cur;
      if ((cur.profile.coins | 0) === n) return cur;
      return Object.assign({}, cur, { profile: Object.assign({}, cur.profile, { coins: n }) });
    });
  }

  /* ---------- ۱) گزارشِ تغییر محلی (بازی/کمک‌هزینه) → delta اعمال‌شده ----------
     exclude: مبلغی که خودِ عملیاتِ بعدی (buy یا daily) روی سرور اعمال می‌کند؛
     برای جلوگیری از محاسبهٔ دو‌برگانه به delta اضافه می‌شود تا از آن خارج بماند.
     تغییرِ بسیار بزرگ (تقلب/کیفِ منقضی) گزارش نمی‌شود — adoption آن را همگام می‌کند. */
  var MAX_PENDING = 8000; // حدِ «تغییرِ واقعی» — از این بیشتر = همگام‌سازیِ کامل
  function reportDelta(exclude) {
    return new Promise(function (resolve) {
      var s = storeNow();
      if (!s || !s.profile || !isLoggedIn()) { resolve(0); return; }
      var c = s.profile.coins | 0;
      // تا اولین adoption از سرور، خط‌مبنای قطعی معلوم نیست — چیزی گزارش نمی‌کنیم
      if (lastCoins === null) { resolve(0); return; }
      var raw = c - lastCoins;
      if (raw > MAX_PENDING || raw < -MAX_PENDING) { resolve(0); return; } // به adoption بسپار
      var d = raw + (exclude || 0);
      if (!d) { resolve(0); return; }
      if (Date.now() < noSessionUntil) { resolve(0); return; }
      api("/api/coins", { op: "delta", delta: d }).then(function (r) {
        if (r.status === 401) { noSessionUntil = Date.now() + 30000; resolve(0); return; }
        if (r.status === 200 && r.body && Number.isFinite(r.body.coins)) {
          lastCoins = r.body.coins;
          adoptCoins(r.body.coins);
          if (r.body.capped) toast("⚖️ بخشی از تغییر سکه توسط سرور محدود شد (سقف روزانه).");
          resolve(1);
        } else { resolve(0); }
      });
    });
  }

  /* ---------- ۲) تماشاگر خرید: قلم تازه در inventory → تأییدِ سروری ---------- */
  function revertItem(itemId) {
    setStore(function (cur) {
      if (!cur || !cur.profile || !Array.isArray(cur.profile.inventory)) return cur;
      var ci = cur.profile.inventory.filter(function (x) { return x !== itemId; });
      return Object.assign({}, cur, { profile: Object.assign({}, cur.profile, { inventory: ci }) });
    });
  }
  function watchInventory() {
    var s = storeNow();
    if (!s || !s.profile || !isLoggedIn()) { lastInv = null; return; }
    var inv = Array.isArray(s.profile.inventory) ? s.profile.inventory : [];
    if (lastInv === null) { lastInv = inv.slice(); return; }
    var fresh = inv.filter(function (id) { return !!ITEMS[id] && lastInv.indexOf(id) === -1; });
    if (!fresh.length) return;
    lastInv = inv.slice();
    // کیف محلی مبلغ خرید را خودش کسر کرده؛ عملیاتِ buy دوباره روی سرور کسر می‌کند.
    // برای جلوگیری از کسرِ دو‌برگانه، مبلغ خرید از گزارشِ delta خارج می‌شود
    // (بعد از هر پاسخِ buy، lastCoins با ترازِ قطعیِ سرور جایگزین می‌شود).
    var priceSum = 0;
    fresh.forEach(function (id) { priceSum += ITEMS[id] || 0; });
    if (lastCoins !== null && priceSum > 0) lastCoins -= priceSum;
    fresh.forEach(function (id) {
      enqueue(function () {
        return reportDelta().then(function () {
          return api("/api/coins", { op: "buy", itemId: id });
        }).then(function (r) {
          if (r.status === 401) { noSessionUntil = Date.now() + 30000; return; }
          if (r.status === 200 && r.body && r.body.ok && Number.isFinite(r.body.coins)) {
            lastCoins = r.body.coins;
            adoptCoins(r.body.coins);
            toast("🛒 خرید روی سرور تأیید شد — تراز: " + r.body.coins + " سکه");
          } else if (r.body && r.body.ok === false) {
            revertItem(id);
            if (Array.isArray(lastInv)) lastInv = lastInv.filter(function (x) { return x !== id; });
            if (Number.isFinite(r.body.coins)) { lastCoins = r.body.coins; adoptCoins(r.body.coins); }
            toast("🛡️ " + (r.body.message || "سرور این خرید را تأیید نکرد."));
          }
        });
      });
    });
  }

  /* ---------- ۳) تماشاگر هدیهٔ روزانه: روز تازه در rewardDays → /api/daily ---------- */
  function watchDaily() {
    var s = storeNow();
    if (!s || !s.profile || !isLoggedIn()) { return; }
    var days = Array.isArray(s.rewardDays) ? s.rewardDays : [];
    var today = dayKey();
    var got = days.indexOf(today) !== -1;
    if (!bootChecked) {
      // خط‌بازِ اولین دیدنِ پروفایل: اگر هدیهٔ امروز پیش از فعال‌شدن بلوک گرفته
      // شده، بازگشتی گزارش نمی‌شود (یک‌بارِ دقیق).
      bootChecked = true;
      if (got) lastRewardDay = today;
      return;
    }
    if (got && lastRewardDay !== today) {
      lastRewardDay = today;
      // هدیهٔ خودِ اپ (o) از delta خارج می‌شود — پاداشِ سروری جایگزین آن است.
      // هر سودِ هم‌زمانیِ دیگر (بازی) عادی گزارش می‌شود.
      var n = days.length - 1;
      if (n < 0) n = 0;
      var o = 20 + Math.min(6, n % 7) * 10;
      enqueue(function () {
        // اگر syncِ میانی، هدیهٔ محلی را پاک کرده باشد، حذفِ جزئی فقط به اندازهٔ
        // آنچه هنوز در کیف مانده اعمال می‌شود.
        var s = storeNow();
        var c = s && s.profile ? (s.profile.coins | 0) : 0;
        var drift = lastCoins === null ? 0 : c - lastCoins;
        var oNow = Math.max(0, Math.min(o, drift));
        return reportDelta(-oNow).then(function () {
          return api("/api/daily", { profile: { id: myServerId() } }).then(function (r) {
            if (r.status === 401) { noSessionUntil = Date.now() + 30000; return; }
            if (r.body && Number.isFinite(r.body.balance)) {
              lastCoins = Math.round(r.body.balance);
              adoptCoins(lastCoins);
            }
          });
        });
      });
    }
  }

  /* ---------- ۴) هر sync: ترازِ قطعیِ سرور را به کیف محلی بسپار ----------
     تغییرِ معلقِ کوچک (سود/کمک‌هزینه/هدیهٔ تازه) پاک نمی‌شود — گزارشگرِ D
     آن را به سرور می‌رساند؛ تغییرِ بسیار بزرگ (تقلب/کیفِ منقضی) به سرور همگام می‌شود. */
  window.addEventListener("gamify:synced", function (e) {
    try {
      var v = e && e.detail && e.detail.coins;
      if (!Number.isFinite(v)) return;
      if (lastCoins === null) { lastCoins = v; adoptCoins(v); return; }
      var s = storeNow();
      var c = s && s.profile ? (s.profile.coins | 0) : null;
      if (c === null) return;
      var pending = c - lastCoins;
      if (pending > MAX_PENDING || pending < -MAX_PENDING) { lastCoins = v; adoptCoins(v); }
    } catch (err) { }
  });

  /* ---------- حلقهٔ نظارت ---------- */
  function tick() {
    if (!isLoggedIn()) { lastCoins = null; lastInv = null; lastRewardDay = null; return; }
    watchInventory();
    watchDaily();
    var s = storeNow();
    if (s && s.profile && lastCoins !== null && ((s.profile.coins | 0) !== lastCoins)) {
      enqueue(reportDelta);
    }
  }
  setInterval(tick, 2500);
  tick();

  // وضعیت برای ابزارهای تست/کنسول
  window.__gamifyCoinsLiveState = function () {
    return { ready: true, lastCoins: lastCoins, lastRewardDay: lastRewardDay, inv: lastInv ? lastInv.length : null };
  };
})();
// COINS-LIVE-END
// EVENTS-LIVE-START — دست نزن؛ این بلوک توسط /root/events-live/apply-events-live.sh نصب/به‌روز می‌شود
// ═══════════════════════════════════════════════════════════════════════════
//  «رویداد و چالش باز — روی سرور» + «مرور/مدال پیوسته با حساب»
//  - فهرست رویدادها از سرور (تورنمنت‌های واقعی)؛ در همهٔ مرورگرها یکسان و واقعی
//  - شرکت = درخواست واقعی به سرور (join + submit)؛ بهترین امتیازت ذخیره می‌شود
//  - نتایج/شرکت‌کنندگان برای همهٔ بقیه قابل‌مشاهده است (از راه فیدِ عمومی)
//  - مدال‌ها (طلا/نقره/برنز/کاپ) از نتایج سرور محاسبه می‌شوند و در همهٔ دستگاه‌ها می‌مانند
//  - «مرور و یادگیری» (سؤال‌های اشتباه) با حساب روی سرور می‌ماند (از راه interests: wq:…)
//  - ساخت رویداد از پنل مدیریت، روی سرور هم ثبت می‌شود
//  بدون rebuild، بدون دست‌زدن به bundle.js اصلی.
// ═══════════════════════════════════════════════════════════════════════════
(function () {
  "use strict";
  if (window.__gamifyEventsLive) return;
  window.__gamifyEventsLive = true;

  var LS_STORE = "gamify2-store-v2";
  var LS_META = "gamify2-server";
  var LS_BANK = "gamify2-bank-v1";
  var WQ = "wq:";                                  // پیشوند سؤالات «مرور» در interests سرور
  var WQ_NONE = "wq:none";                          // نشانهٔ «صف خالی»
  var SH = "sh:";                                   // پیشوند اقلام فروشگاه (بلوک shop-live)
  var MAX_WQ = 20;                                  // ظرفیت صف مرور روی سرور
  var TAG_RE = /^g2ev:([a-z0-9_-]+):(\d+)$/i;       // category پست‌های رویداد: g2ev:<eventId>:<score>
  var REFRESH_MS = 20000;
  var SCAN_MS = 2500;

  var bootAt = 0;
  var st = {
    ready: false,
    serverEvents: [],       // [{id,title,category,description,startsAt,endsAt,active,org}]
    serverIds: {},          // eventId -> true
    participants: {},       // eventId -> [{playerId,name,score,at}]
    myServerId: "",
    refreshes: 0,
    lastRefresh: 0,
    submits: 0,
    announced: 0,
    created: 0,
    reviewPushes: 0,
    reviewRestored: 0,
    medalsAdded: 0,
    lastErr: ""
  };
  var lastHistFp = null;
  var lastReviewsFp = null;
  var lastEventsFp = null;
  var pendingCreate = {};
  var pendingSubmit = {};
  var wqQueue = null;               // صفِ wq:… که باید به بعدی /api/sync تزریق شود
  var lastServerWq = [];            // آخرین صفِ wq:… که روی سرور دیدیم (محافظِ پاک‌شدن)

  /* ---------- ابزارک‌ها ---------- */
  function ls(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function meta() { try { return JSON.parse(ls(LS_META) || "{}") || {}; } catch (e) { return {}; } }
  function live() { try { return window.__gamifyLiveGet ? window.__gamifyLiveGet() : null; } catch (e) { return null; } }
  function dead() { try { return JSON.parse(ls(LS_STORE) || "null"); } catch (e) { return null; } }
  function store() { return live() || dead(); }
  function profile() { var s = store(); return (s && s.profile) || null; }
  function serverId() { var m = meta(); return m.serverId ? String(m.serverId) : ""; }
  function localId() { var p = profile(); return p && p.id ? String(p.id) : ""; }
  function setStore(fn) { try { if (window.__gamifyLiveSet) return window.__gamifyLiveSet(fn); } catch (e) { } }
  function headers() {
    var h = { "Content-Type": "application/json" };
    var m = meta();
    if (m.token) h["x-gamify-token"] = m.token;
    return h;
  }
  function api(path, opts) {
    opts = opts || {};
    opts.method = opts.method || (opts.body ? "POST" : "GET");
    opts.headers = Object.assign(headers(), opts.headers || {});
    opts.credentials = "include";
    opts.cache = "no-store";
    if (opts.body && typeof opts.body !== "string") opts.body = JSON.stringify(opts.body);
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) { return { s: r.status, j: j }; });
    });
  }
  function toast(m) { try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) { } try { console.log("[events-live]", m); } catch (e) { } }
  function isOn(route) { try { return String(location.hash || "").indexOf(route) === 1; } catch (e) { return false; } }
  function logoFor(category) {
    var emoji = "🏁";
    try {
      var s = store();
      var cats = (s && s.categories) || (s && s.settings && s.settings.categories) || null;
      if (Array.isArray(cats)) { var c = cats.find(function (x) { return x && x.id === category; }); if (c && c.emoji) emoji = c.emoji; }
      else {
        var map = { safety: "🛡️", work: "⚡", electric: "⚡", engineering: "🔧", general: "🏁", science: "🔬", math: "🔢", history: "📜", geography: "🌍", literature: "📖", english: "🅰️", sport: "⚽", art: "🎨", cinema: "🎬", music: "🎵", food: "🍽️", nature: "🌿", space: "🚀", animals: "🐾" };
        if (map[category]) emoji = map[category];
      }
    } catch (e) { }
    try {
      var svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><defs><linearGradient id='l' x2='1' y2='1'><stop stop-color='#463050'/><stop offset='1' stop-color='#241b30'/></linearGradient></defs><rect width='64' height='64' rx='14' fill='url(#l)'/><text x='32' y='43' font-size='30' text-anchor='middle'>" + emoji + "</text></svg>";
      return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
    } catch (e) { return ""; }
  }

  /* ---------- ۱) گرفتن رویدادها + شرکت‌کنندگان از سرور ---------- */
  function parseParticipants(posts) {
    var by = {};
    (posts || []).forEach(function (p) {
      var cat = String(p.category || "");
      var m = cat.match(TAG_RE);
      if (!m) return;
      var id = m[1], score = Math.max(0, Math.min(100000, parseInt(m[2], 10) || 0));
      var arr = by[id] || (by[id] = []);
      arr.push({ playerId: String(p.userId || p.authorId || ""), name: String(p.userName || p.author || "بازیکن"), score: score, at: Number(p.createdAt || p.at) || 0 });
    });
    Object.keys(by).forEach(function (id) {
      var best = {};
      by[id].forEach(function (e) {
        if (!e.playerId) return;
        var cur = best[e.playerId];
        if (!cur || e.score > cur.score) best[e.playerId] = e;
      });
      by[id] = Object.keys(best).map(function (k) { return best[k]; }).sort(function (a, b) { return b.score - a.score; }).slice(0, 50);
    });
    return by;
  }

  function serverPosts() {
    var s = store();
    return (s && s.posts) || [];   // 15-realtime فیدِ سرور را زنده در همین آرایه نگه می‌دارد
  }

  function refresh() {
    if (!st.ready) return;
    Promise.all([
      api("/api/tournaments").catch(function () { return { s: 0, j: [] }; }),
      api("/api/feed?type=posts").catch(function () { return { s: 0, j: [] }; })
    ]).then(function (res) {
      var list = Array.isArray(res[0].j) ? res[0].j : [];
      var posts = Array.isArray(res[1].j) ? res[1].j : serverPosts();
      var merged = [];
      var seen = {};
      posts.concat(serverPosts()).forEach(function (p) { if (p && !seen[p.id]) { seen[p.id] = 1; merged.push(p); } });
      st.participants = parseParticipants(merged);
      st.serverIds = {};
      st.serverEvents = list.map(function (t) {
        st.serverIds[String(t.id)] = true;
        return {
          id: String(t.id),
          title: String(t.title || "رویداد"),
          category: String(t.category || "general"),
          description: String(t.description || ""),
          startsAt: Number(t.startsAt) || 0,
          endsAt: Number(t.endsAt) || 0,
          active: !!t.active,
          org: String(t.orgId || "")
        };
      });
      st.myServerId = serverId();
      st.lastRefresh = Date.now();
      st.refreshes++;
      mergeEvents();
      mergeMedals();
    }).catch(function (e) { st.lastErr = String((e && e.message) || e); });
  }

  /* ---------- ۲) نشاندن رویدادهای سرور در استور (جایگزینِ ماک‌ها) ---------- */
  function mergeEvents() {
    var s = store(); if (!s) return;
    var mine = localId(), srv = st.myServerId;
    var server = st.serverEvents.map(function (t) {
      var res = (st.participants[t.id] || []).map(function (r) {
        if (srv && r.playerId === srv) return { playerId: mine, name: (profile() || {}).name || r.name, score: r.score, at: r.at };
        return { playerId: r.playerId, name: r.name, score: r.score, at: r.at };
      });
      // نتیجهٔ محلی خودم (تا پستِ من در فید ظاهر شود) — بهترین امتیاز
      (s.events || []).forEach(function (ev) {
        if (ev && ev.id === t.id) {
          (ev.results || []).forEach(function (r) {
            if (r && r.playerId === mine) {
              var ex = res.find(function (x) { return x.playerId === mine; });
              if (!ex) res.unshift({ playerId: mine, name: (profile() || {}).name || "", score: r.score, at: r.at || 0 });
              else if (r.score > ex.score) ex.score = r.score;
            }
          });
        }
      });
      res.sort(function (a, b) { return b.score - a.score; });
      return {
        id: t.id, title: t.title, description: t.description, category: t.category,
        kind: "event", logo: logoFor(t.category), startsAt: t.startsAt, endsAt: t.endsAt,
        active: t.active, org: t.org || "", medals: {}, hasCup: false,
        results: res,
        open: t.active && t.startsAt <= Date.now() && t.endsAt >= Date.now(),
        myScore: (function () { var r = res.find(function (x) { return x.playerId === mine; }); return r ? r.score : 0; })()
      };
    });
    var keep = (s.events || []).filter(function (e) { return e && e.kind === "league"; });   // فقط لیگ‌ها نگه می‌مانند
    var next = server.concat(keep);
    setStore(function (cur) {
      if (cur && JSON.stringify(cur.events || []) === JSON.stringify(next)) return cur;
      return Object.assign({}, cur, { events: next });
    });
  }

  /* ---------- ۳) مدال‌ها از نتایج سرور ---------- */
  function mergeMedals() {
    var s = store(); if (!s) return;
    var mine = localId(); if (!mine) return;
    var srv = st.myServerId;
    var def = (s.settings && s.settings.defaultMedals) || {};
    var have = {};
    (s.medals || []).forEach(function (m) { if (m && m.id) have[m.id] = true; });
    var add = [];
    st.serverEvents.forEach(function (t) {
      // شناسهٔ خودمان در فید = serverId → به شناسهٔ محلی تبدیل کن تا «رتبهٔ تو» درست بیفتد
      var C = (st.participants[t.id] || []).map(function (r) {
        return (srv && r.playerId === srv) ? { playerId: mine, score: r.score, at: r.at } : r;
      }).sort(function (a, b) { return b.score - a.score; });
      // نتیجهٔ محلی خودم را هم حساب کن (تا همین دستگاه فوری مدال ببیند)
      (s.events || []).forEach(function (ev) {
        if (ev && ev.id === t.id) (ev.results || []).forEach(function (r) {
          if (r && r.playerId === mine && !C.some(function (x) { return x.playerId === mine; })) C.push({ playerId: mine, score: r.score, at: r.at || 0 });
        });
      });
      C.sort(function (a, b) { return b.score - a.score; });
      var idx = C.findIndex(function (r) { return r.playerId === mine; });
      if (idx < 0) return;
      var sc = C[idx].score;
      var tier = idx === 0 ? "gold" : idx === 1 ? "silver" : (idx === 2 || sc >= 700) ? "bronze" : null;
      if (!tier) return;
      var id = "medal-" + t.id + "-" + tier;
      if (have[id]) return;
      add.push({ id: id, eventId: t.id, eventTitle: t.title, tier: tier, image: def[tier] || "", at: C[idx].at || 0, score: sc });
    });
    if (!add.length) return;
    st.medalsAdded += add.length;
    setStore(function (cur) {
      var base = (cur.medals || []).slice();
      // تکرارگیری: اگر مدالِ همین رویداد/رده از راه دیگر (مثلاً محلی) هست، تکرار نمی‌شود
      add.forEach(function (m) {
        if (!base.some(function (x) { return x && x.tier === m.tier && String(x.eventId || "") === String(m.eventId || ""); })) base.unshift(m);
      });
      return Object.assign({}, cur, { medals: base });
    });
    toast("🎖️ مدال تازه از نتایج سرور: " + add.map(function (m) { return m.eventTitle; }).join("، "));
  }

  /* ---------- ۴) پایان مسابقهٔ رویدادی → ثبت روی سرور + اعلام عمومی ---------- */
  function histFp() {
    var s = store(); if (!s) return "";
    var h = s.history || [];
    var l = h[h.length - 1];
    return h.length + "|" + (l ? (l.at || 0) + ":" + (l.eventId || "") : "");
  }
  function scanHistory() {
    var fp = histFp();
    if (fp === lastHistFp) return;
    var first = lastHistFp === null;
    lastHistFp = fp;
    if (first) return;
    var s = store(); if (!s) return;
    var h = s.history || [];
    var last = h[h.length - 1];
    if (!last || !last.eventId) return;
    if ((last.at || 0) <= bootAt) return;      // فقط رکوردهای این نشست
    submitEvent(last);
  }
  function submitEvent(h) {
    var evId = String(h.eventId);
    var score = Math.max(0, Math.min(10000, Number(h.score) || 0));
    var key = evId + "|" + score;
    if (pendingSubmit[key]) return;
    pendingSubmit[key] = 1;
    var title = "";
    st.serverEvents.forEach(function (t) { if (t.id === evId) title = t.title; });
    if (!st.serverIds[evId] && !title) { delete pendingSubmit[key]; return; }   // رویداد محلی (لیگ/ماک) — کار سروری ندارد
    // join (اگر قبلاً عضو شده باشی بی‌اثر است)
    api("/api/tournaments?action=join", { body: { id: evId } }).then(function (rj) {
      if (rj.s === 404 || (rj.j && rj.j.error)) { delete pendingSubmit[key]; return null; }
      return api("/api/tournaments?action=submit", { body: { id: evId, score: score } }).then(function (rs) {
        st.submits++;
        return rs;
      });
    }).then(function () {
      // اعلام عمومی در فید (با category ماشینی: g2ev:<eventId>:<score>)
      var sid = serverId() || localId();
      var pid = "g2ev-" + sid + "-" + evId + "-" + score;
      return api("/api/feed?type=post", { body: {
        id: pid,
        category: "g2ev:" + evId + ":" + score,
        body: "🏆 در رویداد «" + (title || "رویداد") + "» " + score + " امتیاز گرفتم"
      } });
    }).then(function (rp) {
      if (rp && rp.s === 200) { st.announced++; }
      refresh();
    }).catch(function (e) { st.lastErr = String((e && e.message) || e); });
  }

  /* ---------- ۵) دکمهٔ «شرکت» → join فوری روی سرور ---------- */
  var joinedOnce = {};
  function onJoinClick(ev) {
    try {
      var b = ev.target && ev.target.closest ? ev.target.closest("button") : null;
      if (!b) return;
      var txt = String(b.textContent || "");
      if (txt.indexOf("شرکت در") !== 0 && txt.indexOf("شرکت کن") !== 0) return;
      var m = String(location.hash || "").match(/^#events\/([a-z0-9_-]+)/i);
      if (!m) return;
      var id = m[1];
      if (joinedOnce[id]) return;
      joinedOnce[id] = 1;
      api("/api/tournaments?action=join", { body: { id: id } }).then(function (r) {
        if (r.s === 200) st.joined = (st.joined || 0) + 1;
      }).catch(function () { });
    } catch (e) { }
  }

  /* ---------- ۶) ساخت رویداد از پنل مدیریت → سرور ---------- */
  function eventsFp() {
    var s = store(); if (!s) return "";
    return (s.events || []).map(function (e) { return String(e && e.id || ""); }).join(",");
  }
  function scanCreates() {
    var fp = eventsFp();
    if (fp === lastEventsFp) return;
    var first = lastEventsFp === null;
    lastEventsFp = fp;
    if (first) return;
    var s = store(); if (!s) return;
    (s.events || []).forEach(function (e) {
      if (!e || e.kind === "league") return;
      var id = String(e.id || "");
      if (!id || st.serverIds[id]) return;
      if (/^tour/.test(id)) return;
      if (pendingCreate[id]) return;
      pendingCreate[id] = 1;
      var days = 7;
      try { days = Math.max(1, Math.min(30, Math.ceil((Number(e.endsAt) || 0) ? (Number(e.endsAt) - Date.now()) / 86400000 : 7))); } catch (err) { }
      api("/api/tournaments?action=create", { body: { title: e.title || "", category: e.category || "general", days: days, description: e.description || "" } }).then(function (r) {
        if (r.s === 200 && r.j && r.j.id) {
          st.created++;
          var newId = String(r.j.id);
          setStore(function (cur) {
            return Object.assign({}, cur, { events: (cur.events || []).map(function (x) {
              return x && String(x.id) === id ? Object.assign({}, x, { id: newId }) : x;
            }) });
          });
          delete pendingCreate[id];
          toast("📡 رویداد روی سرور هم ثبت شد؛ حالا برای همهٔ بازیکنان دیده می‌شود");
          refresh();
        } else { delete pendingCreate[id]; st.lastErr = "create:" + r.s; }
      }).catch(function (e) { delete pendingCreate[id]; st.lastErr = String((e && e.message) || e); });
    });
  }

  /* ---------- ۷) «مرور و یادگیری» — صف اشتباهات، پیوسته با حساب ---------- */
  function bankQuestions() {
    try { if (window.__gamifyBankData && Array.isArray(window.__gamifyBankData.questions)) return window.__gamifyBankData.questions; } catch (e) { }
    try { var d = JSON.parse(ls(LS_BANK) || "null"); if (d && Array.isArray(d.questions)) return d.questions; } catch (e) { }
    return [];
  }
  function reviewsFp() {
    var s = store(); if (!s) return "";
    return (s.reviews || []).map(function (r) { return String(r && r.questionId || ""); }).join(",");
  }
  function scanReviews() {
    var fp = reviewsFp();
    if (fp === lastReviewsFp) return;
    var first = lastReviewsFp === null;
    lastReviewsFp = fp;
    if (first) return;
    var ids = fp ? fp.split(",") : [];
    ids = ids.filter(Boolean).slice(0, MAX_WQ);
    wqQueue = ids.length ? ids.map(function (i) { return WQ + i; }) : [WQ_NONE];
    st.reviewPushes++;
    try { if (window.__gamifySync && typeof window.__gamifySync.ensure === "function") { /* nothing */ } } catch (e) { }
    // شتاب‌دادن: درخواست /api/sync بعدی همین صف را می‌برد
  }
  function restoreReviews(sv) {
    // sv: پاسخ sync (interests سرور). اگر ندادیم، خودش GET /api/sync می‌کند.
    var run = function (data) {
      if (!data || !Array.isArray(data.interests)) return;
      lastServerWq = data.interests.filter(function (i) { return String(i).indexOf(WQ) === 0; });
      var ids = lastServerWq.map(function (i) { return String(i).slice(WQ.length); }).filter(function (i) { return i && i !== "none"; });
      if (!ids.length) return;
      var bank = bankQuestions();
      if (!bank.length) return;
      var s = store(); if (!s) return;
      var have = {};
      (s.reviews || []).forEach(function (r) { if (r && r.questionId) have[String(r.questionId)] = true; });
      var add = [];
      ids.forEach(function (id) {
        if (have[id]) return;
        var q = bank.find(function (x) { return String(x.id) === id; });
        if (!q) return;
        add.push({ questionId: q.id, category: q.category, title: q.title, options: q.options, correct: q.correct, explanation: q.explanation || "", at: 0 });
      });
      if (!add.length) return;
      st.reviewRestored += add.length;
      setStore(function (cur) {
        var base = (cur.reviews || []).slice();
        add.forEach(function (r) { if (!base.some(function (x) { return x && String(x.questionId) === String(r.questionId); })) base.push(r); });
        return Object.assign({}, cur, { reviews: base });
      });
    };
    if (sv) { run(sv); return; }
    api("/api/sync").then(function (r) { run(r.j); }).catch(function () { });
  }

  /* ---------- تزریق صفِ مرور به /api/sync ---------- */
  var realFetch = window.fetch;
  window.fetch = function (url, opts) {
    try {
      var u = String((url && url.url) || url || "");
      if (u.indexOf("/api/sync") !== -1 && opts && typeof opts.body === "string") {
        var b = JSON.parse(opts.body);
        var p = b && b.profile;
        if (p && typeof p === "object") {
          // قنات‌های interests: دسته‌ها + sh: (فروشگاه) + wq: (مرور). ترتیب: cats, sh, wq
          var raw = Array.isArray(p.interests) ? p.interests : [];
          var cats = raw.filter(function (i) { return String(i).indexOf(WQ) !== 0 && String(i).indexOf(SH) !== 0; });
          var bodySh = raw.filter(function (i) { return String(i).indexOf(SH) === 0; });
          var bodyWq = raw.filter(function (i) { return String(i).indexOf(WQ) === 0; });
          var queue = wqQueue;   // اگر این دستگاه تازه صف را عوض کرده، حرفِ آخر اوست
          if (!queue && !bodyWq.length && lastServerWq.length) queue = lastServerWq;  // وگرنه صفِ سرور حفظ شود
          var wq = (queue && queue.length) ? queue : bodyWq;
          var merged = cats.concat(bodySh, wq);
          var seen = {};
          merged = merged.filter(function (x) { var k = String(x); if (seen[k]) return false; seen[k] = 1; return true; }).slice(0, 20);
          if (JSON.stringify(merged) !== JSON.stringify(raw)) {
            p.interests = merged;
            opts = Object.assign({}, opts, { body: JSON.stringify(b) });
          }
        }
      }
    } catch (e) { }
    return realFetch.call(window, url, opts);
  };

  /* ---------- ۸) پاک‌نمایشِ تگ رویداد از متن فید (فقط ظاهری) ---------- */
  function stripTags() {
    try {
      if (!isOn("#feed") && !isOn("#events")) return;
      var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
      var list = [], n;
      while ((n = walker.nextNode())) {
        if (n.nodeValue && n.nodeValue.indexOf("g2ev:") !== -1) list.push(n);
      }
      list.forEach(function (t) { t.nodeValue = t.nodeValue.replace(/\s*g2ev:[a-z0-9_:-]+/gi, ""); });
    } catch (e) { }
  }

  /* ---------- راه‌اندازی ---------- */
  function boot() {
    var s = store();
    if (!s || !s.profile || !s.profile.id) { setTimeout(boot, 2500); return; }   // تا ورود/ساخت پروفایل
    st.ready = true;
    bootAt = Date.now();
    lastHistFp = histFp();
    lastReviewsFp = reviewsFp();
    lastEventsFp = eventsFp();
    refresh();
    restoreReviews();   // GET /api/sync → صفِ «مرور» روی سرور
    setInterval(function () { if (document.visibilityState !== "hidden") refresh(); }, REFRESH_MS);
    setInterval(function () { scanHistory(); scanCreates(); scanReviews(); }, SCAN_MS);
    setInterval(function () { restoreReviews(); }, 20000);   // تا صف بازسازی شود
    setInterval(stripTags, 5000);
    window.addEventListener("hashchange", stripTags, false);
    document.addEventListener("click", onJoinClick, true);
    // پاسخ هر سینک (که interests سرور را دارد) را هم مستقیم ببینیم
    window.addEventListener("gamify:synced", function (e) {
      try { if (e && e.detail) restoreReviews(e.detail); } catch (err) { }
    }, false);
    try { console.log("%c[gamify] رویدادها و مرور روی سرور وصل شدند 📡", "color:#7cc4ff"); } catch (e) { }
    window.__gamifyEventsLiveStatus = function () {
      return JSON.parse(JSON.stringify({
        ready: st.ready, serverEvents: st.serverEvents.length,
        participants: Object.keys(st.participants).length,
        myServerId: st.myServerId, refreshes: st.refreshes, lastRefresh: st.lastRefresh,
        submits: st.submits, announced: st.announced, created: st.created,
        reviewPushes: st.reviewPushes, reviewRestored: st.reviewRestored,
        medalsAdded: st.medalsAdded, lastErr: st.lastErr
      }));
    };
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else setTimeout(boot, 800);
})();
// EVENTS-LIVE-END
// TOPICS-LIVE-START — «موضوع‌های زنده»: موضوع‌ها از سرور می‌آیند + موضوع‌های ساخته‌شده روی سرور ثبت می‌شوند
//   مشکلِ قبلی: موضوعی که می‌ساختی فقط در localStorage (مرورگرِ خودت) می‌ماند → به کسی نمی‌آمد.
//   حالا:  ۱) موضوع‌های سرور (جدول categories) در بخش «موضوع‌ها» برای همه نمایش داده می‌شوند.
//          ۲) موضوعاتی که در اپ می‌سازی (اگر مدیر باشی) روی سرور هم ثبت می‌شوند تا بقیه ببینند.
(function () {
  "use strict";
  if (window.__gamifyTopicsLive) return;
  window.__gamifyTopicsLive = true;

  // دسته‌های استاندارد که قبلاً داخل bundle (yo) هستند — تکراری در customCategories نیندازیم
  var STD = { safety: 1, electric: 1, general: 1, science: 1, technology: 1, work: 1, nature: 1, sport: 1, geography: 1, history: 1, literature: 1, math: 1, space: 1, art: 1, music: 1, cinema: 1, food: 1, animals: 1, english: 1, engineering: 1 };
  var done = {};   // id → 1 : موضوعاتی که با موفقیت به سرور push شده‌اند
  var pending = {}; // id → 1 : در حالِ push

  function live() { try { return (typeof window.__gamifyLiveGet === "function") ? window.__gamifyLiveGet() : null; } catch (e) { return null; } }
  function setLive(fn) { try { return (window.__gamifyLiveSet) ? window.__gamifyLiveSet(fn) : null; } catch (e) { return null; } }
  function adminToken() { try { return localStorage.getItem("gamify2-admin-token") || ""; } catch (e) { return ""; } }
  function norm(c) { return { id: String(c.id), name: String(c.name || c.id), subtitle: String(c.subtitle || ""), icon: String(c.icon || "globe"), color: String(c.color || "#a98cf7"), tag: String(c.tag || ""), safety: Number(c.safety) || 0 }; }

  function sync() {
    var st = live();
    if (!st || !st.profile || !st.profile.id) return; // اپ هنوز آماده نیست
    fetch("/api/questions?category=_categories", { credentials: "include" })
      .then(function (r) { return r.json(); })
      .then(function (rows) {
        if (!Array.isArray(rows)) return;
        var srv = {};
        rows.forEach(function (c) { var id = String(c && c.id || ""); if (id) srv[id] = { name: String(c.name || id), subtitle: String(c.subtitle || ""), icon: String(c.icon || "globe"), color: String(c.color || "#a98cf7"), tag: String(c.tag || ""), active: c.active !== 0 }; });
        var st2 = live(); if (!st2) return;
        var local = Array.isArray(st2.customCategories) ? st2.customCategories.slice() : [];
        var localIds = {}; local.forEach(function (c) { localIds[String(c.id)] = 1; });

        // ۱) READ: موضوع‌های سرور (غیراستاندارد و فعال) را به موضوع‌ها اضافه کن
        var added = 0;
        Object.keys(srv).forEach(function (id) {
          if (STD[id]) return;
          if (!srv[id].active) return;
          if (localIds[id]) return;
          var n = norm({ id: id, name: srv[id].name, subtitle: srv[id].subtitle, icon: srv[id].icon, color: srv[id].color, tag: srv[id].tag });
          local.push(n); localIds[id] = 1; added++;
        });

        // ۲) WRITE: موضوع‌های محلیِ غیراستاندارد که روی سرور نیستند را (اگر مدیر) push کن
        var tok = adminToken();
        if (tok) {
          local.forEach(function (c) {
            var id = String(c.id);
            if (STD[id]) return;
            if (srv[id]) { done[id] = 1; return; }
            if (done[id] || pending[id]) return;
            pending[id] = 1;
            var body = norm(c);
            fetch("/api/admin?action=set-category", {
              method: "POST", credentials: "include",
              headers: { "Content-Type": "application/json", "x-admin-token": tok },
              body: JSON.stringify({ id: id, name: body.name, subtitle: body.subtitle, icon: body.icon, color: body.color, active: true })
            }).then(function (r) { if (r && (r.ok || r.status === 200)) done[id] = 1; })
              .catch(function () {})
              .then(function () { delete pending[id]; });
          });
        }

        if (added) {
          setLive(function () { var cur = live() || st2; return Object.assign({}, cur, { customCategories: local }); });
        }
      }).catch(function () {});
  }

  function boot() {
    var tries = 0;
    var iv = setInterval(function () {
      tries++;
      try { sync(); } catch (e) {}
      if (tries > 24) clearInterval(iv); // تا ≈ ثانیهٔ ۳۶
    }, 1500);
    setTimeout(function () {
      setInterval(function () { try { sync(); } catch (e) {} }, 25000);
    }, 32000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
// TOPICS-LIVE-END
