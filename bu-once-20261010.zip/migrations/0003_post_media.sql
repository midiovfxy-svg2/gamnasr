CREATE TABLE IF NOT EXISTS post_media (
  id text PRIMARY KEY,
  post_id text NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  owner_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  filename text NOT NULL,
  mime text NOT NULL,
  bytes bigint NOT NULL,
  duration double precision NOT NULL CHECK (duration > 0 AND duration <= 20),
  created_at bigint NOT NULL
);
CREATE INDEX IF NOT EXISTS post_media_post_idx ON post_media(post_id);
