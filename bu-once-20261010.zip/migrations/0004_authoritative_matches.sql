CREATE TABLE IF NOT EXISTS quiz_matches (
  id text PRIMARY KEY,
  user_id text NOT NULL REFERENCES users(id),
  category text NOT NULL REFERENCES categories(id),
  org_id text NOT NULL DEFAULT '',
  mode text NOT NULL,
  competition_id text NOT NULL DEFAULT '',
  day text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  questions jsonb NOT NULL,
  answers jsonb NOT NULL DEFAULT '[]',
  round integer NOT NULL DEFAULT 0,
  seconds integer NOT NULL DEFAULT 25,
  round_at bigint NOT NULL,
  bonus_seconds integer NOT NULL DEFAULT 0,
  helps jsonb NOT NULL DEFAULT '{}',
  used_helps jsonb NOT NULL DEFAULT '{}',
  score integer NOT NULL DEFAULT 0,
  rival_score integer NOT NULL DEFAULT 0,
  rival jsonb,
  created_at bigint NOT NULL,
  finished_at bigint,
  reward jsonb
);
CREATE INDEX IF NOT EXISTS quiz_matches_owner ON quiz_matches(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS quiz_matches_ranking ON quiz_matches(category,org_id,finished_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS quiz_matches_daily ON quiz_matches(user_id,day) WHERE mode='daily';
