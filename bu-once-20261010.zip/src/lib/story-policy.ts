export const STORY_DURATION_MS = 7000;
export const STORY_LIFETIME_MS = 24 * 60 * 60 * 1000;
export const STORY_MAIN_LIMIT = 10;
export type StoryTiming = { createdAt: number; expiresAt: number; seen?: boolean };
export function storyExpiresAt(story: StoryTiming) {
  return Math.min(story.expiresAt, story.createdAt + STORY_LIFETIME_MS);
}
export function storyIsActive(story: StoryTiming, now: number) {
  return Number.isFinite(story.createdAt) && Number.isFinite(story.expiresAt)
    && story.createdAt <= now && storyExpiresAt(story) > now;
}
export function partitionStories<T extends StoryTiming>(stories: T[], now: number) {
  const active = stories.filter(story => storyIsActive(story, now)).sort((a,b)=>b.createdAt-a.createdAt);
  const unread = active.filter(story => !story.seen);
  return { main: unread.slice(0,STORY_MAIN_LIMIT), more: [...unread.slice(STORY_MAIN_LIMIT), ...active.filter(story=>story.seen)] };
}
