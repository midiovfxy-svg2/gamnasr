import { pool } from "@/db";
import { getSessionUser, json, now, uid } from "@/lib/auth";
import { requireAdmin } from "@/lib/admin";

export type CompetitionKind = "league" | "event";
export async function listCompetitions(kind: CompetitionKind) {
  const user = await getSessionUser();
  const result = await pool.query(
    "SELECT * FROM shared_competitions WHERE kind=$1 AND active=true AND (org_id='' OR org_id=$2) ORDER BY starts_at DESC",
    [kind, user?.orgId || ""],
  );
  return json(result.rows.map(row => ({
    id: row.id, title: row.title, category: row.category, orgId: row.org_id,
    startsAt: Number(row.starts_at), endsAt: Number(row.ends_at),
    questionCount: row.question_count, seconds: row.seconds,
    open: Number(row.starts_at) <= now() && Number(row.ends_at) >= now(),
  })));
}

export async function createCompetition(req: Request, kind: CompetitionKind) {
  const admin = await requireAdmin(req);
  if (!admin) return json({ error: "forbidden" }, 403);
  // A signed admin token alone must first be associated with a real account.
  if (!admin.me) return json({ error: "admin-session-required" }, 401);
  const input = await req.json().catch(() => null);
  if (!input || typeof input.title !== "string" || input.title.trim().length < 3)
    return json({ error: "invalid-title" }, 400);
  const start = Number(input.startsAt), end = Number(input.endsAt);
  const count = Number(input.questionCount ?? 7), seconds = Number(input.seconds ?? 25);
  if (![start, end, count, seconds].every(Number.isSafeInteger) || end <= start || count < 1 || count > 100 || seconds < 5 || seconds > 120)
    return json({ error: "invalid-schedule" }, 400);
  const category = String(input.category || "");
  const bank = await pool.query("SELECT count(*)::integer AS total FROM questions WHERE category=$1 AND status='approved'", [category]);
  if (bank.rows[0].total < count) return json({ error: "insufficient-category-questions" }, 409);
  const org = String(input.orgId || "");
  if (org && !(await pool.query("SELECT id FROM organizations WHERE id=$1", [org])).rowCount)
    return json({ error: "unknown-organization" }, 400);
  const id = uid(kind);
  await pool.query(
    "INSERT INTO shared_competitions(id,kind,title,category,org_id,starts_at,ends_at,question_count,seconds,created_by,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)",
    [id, kind, input.title.trim().slice(0,120), category, org, start, end, count, seconds, admin.me.id, now()],
  );
  return json({ ok: true, id }, 201);
}
