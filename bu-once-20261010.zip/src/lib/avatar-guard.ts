/**
 * 🛡️ نگهبان آواتار — جلوگیری از «دایرهٔ مشکی» در بازی
 *
 * چرا لازم است؟ آواتاری که فقط { seed: N } است یا {} خالی، در مرورگر با تابع
 * SVG بازی کشیده می‌شود؛ آن تابع رنگ‌ها را از bg/skin/outfit می‌خواند و چون
 * وجود ندارند، مرورگر آن را «سیاه» رسم می‌کند. (در کد مرورگر هیچ پشتیبانی‌ای
 * برای seed وجود ندارد.)
 *
 * این ماژول هر آواتار «ناقص» را به یک عکس واقعی ۱ تا ۲۰ تبدیل می‌کند — دقیقاً با
 * همان روشی که خودِ بازی برای ساختن آواتار از روی نام استفاده می‌کند (فهرست
 * نام‌های زنانه + هش نام)، تا نتیجه در همهٔ پنل‌ها یکسان باشد.
 *
 * ⚠️ آواتار سالم هرگز تغییر نمی‌کند (عکس انتخابی کاربر یا پروفایل کامل SVG).
 */

/** فهرست نام‌های زنانه — عیناً همان الگوی خودِ بازی */
export const FEMALE_RE = /^(سارا|مریم|زهرا|فاطمه|نرگس|لیلا|الهام|شیرین|سمیرا|پریسا|نازنین|مینا|مهسا|نیلوفر|سحر|شبنم|آزاده|معصومه|زینب|ریحانه|هانیه|فرشته|مهناز|شهلا|پروین|اعظم|سمانه|سپیده|نسرین|مونا|غزل|یاسمن|نگار|نیکا|آیدا|رویا|راضیه|محبوبه|صدیقه|طاهره|کبری|سکینه|خدیجه|مرضیه|فائزه|ملیکا|هستی|ترانه|بهار|ندا|لاله|شقایق|ژیلا|آرزو|افسانه|مهری|منیژه|فریبا|فرزانه|شیوا|شهره|الناز|گلناز|پریا|پانته‌آ|نوشین|نسیم|مهتاب|ستاره|درسا|دنیا|آتنا|آناهیتا|هدیه|هلیا|کیمیا|روژان|نیایش|پرنیان)/;

/** عکس‌های زنانه و مردانه — همان دو فهرست خودِ بازی */
export const AVATAR_IMGS_F = [2, 4, 6, 9, 15, 16, 18];
export const AVATAR_IMGS_M = [1, 3, 5, 7, 8, 10, 11, 12, 13, 14, 17, 19, 20];

/** کلیدهایی که پروفایل کامل SVG را می‌سازند */
const SVG_KEYS = ["bg", "skin", "outfit", "hair", "hairColor", "eyes"] as const;

/** شمارهٔ عکس ۱ تا ۲۰ (یا ۰ اگر ندارد) */
function imgOf(a: unknown): number {
  if (typeof a === "number") return Number.isFinite(a) ? Math.round(a) : 0;
  if (!a || typeof a !== "object") return 0;
  const v = Number((a as Record<string, unknown>).img);
  if (!Number.isFinite(v)) return 0;
  const i = Math.round(v);
  return i >= 1 && i <= 20 ? i : 0;
}

/** آیا پروفایل کامل SVG است؟ (همان چیزی که بازی می‌تواند درست بکشد) */
function isFullSvg(a: unknown): boolean {
  if (!a || typeof a !== "object") return false;
  const o = a as Record<string, unknown>;
  return SVG_KEYS.every((k) => !!o[k]);
}

/** آواتار سالم است؟ (عکس ۱ تا ۲۰ یا پروفایل کامل SVG) */
export function isValidAvatar(a: unknown): boolean {
  return imgOf(a) > 0 || isFullSvg(a);
}

/** انتخاب شمارهٔ عکس از روی نام — همان روش خودِ بازی */
export function pickAvatarImg(name: unknown): number {
  const n = String(name ?? "").trim();
  const list = FEMALE_RE.test(n) ? AVATAR_IMGS_F : AVATAR_IMGS_M;
  let h = 0;
  for (let i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) >>> 0;
  return list[h % list.length];
}

/**
 * آواتار را سالم می‌کند: اگر سالم بود دست‌نخورده برمی‌گردد،
 * وگرنه عکس مناسبی بر اساس نام انتخاب می‌شود.
 */
export function fixAvatar(a: unknown, name: unknown): object {
  if (isValidAvatar(a)) {
    const i = imgOf(a);
    const o = a as Record<string, unknown>;
    if (i > 0 && (typeof a === "number" || Object.keys(o).length === 1)) return { img: i };
    return a as object;
  }
  return { img: pickAvatarImg(name) };
}
