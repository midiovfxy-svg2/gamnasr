"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { STORY_DURATION_MS, storyIsActive } from "@/lib/story-policy";
import styles from "./StoryRail.module.css";

type Story = {id:string;userId:string;author:string;avatar:unknown;title:string;media:string;options:string[];createdAt:number;expiresAt:number;seen:boolean};
type Page = {stories:Story[];serverNow:number;hasMore:boolean};
declare global { interface Window { __gamifyAvatarSrc?: (avatar:unknown)=>string } }
async function request<T>(url:string, body?:unknown):Promise<T> {
  const headers:Record<string,string>={"Content-Type":"application/json"};
  try { const token=JSON.parse(localStorage.getItem("gamify2-server")||"{}").token;if(token)headers["x-gamify-token"]=token; } catch {}
  const response=await fetch(url,{method:body?"POST":"GET",credentials:"include",cache:"no-store",headers,body:body?JSON.stringify(body):undefined});
  if(!response.ok)throw new Error(response.status===404?"این استوری منقضی شده است.":"ارتباط با سرور برقرار نشد؛ دوباره تلاش کن.");
  return response.json();
}
function Avatar({story}:{story:Story}) {
  const source=window.__gamifyAvatarSrc?.(story.avatar);
  return source?<img src={source} alt="" className={styles.avatar}/>:<span className={styles.avatar}>{story.author.slice(0,1)}</span>;
}
function Viewer({story,next,previous,close,clock}:{story:Story;next:()=>void;previous:()=>void;close:()=>void;clock:number}) {
  const dialog=useRef<HTMLDialogElement>(null);
  const startedAt=useRef(0);
  const [remaining,setRemaining]=useState(STORY_DURATION_MS);
  const [answer,setAnswer]=useState<number|null>(null);
  const [result,setResult]=useState<{correct:number;explanation:string}|null>(null);
  const [error,setError]=useState("");
  useEffect(()=>{
    const element=dialog.current;element?.showModal();
    return ()=>element?.close();
  },[]);
  useEffect(()=>{
    if(!startedAt.current)startedAt.current=performance.now();
    const start=startedAt.current;
    const timer=setInterval(()=>{
      const left=Math.max(0,STORY_DURATION_MS-(performance.now()-start));setRemaining(left);
      if(left===0||!storyIsActive(story,Date.now()+clock))next();
    },100);
    return ()=>clearInterval(timer);
  },[story,next,clock]);
  const choose=async (choice:number)=>{
    if(answer!==null)return;
    setAnswer(choice);
    try {setResult(await request('/api/stories',{id:story.id,answer:choice}));}catch(e){setError((e as Error).message);}
  };
  return <dialog ref={dialog} className={styles.viewer} onCancel={close} aria-label={`استوری ${story.author}`} onKeyDown={e=>{if(e.key==='ArrowLeft'){e.preventDefault();next();}if(e.key==='ArrowRight'){e.preventDefault();previous();}}}>
    <div className={styles.progress} role="progressbar" aria-label="زمان استوری" aria-valuemin={0} aria-valuemax={7} aria-valuenow={Math.ceil(remaining/1000)}><span style={{width:`${remaining/STORY_DURATION_MS*100}%`}}/></div>
    <header className={styles.header}><Avatar story={story}/><a href={`#messages/${encodeURIComponent(story.userId)}`} onClick={close}>{story.author}</a><span>{Math.ceil(remaining/1000).toLocaleString('fa-IR')}</span><button onClick={close} aria-label="بستن استوری">×</button></header>
    <div className={styles.content}>
      {story.media&&<img className={styles.media} src={story.media} alt="تصویر استوری"/>}
      <p>{story.title}</p>
      {!!story.options?.length&&<div className={styles.options}>{story.options.map((option,i)=><button key={i} disabled={answer!==null} onClick={()=>void choose(i)} style={result&&i===result.correct?{borderColor:'#7cd7b6',background:'#21493c'}:undefined}>{option}</button>)}</div>}
      {result&&<p role="status">{answer===result.correct?'آفرین! پاسخ درست بود.':`پاسخ درست: ${story.options[result.correct]}`} {result.explanation}</p>}
      {error&&<p role="alert">{error}</p>}
    </div>
    <footer className={styles.controls}><button onClick={previous}>قبلی ←</button><button onClick={next}>→ بعدی</button></footer>
  </dialog>;
}

export default function StoryRail(){
  const [host,setHost]=useState<Element|null>(null);
  const [main,setMain]=useState<Story[]>([]),[more,setMore]=useState<Story[]>([]);
  const [showMore,setShowMore]=useState(false),[hasMore,setHasMore]=useState(false),[loading,setLoading]=useState(false);
  const [queue,setQueue]=useState<Story[]>([]),[index,setIndex]=useState(0);
  const [clock,setClock]=useState(0),[time,setTime]=useState(Date.now()),[error,setError]=useState("");
  const moreDialog=useRef<HTMLDialogElement>(null);
  const loadMain=useCallback(async()=>{
    try {await window.__gamifyBootstrap;const page=await request<Page>('/api/stories');setClock(page.serverNow-Date.now());setMain(page.stories);setError('');}
    catch(e){setError((e as Error).message);}
  },[]);
  useEffect(()=>{
    const locate=()=>setHost(document.querySelector('[data-server-stories]'));
    locate();const observer=setInterval(locate,500);const clockTimer=setInterval(()=>setTime(Date.now()),1000);
    void loadMain();const refresh=setInterval(()=>void loadMain(),30000);
    return ()=>{clearInterval(observer);clearInterval(clockTimer);clearInterval(refresh);};
  },[loadMain]);
  const close=useCallback(()=>{setQueue([]);void loadMain();},[loadMain]);
  const next=useCallback(()=>{if(index+1<queue.length)setIndex(index+1);else close();},[index,queue.length,close]);
  const previous=()=>{if(index>0)setIndex(index-1);};
  const story=queue[index];
  useEffect(()=>{
    if(!story)return;
    let active=true;
    request('/api/stories',{id:story.id}).then(()=>{if(active){setMain(rows=>rows.filter(s=>s.id!==story.id));}}).catch(e=>{if(active)setError((e as Error).message);});
    return ()=>{active=false;};
  },[story]);
  const loadMore=async(append=false)=>{
    if(loading)return;setLoading(true);
    try {
      await window.__gamifyBootstrap;
      const page=await request<Page>(`/api/stories?view=more&offset=${append?more.length:0}`);
      setClock(page.serverNow-Date.now());setMore(old=>append?[...old,...page.stories.filter(s=>!old.some(o=>o.id===s.id))]:page.stories);
      setHasMore(page.hasMore);setShowMore(true);setError('');
    }catch(e){setError((e as Error).message);}finally{setLoading(false);}
  };
  useEffect(()=>{if(showMore)moreDialog.current?.showModal();else moreDialog.current?.close();},[showMore]);
  const visibleMain=main.filter(s=>storyIsActive(s,time+clock)&&!s.seen).slice(0,10);
  const visibleMore=more.filter(s=>storyIsActive(s,time+clock));
  const open=(items:Story[],i:number)=>{setShowMore(false);setQueue(items);setIndex(i);};
  const tile=(s:Story,i:number,items:Story[])=><button key={s.id} className={styles.tile} onClick={()=>open(items,i)} aria-label={`استوری ${s.author}${s.seen?'، دیده‌شده':''}`}><span className={`${styles.ring} ${s.seen?styles.seen:''}`}><Avatar story={s}/></span><span>{s.author}</span>{s.seen&&<small>دیده‌شده</small>}</button>;
  if(!host)return null;
  return createPortal(<>
    <section className={styles.rail} aria-label="استوری‌ها">{visibleMain.map((s,i)=>tile(s,i,visibleMain))}<button className={styles.more} onClick={()=>void loadMore()} disabled={loading}>•••<span>{loading?'در حال دریافت…':'بیشتر'}</span></button></section>
    {error&&<p role="alert" className={styles.error}>{error}<button onClick={()=>void loadMain()}>تلاش دوباره</button></p>}
    {showMore&&<dialog ref={moreDialog} className={styles.gallery} onCancel={()=>setShowMore(false)} aria-label="استوری‌های بیشتر"><header className={styles.header}><h2>استوری‌های بیشتر</h2><button onClick={()=>setShowMore(false)} aria-label="بستن">×</button></header><div className={styles.grid}>{visibleMore.map((s,i)=>tile(s,i,visibleMore))}</div>{!visibleMore.length&&<p>استوری دیگری در ۲۴ ساعت گذشته وجود ندارد.</p>}{hasMore&&<button className="btn" disabled={loading} onClick={()=>void loadMore(true)}>نمایش بیشتر</button>}</dialog>}
    {story&&<Viewer key={story.id} story={story} next={next} previous={previous} close={close} clock={clock}/>}
  </>,host);
}
