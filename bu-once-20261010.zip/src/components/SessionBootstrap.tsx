"use client";

import { useEffect, useState } from "react";
import { createSessionClient, type SessionProfile } from "@/lib/session-client";

type LiveState = { profile?: Record<string, unknown> | null; [key: string]: unknown };
declare global {
  interface Window {
    __gamifyBootstrap?: Promise<SessionProfile>;
    __gamifyBootstrapDone?: boolean;
    __gamifyLiveSet?: (update: (state: LiveState) => LiveState) => void;
  }
}
const client = createSessionClient((url, init) => fetch(url, init), () => {
  try { return JSON.parse(localStorage.getItem("gamify2-server") || "{}").token || ""; }
  catch { return ""; }
});

/** Transitional bridge: keep the original renderer while session ownership moves to the server. */
export default function SessionBootstrap() {
  const [error, setError] = useState(false);
  useEffect(() => {
    let mounted = true;
    if (!window.__gamifyBootstrap) {
      window.__gamifyBootstrap = client.ensure().then(async profile => {
        // The original module installs its state bridge once it has loaded.
        for (let attempt = 0; !window.__gamifyLiveSet && attempt < 200; attempt++) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
        if (!window.__gamifyLiveSet) throw new Error("game-renderer-unavailable");
        window.__gamifyLiveSet(state => ({
          ...state,
          profile: { ...state.profile, ...profile, org: profile.orgId || "" },
        }));
        try {
          const meta = JSON.parse(localStorage.getItem("gamify2-server") || "{}");
          localStorage.setItem("gamify2-server", JSON.stringify({ ...meta, serverId: profile.id, token: profile.serverToken || meta.token }));
        } catch { /* The HttpOnly session cookie still works if storage is unavailable. */ }
        window.__gamifyBootstrapDone = true;
        window.dispatchEvent(new CustomEvent("gamify:synced", { detail: profile }));
        return profile;
      });
    }
    window.__gamifyBootstrap.catch(() => { if (mounted) setError(true); });
    return () => { mounted = false; };
  }, []);
  if (!error) return null;
  return <div role="alert" style={{ position: "fixed", bottom: 16, right: 16, zIndex: 100999, padding: 16, background: "#241a33", color: "#fff", borderRadius: 12 }}>
    اتصال به حساب سرور انجام نشد. <button onClick={() => location.reload()}>تلاش دوباره</button>
  </div>;
}
