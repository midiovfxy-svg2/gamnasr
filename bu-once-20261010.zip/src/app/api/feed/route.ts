import { desc, eq, and, gt, lte } from "drizzle-orm";
import { db } from "@/db";
import { posts, stories } from "@/db/schema";
import { uid, now, json, getSessionUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";
import { moderationFlags, getJsonSetting } from "@/lib/admin";
import { publish } from "@/lib/realtime";

// GET ?type=posts|stories — فید سرور (بکاپ + نمایش)
// POST ?type=post|story — ثبت در سرور (آینهٔ localStorage) برای صف تأیید مدیر
export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url);
  const type = url.searchParams.get("type") || "posts";
  const since = Number(url.searchParams.get("since") || 0);
  if (type === "stories") {
    const at = now();
    const rows = await db.select().from(stories).where(and(eq(stories.status, "approved"), gt(stories.expiresAt, at), gt(stories.createdAt, Math.max(Number.isFinite(since) ? since : 0, at - 86400000)), lte(stories.createdAt, at))).orderBy(desc(stories.createdAt)).limit(60);
    return json(rows);
  }
  if (type === "pending") {
    const me = await getSessionUser();
    if (!me || me.role !== "admin") return json({ error: "forbidden" }, 403);
    const p = await db.select().from(posts).where(eq(posts.status, "pending")).orderBy(desc(posts.createdAt)).limit(60);
    const st = await db.select().from(stories).where(eq(stories.status, "pending")).orderBy(desc(stories.createdAt)).limit(60);
    return json({ posts: p, stories: st });
  }
  const rows = await db.select().from(posts).where(since ? and(eq(posts.status, "approved"), gt(posts.createdAt, since)) : eq(posts.status, "approved")).orderBy(desc(posts.createdAt)).limit(60);
  return json(rows);
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed" }, 401);
  const type = new URL(req.url).searchParams.get("type") || "post";
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const t = now();
  const flags = await moderationFlags();
  const avatar = me.avatar;

  if (type === "story") {
    const title = String(b.title || "").slice(0, 500);
    if (title.length < 5) return json({ error: "متن سؤال کوتاه است." }, 400);
    const id = String(b.id || uid("st"));
    await db.insert(stories).values({
      id, userId: me.id, userName: me.name,
      category: String(b.category || "general"),
      title, options: Array.isArray(b.options) ? (b.options as string[]).slice(0, 4) : [],
      correct: Number(b.correct) || 0,
      explanation: String(b.explanation || "").slice(0, 1000),
      media: String(b.media || ""),
      status: me.role === "admin" || !flags.moderateStories ? "approved" : "pending",
      autoApproved: !flags.moderateStories, moderatedBy: "", createdAt: t, expiresAt: t + 86400000,
    }).onConflictDoNothing();
    const stStatus = me.role === "admin" || !flags.moderateStories ? "approved" : "pending";
    if (stStatus === "approved") {
      publish("*", "feed:story", { id, authorId: me.id, author: me.name, avatar, category: String(b.category || "general"), title, options: Array.isArray(b.options) ? (b.options as string[]).slice(0, 4) : [], correct: Number(b.correct) || 0, explanation: String(b.explanation || "").slice(0, 1000), media: String(b.media || ""), at: t, expiresAt: t + 86400000 });
    } else publish("*", "moderation:pending", { kind: "story", id });
    return json({ ok: true, id, status: stStatus });
  }

  const body = String(b.body || "").slice(0, 4000);
  const site = await getJsonSetting<Record<string,unknown>>("site-config", {});
  if (String(b.media || "").startsWith("/api/post-media/")) return json({error:"ویدئو را از بخش ارسال ویدئو بارگذاری کنید"},400);
  if (me.role !== "admin") {
    if (b.media && site.allowPostImages === false) return json({error:"انتشار عکس توسط مدیر غیرفعال شده است"},403);
    if (b.audio && site.allowPostAudio === false) return json({error:"انتشار صدا توسط مدیر غیرفعال شده است"},403);
  }
  if (body.length < 3) return json({ error: "متن پست کوتاه است." }, 400);
  const id = String(b.id || uid("post"));
  await db.insert(posts).values({
    id, userId: me.id, userName: me.name,
    category: String(b.category || "work"),
    body, media: String(b.media || ""), audio: String(b.audio || ""),
    status: me.role === "admin" || !flags.moderatePosts ? "approved" : "pending",
    likes: 0, autoApproved: !flags.moderatePosts, moderatedBy: "", moderatedAt: 0, createdAt: t,
  }).onConflictDoNothing();
  const pStatus = me.role === "admin" || !flags.moderatePosts ? "approved" : "pending";
  if (pStatus === "approved") {
    publish("*", "feed:post", { id, authorId: me.id, author: me.name, avatar, category: String(b.category || "work"), body, media: String(b.media || ""), audio: String(b.audio || ""), at: t });
  } else publish("*", "moderation:pending", { kind: "post", id });
  return json({ ok: true, id, status: pStatus });
}
