import { getSessionUser, json } from "@/lib/auth";
import { notifyUser, subsOf } from "@/lib/push";

/** 🧪 ارسال اعلان آزمایشی برای خودم (دکمهٔ «تست اعلان» در پنل) */
export const dynamic = "force-dynamic";

export async function POST() {
  const me = await getSessionUser();
  if (!me) return json({ ok: false, error: "not-authed" }, 401);
  const subs = await subsOf(me.id);
  const web = subs.filter((s) => s.kind === "web").length;
  const dev = subs.filter((s) => s.kind === "device").length;
  const r = await notifyUser(me.id, {
    title: "🔔 اعلان‌ها فعال است",
    body: `از این پس دعوت به مبارزه، نتیجهٔ مسابقه و پیام‌های مدیر را همین‌جا می‌بینی. (${me.name})`,
    link: "#feed",
    tag: "test-" + Date.now(),
    kind: "info",
  });
  return json({
    ok: true, id: r.id, pushed: r.pushed, webSubs: web, devices: dev,
    message: web || dev
      ? `اعلان آزمایشی برای ${web} مرورگر و ${dev} دستگاه فرستاده شد.`
      : "هیچ اشتراک فعالی پیدا نشد؛ اول اعلان‌ها را روشن کن.",
  });
}
