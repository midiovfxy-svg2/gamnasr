import { json } from "@/lib/auth";
import { getVapid, pushSettingGet } from "@/lib/push";

/**
 * 🔑 کلید عمومی VAPID برای مرورگر
 * مرورگر با این کلید اشتراک پوش می‌سازد (window.PushManager.subscribe).
 */
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const v = await getVapid();
    const enabled = (await pushSettingGet("push_enabled", "on")) === "on";
    return json({ ok: true, enabled, publicKey: v.publicKey, version: 1 });
  } catch {
    return json({ ok: false, enabled: false, publicKey: "" }, 200);
  }
}
