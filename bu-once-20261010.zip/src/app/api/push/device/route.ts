import { getSessionUser, json } from "@/lib/auth";
import { saveDevice } from "@/lib/push";

/**
 * 📱 ثبت دستگاه اپ اندروید
 * بدنه: { deviceId }
 * خروجی: { ok, token } — توکن مخصوص همین دستگاه که اپ با آن اعلان‌هایش را می‌گیرد.
 * هویت فقط از نشست معتبر خوانده می‌شود.
 */
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const me = await getSessionUser();
  if (!me) return json({ ok: false, error: "not-authed" }, 401);
  let b: { deviceId?: string; ua?: string } = {};
  try { b = await req.json(); } catch { b = {}; }
  const r = await saveDevice(me.id, String(b.deviceId || ""), String(b.ua || req.headers.get("user-agent") || ""));
  if (!r.ok) return json({ ok: false, error: r.error }, 400);
  return json({ ok: true, token: r.token, user: me.name });
}
