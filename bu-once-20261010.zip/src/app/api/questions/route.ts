import { eq, and, sql, count } from "drizzle-orm";
import { db } from "@/db";
import { questions, categories } from "@/db/schema";
import { json } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// GET ?category=general&count=5 — سؤال برای نبرد قبیله‌ای/تورنمنت (بدون پاسخ!)
export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url).searchParams.get("category") || "general";
  const requested = Number(new URL(req.url).searchParams.get("count") || 5);
  if (!Number.isInteger(requested) || requested < 1 || requested > 10) return json({ error: "invalid-count" }, 400);
  const countN = requested;
  if (url === "_categories") {
    const rows = await db.select().from(categories);
    const out = [];
    for (const c of rows) {
      const n = await db.select({ total: count() }).from(questions).where(and(eq(questions.category, c.id), eq(questions.status, "approved")));
      out.push({ ...c, questionCount: Number(n[0]?.total ?? 0) });
    }
    return json(out);
  }
  const bank = await db.select().from(questions).where(and(eq(questions.category, url), eq(questions.status, "approved"))).orderBy(sql`random()`).limit(countN);
  if (bank.length < countN) return json({ error: "insufficient-category-questions", message: "سؤال تأییدشدهٔ کافی در این دسته وجود ندارد." }, 409);
  const picked = bank
    .map((q) => ({ id: q.id, category: q.category, title: q.title, options: q.options, seconds: q.seconds ?? 25 }));
  return json(picked);
}
