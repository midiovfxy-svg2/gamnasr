import { eq, or, and, inArray } from "drizzle-orm";
import { db } from "@/db";
import { users, orgMembers, notifications } from "@/db/schema";
import { coinLedger } from "@/db/coinledger";
import { uid, now, pub, createSession, setAuthCookie, json, getSessionUser, getCurrentToken } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

/**
 * قلب تپندهٔ ذخیرهٔ دوگانه:
 * - بازی اصلی در localStorage با کلید gamify2-store-v2 ذخیره می‌کند (دست‌نخورده می‌ماند)
 * - این API هم‌زمان همان پروفایل را در سرور (Postgres) ذخیره/به‌روز می‌کند
 * - فقط صاحب نشست معتبر به‌روز می‌شود؛ شناسه یا تماس ارسالی مجوز ورود نیست.
 *
 * 🪙 بستهٔ «سکهٔ زنده» (D): تراز سکه از این‌بعد مرجعِ سرور است.
 * - در ثبتِ نخست، سکهٔ اعلام‌شده (با سقف ۱۰٬۰۰) به‌عنوان تراز اولیه می‌نشیند.
 * - بعد از آن، sync دیگر سکهٔ اعلامی را نمی‌پذیرد (ضدتقلبِ تورم)؛
 *   سکه فقط از مسیر /api/coins (delta/buy/adjust) و /api/daily تغییر می‌کند.
 */

const MAX_BOOTSTRAP_COINS = 10000; // سقف تراز اولیهٔ ثبتِ نخست

export async function POST(req: Request) {
  await ensureSeed();
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }

  const profile = (b.profile ?? b) as Record<string, unknown>;
  const localId = String(profile.id ?? profile.localId ?? "");
  const name = String(profile.name ?? "میهمان").slice(0, 40) || "میهمان";
  const orgId = String(profile.org ?? profile.orgId ?? "");

  const num = (v: unknown, d = 0) => (typeof v === "number" && Number.isFinite(v) ? Math.max(0, Math.round(v)) : d);
  const xp = num(profile.xp), coins = num(profile.coins, 50), cups = num(profile.cups);
  const streak = num(profile.streak), wins = num(profile.wins), played = num(profile.played);
  const rating = num(profile.rating, 1000), weekXp = num(profile.weekXp ?? profile.week_xp, xp);
  const level = Math.floor(xp / 250) + 1;

  // ۱) نشست فعلی؟
  const me = await getSessionUser();
  let user = me;

  if (!user) return json({ error: "not-authed", message: "نشست معتبر لازم است؛ صفحه را دوباره باز کنید." }, 401);
  {
    // به‌روزرسانی افزایشی: بزرگ‌ترین مقدار نگه داشته می‌شود تا XP کم نشود
    // 🪙 سکه: استثنائاست — ترازِ سرور حفظ می‌شود (سکه فقط از /api/coins و /api/daily تغییر می‌کند)

    // 🪙 قفلِ قناتِ فروشگاه: قلمِ sh: تازه فقط با رکوردِ خرید (دفتر سکه) پذیرفته
    // می‌شود تا ثبتِ مالکیتِ بی‌پرداخت (از مسیر sync) امکان‌پذیر نباشد.
    const clientInterests: string[] = Array.isArray(profile.interests) ? (profile.interests as string[]) : [];
    const prevInterests: string[] = Array.isArray(user.interests) ? (user.interests as string[]) : [];
    const prevSet = new Set(prevInterests);
    const newSh = clientInterests.filter((x) => typeof x === "string" && x.indexOf("sh:") === 0 && !prevSet.has(x));
    let mergedInterests: string[];
    if (!clientInterests.length) {
      mergedInterests = prevInterests;
    } else if (!newSh.length) {
      mergedInterests = clientInterests.slice(0, 20);
    } else {
      const ids = newSh.map((x) => x.slice(3)).filter(Boolean);
      const paid = await db
        .select()
        .from(coinLedger)
        .where(and(eq(coinLedger.userId, user.id), eq(coinLedger.reason, "buy"), inArray(coinLedger.ref, ids)))
        .limit(50);
      const paidSet = new Set(paid.map((p) => p.ref));
      mergedInterests = clientInterests
        .filter((x) => {
          if (typeof x === "string" && x.indexOf("sh:") === 0 && !prevSet.has(x)) return paidSet.has(x.slice(3));
          return true;
        })
        .slice(0, 20);
    }

    const patch = {
      extra: { ...(user.extra as Record<string,unknown> || {}), interestsSet: !!(user.extra as Record<string,unknown> | null)?.interestsSet || profile.interestsSet === true },
      name: name !== "میهمان" || !user.name ? name : user.name,
      avatar: (profile.avatar as object) ?? user.avatar,
      bio: profile.bio !== undefined ? String(profile.bio).slice(0, 300) : user.bio,
      orgId: user.orgId,
      xp: Math.max(user.xp ?? 0, xp),
      coins: user.coins ?? 0,
      cups: Math.max(user.cups ?? 0, cups),
      streak: Math.max(user.streak ?? 0, streak),
      wins: Math.max(user.wins ?? 0, wins),
      played: Math.max(user.played ?? 0, played),
      rating: rating || user.rating,
      weekXp: Math.max(user.weekXp ?? 0, weekXp),
      level: Math.max(user.level ?? 1, level),
      interests: mergedInterests,
      lastSeen: now(),
      localId: user.localId || localId,
    };
    await db.update(users).set(patch).where(eq(users.id, user.id));
    user = { ...user, ...patch };

  }

  // نشست فعلی معتبر است؟ همان را نگه دار (از انباشت نشست‌های تکراری جلوگیری می‌شود)
  const token = me && user.id === me.id ? (await getCurrentToken()) || (await createSession(user.id)).token : (await createSession(user.id)).token;
  const res = json({ ...pub(user), serverToken: token, syncedAt: now() });
  return setAuthCookie(res, token);
}

export async function GET() {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed" }, 401);
  return json(pub(me));
}
