import { eq, and, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, dailyClaims } from "@/db/schema";
import { coinLedger } from "@/db/coinledger";
import { uid, now, json, getSessionUser, createSession, setAuthCookie } from "@/lib/auth";
import { requireAdmin } from "@/lib/admin";
import { ensureSeed } from "@/lib/ensure-seed";

/**
 * 🪙 سکهٔ زنده — تراز سکه سمت سرور + ضدتقلب
 * ─────────────────────────────────────────────────────────────
 * GET  → { coins, streak, lastDaily, claimedToday }
 * POST { op:"delta",  delta }        تغییر محلی (بازی/کمک‌هزینه) — با سقف ساعتی/روزانه
 * POST { op:"buy",    itemId }       خرید فروشگاه — قیمت مالکیت سروری، کسر اتمیک
 * POST { op:"adjust", userId, amount, note }   فقط مدیر (کد مدیریت)
 * هر پاسخ، تراز قطعی سرور (coins) را برمی‌گرداند تا کلاینت روی آن همگام شود.
 */

// همان فهرست قیمتِ بستهٔ «فروشگاه زنده» (C) — سرور مرجعِ قیمت است
const PRICE: Record<string, number> = {
  "title-mentor": 300,
  "title-safety": 250,
  "extra-life": 120,
  "frame-gold": 400,
  "theme-night": 200,
  "badge-fire": 150,
};
const SH = "sh:";

const MAX_PER_TX = 500;    // سقف یک گزارشِ تغییر محلی
const MAX_PER_HOUR = 2000; // سقف مثبتِ ساعتی (ضدتقلب)
const MAX_PER_DAY = 8000;  // سقف مثبتِ روزانه

async function posSum(userId: string, sinceMs: number) {
  const rows = await db
    .select({ s: sql<number>`COALESCE(SUM(CASE WHEN ${coinLedger.delta} > 0 THEN ${coinLedger.delta} ELSE 0 END), 0)::int` })
    .from(coinLedger)
    .where(and(eq(coinLedger.userId, userId), gte(coinLedger.createdAt, sinceMs)));
  return Number(rows[0]?.s ?? 0);
}

async function ledger(userId: string, delta: number, reason: string, ref = "", note = "") {
  if (!delta) return;
  try {
    await db.insert(coinLedger).values({ id: uid("cl"), userId, delta, reason, ref, note, createdAt: now() });
  } catch { /* دفتر نباید مسیر اصلی را بشکند */ }
}

export async function GET(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed" }, 401);
  const today = new Date().toISOString().slice(0, 10);
  const cl = (await db.select().from(dailyClaims).where(and(eq(dailyClaims.userId, me.id), eq(dailyClaims.day, today))).limit(1))[0];
  return json({ coins: me.coins ?? 0, streak: me.streak ?? 0, lastDaily: me.lastDaily ?? "", claimedToday: !!cl });
}

export async function POST(req: Request) {
  await ensureSeed();
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو 🌱" }, 401);
  const op = String(b.op ?? "");
  const t = now();

  /* ---------- گزارشِ تغییر محلی (بازی/کمک‌هزینه) ---------- */
  if (op === "delta") {
    let delta = typeof b.delta === "number" && Number.isFinite(b.delta) ? Math.round(b.delta) : 0;
    if (!delta) return json({ ok: true, coins: me.coins ?? 0 });
    delta = Math.max(-MAX_PER_TX, Math.min(MAX_PER_TX, delta));
    let capped = false;
    if (delta > 0) {
      const hUsed = await posSum(me.id, t - 3600000);
      const dUsed = await posSum(me.id, t - 86400000);
      const allow = Math.min(delta, MAX_PER_HOUR - hUsed, MAX_PER_DAY - dUsed);
      if (allow < delta) capped = true;
      delta = Math.max(0, allow);
      if (!delta) {
        return json({ ok: false, capped: true, coins: me.coins ?? 0, message: "سقف سکهٔ ساعتی/روزانه به پایان رسید؛ فردا دوباره امتحان کن." });
      }
    }
    const cur = me.coins ?? 0;
    const next = Math.max(0, cur + delta);
    if (next !== cur + delta) capped = true; // کف صفر
    await db.update(users).set({ coins: next }).where(eq(users.id, me.id));
    await ledger(me.id, next - cur, "delta", "", String(b.reason ?? "").slice(0, 40));
    const { token } = await createSession(me.id);
    const res = json({ ok: true, coins: next, capped, serverToken: token });
    return setAuthCookie(res, token);
  }

  /* ---------- خرید فروشگاه (قیمت و مالکیت مرجعِ سرور) ---------- */
  if (op === "buy") {
    const itemId = String(b.itemId ?? "");
    const price = PRICE[itemId];
    if (!price) return json({ ok: false, error: "invalid", coins: me.coins ?? 0, message: "این قلم در فهرست قیمت سرور نیست." }, 400);
    const interests: string[] = Array.isArray(me.interests) ? (me.interests as string[]) : [];
    const tag = SH + itemId;
    if (interests.includes(tag)) {
      // مالکیت قبلاً ثبت شده (مثلاً از مسیر sync بستهٔ C).
      // ضمانتِ «یک‌بارِ دقیق»: اگر هنوز کسری روی سرور نبوده، حالا تسویه می‌شود.
      const paid = (await db.select().from(coinLedger).where(and(eq(coinLedger.userId, me.id), eq(coinLedger.reason, "buy"), eq(coinLedger.ref, itemId))).limit(1))[0];
      if (paid) return json({ ok: true, coins: me.coins ?? 0, already: true, owned: interests });
      const curSettle = me.coins ?? 0;
      if (curSettle < price) return json({ ok: false, error: "insufficient", coins: curSettle, message: "سکهٔ کافی نداری (به " + price + " سکه نیاز است)." });
      const nextSettle = curSettle - price;
      await db.transaction(async (tx) => {
        await tx.update(users).set({ coins: nextSettle }).where(eq(users.id, me.id));
        await tx.insert(coinLedger).values({ id: uid("cl"), userId: me.id, delta: -price, reason: "buy", ref: itemId, note: "settle", createdAt: t });
      });
      const tok2 = await createSession(me.id);
      const res2 = json({ ok: true, coins: nextSettle, settled: true, owned: interests, serverToken: tok2.token });
      return setAuthCookie(res2, tok2.token);
    }
    const cur = me.coins ?? 0;
    if (cur < price) return json({ ok: false, error: "insufficient", coins: cur, message: "سکهٔ کافی نداری (به " + price + " سکه نیاز است)." });
    const next = cur - price;
    const newInterests = interests.filter((x) => x !== tag);
    newInterests.push(tag);
    await db.transaction(async (tx) => {
      await tx.update(users).set({ coins: next, interests: newInterests.slice(0, 20) }).where(eq(users.id, me.id));
      await tx.insert(coinLedger).values({ id: uid("cl"), userId: me.id, delta: -price, reason: "buy", ref: itemId, note: "", createdAt: t });
    });
    const { token } = await createSession(me.id);
    const res = json({ ok: true, coins: next, owned: newInterests.slice(0, 20), serverToken: token });
    return setAuthCookie(res, token);
  }

  /* ---------- تنظیم دستی (فقط مدیر) ---------- */
  if (op === "adjust") {
    const adm = await requireAdmin(req);
    if (!adm) return json({ error: "forbidden", message: "برای این عمل باید با کد مدیریت وارد باشی." }, 403);
    const targetId = String(b.userId ?? "");
    const amount = typeof b.amount === "number" && Number.isFinite(b.amount) ? Math.round(b.amount) : 0;
    const note = String(b.note ?? "").slice(0, 120) || "پنل مدیریت";
    if (!targetId || !amount) return json({ error: "invalid" }, 400);
    const rows = await db.select().from(users).where(eq(users.id, targetId)).limit(1);
    if (!rows[0]) return json({ error: "not-found" }, 404);
    const cur = rows[0].coins ?? 0;
    const next = Math.max(0, cur + amount);
    await db.transaction(async (tx) => {
      await tx.update(users).set({ coins: next }).where(eq(users.id, targetId));
      await tx.insert(coinLedger).values({ id: uid("cl"), userId: targetId, delta: next - cur, reason: "admin", ref: adm.me ? adm.me.id : "admin-token", note, createdAt: t });
    });
    return json({ ok: true, coins: next });
  }

  return json({ error: "unknown-op" }, 400);
}
