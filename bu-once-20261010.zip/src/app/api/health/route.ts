import { json } from "@/lib/auth";
import { pool } from "@/db";

export async function GET() {
  try {
    await pool.query("SELECT 1");
    return json({ ok: true, database: "connected", app: "gamify2", ts: Date.now() });
  } catch {
    return json({ ok: false, database: "unavailable" }, 503);
  }
}
