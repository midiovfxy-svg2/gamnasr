import { db } from "@/db";
import { fixAvatar } from "@/lib/avatar-guard";
import { users, orgMembers, sessions } from "@/db/schema";
import { uid, now, pub, newToken, setAuthCookie, json, getSessionUser, getCurrentToken } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// سازگار با server.cjs نسخه اصلی + پشتیبانی از org
export async function POST(req: Request) {
  await ensureSeed();
  const current = await getSessionUser();
  if (current) return setAuthCookie(json({ ...pub(current), serverToken: await getCurrentToken() }), await getCurrentToken());
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const orgId = String(b.org ?? b.orgId ?? "");
  const id = uid("u");
  const row = {
    id, localId: id,
    name: (!b.name || String(b.name).trim() === "میهمان") ? "میهمان " + id.slice(-5) : String(b.name).slice(0, 40),
    avatar: fixAvatar(b.avatar, String(b.name || "میهمان")),
    bio: "", email: "", phone: "",
    provider: "guest",
    googleSub: "", role: "player", orgId,
    xp: 0, coins: 50, cups: 0, streak: 0, wins: 0, played: 0, rating: 1000, weekXp: 0, level: 1,
    interests: Array.isArray(b.interests) ? (b.interests as string[]).slice(0, 20) : [],
    friends: [], isPrivate: false, banned: false, isDemo: false,
    lastSeen: now(), lastDaily: "", createdAt: now(), extra: {},
  };
  const token = newToken();
  const saved = await db.transaction(async (tx) => {
    const [created] = await tx.insert(users).values(row).returning();
    await tx.insert(sessions).values({ token, userId: id, csrf: newToken(), expires: now() + 30 * 86400000 });
    if (orgId) await tx.insert(orgMembers).values({ orgId, userId: id, status: "pending", joinedAt: now() }).onConflictDoNothing();
    return created;
  });
  const res = json({ ...pub(saved), serverToken: token });
  return setAuthCookie(res, token);
}
