import {scrypt,randomBytes,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {pool} from '@/db';
import {getSessionUser,getCurrentToken,createSession,setAuthCookie,json,now,pub,uid} from '@/lib/auth';
import {requireAdmin} from '@/lib/admin';
const derive=promisify(scrypt);
const normalize=(value:unknown)=>String(value||'').trim().toLowerCase().replace(/[۰-۹]/g,d=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
async function hash(password:string){const salt=randomBytes(16).toString('hex');return salt+':'+(await derive(password,salt,64) as Buffer).toString('hex');}
async function verify(password:string,stored:string){const [salt,key]=stored.split(':');if(!salt||!key)return false;const expected=Buffer.from(key,'hex'),actual=await derive(password,salt,64) as Buffer;return expected.length===actual.length&&timingSafeEqual(expected,actual);}
export async function GET(req:Request){
 const url=new URL(req.url),candidate=normalize(url.searchParams.get('username'));
 if(candidate){if(!/^[\p{L}\p{N}_.@+\-]{3,100}$/u.test(candidate))return json({available:false});return json({available:!(await pool.query('SELECT 1 FROM account_logins WHERE identifier=$1',[candidate])).rowCount});}
 const me=await getSessionUser();if(!me)return json({error:'not-authed'},401);

 const identifiers=(await pool.query('SELECT identifier,kind FROM account_logins WHERE user_id=$1',[me.id])).rows;
 return json({user:pub(me),identifiers,hasPassword:!!(await pool.query('SELECT 1 FROM account_passwords WHERE user_id=$1',[me.id])).rowCount,pushEnabled:me.extra?.pushEnabled!==false});
}
export async function POST(req:Request){
 const b=await req.json().catch(()=>null);if(!b)return json({error:'invalid-body'},400);
 const action=String(b.action||'save');
 if(action==='login'){
  const identifier=normalize(b.identifier),password=String(b.password||'');if(password.length>128)return json({error:'اطلاعات ورود درست نیست'},401);
  const account=(await pool.query('SELECT p.* FROM account_passwords p JOIN account_logins l ON l.user_id=p.user_id JOIN users u ON u.id=p.user_id WHERE l.identifier=$1 AND u.banned=false',[identifier])).rows[0];
  if(!account||Number(account.locked_until)>now()||!(await verify(password,account.password_hash))){if(account)await pool.query('UPDATE account_passwords SET failed_attempts=failed_attempts+1,locked_until=CASE WHEN failed_attempts>=4 THEN $2 ELSE locked_until END WHERE user_id=$1',[account.user_id,now()+900000]);await new Promise(r=>setTimeout(r,250));return json({error:'نام کاربری یا رمز درست نیست؛ در صورت فراموشی با مدیر تماس بگیرید.'},401);}
  await pool.query('UPDATE account_passwords SET failed_attempts=0,locked_until=0 WHERE user_id=$1',[account.user_id]);const session=await createSession(account.user_id);return setAuthCookie(json({ok:true,serverToken:session.token}),session.token);
 }
 const me=await getSessionUser();if(!me)return json({error:'not-authed'},401);
 if(action==='admin-reset'){
  if(!(await requireAdmin(req)))return json({error:'forbidden'},403);
  const target=String(b.userId||''),username=normalize(b.username),password=String(b.password||'');
  if(!/^[\p{L}\p{N}_.@+\-]{3,100}$/u.test(username)||password.length<4||password.length>128)return json({error:'نام کاربری و رمز معتبر وارد کنید'},400);
  const c=await pool.connect();try{await c.query('BEGIN');if(!(await c.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[target])).rowCount)throw Error('کاربر پیدا نشد');const existing=(await c.query('SELECT user_id FROM account_logins WHERE identifier=$1',[username])).rows[0];if(existing&&existing.user_id!==target)throw Error('نام کاربری تکراری است');await c.query("INSERT INTO account_logins(identifier,user_id,kind) VALUES($1,$2,'username') ON CONFLICT(identifier) DO NOTHING",[username,target]);await c.query('INSERT INTO account_passwords(user_id,password_hash) VALUES($1,$2) ON CONFLICT(user_id) DO UPDATE SET password_hash=excluded.password_hash,failed_attempts=0,locked_until=0',[target,await hash(password)]);await c.query("UPDATE users SET provider='password',extra=coalesce(extra,'{}'::jsonb)||$2::jsonb WHERE id=$1",[target,JSON.stringify({username})]);await c.query('COMMIT');return json({ok:true,username});}catch(e){await c.query('ROLLBACK');return json({error:e instanceof Error?e.message:'ثبت انجام نشد'},409);}finally{c.release();}
 }
 if(action==='logout'){const token=await getCurrentToken();await pool.query('DELETE FROM sessions WHERE token=$1',[token]);const response=json({ok:true});for(const key of ['gtok','gm_session'])response.cookies.set(key,'',{path:'/',maxAge:0});return response;}
 if(action==='push'){await pool.query("UPDATE users SET extra=coalesce(extra,'{}'::jsonb)||$2::jsonb WHERE id=$1",[me.id,JSON.stringify({pushEnabled:b.enabled===true})]);if(b.enabled!==true)await pool.query('DELETE FROM push_subs WHERE user_id=$1',[me.id]);return json({ok:true});}
 const administrator=action==='admin-save'?await requireAdmin(req):null;
 if(action==='admin-save'&&!administrator)return json({error:'forbidden'},403);
 const userId=administrator?String(b.userId||''):me.id,password=String(b.password||''),username=normalize(b.username),email=normalize(b.email),phone=normalize(b.phone),name=String(b.name||'').trim().slice(0,40);
 if(!/^[\p{L}\p{N}_.@+\-]{3,100}$/u.test(username)||password.length<4||password.length>128)return json({error:'نام کاربری حداقل ۳ و رمز حداقل ۴ نویسه باشد'},400);
 if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return json({error:'ایمیل معتبر نیست'},400);
 if(phone&&!/^\+?\d{8,15}$/.test(phone))return json({error:'موبایل معتبر نیست'},400);
 const client=await pool.connect();
 try{
  await client.query('BEGIN');const user=(await client.query('SELECT * FROM users WHERE id=$1 FOR UPDATE',[userId])).rows[0];if(!user)throw Error('کاربر پیدا نشد');
  const old=(await client.query('SELECT password_hash FROM account_passwords WHERE user_id=$1',[userId])).rows[0];
  if(old&&!administrator&&!(await verify(String(b.currentPassword||''),old.password_hash)))throw Error('برای تغییر حساب، رمز فعلی را وارد کنید');
  const identifiers=[{kind:'username',value:username},{kind:'email',value:email},{kind:'phone',value:phone}].filter(x=>x.value);
  for(const item of identifiers){if((await client.query('SELECT 1 FROM account_logins WHERE identifier=$1 AND user_id<>$2',[item.value,userId])).rowCount)throw Error('این نام کاربری، ایمیل یا موبایل قبلاً ثبت شده است');}
  if((email||phone)&&(await client.query("SELECT 1 FROM users WHERE id<>$1 AND (($2<>'' AND lower(email)=$2) OR ($3<>'' AND phone=$3)) LIMIT 1",[userId,email,phone])).rowCount)throw Error('اطلاعات تماس متعلق به حساب دیگری است؛ با مدیر تماس بگیرید');
  const reward=!!(email||phone)&&user.extra?.contactReward!==true?50:0;
  await client.query('DELETE FROM account_logins WHERE user_id=$1',[userId]);const inserted=new Set<string>();for(const item of identifiers){if(inserted.has(item.value))continue;await client.query('INSERT INTO account_logins(identifier,user_id,kind) VALUES($1,$2,$3)',[item.value,userId,item.kind]);inserted.add(item.value);}
  await client.query('INSERT INTO account_passwords(user_id,password_hash) VALUES($1,$2) ON CONFLICT(user_id) DO UPDATE SET password_hash=excluded.password_hash,failed_attempts=0,locked_until=0',[userId,await hash(password)]);
  await client.query("UPDATE users SET name=$2,email=$3,phone=$4,provider='password',coins=coalesce(coins,0)+$5,extra=coalesce(extra,'{}'::jsonb)||$6::jsonb WHERE id=$1",[userId,name||user.name,email,phone,reward,JSON.stringify({contactReward:reward>0||user.extra?.contactReward===true})]);
  if(reward)await client.query('INSERT INTO coin_ledger(id,user_id,delta,reason,ref,note,created_at) VALUES($1,$2,50,$3,$4,$5,$6)',[uid('cl'),userId,'contact','account','contact registration',now()]);
  await client.query('COMMIT');return json({ok:true,reward});
 }catch(e){await client.query('ROLLBACK');return json({error:e instanceof Error?e.message:'ثبت حساب انجام نشد'},409);}finally{client.release();}
}
