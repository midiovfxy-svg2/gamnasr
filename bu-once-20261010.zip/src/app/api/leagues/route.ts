import { listCompetitions, createCompetition } from "@/lib/competitions";
export const dynamic = "force-dynamic";
export function GET() { return listCompetitions("league"); }
export function POST(req: Request) { return createCompetition(req, "league"); }
