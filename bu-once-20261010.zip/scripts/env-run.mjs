import { readFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { parse } from 'dotenv';
const [file, command, ...args] = process.argv.slice(2);
if (!file || !command) throw new Error('Usage: env-run.mjs ENV_FILE COMMAND [ARGS]');
const child = spawn(command, args, { stdio: 'inherit', env: { ...process.env, ...parse(readFileSync(file)), ALLOW_DEMO_SEED: 'false', NEXT_TELEMETRY_DISABLED: '1' } });
child.on('error', e => { console.error(e.message); process.exitCode = 1; });
child.on('exit', code => { process.exitCode = code ?? 1; });
for (const signal of ['SIGTERM','SIGINT']) process.on(signal, () => child.kill(signal));
