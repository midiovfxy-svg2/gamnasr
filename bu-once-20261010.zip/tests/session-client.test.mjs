import test from 'node:test';
import assert from 'node:assert/strict';
import { createSessionClient } from '../src/lib/session-client.ts';

test('concurrent guest requests share one creation and retain the server identity', async () => {
  const requests = [];
  const client = createSessionClient(async path => {
    requests.push(path);
    return path === '/api/me' ? new Response('{}', {status:401}) : Response.json({id:'server-1',name:'Guest'});
  });
  const results = await Promise.all([client.ensure(),client.ensure(),client.ensure()]);
  assert.deepEqual(requests,['/api/me','/api/auth/guest']);
  assert.ok(results.every(p=>p.id==='server-1'));
  await client.ensure();
  assert.equal(requests.length,2);
});
test('existing server accounts are reused', async () => {
  const client = createSessionClient(async (path,init) => {
    assert.equal(path,'/api/me');
    assert.equal(init.headers['x-gamify-token'],'existing');
    return Response.json({id:'member'});
  },()=> 'existing');
  assert.equal((await client.ensure()).id,'member');
});
test('database failures do not create guest accounts and can be retried', async () => {
  let calls=0;
  const client=createSessionClient(async path=>{
    assert.equal(path,'/api/me');
    return ++calls===1?new Response('{}',{status:503}):Response.json({id:'recovered'});
  });
  await assert.rejects(client.ensure(),/503/);
  assert.equal((await client.ensure()).id,'recovered');
});
