import test from 'node:test';
import assert from 'node:assert/strict';
import {storyIsActive,partitionStories,STORY_LIFETIME_MS,STORY_DURATION_MS} from '../src/lib/story-policy.ts';
const now=1800000000000;
test('exact 24-hour cutoff applies even with a later stored expiry',()=>{
  assert.equal(storyIsActive({createdAt:now-STORY_LIFETIME_MS,expiresAt:now+999999},now),false);
  assert.equal(storyIsActive({createdAt:now-STORY_LIFETIME_MS+1,expiresAt:now+999999},now),true);
  assert.equal(storyIsActive({createdAt:now-100,expiresAt:now},now),false);
  assert.equal(storyIsActive({createdAt:now+1,expiresAt:now+999},now),false);
});
test('main contains ten unseen stories; more retains remaining unseen and viewed only while active',()=>{
  const rows=Array.from({length:14},(_,i)=>({id:i,createdAt:now-i*1000,expiresAt:now+10000,seen:i>=12}));
  rows.push({id:99,createdAt:now-STORY_LIFETIME_MS,expiresAt:now+10000,seen:false});
  const p=partitionStories(rows,now);
  assert.equal(p.main.length,10);
  assert.deepEqual(p.more.map(x=>x.id),[10,11,12,13]);
  assert.ok(p.main.every(x=>!x.seen));
});
test('duration is seven seconds and a viewed story moves to more on revisit',()=>{
  assert.equal(STORY_DURATION_MS,7000);
  const p=partitionStories([{createdAt:now,expiresAt:now+10000,seen:true}],now);
  assert.equal(p.main.length,0);assert.equal(p.more.length,1);
});
