import test from 'node:test';import assert from 'node:assert/strict';
import {pointsFor,choiceIsValid,answeredInTime} from '../src/lib/quiz-rules.ts';
test('wrong answers never award points',()=>assert.equal(pointsFor(false,0,25,20),0));
test('timing uses server deadline',()=>{assert.equal(answeredInTime(26001,1000,25),false);assert.equal(answeredInTime(999,1000,25),false);assert.equal(answeredInTime(26000,1000,25),true);});
test('invalid client choices rejected',()=>{for(const v of [-2,4,1.5,'1',null])assert.equal(choiceIsValid(v),false);assert.equal(choiceIsValid(-1),true);});
